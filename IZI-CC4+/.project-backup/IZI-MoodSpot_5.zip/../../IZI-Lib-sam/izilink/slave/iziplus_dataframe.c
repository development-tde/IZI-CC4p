/*
 * iziplus_dataframe.c
 *
 *  Created on: 22 apr. 2021
 *      Author: Milo
 */
#include "includes.h"
#include "iziplus_dataframe.h"
#include "iziplus_networkframe.h"
#include "appconfig.h"
#include "crc.h"
//#include "rtctime.h"
#include "dcbm1_driver.h"

// Defines
#define TASK_PLUS_RX_STACK_SIZE (1024 / sizeof(portSTACK_TYPE))
#define TASK_PLUS_RX_TASK_PRIORITY (tskIDLE_PRIORITY + 5)
#ifndef IZIPLUS_RX_FRAME_BFR_MAX
#define	IZIPLUS_RX_FRAME_BFR_MAX	4
#endif
#define BAD_COMQUALITY_LIMIT		35			// Percentage where com warning is given...

// Globals
trace_level_t iziplus_trace_lvl = IZI_DFLT_TRACE_LVL;

static SemaphoreHandle_t xiziplus_data_RxCmdSemaphore = NULL;
static TaskHandle_t		xiziplus_data_RxTask;

static volatile uint8_t iziplus_next_rx_idx = 0;

static iziplus_data_frame_t iziplus_rx_frame[IZIPLUS_RX_FRAME_BFR_MAX];
static volatile uint8_t iziplus_rx_frame_sel = 0;
static TickType_t iziplus_rx_time[IZIPLUS_RX_FRAME_BFR_MAX];
static uint8_t iziplus_rx_overflow = 0;

static volatile uint16_t iziplus_rx_frame_idx;
static volatile bool iziplus_rx_start_detect = false;
static volatile bool iziplus_rx_cmd_detect = false;
static volatile uint8_t iziplus_escape_esc = false;
uint16_t volatile iziplus_device_type = 0;

TickType_t last_send_ticks = 0;

static uint8_t iziplus_dataframe[IZIPLUS_MAX_DATAFRAME_DATA+32];

// Proto
static void iziplus_data_RxTask(void *p);
#ifdef IZIPLUS_DATAFRAME_ONLY_RXINT
void iziplus_data_Dcbm1Rx(uint8_t data);
#else
void iziplus_data_Dcbm1Rx(uint8_t data, bool interrupt);
#endif
void iziplus_data_Dcbm1TxReady();
void iziplus_data_handle_rx(iziplus_data_frame_t *frame);
uint16_t iziplus_dataframe_sendrsp(uint32_t panid, uint16_t devtype, uint8_t *data, uint16_t length, uint8_t *frame);

void iziplus_dataframe_init(uint16_t device_type)
{
	iziplus_device_type = device_type;
	if(xiziplus_data_RxCmdSemaphore == NULL)
		xiziplus_data_RxCmdSemaphore = xSemaphoreCreateBinary();
	
	dcbm1_set_rx_callback(iziplus_data_Dcbm1Rx);
	
	if(xiziplus_data_RxTask == NULL)
	{
		if (xTaskCreate(iziplus_data_RxTask, "IziPlusRx", TASK_PLUS_RX_STACK_SIZE, NULL, TASK_PLUS_RX_TASK_PRIORITY, &xiziplus_data_RxTask) != pdPASS) {
			while (1) {
				;
			}
		}
	}
}

static iziplus_cb_func_rxptr iziplus_cb_func_rx = NULL;
void iziplus_dataframe_set_rx_callback(iziplus_cb_func_rxptr ptr)
{
	iziplus_cb_func_rx = ptr;
}

static iziplus_cb_func_rxidleptr iziplus_cb_func_rxidle = NULL;
void iziplus_dataframe_set_rxidle_callback(iziplus_cb_func_rxidleptr ptr)
{
	iziplus_cb_func_rxidle = ptr;
}

extern boot_t boot_data;

/************************************************************************/
/* Rx handler task														        */
/************************************************************************/
static void iziplus_data_RxTask(void *p)
{
	while(true)
	{
		if(xSemaphoreTake(xiziplus_data_RxCmdSemaphore, 1000))
		{
			uint8_t idx = iziplus_next_rx_idx;									// Used to handle in correct order
			for(int i = 0; i < IZIPLUS_RX_FRAME_BFR_MAX; i++)
			{
				if(iziplus_rx_time[idx] > 0)
				{
					iziplus_data_frame_t *frame = &iziplus_rx_frame[idx];
					if(iziplus_dataframe_checkcrc(frame))
					{
						if(frame->lengthdir.u.length >= sizeof(iziplus_network_data_t) && frame->lengthdir.u.direction == dir_masterslave)
						{
							iziplus_data_handle_rx(frame);				// Handle command if CRC OK
							IZIPLUS_TRACE_DEBUG("Rec frame[%d]: OK -> Module: %08x, Cmd: %02x\r\n", idx, frame->destination, frame->data[2]);
						}
						else
							IZIPLUS_TRACE_DEBUG("Rec frame[%d]: No data -> Module: %08x, Cmd: %02x\r\n\r\n", idx, frame->destination, frame->data[2]);
					}
					else
						IZIPLUS_TRACE_DEBUG("Rec frame[%d]: Err -> Module: %08x, Cmd: %02x\r\n", idx, frame->destination, frame->data[2]);

					iziplus_rx_time[idx] = 0;			// Set handled
					iziplus_next_rx_idx = idx;
					if(++iziplus_next_rx_idx >= IZIPLUS_RX_FRAME_BFR_MAX)
						iziplus_next_rx_idx = 0;
				}
				if(++idx >= IZIPLUS_RX_FRAME_BFR_MAX)
					idx = 0;
			}
		}
		boot_data.last_code = 'J';
		if(iziplus_rx_overflow > 0)
		{
			IZIPLUS_TRACE_INFO("Rx overflow: %d\r\n", iziplus_rx_overflow);
			iziplus_rx_overflow = 0;
		}
		if(iziplus_cb_func_rxidle != NULL)
			iziplus_cb_func_rxidle();

#if defined(REPORT_STACK) && defined(TASK_IZIDATA)
		REPORT_STACK(TASK_PLUS_RX_STACK_SIZE, TASK_IZIDATA);
#endif
		boot_data.last_code = 'K';
	}
}

bool iziplus_data_quality_first = true;
uint8_t iziplus_data_quality = 255;
uint8_t iziplus_data_last_seq = 0;
uint16_t iziplus_data_last_cnt = 0;

uint8_t iziplus_data_comquality()
{
	return iziplus_data_quality;
}

void iziplus_data_handle_rx(iziplus_data_frame_t *frame)
{
	bool handled = true;
	iziplus_network_data_t *nw_data = ((iziplus_network_data_t *)frame->data);
	if((((frame->pan_id == IZIPLUS_PANID_WILDCARD) || (frame->pan_id == appConfig->pan_id))) &&										// Only accept broadcast and unicast
		(nw_data->msgtype.u.frame_type != IZIPLUS_FRAMETYPE_RSP) && (nw_data->msgtype.u.frame_type != IZIPLUS_FRAMETYPE_DLY))		// Messages to a slave can never be a response or delayed response (can only be from other slave)
		
	{
		if((frame->device_type == IZIPLUS_DEVTYPE_BROADCAST) || (((frame->device_type & IZIPLUS_DEVTYPE_GROUPCAST_MASK) == (iziplus_device_type & 0xFFE0)) && (frame->destination == PRODUCTION_SERIAL || frame->destination == 0 || nw_data->msgtype.u.frame_type == IZIPLUS_FRAMETYPE_REQ_MULTI)))
			handled = false;			// If it is for us, mark as not handled, so application will check content
		
		if(nw_data->seqid < iziplus_data_last_seq)		// Roll over
		{
			if(!iziplus_data_quality_first)
			{
				iziplus_data_quality = (uint8_t)((iziplus_data_last_cnt * 100)/256);
				if(iziplus_data_quality < BAD_COMQUALITY_LIMIT && (xTaskGetTickCount() > 20000))			// Only report bad com quality 20 sec after power-up (make sure sequence nr has made a loop)
					State_SetWarning(STATE_WARNING_BAD_COMQUAL);
				else
					State_ClearWarning(STATE_WARNING_BAD_COMQUAL);
			}
			else
				iziplus_data_quality_first = false;
			iziplus_data_last_cnt = 1;	
		}
		else
			iziplus_data_last_cnt++;
			
		iziplus_data_last_seq = nw_data->seqid;
	}
	if(nw_data->msgtype.u.frame_type == IZIPLUS_FRAMETYPE_REQ_MULTI)		// Check destination to see if it is a request or notification
	{
		if(frame->destination == PRODUCTION_SERIAL)
			nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_REQ;
		else
			nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_NOT;
	}
	if(iziplus_cb_func_rx != NULL)
		iziplus_cb_func_rx(frame, handled);
}

extern volatile uint16_t com_disbale;
uint16_t iziplus_dataframe_response(uint32_t panid, uint16_t devtype, uint8_t *data, uint16_t length)
{
	uint16_t len = iziplus_dataframe_sendrsp(panid, devtype, data, length, iziplus_dataframe);
	//uint16_t res = 0;
	//if(com_disbale == 0)
	uint16_t res = dcbm1_send((uint8_t *)iziplus_dataframe, len);
	
	return res == len;
}

uint16_t iziplus_dataframe_sendrsp(uint32_t panid, uint16_t devtype, uint8_t *data, uint16_t length, uint8_t *frame)
{
	if(length > IZIPLUS_MAX_DATAFRAME_DATA)
		return 0;

	uint16_t send_len = IZPLUS_MAX_DATAFRAME_BASE + length;
	iziplus_data_frame_t data_frame;
	data_frame.pan_id = panid;
	data_frame.destination = PRODUCTION_SERIAL;
	data_frame.device_type = devtype;
	data_frame.lengthdir.u.length = length;
	data_frame.lengthdir.u.direction = dir_slavemaster;
	memcpy(data_frame.data, data, length);
	uint16_t crc = Crc16((uint8_t *)&data_frame, send_len - 4, 0x0000) ^ 0xFFFF;			// Crc is without Start word (and crc itself)
	data_frame.data[length] = (uint8_t)(crc >> 8);
	data_frame.data[length + 1] = (uint8_t)crc;

	frame[0] = (uint8_t)(IZIPLUS_START >> 8);
	frame[1] = (uint8_t)(IZIPLUS_START >> 0);

	uint16_t idx = 2;
	bool escape_start = false, escape_esc = false;
	for(int i = 0; i < send_len - 2; i++)
	{
		uint8_t data = ((uint8_t *)&data_frame)[i];
		frame[idx++] = data;
		if(escape_esc && data == 0xDC)
		{
			frame[idx++] = IZIPLUS_ESCAPE_ESC;
			escape_esc = false;
		}
		else if(data == 0xAC)
			escape_esc = true;
		else
			escape_esc = false;

		if(escape_start && data == 0xBA)
		{
			frame[idx-2] = 0xAC;
			frame[idx-1] = 0xDC;
			frame[idx++] = IZIPLUS_ESCAPE_START;
			escape_start = false;
		}
		else if(data == 0xAB)
			escape_start = true;
		else
			escape_start = false;
	}
	return idx;
}

bool iziplus_dataframe_checkcrc(iziplus_data_frame_t *data_frame)
{
	return (Crc16((uint8_t *)data_frame, data_frame->lengthdir.u.length + IZPLUS_MAX_DATAFRAME_NOSTART, 0x0000) ^ 0xFFFF) == 0;

}

#ifdef IZIPLUS_DATAFRAME_ONLY_RXINT
void iziplus_data_Dcbm1Rx(uint8_t data)
#else
void iziplus_data_Dcbm1Rx(uint8_t data, bool interrupt)
#endif
{
	bool skip = false;
	if(!iziplus_rx_start_detect && data == 0xAB)
		iziplus_rx_start_detect = true;
	else if(iziplus_rx_start_detect)
	{
		if(data == 0xBA)
		{
			iziplus_rx_frame_idx = 0;
			iziplus_rx_start_detect = false;
			iziplus_rx_cmd_detect = true;
			iziplus_escape_esc = 0;
			skip = true;
		}
		else
			iziplus_rx_start_detect = false;
	}
	if(!skip && iziplus_rx_cmd_detect && iziplus_rx_frame_idx < sizeof(iziplus_data_frame_t))
	{
		uint8_t *bfr = (uint8_t *)&iziplus_rx_frame[iziplus_rx_frame_sel];

		if(iziplus_escape_esc == 2)
		{
			//if(data == IZIPLUS_ESCAPE_ESC)
			//	return;								// Skip handling of this byte, escape means 0xACDC was meant to be
			if(data == IZIPLUS_ESCAPE_START)
			{
				bfr[iziplus_rx_frame_idx - 1] = 0xBA;
				bfr[iziplus_rx_frame_idx - 2] = 0xAB;		// Replace by 0xABBA
			}
			iziplus_escape_esc = 0;
			return;
		}
		else if(iziplus_escape_esc == 1 && data == 0xDC)
			iziplus_escape_esc = 2;
		else if(iziplus_escape_esc == 0 && data == 0xAC)
			iziplus_escape_esc = 1;
		else
			iziplus_escape_esc = 0;

		bfr[iziplus_rx_frame_idx++] = data;
		if(iziplus_rx_frame_idx == IZPLUS_MAX_DATAFRAME_NOSTART)		// Minimum amount for datalayer is received?
		{
			uint16_t length = iziplus_rx_frame[iziplus_rx_frame_sel].lengthdir.u.length;
			if(length > IZIPLUS_MAX_DATAFRAME_DATA)
			{
				iziplus_rx_cmd_detect = false;							// Dump, incorrect length
				return;
			}
		}
		if(iziplus_rx_frame_idx >= IZPLUS_MAX_DATAFRAME_NOSTART)
		{
			uint16_t length = iziplus_rx_frame[iziplus_rx_frame_sel].lengthdir.u.length;
			if((iziplus_rx_frame_idx - IZPLUS_MAX_DATAFRAME_NOSTART) >= length)
			{
				iziplus_rx_start_detect = 0;
				iziplus_rx_frame_idx = 0;
				iziplus_rx_cmd_detect = false;
				if(iziplus_rx_time[iziplus_rx_frame_sel] > 0)
					iziplus_rx_overflow++;
#ifdef IZIPLUS_DATAFRAME_ONLY_RXINT					
				iziplus_rx_time[iziplus_rx_frame_sel] = xTaskGetTickCountFromISR();
#else	
				iziplus_rx_time[iziplus_rx_frame_sel] = interrupt ? xTaskGetTickCountFromISR() : xTaskGetTickCount();				
#endif				
				if(iziplus_rx_time[iziplus_rx_frame_sel] == 0)
					iziplus_rx_time[iziplus_rx_frame_sel] += 1;		// 0 means empty
				if(++iziplus_rx_frame_sel >= IZIPLUS_RX_FRAME_BFR_MAX)
					iziplus_rx_frame_sel = 0;

#ifndef IZIPLUS_DATAFRAME_ONLY_RXINT
				if(interrupt)
				{
#endif					
					xSemaphoreGiveFromISR(xiziplus_data_RxCmdSemaphore, NULL);
					portEND_SWITCHING_ISR(true);			// Make sure the semaphore is directly handled (iso the next tick)
#ifndef IZIPLUS_DATAFRAME_ONLY_RXINT
				}
				else
				{
					xSemaphoreGive(xiziplus_data_RxCmdSemaphore);
				}
#endif				
			}
		}
	}
}



