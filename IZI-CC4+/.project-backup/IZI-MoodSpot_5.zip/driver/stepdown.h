/*
 * stepdown.h
 *
 * Created: 3-3-2022 13:39:44
 *  Author: Milo
 */ 


#ifndef STEPDOWN_H_
#define STEPDOWN_H_

#define PORT_EVCTRL_EVACT1_OUT      (PORT_EVCTRL_EVACT0_OUT_Val    << PORT_EVCTRL_EVACT1_Pos)
#define PORT_EVCTRL_EVACT1_SET      (PORT_EVCTRL_EVACT0_SET_Val    << PORT_EVCTRL_EVACT1_Pos)
#define PORT_EVCTRL_EVACT1_CLR      (PORT_EVCTRL_EVACT0_CLR_Val    << PORT_EVCTRL_EVACT1_Pos)
#define PORT_EVCTRL_EVACT1_TGL      (PORT_EVCTRL_EVACT0_TGL_Val    << PORT_EVCTRL_EVACT1_Pos)

#define PORT_EVCTRL_EVACT2_OUT      (PORT_EVCTRL_EVACT0_OUT_Val    << PORT_EVCTRL_EVACT2_Pos)
#define PORT_EVCTRL_EVACT2_SET      (PORT_EVCTRL_EVACT0_SET_Val    << PORT_EVCTRL_EVACT2_Pos)
#define PORT_EVCTRL_EVACT2_CLR      (PORT_EVCTRL_EVACT0_CLR_Val    << PORT_EVCTRL_EVACT2_Pos)
#define PORT_EVCTRL_EVACT2_TGL      (PORT_EVCTRL_EVACT0_TGL_Val    << PORT_EVCTRL_EVACT2_Pos)

#define PORT_EVCTRL_EVACT3_OUT      (PORT_EVCTRL_EVACT0_OUT_Val    << PORT_EVCTRL_EVACT3_Pos)
#define PORT_EVCTRL_EVACT3_SET      (PORT_EVCTRL_EVACT0_SET_Val    << PORT_EVCTRL_EVACT3_Pos)
#define PORT_EVCTRL_EVACT3_CLR      (PORT_EVCTRL_EVACT0_CLR_Val    << PORT_EVCTRL_EVACT3_Pos)
#define PORT_EVCTRL_EVACT3_TGL      (PORT_EVCTRL_EVACT0_TGL_Val    << PORT_EVCTRL_EVACT3_Pos)

#define MAX_TABLE		64

typedef uint16_t (*stepdown_control_vled_func)(void);
typedef bool (*stepdown_control_issafetyoff_func)(void);
typedef uint16_t (*stepdown_control_temp_func)(uint16_t);
typedef void (*stepdown_control_setcurrent_func)(uint16_t);
typedef void (*stepdown_control_channelenable_func)(bool);

struct stepdown_control_s {
	int32_t level_filter;
	int32_t level_curve;
	int32_t freq_new;
	int32_t freq_shifted;
	uint32_t period;
	uint32_t div;
	int32_t pwm_new;
	int32_t pwm_prev;
	int32_t freq_prev;
	uint16_t level;
	uint16_t channel;
	stepdown_control_vled_func vled_func;
	stepdown_control_vled_func vled_raw_func;
	stepdown_control_setcurrent_func set_current;
	stepdown_control_temp_func temp_limit;
	stepdown_control_issafetyoff_func issafety_off;
	stepdown_control_channelenable_func channel_enable;
	volatile uint16_t stepdown_offtime;
	uint16_t mA;
	uint32_t freq_shift_max_filter;
	uint16_t vled_ad;		// Value where mA calc is done with
	uint16_t vled_max;		// Max since start
	uint16_t toff;
	uint8_t no_change_cnt;
	uint8_t show_level;
	uint32_t comp_lvl;
	uint16_t pwm_filter;
	uint16_t dac_data;
	uint16_t dac_data_org;
	uint16_t vin_ad;
	uint16_t sc_error_prs;
	uint16_t oc_warning_prs;
	int16_t pwm_offset;
	uint16_t vled_max_session;	// Max Vled since off (when at least 50%)
	uint16_t vled_max_session_prs;	// Max Vled since off (when at least 50%)
	uint16_t vled_max_store_mv;	// Max Vled since off (when at least 50%), used to check if to be stored (only done when both channels are off)
	uint8_t filter_fast_time;
	uint8_t filter_fast_speed;
	uint16_t dac_data_real;
	uint8_t data_dir;
	uint8_t force_calibration;
	int32_t level_curve_raw;
	uint16_t freq_max;
	bool update_timer;
	uint8_t cnt;
	int per[MAX_TABLE];
	int cc0[MAX_TABLE];
	int ccx[MAX_TABLE];
	uint16_t toff_min;
	uint8_t is_16b;
	uint8_t fe;
	uint32_t tcc_freq;
} __attribute__((packed));

typedef struct stepdown_control_s stepdown_control_t;

// Proto
void StepDown_Init();
void StepDown_Close(uint16_t time);
bool StepDown_IsClosed();
void StepDown_Debug(uint8_t* par1, uint16_t length);
void StepDown_Module_Update();
void Stepdown_SetCurrentCh1(uint16_t mA);
void Stepdown_SetCurrentCh2(uint16_t mA);
void Stepdown_SetCurrentCh3(uint16_t mA);
void Stepdown_SetCurrentCh4(uint16_t mA);
uint8_t StepDown_DebugLevel();
void StepDown_GetPower(uint16_t *ch1, uint16_t *ch2);
void StepDown_ForceCalibration();
bool StepDown_SleepCheck();
void StepDown_GetFrequency(uint16_t *ch1, uint16_t *ch2);
void StepDown_ChannelEnable_Ch1(bool start);
void StepDown_ChannelEnable_Ch2(bool start);
void StepDown_ChannelEnable_Ch3(bool start);
void StepDown_ChannelEnable_Ch4(bool start);

#endif /* STEPDOWN_H_ */