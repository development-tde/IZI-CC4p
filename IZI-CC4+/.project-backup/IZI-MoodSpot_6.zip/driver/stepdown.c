/*
 * stepdown.c
 *
 * Created: 3-3-2022 13:39:31
 *  Author: Milo
 */ 

#include "includes.h"
#include "stepdown.h"
#include "timer_def.h"
#include "izi_output.h"
#include "curve.h"
//#include "adc.h"
#include "appconfig.h"
#include "iziplus_module_def.h"
#include "limits.h"
#include "mcp4725.h"

#define TASK_STEPDOWN_STACK_SIZE (2048 / sizeof(portSTACK_TYPE))
#define TASK_STEPDOWN_TASK_PRIORITY (tskIDLE_PRIORITY + 6)

#define STEPDOWN_FREQ			100000	//0				// 100kHz
#define STEPDOWN_TICK_US		(1000000 / STEPDOWN_FREQ)	// 10us
#define STEPDOWN_OFF_TIME		0.000001				// 1us	(If changed, check STEPDOWN_SAFETY_TIME, STEPDOWN_OFF_TIME should be +/- 85% of STEPDOWN_SAFETY_TIME
#define STEPDOWN_SAFETY_TIME	0.0000066				// 8us	(when AC does not trigger, safety off)

#define PWM_START_LEVEL_MAX		5						// Start of frequency increase
#define PWM_LVL_OC_DETECT		32						// PWM level where open circuit is checked by vled (should be smaller than VLED_SC_ERROR_DBC)
#define PWM_START_LEVEL_FREQ	(72)					// Level for start of frequency increase start
#define PWM_LVL_SHORT_DETECT	250						// Filter Level value from where short circuit will be checked		
#define PWM_START_FREQ			500UL					// 500Hz start frequency
#define PWM_END_FREQ			22000UL					// 22000Hz end/highest frequency
#define PWM_FREQ				PWM_START_FREQ	

#define DAC_MIN					234						// Minimum DAC value for OK measurement

#define VIN_WARNING_DBC			4						// Debounce for vin warning (per 8 ms)
#define VLED_OC_WARNING_DBC		4						// Debounce for open circuit warning (per 8 ms)
#define VLED_SC_ERROR_DBC		40						// Debounce for short circuit error (per 8 ms) (should be larger than PWM_LVL_OC_DETECT)

#define SAFETY_OFF_OPEN_MS		1000					// 1 sec off when open output detected
#define SAFETY_OFF_SHORT_MS		5000					// 5 sec off when short on output detected

#define VLED_MIN_MV				12000					// Min Led voltage supported
#define VLED_MAX_MV				40500					// Max Led voltage supported

#define BLANKING_TIME			2						// Time in STEPDOWN_TIMEROS_TICKS = 8ms * (2 - 1) = 8ms and a bit to blank short detection

#ifndef _NVM_SW_CALIB_AREA_BASE
#define _NVM_SW_CALIB_AREA_BASE 0x00800080
#endif

#define STEPDOWN_TIMEROS_TICKS		8					// Amount of ticks for 8 msecond timer

#define MAX_VIN_VLED_DIFF_MV	4000					// Max 4000 mV difference between Vin and Vled for proper outcome of calculation
#define MIN_VLED_MV				3000					// Minimal Vled voltage (also used for short detection)
#define MIN_VIN_MV				30000					// Stop operation if vin lower than 30V
#define MAX_VIN_MV				53000					// High vin detected


// Change numbers for other timer TCCx used for channel 1 (x is 0 to 2). WARNING ONLY TCC0 and TCC1 are 24-bit (others are 16-bit). This means 16-bit timers (running @ 120MHz, only support 120MHz/65535= 1831Hz not lower!!!
#define TCCX_IRQ_OVF_EN_CH1			TCCX_IRQ_OVF_DEF(0)
#define TCCX_TIMER_EN_CH1			TCCX_DEF(0)
#define TCCX_GCLK_ID_EN_CH1			TCCX_GCLK_ID(0)
#define TCCX_EVSYS_ID_OVF_EN_CH1	TCCX_EVSYS_ID_GEN_OVF(0)
#define TCCX_EVSYS_ID_USER_EV0_CH1	EVSYS_ID_USER_TCC0_EV_0
#define TCCX_EVSYS_ID_USER_EV1_CH1	EVSYS_ID_USER_TCC0_EV_1
#define TCCX_APBXMASK_EN_CH1		((Mclk *)MCLK)->APBBMASK.bit.TCC0_
#define TCCX_INTO_HANDLER_EN_CH1	TCCX_INT_OVF_HANDLER(0)
#define TCCX_INTC_HANDLER_EN_CH1	TCCX_INT_MCMP0_HANDLER(0)		// CHECK EN WO when changed!!!!
#define TCCX_INTC_INTENSET_CH1		TCC_INTENSET_OVF// TCC_INTENSET_MC2				// CHECK EN WO when changed!!!!
#define TCCX_DRVCTRL_INV_CH1		TCC_DRVCTRL_INVEN1				// CHECK EN WO when changed!!!!
#define TCCX_CLOCK_FREQ_EN_CH1		(GCLK_GEN3_FREQ)				// If changed, check clock settings in code

// Change numbers for other timer TCCx used for channel 2 (x is 0 to 2). WARNING ONLY TCC0 and TCC1 are 24-bit (others are 16-bit). This means 16-bit timers (running @ 120MHz, only support 120MHz/65535= 1831Hz not lower!!!
#define TCCX_IRQ_OVF_EN_CH2			TCCX_IRQ_OVF_DEF(1)
#define TCCX_TIMER_EN_CH2			TCCX_DEF(1)
#define TCCX_GCLK_ID_EN_CH2			TCCX_GCLK_ID(1)
#define TCCX_EVSYS_ID_OVF_EN_CH2	TCCX_EVSYS_ID_GEN_OVF(1)
#define TCCX_EVSYS_ID_USER_EV0_CH2	EVSYS_ID_USER_TCC1_EV_0
#define TCCX_EVSYS_ID_USER_EV1_CH2	EVSYS_ID_USER_TCC1_EV_1
#define TCCX_APBXMASK_EN_CH2		((Mclk *)MCLK)->APBBMASK.bit.TCC1_
#define TCCX_INTO_HANDLER_EN_CH2	TCCX_INT_OVF_HANDLER(1)
#define TCCX_INTC_HANDLER_EN_CH2	TCCX_INT_MCMP2_HANDLER(1)		// CHECK EN WO when changed!!!!
#define TCCX_INTC_INTENSET_CH2		TCC_INTENSET_OVF				// CHECK EN WO when changed!!!!
#define TCCX_DRVCTRL_INV_CH2		TCC_DRVCTRL_INVEN3				// CHECK EN WO when changed!!!!
#define TCCX_CLOCK_FREQ_EN_CH2		(GCLK_GEN3_FREQ)				// If changed, check clock settings in code

// Change numbers for other timer TCCx used for channel 3 (x is 0 to 2). WARNING ONLY TCC0 and TCC1 are 24-bit (others are 16-bit). This means 16-bit timers (running @ 120MHz, only support 120MHz/65535= 1831Hz not lower!!!
#define TCCX_IRQ_OVF_EN_CH3			TCCX_IRQ_OVF_DEF(2)
#define TCCX_TIMER_EN_CH3			TCCX_DEF(2)
#define TCCX_GCLK_ID_EN_CH3			TCCX_GCLK_ID(2)
#define TCCX_EVSYS_ID_OVF_EN_CH3	TCCX_EVSYS_ID_GEN_OVF(2)
#define TCCX_EVSYS_ID_USER_EV0_CH3	EVSYS_ID_USER_TCC2_EV_0
#define TCCX_EVSYS_ID_USER_EV1_CH3	EVSYS_ID_USER_TCC2_EV_1
#define TCCX_APBXMASK_EN_CH3		((Mclk *)MCLK)->APBCMASK.bit.TCC2_
#define TCCX_INTO_HANDLER_EN_CH3	TCCX_INT_OVF_HANDLER(2)
#define TCCX_INTC_HANDLER_EN_CH3	TCCX_INT_MCMP2_HANDLER(2)		// CHECK EN WO when changed!!!!
#define TCCX_INTC_INTENSET_CH3		TCC_INTENSET_OVF				// CHECK EN WO when changed!!!!
#define TCCX_DRVCTRL_INV_CH3		TCC_DRVCTRL_INVEN2				// CHECK EN WO when changed!!!!
#define TCCX_CLOCK_FREQ_EN_CH3		(GCLK_GEN3_FREQ/4)				// If changed, check clock settings in code

// Change numbers for other timer TCCx used for channel 4 (x is 0 to 2). WARNING ONLY TCC0 and TCC1 are 24-bit (others are 16-bit). This means 16-bit timers (running @ 120MHz, only support 120MHz/65535= 1831Hz not lower!!!
#define TCCX_IRQ_OVF_EN_CH4			TCCX_IRQ_OVF_DEF(3)
#define TCCX_TIMER_EN_CH4			TCCX_DEF(3)
#define TCCX_GCLK_ID_EN_CH4			TCCX_GCLK_ID(3)
#define TCCX_EVSYS_ID_OVF_EN_CH4	TCCX_EVSYS_ID_GEN_OVF(3)
#define TCCX_EVSYS_ID_USER_EV0_CH4	EVSYS_ID_USER_TCC3_EV_0
#define TCCX_EVSYS_ID_USER_EV1_CH4	EVSYS_ID_USER_TCC3_EV_1
#define TCCX_APBXMASK_EN_CH4		((Mclk *)MCLK)->APBCMASK.bit.TCC3_
#define TCCX_INTO_HANDLER_EN_CH4	TCCX_INT_OVF_HANDLER(3)
#define TCCX_INTC_HANDLER_EN_CH4	TCCX_INT_MCMP0_HANDLER(3)		// CHECK EN WO when changed!!!!
#define TCCX_INTC_INTENSET_CH4		TCC_INTENSET_OVF				// CHECK EN WO when changed!!!!
#define TCCX_DRVCTRL_INV_CH4		TCC_DRVCTRL_INVEN0				// CHECK EN WO when changed!!!!
#define TCCX_CLOCK_FREQ_EN_CH4		(GCLK_GEN3_FREQ/4)				// If changed, check clock settings in code

// Change numbers for other timer TCx used for channel 1 (x is 0 to 3)
#define TCX_IRQ_CH1				TCX_IRQ_DEF(0)
#define TCX_TIMER_CH1			TCX_DEF(0)
#define TCX_GCLK_ID_CH1			TCX_GCLK_ID(0)
#define TCX_EVSYS_ID_OVF_CH1	TCX_EVSYS_ID_GEN_OVF(0)
#define TCX_EVSYS_ID_MCMP_CH1	TCX_EVSYS_ID_GEN_MCMP1(0)
#define TCX_EVSYS_ID_USER_CH1	EVSYS_ID_USER_TC0_EVU
#define TCX_APBXMASK_CH1		((Mclk *)MCLK)->APBAMASK.bit.TC0_
#define TCX_INT_HANDLER_CH1		TCX_INT_HANDLER(0)
#define TCX_CLOCK_FREQ_CH1		(GCLK_GEN3_FREQ)			// If changed, check clock settings in code

// Change numbers for other timer TCx used for channel 2 (x is 0 to 3)
#define TCX_IRQ_CH2				TCX_IRQ_DEF(1)
#define TCX_TIMER_CH2			TCX_DEF(1)
#define TCX_GCLK_ID_CH2			TCX_GCLK_ID(1)
#define TCX_EVSYS_ID_OVF_CH2	TCX_EVSYS_ID_GEN_OVF(1)
#define TCX_EVSYS_ID_MCMP_CH2	TCX_EVSYS_ID_GEN_MCMP1(1)
#define TCX_EVSYS_ID_USER_CH2	EVSYS_ID_USER_TC1_EVU
#define TCX_APBXMASK_CH2		((Mclk *)MCLK)->APBAMASK.bit.TC1_
#define TCX_INT_HANDLER_CH2		TCX_INT_HANDLER(1)
#define TCX_CLOCK_FREQ_CH2		TCX_CLOCK_FREQ_CH1			// If changed, check clock settings in code

// Change numbers for other timer TCx used for channel 2 (x is 0 to 3)
#define TCX_IRQ_CH3				TCX_IRQ_DEF(2)
#define TCX_TIMER_CH3			TCX_DEF(2)
#define TCX_GCLK_ID_CH3			TCX_GCLK_ID(2)
#define TCX_EVSYS_ID_OVF_CH3	TCX_EVSYS_ID_GEN_OVF(2)
#define TCX_EVSYS_ID_MCMP_CH3	TCX_EVSYS_ID_GEN_MCMP1(2)
#define TCX_EVSYS_ID_USER_CH3	EVSYS_ID_USER_TC2_EVU
#define TCX_APBXMASK_CH3		((Mclk *)MCLK)->APBBMASK.bit.TC2_
#define TCX_INT_HANDLER_CH3		TCX_INT_HANDLER(2)
#define TCX_CLOCK_FREQ_CH3		TCX_CLOCK_FREQ_CH1			// If changed, check clock settings in code

// Change numbers for other timer TCx used for channel 2 (x is 0 to 3)
#define TCX_IRQ_CH4				TCX_IRQ_DEF(3)
#define TCX_TIMER_CH4			TCX_DEF(3)
#define TCX_GCLK_ID_CH4			TCX_GCLK_ID(3)
#define TCX_EVSYS_ID_OVF_CH4	TCX_EVSYS_ID_GEN_OVF(3)
#define TCX_EVSYS_ID_MCMP_CH4	TCX_EVSYS_ID_GEN_MCMP1(3)
#define TCX_EVSYS_ID_USER_CH4	EVSYS_ID_USER_TC3_EVU
#define TCX_APBXMASK_CH4		((Mclk *)MCLK)->APBBMASK.bit.TC3_
#define TCX_INT_HANDLER_CH4		TCX_INT_HANDLER(3)
#define TCX_CLOCK_FREQ_CH4		TCX_CLOCK_FREQ_CH1			// If changed, check clock settings in code

// LUT usage
#define CCL_LUT_CH1				 CCL->LUTCTRL[0]
#define CCL_LUT_CH2				 CCL->LUTCTRL[1]
#define CCL_LUT_CH3				 CCL->LUTCTRL[2]
#define CCL_LUT_CH4				 CCL->LUTCTRL[3]

// Event
#define EVSYS_ID_GEN_CH1		EVSYS_ID_GEN_CCL_LUTOUT_0
#define EVSYS_ID_GEN_CH2		EVSYS_ID_GEN_CCL_LUTOUT_1
#define EVSYS_ID_GEN_CH3		EVSYS_ID_GEN_CCL_LUTOUT_2
#define EVSYS_ID_GEN_CH4		EVSYS_ID_GEN_CCL_LUTOUT_3

volatile uint32_t counter = 0, ac_ok = 0;

uint16_t stepdown_current_chx = 0;

static uint8_t			time_after_pup = 0;		// in 10ms

static TaskHandle_t		xStepDown_Task;
static TickType_t		last_log_ticks;

#define ADC_VIN_MAX				56561UL	
#define ADC_RAW_MV(r)			((uint16_t)((r * ADC_VIN_MAX)/4095UL))
#define ADC_MV_RAW(m)			((uint16_t)((m * 4095UL)/ADC_VIN_MAX))

uint16_t Adc_GetVled1Raw()
{
	return ADC_MV_RAW(32000);
}

uint16_t Adc_GetVled1()
{
	return 32000;
}

uint16_t Adc_GetVled2Raw()
{
	return ADC_MV_RAW(32000);
}

uint16_t Adc_GetVled2()
{
	return 32000;
}

uint16_t Adc_GetVled3Raw()
{
	return ADC_MV_RAW(32000);
}

uint16_t Adc_GetVled3()
{
	return 32000;
}

uint16_t Adc_GetVled4Raw()
{
	return ADC_MV_RAW(32000);
}

uint16_t Adc_GetVled4()
{
	return 32000;
}

volatile stepdown_control_t stepdown_ctrl_chx[MAX_DIM_CHANNELS] = 
{
	{
		.channel = 1,
		.vled_func = Adc_GetVled1,
		.vled_raw_func = Adc_GetVled1Raw,
		.set_current = Stepdown_SetCurrentCh1,
		//.temp_limit = IziPlus_Module_TempLimit_Chan1,
		//.issafety_off = IziPlus_Module_IsSafetyOff_Ch1,
		.channel_enable = StepDown_ChannelEnable_Ch1,
		.is_16b = false,
		.tcc_freq = TCCX_CLOCK_FREQ_EN_CH1
	},
	{
		.channel = 2,
		.vled_func = Adc_GetVled2,
		.vled_raw_func = Adc_GetVled2Raw,
		.set_current = Stepdown_SetCurrentCh2,
		//.temp_limit = IziPlus_Module_TempLimit_Chan2,
		//.issafety_off = IziPlus_Module_IsSafetyOff_Ch2,
		.channel_enable = StepDown_ChannelEnable_Ch2,
		.is_16b = false,
		.tcc_freq = TCCX_CLOCK_FREQ_EN_CH2
	},
	{
		.channel = 3,
		.vled_func = Adc_GetVled3,
		.vled_raw_func = Adc_GetVled3Raw,
		.set_current = Stepdown_SetCurrentCh3,
		//.temp_limit = IziPlus_Module_TempLimit_Chan3,
		//.issafety_off = IziPlus_Module_IsSafetyOff_Ch3,
		.channel_enable = StepDown_ChannelEnable_Ch3,
		.is_16b = true,
		.tcc_freq = TCCX_CLOCK_FREQ_EN_CH3
	},
	{
		.channel = 4,
		.vled_func = Adc_GetVled4,
		.vled_raw_func = Adc_GetVled4Raw,
		.set_current = Stepdown_SetCurrentCh4,
		//.temp_limit = IziPlus_Module_TempLimit_Chan3,
		//.issafety_off = IziPlus_Module_IsSafetyOff_Ch4,
		.channel_enable = StepDown_ChannelEnable_Ch4,
		.is_16b = true,
		.tcc_freq = TCCX_CLOCK_FREQ_EN_CH4
	}
};

static uint16_t stepdown_closed = 0;
static uint8_t stepdown_force_update = 0;
static uint8_t stepdown_debug_level = 0;
static uint8_t stepdown_debug_channel = 0;
static uint8_t	stepdown_i2c_warning_time;

static volatile uint8_t stepdown_blank_short = 0;

//static uint16_t stepdown_test = 0;

// Proto
void Stepdown_SetCurrent(uint16_t mA);
void StepDown_StepTimer();
static void StepDown_Task(void *p);
uint16_t StepDown_GetCurrent();

/************************************************************************/
/* Init Timer for channel 1. Timer is used for stepdown off time  xStepDown_Task      */
/************************************************************************/
void StepDown_InitTimer1()
{
	// Timer init (TCx)
	MCLK_CRITICAL_SECTION_ENTER();
	TCX_APBXMASK_CH1 = 1;
	MCLK_CRITICAL_SECTION_LEAVE();

	hri_gclk_write_PCHCTRL_reg(GCLK, TCX_GCLK_ID_CH1, GCLK_PCHCTRL_GEN_GCLK3_Val | (1 << GCLK_PCHCTRL_CHEN_Pos));		// Set to Main clock (Generic clock generator 3) = 120MHz

	TCX_TIMER_CH1->COUNT16.CTRLA.reg = TC_CTRLA_SWRST;
	while ((TCX_TIMER_CH1->COUNT16.SYNCBUSY.reg) & TC_SYNCBUSY_SWRST) {
	};

	TCX_TIMER_CH1->COUNT16.CTRLA.reg = TC_CTRLA_PRESCALER_DIV1 | TC_CTRLA_MODE(TC_CTRLA_MODE_COUNT16_Val);				// 120MHz / 1 = 120MHz
	//TCX_TIMER_CH1->COUNT16.INTENSET.reg = TC_INTENSET_OVF | TC_INTENSET_MC0;									// Overflow will only occur when AC does not trigger (safety)
	TCX_TIMER_CH1->COUNT16.WAVE.reg = 0x03;//TC_WAVE_WAVEGEN_MFRQ;						
	TCX_TIMER_CH1->COUNT16.CCBUF[0].reg = TCX_CLOCK_FREQ_CH1 * STEPDOWN_SAFETY_TIME; 
	//TCX_TIMER_CH1->COUNT16.CCBUF[1].reg = TCX_CLOCK_FREQ_CH1 * STEPDOWN_OFF_TIME;
	TCX_TIMER_CH1->COUNT16.EVCTRL.reg = TC_EVCTRL_OVFEO | TC_EVCTRL_MCEO1 | TC_EVCTRL_TCEI | TC_EVCTRL_EVACT_RETRIGGER;			// Output event on overflow and compare match (MUST BE SET BEFORE ENABLED!!)
	TCX_TIMER_CH1->COUNT16.CTRLBSET.reg = TC_CTRLBSET_ONESHOT;	
	TCX_TIMER_CH1->COUNT16.CTRLA.reg |= TC_CTRLA_ENABLE;	// Use 16-bit

	/*NVIC_DisableIRQ(TCX_IRQ_CH1);
	NVIC_ClearPendingIRQ(TCX_IRQ_CH1);
	NVIC_SetPriority(TCX_IRQ_CH1, 1);					// Prio 0 is highest, 7 is lowest
	NVIC_EnableIRQ(TCX_IRQ_CH1);*/
}

/************************************************************************/
/* Init Timer for channel 2. Timer is used for stepdown off time        */
/************************************************************************/
void StepDown_InitTimer2()
{
	// Timer init (TCx)
	MCLK_CRITICAL_SECTION_ENTER();
	TCX_APBXMASK_CH2 = 1;
	MCLK_CRITICAL_SECTION_LEAVE();

	hri_gclk_write_PCHCTRL_reg(GCLK, TCX_GCLK_ID_CH2, GCLK_PCHCTRL_GEN_GCLK3_Val | (1 << GCLK_PCHCTRL_CHEN_Pos));		// Set to Main clock (Generic clock generator 3) = 120MHz

	TCX_TIMER_CH2->COUNT16.CTRLA.reg = TC_CTRLA_SWRST;
	while ((TCX_TIMER_CH2->COUNT16.SYNCBUSY.reg) & TC_SYNCBUSY_SWRST) {
	};

	TCX_TIMER_CH2->COUNT16.CTRLA.reg = TC_CTRLA_PRESCALER_DIV1 | TC_CTRLA_MODE(TC_CTRLA_MODE_COUNT16_Val);				// 120MHz / 1 = 120MHz
	//TCX_TIMER_CH2->COUNT16.INTENSET.reg = TC_INTENSET_OVF | TC_INTENSET_MC0;									// Overflow will only occur when AC does not trigger (safety)
	TCX_TIMER_CH2->COUNT16.WAVE.reg = 0x03;//TCC_WAVE_WAVEGEN_NPWM;						
	TCX_TIMER_CH2->COUNT16.CCBUF[0].reg = TCX_CLOCK_FREQ_CH2 * STEPDOWN_SAFETY_TIME; 
	//TCX_TIMER_CH2->COUNT16.CCBUF[1].reg = TCX_CLOCK_FREQ_CH2 * STEPDOWN_OFF_TIME;
	TCX_TIMER_CH2->COUNT16.EVCTRL.reg = TC_EVCTRL_OVFEO | TC_EVCTRL_MCEO1 | TC_EVCTRL_TCEI | TC_EVCTRL_EVACT_RETRIGGER;			// Output event on overflow and compare match (MUST BE SET BEFORE ENABLED!!)
	TCX_TIMER_CH2->COUNT16.CTRLBSET.reg = TC_CTRLBSET_ONESHOT;	
	TCX_TIMER_CH2->COUNT16.CTRLA.reg |= TC_CTRLA_ENABLE;	// Use 16-bit

	/*NVIC_DisableIRQ(TCX_IRQ_CH2);
	NVIC_ClearPendingIRQ(TCX_IRQ_CH2);
	NVIC_SetPriority(TCX_IRQ_CH2, 1);					// Prio 0 is highest, 7 is lowest
	NVIC_EnableIRQ(TCX_IRQ_CH2);*/
}

/************************************************************************/
/* Init Timer for channel 3. Timer is used for stepdown off time        */
/************************************************************************/
void StepDown_InitTimer3()
{
	// Timer init (TCx)
	MCLK_CRITICAL_SECTION_ENTER();
	TCX_APBXMASK_CH3 = 1;
	MCLK_CRITICAL_SECTION_LEAVE();

	hri_gclk_write_PCHCTRL_reg(GCLK, TCX_GCLK_ID_CH3, GCLK_PCHCTRL_GEN_GCLK3_Val | (1 << GCLK_PCHCTRL_CHEN_Pos));		// Set to Main clock (Generic clock generator 3) = 120MHz

	TCX_TIMER_CH3->COUNT16.CTRLA.reg = TC_CTRLA_SWRST;
	while ((TCX_TIMER_CH3->COUNT16.SYNCBUSY.reg) & TC_SYNCBUSY_SWRST) {
	};

	TCX_TIMER_CH3->COUNT16.CTRLA.reg = TC_CTRLA_PRESCALER_DIV1 | TC_CTRLA_MODE(TC_CTRLA_MODE_COUNT16_Val);				// 120MHz / 1 = 120MHz
	//TCX_TIMER_CH3->COUNT16.INTENSET.reg = TC_INTENSET_OVF | TC_INTENSET_MC0;									// Overflow will only occur when AC does not trigger (safety)
	TCX_TIMER_CH3->COUNT16.WAVE.reg = 0x03;//TCC_WAVE_WAVEGEN_NPWM;						
	TCX_TIMER_CH3->COUNT16.CCBUF[0].reg = TCX_CLOCK_FREQ_CH3 * STEPDOWN_SAFETY_TIME; 
	//TCX_TIMER_CH2->COUNT16.CCBUF[1].reg = TCX_CLOCK_FREQ_CH3 * STEPDOWN_OFF_TIME;
	TCX_TIMER_CH3->COUNT16.EVCTRL.reg = TC_EVCTRL_OVFEO | TC_EVCTRL_MCEO1 | TC_EVCTRL_TCEI | TC_EVCTRL_EVACT_RETRIGGER;			// Output event on overflow and compare match (MUST BE SET BEFORE ENABLED!!)
	TCX_TIMER_CH3->COUNT16.CTRLBSET.reg = TC_CTRLBSET_ONESHOT;	
	TCX_TIMER_CH3->COUNT16.CTRLA.reg |= TC_CTRLA_ENABLE;	// Use 16-bit

	/*NVIC_DisableIRQ(TCX_IRQ_CH2);
	NVIC_ClearPendingIRQ(TCX_IRQ_CH2);
	NVIC_SetPriority(TCX_IRQ_CH2, 1);					// Prio 0 is highest, 7 is lowest
	NVIC_EnableIRQ(TCX_IRQ_CH2);*/
}

/************************************************************************/
/* Init Timer for channel 4. Timer is used for stepdown off time        */
/************************************************************************/
void StepDown_InitTimer4()
{
	// Timer init (TCx)
	MCLK_CRITICAL_SECTION_ENTER();
	TCX_APBXMASK_CH4 = 1;
	MCLK_CRITICAL_SECTION_LEAVE();

	hri_gclk_write_PCHCTRL_reg(GCLK, TCX_GCLK_ID_CH4, GCLK_PCHCTRL_GEN_GCLK3_Val | (1 << GCLK_PCHCTRL_CHEN_Pos));		// Set to Main clock (Generic clock generator 3) = 120MHz

	TCX_TIMER_CH4->COUNT16.CTRLA.reg = TC_CTRLA_SWRST;
	while ((TCX_TIMER_CH4->COUNT16.SYNCBUSY.reg) & TC_SYNCBUSY_SWRST) {
	};

	TCX_TIMER_CH4->COUNT16.CTRLA.reg = TC_CTRLA_PRESCALER_DIV1 | TC_CTRLA_MODE(TC_CTRLA_MODE_COUNT16_Val);				// 120MHz / 1 = 120MHz
	//TCX_TIMER_CH4->COUNT16.INTENSET.reg = TC_INTENSET_OVF | TC_INTENSET_MC0;									// Overflow will only occur when AC does not trigger (safety)
	TCX_TIMER_CH4->COUNT16.WAVE.reg = 0x03;//TCC_WAVE_WAVEGEN_NPWM;						
	TCX_TIMER_CH4->COUNT16.CCBUF[0].reg = TCX_CLOCK_FREQ_CH4 * STEPDOWN_SAFETY_TIME; 
	//TCX_TIMER_CH2->COUNT16.CCBUF[1].reg = TCX_CLOCK_FREQ_CH4 * STEPDOWN_OFF_TIME;
	TCX_TIMER_CH4->COUNT16.EVCTRL.reg = TC_EVCTRL_OVFEO | TC_EVCTRL_MCEO1 | TC_EVCTRL_TCEI | TC_EVCTRL_EVACT_RETRIGGER;			// Output event on overflow and compare match (MUST BE SET BEFORE ENABLED!!)
	TCX_TIMER_CH4->COUNT16.CTRLBSET.reg = TC_CTRLBSET_ONESHOT;	
	TCX_TIMER_CH4->COUNT16.CTRLA.reg |= TC_CTRLA_ENABLE;	// Use 16-bit

	/*NVIC_DisableIRQ(TCX_IRQ_CH2);
	NVIC_ClearPendingIRQ(TCX_IRQ_CH2);
	NVIC_SetPriority(TCX_IRQ_CH2, 1);					// Prio 0 is highest, 7 is lowest
	NVIC_EnableIRQ(TCX_IRQ_CH2);*/
}


/************************************************************************/
/* Init Timer for PWM channel 1. Timer is used for level duty cycle on DIM1 */
/************************************************************************/
void StepDown_InitPwmChannel1()
{
	// Timer init (TCCx)
	MCLK_CRITICAL_SECTION_ENTER();
	TCCX_APBXMASK_EN_CH1 = 1;
	MCLK_CRITICAL_SECTION_LEAVE();
	
	hri_gclk_write_PCHCTRL_reg(GCLK, TCCX_GCLK_ID_EN_CH1, GCLK_PCHCTRL_GEN_GCLK3_Val | (1 << GCLK_PCHCTRL_CHEN_Pos));		// Set to Main clock (Generic clock generator 0) = 120MHz
	
	TCCX_TIMER_EN_CH1->CTRLA.reg = TCC_CTRLA_SWRST;
	while ((TCCX_TIMER_EN_CH1->SYNCBUSY.reg) & TCC_SYNCBUSY_SWRST) {
	};
	
	TCCX_TIMER_EN_CH1->CTRLA.reg = TCC_CTRLA_PRESCALER_DIV1;
	TCCX_TIMER_EN_CH1->INTENSET.reg = TCCX_INTC_INTENSET_CH1;
	TCCX_TIMER_EN_CH1->PER.bit.PER = 0xFFFFFF;//(GCLK_GEN3_FREQ / PWM_FREQ) / 1;
	TCCX_TIMER_EN_CH1->CC[DIM1_WO].reg = 99;				// Super short
	TCCX_TIMER_EN_CH1->WAVE.reg = TCC_WAVE_WAVEGEN_NPWM;								// Normal PWM
	TCCX_TIMER_EN_CH1->EVCTRL.reg = TCC_EVCTRL_EVACT0_START | TCC_EVCTRL_EVACT1_STOP | TCC_EVCTRL_TCEI0 | TCC_EVCTRL_TCEI1 | TCC_EVCTRL_OVFEO;	// Start/Stop via event system
/*#ifdef CC2_22021601
	TCCX_TIMER_EN_CH1->DRVCTRL.reg |= TCCX_DRVCTRL_INV_CH1;
#endif*/
	//TCCX_TIMER_EN_CH1->DRVCTRL.reg |= TCC_DRVCTRL_INVEN0;
	TCCX_TIMER_EN_CH1->CTRLA.reg |= TCC_CTRLA_ENABLE;
	
	NVIC_DisableIRQ(TCCX_IRQ_OVF_EN_CH1);
	NVIC_ClearPendingIRQ(TCCX_IRQ_OVF_EN_CH1);
	NVIC_SetPriority(TCCX_IRQ_OVF_EN_CH1, 0);					// Prio 0 is highest, 7 is lowest
	NVIC_EnableIRQ(TCCX_IRQ_OVF_EN_CH1);
}

/************************************************************************/
/* Init Timer for PWM channel 2. Timer is used for level duty cycle on DIM2 */
/************************************************************************/
void StepDown_InitPwmChannel2()
{
	// Timer init (TCCx)
	MCLK_CRITICAL_SECTION_ENTER();
	TCCX_APBXMASK_EN_CH2 = 1;
	MCLK_CRITICAL_SECTION_LEAVE();
	
	hri_gclk_write_PCHCTRL_reg(GCLK, TCCX_GCLK_ID_EN_CH2, GCLK_PCHCTRL_GEN_GCLK3_Val | (1 << GCLK_PCHCTRL_CHEN_Pos));		// Set to Main clock (Generic clock generator 0) = 120MHz
	
	TCCX_TIMER_EN_CH2->CTRLA.reg = TCC_CTRLA_SWRST;
	while ((TCCX_TIMER_EN_CH2->SYNCBUSY.reg) & TCC_SYNCBUSY_SWRST) {
	};
	
	TCCX_TIMER_EN_CH2->CTRLA.reg = TCC_CTRLA_PRESCALER_DIV1;
	TCCX_TIMER_EN_CH2->INTENSET.reg = TCCX_INTC_INTENSET_CH2;
	TCCX_TIMER_EN_CH2->PER.bit.PER = 0xFFFFFF;//(GCLK_GEN3_FREQ / PWM_FREQ) / 1;
	TCCX_TIMER_EN_CH2->CC[DIM2_WO].reg = 99;				// Set later on
	TCCX_TIMER_EN_CH2->WAVE.reg = TCC_WAVE_WAVEGEN_NPWM;								// Normal PWM
	TCCX_TIMER_EN_CH2->EVCTRL.reg = TCC_EVCTRL_EVACT0_START | TCC_EVCTRL_EVACT1_STOP | TCC_EVCTRL_TCEI0 | TCC_EVCTRL_TCEI1 | TCC_EVCTRL_OVFEO;	// Start/Stop via event system
/*#ifdef CC2_22021601
	TCCX_TIMER_EN_CH2->DRVCTRL.reg |= TCCX_DRVCTRL_INV_CH2;
#endif*/
	TCCX_TIMER_EN_CH2->CTRLA.reg |= TCC_CTRLA_ENABLE;
	
	NVIC_DisableIRQ(TCCX_IRQ_OVF_EN_CH2);
	NVIC_ClearPendingIRQ(TCCX_IRQ_OVF_EN_CH2);
	NVIC_SetPriority(TCCX_IRQ_OVF_EN_CH2, 0);					// Prio 0 is highest, 7 is lowest
	NVIC_EnableIRQ(TCCX_IRQ_OVF_EN_CH2);
}

/************************************************************************/
/* Init Timer for PWM channel 3. Timer is used for level duty cycle on DIM3 */
/************************************************************************/
void StepDown_InitPwmChannel3()
{
	// Timer init (TCCx)
	MCLK_CRITICAL_SECTION_ENTER();
	TCCX_APBXMASK_EN_CH3 = 1;
	MCLK_CRITICAL_SECTION_LEAVE();
	
	hri_gclk_write_PCHCTRL_reg(GCLK, TCCX_GCLK_ID_EN_CH3, GCLK_PCHCTRL_GEN_GCLK3_Val | (1 << GCLK_PCHCTRL_CHEN_Pos));		// Set to Main clock (Generic clock generator 0) = 120MHz
	
	TCCX_TIMER_EN_CH3->CTRLA.reg = TCC_CTRLA_SWRST;
	while ((TCCX_TIMER_EN_CH3->SYNCBUSY.reg) & TCC_SYNCBUSY_SWRST) {
	};
	
	TCCX_TIMER_EN_CH3->CTRLA.reg = TCC_CTRLA_PRESCALER_DIV4;
	TCCX_TIMER_EN_CH3->INTENSET.reg = TCCX_INTC_INTENSET_CH3;
	TCCX_TIMER_EN_CH3->PER.bit.PER = 0xFFFF;//(GCLK_GEN3_FREQ / PWM_FREQ) / 1;
	TCCX_TIMER_EN_CH3->CC[DIM3_WO].reg = 99;				// Set later on
	TCCX_TIMER_EN_CH3->WAVE.reg = TCC_WAVE_WAVEGEN_NPWM;								// Normal PWM
	TCCX_TIMER_EN_CH3->EVCTRL.reg = TCC_EVCTRL_EVACT0_START | TCC_EVCTRL_EVACT1_STOP | TCC_EVCTRL_TCEI0 | TCC_EVCTRL_TCEI1 | TCC_EVCTRL_OVFEO;	// Start/Stop via event system
/*#ifdef CC2_22021601
	TCCX_TIMER_EN_CH3->DRVCTRL.reg |= TCCX_DRVCTRL_INV_CH2;
#endif*/
	TCCX_TIMER_EN_CH3->CTRLA.reg |= TCC_CTRLA_ENABLE;
	
	NVIC_DisableIRQ(TCCX_IRQ_OVF_EN_CH3);
	NVIC_ClearPendingIRQ(TCCX_IRQ_OVF_EN_CH3);
	NVIC_SetPriority(TCCX_IRQ_OVF_EN_CH3, 0);					// Prio 0 is highest, 7 is lowest
	NVIC_EnableIRQ(TCCX_IRQ_OVF_EN_CH3);
}

/************************************************************************/
/* Init Timer for PWM channel 4. Timer is used for level duty cycle on DIM4 */
/************************************************************************/
void StepDown_InitPwmChannel4()
{
	// Timer init (TCCx)
	MCLK_CRITICAL_SECTION_ENTER();
	TCCX_APBXMASK_EN_CH4 = 1;
	MCLK_CRITICAL_SECTION_LEAVE();
	
	hri_gclk_write_PCHCTRL_reg(GCLK, TCCX_GCLK_ID_EN_CH4, GCLK_PCHCTRL_GEN_GCLK3_Val | (1 << GCLK_PCHCTRL_CHEN_Pos));		// Set to Main clock (Generic clock generator 0) = 120MHz
	
	TCCX_TIMER_EN_CH4->CTRLA.reg = TCC_CTRLA_SWRST;
	while ((TCCX_TIMER_EN_CH4->SYNCBUSY.reg) & TCC_SYNCBUSY_SWRST) {
	};
	
	TCCX_TIMER_EN_CH4->CTRLA.reg = TCC_CTRLA_PRESCALER_DIV4;
	TCCX_TIMER_EN_CH4->INTENSET.reg = TCCX_INTC_INTENSET_CH4;
	TCCX_TIMER_EN_CH4->PER.bit.PER = 0xFFFF;//(GCLK_GEN3_FREQ / PWM_FREQ) / 1;
	TCCX_TIMER_EN_CH4->CC[DIM4_WO].reg = 99;				// Set later on
	TCCX_TIMER_EN_CH4->WAVE.reg = TCC_WAVE_WAVEGEN_NPWM;								// Normal PWM
	TCCX_TIMER_EN_CH4->EVCTRL.reg = TCC_EVCTRL_EVACT0_START | TCC_EVCTRL_EVACT1_STOP | TCC_EVCTRL_TCEI0 | TCC_EVCTRL_TCEI1 | TCC_EVCTRL_OVFEO;	// Start/Stop via event system
/*#ifdef CC2_22021601
	TCCX_TIMER_EN_CH4->DRVCTRL.reg |= TCCX_DRVCTRL_INV_CH2;
#endif*/
	TCCX_TIMER_EN_CH4->CTRLA.reg |= TCC_CTRLA_ENABLE;
	
	NVIC_DisableIRQ(TCCX_IRQ_OVF_EN_CH4);
	NVIC_ClearPendingIRQ(TCCX_IRQ_OVF_EN_CH4);
	NVIC_SetPriority(TCCX_IRQ_OVF_EN_CH4, 0);					// Prio 0 is highest, 7 is lowest
	NVIC_EnableIRQ(TCCX_IRQ_OVF_EN_CH4);
}

/************************************************************************/
/* Init channel 1 AC/Timer/Event system                                 */
/************************************************************************/
void StepDown_InitChannel1()
{
	StepDown_InitTimer1();
	StepDown_InitPwmChannel1();
	
	// Pin
	uint32_t oldval = PORT->Group[SW1_PORT].EVCTRL.reg;
	PORT->Group[SW1_PORT].EVCTRL.reg = oldval | PORT_EVCTRL_PORTEI0 | PORT_EVCTRL_EVACT0_OUT | PORT_EVCTRL_PID0(SW1_PIN);
												 /*PORT_EVCTRL_PORTEI1 | PORT_EVCTRL_EVACT1_CLR | PORT_EVCTRL_PID1(SW1_PIN) |
												 PORT_EVCTRL_PORTEI2 | PORT_EVCTRL_EVACT2_TGL | PORT_EVCTRL_PID2(SHUNT1_PIN);*/
	
	EVSYS->Channel[0].CHANNEL.reg = EVSYS_CHANNEL_EDGSEL_NO_EVT_OUTPUT | EVSYS_CHANNEL_PATH_ASYNCHRONOUS | EVSYS_CHANNEL_EVGEN(AC_EXT_IN1_EVENT_ID_GEN);		// External int x
	EVSYS->Channel[1].CHANNEL.reg = EVSYS_CHANNEL_EDGSEL_NO_EVT_OUTPUT | EVSYS_CHANNEL_PATH_ASYNCHRONOUS | EVSYS_CHANNEL_EVGEN(EVSYS_ID_GEN_CH1);				// LUTOUT_0
	
	EVSYS->USER[EVSYS_ID_USER_PORT_EV_0].reg = EVSYS_USER_CHANNEL(1 + 1);			// Set port high (set in PORT->Group[SW1_PORT].EVCTRL)
	EVSYS->USER[TCX_EVSYS_ID_USER_CH1].reg = EVSYS_USER_CHANNEL(0 + 1);				// Retrigger/start timer
	
	EVSYS->SWEVT.reg = EVSYS_SWEVT_CHANNEL0;			// Start TC, needed for RETRIGGER mode
	
	// Comparator
	//AC->COMPCTRL[0].reg = (SNS1_COMPCTRL_MUXPOS) | (DAC_EXT_AC_MUXNEG2) | (AC_COMPCTRL_INTSEL_RISING) | AC_COMPCTRL_FLEN_MAJ3 | AC_COMPCTRL_OUT_ASYNC;
	//AC->COMPCTRL[0].reg |= AC_COMPCTRL_ENABLE | AC_COMPCTRL_SPEED(3);
	//AC->EVCTRL.reg |= AC_EVCTRL_COMPEO0;
	/*AC->INTENSET.reg = AC_INTENSET_COMP0;
	
	NVIC_DisableIRQ(AC_IRQn);
	NVIC_ClearPendingIRQ(AC_IRQn);
	NVIC_SetPriority(AC_IRQn, 1);					// Prio 0 is highest, 7 is lowest
	NVIC_EnableIRQ(AC_IRQn);
	*/
	// CCL system (init basics)
	MCLK_CRITICAL_SECTION_ENTER();
	((Mclk *)MCLK)->APBCMASK.bit.CCL_ = 1;
	MCLK_CRITICAL_SECTION_LEAVE();
	
	hri_gclk_write_PCHCTRL_reg(GCLK, CCL_GCLK_ID, GCLK_PCHCTRL_GEN_GCLK0_Val | (1 << GCLK_PCHCTRL_CHEN_Pos));		// Set to Main clock (Generic clock generator 0) = CONF_CPU_FREQUENCY = 120MHz
	
	CCL_LUT_CH1.reg = CCL_LUTCTRL_INSEL0_TCC | CCL_LUTCTRL_INSEL1_TC | CCL_LUTCTRL_INSEL2_MASK | CCL_LUTCTRL_LUTEI | CCL_LUTCTRL_LUTEO | CCL_LUTCTRL_TRUTH(1 << 0);
	
	gpio_set_pin_direction(SW1, GPIO_DIRECTION_OUT);
	gpio_set_pin_pull_mode(SW1, GPIO_PULL_OFF);
	gpio_set_pin_function(SW1, GPIO_PIN_FUNCTION_OFF);
	PORT->Group[SW1_PORT].OUTCLR.reg = 0x01 << SW1_PIN;
	
	gpio_set_pin_direction(DIM1, GPIO_DIRECTION_OUT);
	gpio_set_pin_pull_mode(DIM1, GPIO_PULL_OFF);
	gpio_set_pin_function(DIM1, GPIO_PIN_FUNCTION_OFF);
	PORT->Group[DIM1_PORT].OUTSET.reg = 0x01 << DIM1_PIN;
}

/************************************************************************/
/* Init channel 2 AC/Timer/Event system                                 */
/************************************************************************/
void StepDown_InitChannel2()
{
	StepDown_InitTimer2();
	StepDown_InitPwmChannel2();
	
	// Pin
	uint32_t oldval = PORT->Group[SW2_PORT].EVCTRL.reg;
	PORT->Group[SW2_PORT].EVCTRL.reg = oldval | PORT_EVCTRL_PORTEI2 | PORT_EVCTRL_EVACT2_OUT | PORT_EVCTRL_PID2(SW2_PIN) /*|
												 PORT_EVCTRL_PORTEI3 | PORT_EVCTRL_EVACT3_CLR | PORT_EVCTRL_PID3(SW2_PIN) |
												 PORT_EVCTRL_PORTEI2 | PORT_EVCTRL_EVACT2_CLR | PORT_EVCTRL_PID2(SW1_PIN)*/;
	
	EVSYS->Channel[2].CHANNEL.reg = EVSYS_CHANNEL_EDGSEL_NO_EVT_OUTPUT | EVSYS_CHANNEL_PATH_ASYNCHRONOUS | EVSYS_CHANNEL_EVGEN(AC_EXT_IN2_EVENT_ID_GEN);		// External int x
	EVSYS->Channel[3].CHANNEL.reg = EVSYS_CHANNEL_EDGSEL_NO_EVT_OUTPUT | EVSYS_CHANNEL_PATH_ASYNCHRONOUS | EVSYS_CHANNEL_EVGEN(EVSYS_ID_GEN_CH2);				// LUTOUT_1
	
	EVSYS->USER[EVSYS_ID_USER_PORT_EV_2].reg = EVSYS_USER_CHANNEL(3 + 1);			// Set port high (set in PORT->Group[SW2_PORT].EVCTRL)
	EVSYS->USER[TCX_EVSYS_ID_USER_CH2].reg = EVSYS_USER_CHANNEL(2 + 1);				// Retrigger/start timer
	
	EVSYS->SWEVT.reg = EVSYS_SWEVT_CHANNEL2;			// Start TC, needed for RETRIGGER mode

	// Comparator
	//AC->COMPCTRL[1].reg = (SNS2_COMPCTRL_MUXPOS) | (DAC_EXT_AC_MUXNEG) | (AC_COMPCTRL_INTSEL_RISING) | AC_COMPCTRL_FLEN_MAJ3 | AC_COMPCTRL_OUT_ASYNC;
	//AC->COMPCTRL[1].reg |= AC_COMPCTRL_ENABLE | AC_COMPCTRL_SPEED(3);
	//AC->EVCTRL.reg |= AC_EVCTRL_COMPEO1;
	/*AC->INTENSET.reg = AC_INTENSET_COMP1;
	
	NVIC_DisableIRQ(AC_IRQn);
	NVIC_ClearPendingIRQ(AC_IRQn);
	NVIC_SetPriority(AC_IRQn, 1);					// Prio 0 is highest, 7 is lowest
	NVIC_EnableIRQ(AC_IRQn);
	*/
	
	CCL_LUT_CH2.reg = CCL_LUTCTRL_INSEL0_TCC | CCL_LUTCTRL_INSEL1_TC | CCL_LUTCTRL_INSEL2_MASK | CCL_LUTCTRL_LUTEI | CCL_LUTCTRL_LUTEO | CCL_LUTCTRL_TRUTH(1 << 0);
	
	gpio_set_pin_direction(SW2, GPIO_DIRECTION_OUT);
	gpio_set_pin_pull_mode(SW2, GPIO_PULL_OFF);
	gpio_set_pin_function(SW2, GPIO_PIN_FUNCTION_OFF);
	PORT->Group[SW2_PORT].OUTCLR.reg = 0x01 << SW2_PIN;
	
	gpio_set_pin_direction(DIM2, GPIO_DIRECTION_OUT);
	gpio_set_pin_pull_mode(DIM2, GPIO_PULL_OFF);
	gpio_set_pin_function(DIM2, GPIO_PIN_FUNCTION_OFF);
	PORT->Group[DIM2_PORT].OUTSET.reg = 0x01 << DIM2_PIN;
}

/************************************************************************/
/* Init channel 3 AC/Timer/Event system                                 */
/************************************************************************/
void StepDown_InitChannel3()
{
	StepDown_InitTimer3();
	StepDown_InitPwmChannel3();
	
	// Pin
	uint32_t oldval = PORT->Group[SW3_PORT].EVCTRL.reg;
	PORT->Group[SW3_PORT].EVCTRL.reg = oldval | PORT_EVCTRL_PORTEI1 | PORT_EVCTRL_EVACT1_OUT | PORT_EVCTRL_PID1(SW3_PIN) ;
	
	EVSYS->Channel[4].CHANNEL.reg = EVSYS_CHANNEL_EDGSEL_NO_EVT_OUTPUT | EVSYS_CHANNEL_PATH_ASYNCHRONOUS | EVSYS_CHANNEL_EVGEN(AC_EXT_IN3_EVENT_ID_GEN);		// External int x
	EVSYS->Channel[5].CHANNEL.reg = EVSYS_CHANNEL_EDGSEL_NO_EVT_OUTPUT | EVSYS_CHANNEL_PATH_ASYNCHRONOUS | EVSYS_CHANNEL_EVGEN(EVSYS_ID_GEN_CH3);				// LUTOUT_2
	
	EVSYS->USER[EVSYS_ID_USER_PORT_EV_1].reg = EVSYS_USER_CHANNEL(5 + 1);			// Set port high (set in PORT->Group[SW3_PORT].EVCTRL)
	EVSYS->USER[TCX_EVSYS_ID_USER_CH3].reg = EVSYS_USER_CHANNEL(4 + 1);				// Retrigger/start timer
	
	EVSYS->SWEVT.reg = EVSYS_SWEVT_CHANNEL4;			// Start TC, needed for RETRIGGER mode

	// Comparator
	//AC->COMPCTRL[1].reg = (SNS2_COMPCTRL_MUXPOS) | (DAC_EXT_AC_MUXNEG) | (AC_COMPCTRL_INTSEL_RISING) | AC_COMPCTRL_FLEN_MAJ3 | AC_COMPCTRL_OUT_ASYNC;
	//AC->COMPCTRL[1].reg |= AC_COMPCTRL_ENABLE | AC_COMPCTRL_SPEED(3);
	//AC->EVCTRL.reg |= AC_EVCTRL_COMPEO1;
	/*AC->INTENSET.reg = AC_INTENSET_COMP1;
	
	NVIC_DisableIRQ(AC_IRQn);
	NVIC_ClearPendingIRQ(AC_IRQn);
	NVIC_SetPriority(AC_IRQn, 1);					// Prio 0 is highest, 7 is lowest
	NVIC_EnableIRQ(AC_IRQn);
	*/
	
	CCL_LUT_CH3.reg = CCL_LUTCTRL_INSEL0_TCC | CCL_LUTCTRL_INSEL1_TC | CCL_LUTCTRL_INSEL2_MASK | CCL_LUTCTRL_LUTEI | CCL_LUTCTRL_LUTEO | CCL_LUTCTRL_TRUTH(1 << 0);
	
	gpio_set_pin_direction(SW3, GPIO_DIRECTION_OUT);
	gpio_set_pin_pull_mode(SW3, GPIO_PULL_OFF);
	gpio_set_pin_function(SW3, GPIO_PIN_FUNCTION_OFF);
	PORT->Group[SW3_PORT].OUTCLR.reg = 0x01 << SW3_PIN;
	
	gpio_set_pin_direction(DIM3, GPIO_DIRECTION_OUT);
	gpio_set_pin_pull_mode(DIM3, GPIO_PULL_OFF);
	gpio_set_pin_function(DIM3, GPIO_PIN_FUNCTION_OFF);
	PORT->Group[DIM3_PORT].OUTSET.reg = 0x01 << DIM3_PIN;
}

/************************************************************************/
/* Init channel 4 AC/Timer/Event system                                 */
/************************************************************************/
void StepDown_InitChannel4()
{
	StepDown_InitTimer4();
	StepDown_InitPwmChannel4();
	
	// Pin
	uint32_t oldval = PORT->Group[SW4_PORT].EVCTRL.reg;
	PORT->Group[SW4_PORT].EVCTRL.reg = oldval | PORT_EVCTRL_PORTEI3 | PORT_EVCTRL_EVACT3_OUT | PORT_EVCTRL_PID3(SW4_PIN) ;
	
	EVSYS->Channel[6].CHANNEL.reg = EVSYS_CHANNEL_EDGSEL_NO_EVT_OUTPUT | EVSYS_CHANNEL_PATH_ASYNCHRONOUS | EVSYS_CHANNEL_EVGEN(AC_EXT_IN4_EVENT_ID_GEN);		// External int x
	EVSYS->Channel[7].CHANNEL.reg = EVSYS_CHANNEL_EDGSEL_NO_EVT_OUTPUT | EVSYS_CHANNEL_PATH_ASYNCHRONOUS | EVSYS_CHANNEL_EVGEN(EVSYS_ID_GEN_CH4);				// LUTOUT_3
	
	EVSYS->USER[EVSYS_ID_USER_PORT_EV_3].reg = EVSYS_USER_CHANNEL(7 + 1);			// Set port high (set in PORT->Group[SW3_PORT].EVCTRL)
	EVSYS->USER[TCX_EVSYS_ID_USER_CH4].reg = EVSYS_USER_CHANNEL(6 + 1);				// Retrigger/start timer
	
	EVSYS->SWEVT.reg = EVSYS_SWEVT_CHANNEL6;			// Start TC, needed for RETRIGGER mode

	// Comparator
	//AC->COMPCTRL[1].reg = (SNS2_COMPCTRL_MUXPOS) | (DAC_EXT_AC_MUXNEG) | (AC_COMPCTRL_INTSEL_RISING) | AC_COMPCTRL_FLEN_MAJ3 | AC_COMPCTRL_OUT_ASYNC;
	//AC->COMPCTRL[1].reg |= AC_COMPCTRL_ENABLE | AC_COMPCTRL_SPEED(3);
	//AC->EVCTRL.reg |= AC_EVCTRL_COMPEO1;
	/*AC->INTENSET.reg = AC_INTENSET_COMP1;
	
	NVIC_DisableIRQ(AC_IRQn);
	NVIC_ClearPendingIRQ(AC_IRQn);
	NVIC_SetPriority(AC_IRQn, 1);					// Prio 0 is highest, 7 is lowest
	NVIC_EnableIRQ(AC_IRQn);
	*/
	
	CCL_LUT_CH4.reg = CCL_LUTCTRL_INSEL0_TCC | CCL_LUTCTRL_INSEL1_TC | CCL_LUTCTRL_INSEL2_MASK | CCL_LUTCTRL_LUTEI | CCL_LUTCTRL_LUTEO | CCL_LUTCTRL_TRUTH(1 << 0);
	
	gpio_set_pin_direction(SW4, GPIO_DIRECTION_OUT);
	gpio_set_pin_pull_mode(SW4, GPIO_PULL_OFF);
	gpio_set_pin_function(SW4, GPIO_PIN_FUNCTION_OFF);
	PORT->Group[SW4_PORT].OUTCLR.reg = 0x01 << SW4_PIN;
	
	gpio_set_pin_direction(DIM4, GPIO_DIRECTION_OUT);
	gpio_set_pin_pull_mode(DIM4, GPIO_PULL_OFF);
	gpio_set_pin_function(DIM4, GPIO_PIN_FUNCTION_OFF);
	PORT->Group[DIM4_PORT].OUTSET.reg = 0x01 << DIM4_PIN;
	
	gpio_set_pin_direction(DIM4_IN, GPIO_DIRECTION_IN);
	gpio_set_pin_pull_mode(DIM4_IN, GPIO_PULL_OFF);
	gpio_set_pin_function(DIM4_IN, DIM4_IN_FUNC);
}

void StepDown_Init()
{
	// Event system (init basics)
	MCLK_CRITICAL_SECTION_ENTER();
	((Mclk *)MCLK)->APBBMASK.bit.EVSYS_ = 1;
	MCLK_CRITICAL_SECTION_LEAVE();
	
	EVSYS->CTRLA.reg = EVSYS_CTRLA_SWRST;
	
	// Comparator (init basics, enable is later)
	MCLK_CRITICAL_SECTION_ENTER();
	((Mclk *)MCLK)->APBCMASK.bit.AC_ = 1;
	MCLK_CRITICAL_SECTION_LEAVE();
	
	hri_gclk_write_PCHCTRL_reg(GCLK, AC_GCLK_ID, GCLK_PCHCTRL_GEN_GCLK0_Val | (1 << GCLK_PCHCTRL_CHEN_Pos));		// Set to Main clock (Generic clock generator 3) = CONF_CPU_FREQUENCY = 120MHz
	
	/*AC->CTRLA.bit.SWRST = 1;
	while ((AC->SYNCBUSY.reg) & AC_SYNCBUSY_SWRST) {
	};
	AC->CALIB.reg = ((uint8_t *)_NVM_SW_CALIB_AREA_BASE)[0] & 0x03;		// Search for 'NVM Software Calibration Area Mapping' in datasheet
		*/
	CCL->CTRL.reg = CCL_CTRL_SWRST;
	
	StepDown_InitChannel1();
	StepDown_InitChannel2();
	StepDown_InitChannel3();
	StepDown_InitChannel4();

	// DAC
	Mcp4725_Init();
	Mcp4725_WriteDac(false, 0);
	Mcp4725_WriteDac(true, 0);
	
	MCLK_CRITICAL_SECTION_ENTER();
	((Mclk *)MCLK)->APBDMASK.bit.DAC_ = 1;
	MCLK_CRITICAL_SECTION_LEAVE();
	
	hri_gclk_write_PCHCTRL_reg(GCLK, DAC_GCLK_ID, GCLK_PCHCTRL_GEN_GCLK1_Val | (1 << GCLK_PCHCTRL_CHEN_Pos));		// Set to Main clock (Generic clock generator 1) = CONF_CPU_FREQUENCY = 12MHz
	
	DAC->CTRLA.bit.SWRST = 1;
	while ((DAC->SYNCBUSY.reg) & DAC_SYNCBUSY_SWRST) {
	};
	
	DAC->CTRLB.reg = DAC_CTRLB_REFSEL_INTREF; //DAC_CTRLB_REFSEL_VDDANA;
	DAC->DACCTRL[0].reg = DAC_DACCTRL_REFRESH(2) | DAC_DACCTRL_ENABLE;
	DAC->DACCTRL[1].reg = DAC_DACCTRL_REFRESH(2) | DAC_DACCTRL_ENABLE;
	//DAC->DACCTRL[0].bit.ENABLE = 1;
	DAC->CTRLA.reg |= DAC_CTRLA_ENABLE;
	
	gpio_set_pin_direction(DAC_EXT_OUT, GPIO_DIRECTION_IN);
	gpio_set_pin_pull_mode(DAC_EXT_OUT, GPIO_PULL_OFF);
	gpio_set_pin_function(DAC_EXT_OUT, DAC_EXT_OUT_FUNC);
	
	gpio_set_pin_direction(DAC2_EXT_OUT, GPIO_DIRECTION_IN);
	gpio_set_pin_pull_mode(DAC2_EXT_OUT, GPIO_PULL_OFF);
	gpio_set_pin_function(DAC2_EXT_OUT, DAC2_EXT_OUT_FUNC);

	while(!DAC->STATUS.bit.READY1) {
	};
	while(!DAC->STATUS.bit.READY0) {
	};

	// Comparator
	//AC->CTRLA.reg = AC_CTRLA_ENABLE;				
	
	// Enable CCL
	CCL->CTRL.reg = CCL_CTRL_ENABLE;
	
	/*NVIC_DisableIRQ(AC_IRQn);
	NVIC_ClearPendingIRQ(AC_IRQn);
	NVIC_SetPriority(AC_IRQn, 1);					// Prio 0 is highest, 7 is lowest
	NVIC_EnableIRQ(AC_IRQn);*/
		
	Stepdown_SetCurrent(StepDown_GetCurrent());				// Set initial current
	
	//StepDown_Test();
	if(xStepDown_Task == NULL)
	{
		if (xTaskCreate(StepDown_Task, "StepDown", TASK_STEPDOWN_STACK_SIZE, NULL, TASK_STEPDOWN_TASK_PRIORITY, &xStepDown_Task) != pdPASS) {
			while (1) {
				;
			}
		}
	}
}

bool StepDown_IsClosed()
{
	return stepdown_closed > 0;	
}

/************************************************************************/
/* Close stepdown (= 0%)for time ms                                                                     */
/************************************************************************/
void StepDown_Close(uint16_t time)
{
	stepdown_closed = time / STEPDOWN_TIMEROS_TICKS;
	
	StepDown_ChannelEnable_Ch1(false);
	StepDown_ChannelEnable_Ch2(false);
	StepDown_ChannelEnable_Ch3(false);
	StepDown_ChannelEnable_Ch4(false);
	
	gpio_set_pin_direction(DIM1, GPIO_DIRECTION_OUT);
	gpio_set_pin_function(DIM1, GPIO_PIN_FUNCTION_OFF);
	PORT->Group[DIM1_PORT].OUTSET.reg = 0x01 << DIM1_PIN;	
	
	gpio_set_pin_direction(SW1, GPIO_DIRECTION_OUT);
	gpio_set_pin_function(SW1, GPIO_PIN_FUNCTION_OFF);		
	PORT->Group[SW1_PORT].OUTCLR.reg = 0x01 << SW1_PIN;
	
	gpio_set_pin_direction(DIM2, GPIO_DIRECTION_OUT);
	gpio_set_pin_function(DIM2, GPIO_PIN_FUNCTION_OFF);
	PORT->Group[DIM2_PORT].OUTCLR.reg = 0x01 << DIM2_PIN;
	
	gpio_set_pin_direction(SW2, GPIO_DIRECTION_OUT);
	gpio_set_pin_function(SW2, GPIO_PIN_FUNCTION_OFF);		
	PORT->Group[SW2_PORT].OUTCLR.reg = 0x01 << SW2_PIN;
	
	gpio_set_pin_direction(DIM3, GPIO_DIRECTION_OUT);
	gpio_set_pin_function(DIM3, GPIO_PIN_FUNCTION_OFF);
	PORT->Group[DIM3_PORT].OUTCLR.reg = 0x01 << DIM3_PIN;
	
	gpio_set_pin_direction(SW3, GPIO_DIRECTION_OUT);
	gpio_set_pin_function(SW3, GPIO_PIN_FUNCTION_OFF);
	PORT->Group[SW3_PORT].OUTCLR.reg = 0x01 << SW3_PIN;
	
	gpio_set_pin_direction(DIM4, GPIO_DIRECTION_OUT);
	gpio_set_pin_function(DIM4, GPIO_PIN_FUNCTION_OFF);
	PORT->Group[DIM4_PORT].OUTCLR.reg = 0x01 << DIM4_PIN;
	
	gpio_set_pin_direction(SW4, GPIO_DIRECTION_OUT);
	gpio_set_pin_function(SW4, GPIO_PIN_FUNCTION_OFF);
	PORT->Group[SW4_PORT].OUTCLR.reg = 0x01 << SW4_PIN;
} 


/************************************************************************/
/* Overflow interrupt of PWM timer to create random period			    */
/************************************************************************/
void TCCX_INTO_HANDLER_EN_CH1()
{
	volatile stepdown_control_t *ctrl = &stepdown_ctrl_chx[0];
	if(!ctrl->update_timer)
	{
		uint8_t cnt = ctrl->cnt;
		TCCX_TIMER_EN_CH1->PERBUF.reg = ctrl->per[cnt];
		TCCX_TIMER_EN_CH1->CCBUF[0].reg = ctrl->cc0[cnt];
		TCCX_TIMER_EN_CH1->CCBUF[DIM1_WO].reg = ctrl->ccx[cnt];
		if(++ctrl->cnt >= MAX_TABLE)
			ctrl->cnt = 0;
	}
	TCCX_TIMER_EN_CH1->INTFLAG.reg = TCC_INTFLAG_OVF;
}

/************************************************************************/
/* Overflow interrupt of PWM timer to create random period			    */
/************************************************************************/
void TCCX_INTO_HANDLER_EN_CH2()
{
	volatile stepdown_control_t *ctrl = &stepdown_ctrl_chx[1];
	if(!ctrl->update_timer)
	{
		uint8_t cnt = ctrl->cnt;
		TCCX_TIMER_EN_CH2->PERBUF.reg = ctrl->per[cnt];
		TCCX_TIMER_EN_CH2->CCBUF[0].reg = ctrl->cc0[cnt];
		TCCX_TIMER_EN_CH2->CCBUF[DIM2_WO].reg = ctrl->ccx[cnt];
		if(++ctrl->cnt >= MAX_TABLE)
			ctrl->cnt = 0;
	}
	TCCX_TIMER_EN_CH2->INTFLAG.reg = TCC_INTFLAG_OVF;
}

/************************************************************************/
/* Overflow interrupt of PWM timer to create random period			    */
/************************************************************************/
void TCCX_INTO_HANDLER_EN_CH3()
{
	volatile stepdown_control_t *ctrl = &stepdown_ctrl_chx[2];
	if(!ctrl->update_timer)
	{
		uint8_t cnt = ctrl->cnt;
		TCCX_TIMER_EN_CH3->PERBUF.reg = ctrl->per[cnt];
		TCCX_TIMER_EN_CH3->CCBUF[0].reg = ctrl->cc0[cnt];
		TCCX_TIMER_EN_CH3->CCBUF[DIM3_WO].reg = ctrl->ccx[cnt];
		if(++ctrl->cnt >= MAX_TABLE)
			ctrl->cnt = 0;
	}
	TCCX_TIMER_EN_CH3->INTFLAG.reg = TCC_INTFLAG_OVF;
}
/************************************************************************/
/* Overflow interrupt of PWM timer to create random period			    */
/************************************************************************/
void TCCX_INTO_HANDLER_EN_CH4()
{
	volatile stepdown_control_t *ctrl = &stepdown_ctrl_chx[3];
	if(!ctrl->update_timer)
	{
		uint8_t cnt = ctrl->cnt;
		TCCX_TIMER_EN_CH4->PERBUF.reg = ctrl->per[cnt];
		TCCX_TIMER_EN_CH4->CCBUF[0].reg = ctrl->cc0[cnt];
		TCCX_TIMER_EN_CH4->CCBUF[DIM4_WO].reg = ctrl->ccx[cnt];
		if(++ctrl->cnt >= MAX_TABLE)
			ctrl->cnt = 0;
	}
	TCCX_TIMER_EN_CH4->INTFLAG.reg = TCC_INTFLAG_OVF;
}


#define MAX_CFG_MA	19
const uint16_t config2mA[MAX_CFG_MA] = { 189, 235, 276, 322, 365, 409, 450, 500, 550, 600, 655, 705, 757, 808, 860, 910, 960, 1012, 1063 };

uint16_t StepDown_GetCurrent()
{
	//uint8_t idx = CONFIG_CURRENT_MA_RAW(appConfig->config);
	//if(idx >= MAX_CFG_MA)
	//	idx = 0;
	uint8_t idx = 0;
	return config2mA[idx];//CONFIG_CURRENT_MA(appConfig->config);
}

void StepDown_Module_Update()
{
	uint16_t mA = StepDown_GetCurrent();
	if(mA != stepdown_current_chx)
	{
		Stepdown_SetCurrent(mA);
	}
}

bool dir = false;
uint8_t last_level = 0;

void StepDown_Debug(uint8_t* data, uint16_t length)
{
	if(length >= 2)
	{
		if(data[0] == 'A')
		{
			Stepdown_SetCurrent((data[1] - '0') * 150);
			appconfig_t *cfgram = AppConfig_Get();
			CONFIG_CURRENT_MA_REV(cfgram->config, (data[1] - '0') * 150);
			AppConfig_Set();
		}
		else if(data[0] == 'C')
		{
			appconfig_t *cfgram = AppConfig_Get();
			cfgram->mode = 2;			// Set fixed to 2 channel mode
			AppConfig_Set();
		}
		else if(data[0] == 'L')
		{
			//Adc_SetVled(12000 + ((data[1] - '0') * 1000));
			Stepdown_SetCurrent(stepdown_current_chx);
		}
		else if(data[0] == 'T')
		{
			stepdown_debug_level = (data[1] - '0');
			stepdown_debug_channel = (data[2] - '0');
			OS_TRACE_ERROR("Debug Lvl: %d, Chan: %d\r\n", stepdown_debug_level, stepdown_debug_channel);
		}
	}
}


static uint8_t vin_error_prs = 0, vin_high_warn_prs = 0;

void StepDown_CheckLimits()
{
	uint32_t vin = Analog_GetSupplyVoltage();// Adc_GetVin();
	if(vin < MIN_VIN_MV)
	{
		if(++vin_error_prs >= (2*VIN_WARNING_DBC))
		{
			State_SetError(STATE_ERROR_VIN_LOW);
			vin_error_prs = VIN_WARNING_DBC;			// Set again after 4 ticks
			StepDown_Close(2000);
		}
	}
	else
	{
		if(vin_error_prs > 0)
		{
			if(--vin_error_prs == 0)
				State_ClearError(STATE_ERROR_VIN_LOW);
		}
	}
	if(vin > MAX_VIN_MV)
	{
		if(++vin_high_warn_prs >= VIN_WARNING_DBC)
		{
			State_SetWarning(STATE_WARNING_SUPPLY_HIGH);
			vin_high_warn_prs = VIN_WARNING_DBC;			// Clip here
			
		}
	}
	else
	{
		if(vin_high_warn_prs > 0)
		{
			if(--vin_high_warn_prs == 0)
				State_ClearWarning(STATE_WARNING_SUPPLY_HIGH);
		}
	}
}

#define CONST_A		31UL		// 25% ripple
#define CONST_B		13UL
#define CONST_C		391UL
#define CONST_D		0UL
#define CONST_E		713UL
#define CONST_F		936UL
#define CONST_G		10UL
#define CONST_H		468UL

static uint8_t vled_prs = 0;

void Stepdown_SetCurrentCalc(uint16_t mA, volatile  stepdown_control_t *ctrl)
{
	uint16_t mA_org = mA;
	uint16_t vled_ad = ctrl->vled_raw_func();
	uint16_t vin_ad = Analog_GetSupplyVoltageRaw();
	
	if(vled_ad < ADC_MV_RAW(MIN_VLED_MV))
		vled_ad = ADC_MV_RAW(MIN_VLED_MV);										// If too low, use 5V so calculation will not fail
	
	// Top detector
	if((vled_ad > ctrl->vled_ad) || (vled_prs == 0))							// Fast up
	{
		uint16_t vled_old = ctrl->vled_ad;
		if(vled_old < vled_ad)
		{
			if(ctrl->filter_fast_speed <= 1)
			{
				ctrl->vled_ad = (uint16_t)(vled_old + ((vled_ad - vled_old) >> 2));
				if(vled_old == ctrl->vled_ad)
					ctrl->vled_ad++;
			}
			else
				ctrl->vled_ad = vled_ad;
		}
		else
		{
			ctrl->vled_ad = (uint16_t)(vled_old - ((vled_old - vled_ad) >> 4));
			if(vled_old == ctrl->vled_max)
				ctrl->vled_ad--;
		}
	}
	if(ctrl->vled_ad > ctrl->vled_max)
		ctrl->vled_max = ctrl->vled_ad;
	if((ctrl->vled_ad > ctrl->vled_max_session) && (ctrl->level >= 0xC000))		// Only store if more than 75% level
	{
		if(++ctrl->vled_max_session_prs >= 100)					// At least 800ms above 75% and more than previous max?
			ctrl->vled_max_session = ctrl->vled_ad;
	}
	else
		ctrl->vled_max_session_prs = 0;
	
	ctrl->vin_ad = vin_ad;
	if(ctrl->vin_ad < ctrl->vled_ad)
		ctrl->vled_ad = ctrl->vin_ad;
	
	uint32_t toff_min = ((ctrl->vin_ad - vled_ad) * CONST_A) / (vled_ad - CONST_B);
		
	uint32_t toff = ((uint32_t)mA * CONST_C) / vled_ad;
	if(toff < toff_min)
		toff = toff_min;
		
	ctrl->toff_min = toff_min;
	ctrl->toff = toff;
	uint32_t toff_set = toff > CONST_D ? (toff - CONST_D) : 0;
	
	ctrl->dac_data = ((mA * CONST_E)/256) + ((toff*vled_ad) / CONST_F) - ((vin_ad - vled_ad)/CONST_G);
	
	if(ctrl->dac_data > 4095)				// Check if value was not a negative value or outside the 12-bit DAC range
	{
		ctrl->dac_data = DAC_MIN;			// Set to the minimum value where DAC and AC can operate OK
		ctrl->dac_data_real = DAC_MIN/2;	// Value used to recalculate PWM value
	}
	else if(ctrl->dac_data < DAC_MIN)
	{
		if(ctrl->dac_data < (DAC_MIN/2))
			ctrl->dac_data_real = DAC_MIN/2;
		else
			ctrl->dac_data_real = ctrl->dac_data;
		ctrl->dac_data = DAC_MIN;
	}
	else
		ctrl->dac_data_real = ctrl->dac_data;
	
	ctrl->stepdown_offtime = toff_set;
	if(ctrl->channel == 1)
	{
		TCX_TIMER_CH1->COUNT16.CCBUF[1].reg = ctrl->stepdown_offtime;
		TCX_TIMER_CH1->COUNT16.CCBUF[0].reg = ctrl->stepdown_offtime + 3;
	}
	else if(ctrl->channel == 2)
	{
		TCX_TIMER_CH2->COUNT16.CCBUF[1].reg = ctrl->stepdown_offtime;
		TCX_TIMER_CH2->COUNT16.CCBUF[0].reg = ctrl->stepdown_offtime + 3;
	}
	else if(ctrl->channel == 3)
	{
		TCX_TIMER_CH3->COUNT16.CCBUF[1].reg = ctrl->stepdown_offtime;
		TCX_TIMER_CH3->COUNT16.CCBUF[0].reg = ctrl->stepdown_offtime + 3;
	}
	else
	{
		TCX_TIMER_CH4->COUNT16.CCBUF[1].reg = ctrl->stepdown_offtime;
		TCX_TIMER_CH4->COUNT16.CCBUF[0].reg = ctrl->stepdown_offtime + 3;
	}
	
	stepdown_current_chx = mA_org;
	ctrl->freq_shift_max_filter = 7000;// - mA_org; //6925 - ((mA_org + 2000) * 2); 
	
	ctrl->mA = mA_org;
}

void Stepdown_SetCurrentCh1(uint16_t mA)
{
	Stepdown_SetCurrentCalc(mA, &stepdown_ctrl_chx[0]);
}

void Stepdown_SetCurrentCh2(uint16_t mA)
{
	Stepdown_SetCurrentCalc(mA, &stepdown_ctrl_chx[1]);
}

void Stepdown_SetCurrentCh3(uint16_t mA)
{
	Stepdown_SetCurrentCalc(mA, &stepdown_ctrl_chx[2]);
}

void Stepdown_SetCurrentCh4(uint16_t mA)
{
	Stepdown_SetCurrentCalc(mA, &stepdown_ctrl_chx[3]);
}

void Stepdown_SetCurrent(uint16_t mA)
{
	Stepdown_SetCurrentCh1(mA);
	Stepdown_SetCurrentCh2(mA);
	Stepdown_SetCurrentCh3(mA);
	Stepdown_SetCurrentCh4(mA);
}

bool StepDown_SleepCheck()
{
	for(int i = 0; i < MAX_DIM_CHANNELS; i++)
	{
		if(stepdown_ctrl_chx[0].level > 0)
			return false;
	}
	return true;
}

void StepDown_CheckCalibration()
{
	if(StepDown_SleepCheck())		// Don't store anything when one of the channels is on
		return;
	
	bool store = false;
	/*if(stepdown_ctrl_ch1.vled_max_store_mv > 0)
	{
		int32_t diff = (int32_t)appCalibData->vled1_max_mv - (int32_t)stepdown_ctrl_ch1.vled_max_store_mv;
		if((abs(diff) > 2000) || (stepdown_ctrl_ch1.force_calibration == 2))		// More than 2V diff
		{
			appCalibData->pwm1_offset = stepdown_ctrl_ch1.pwm_offset;
			appCalibData->vled1_max_mv = stepdown_ctrl_ch1.vled_max_store_mv;
			stepdown_ctrl_ch1.force_calibration = 0;
			store = true;
		}
		stepdown_ctrl_ch1.vled_max_store_mv = 0;
	}
	if(stepdown_ctrl_ch2.vled_max_store_mv > 0)
	{
		int32_t diff = (int32_t)appCalibData->vled2_max_mv - (int32_t)stepdown_ctrl_ch2.vled_max_store_mv;
		if(abs(diff) > 2000 || (stepdown_ctrl_ch2.force_calibration == 2))		// More than 2V diff
		{
			appCalibData->pwm2_offset = stepdown_ctrl_ch2.pwm_offset;
			appCalibData->vled2_max_mv = stepdown_ctrl_ch2.vled_max_store_mv;
			stepdown_ctrl_ch2.force_calibration = 0;
			store = true;
		}
		stepdown_ctrl_ch2.vled_max_store_mv = 0;
	}
	if(store)
	{
		AppCalib_Set();				// Set can be seen if level is not 0!!
		State_SetAttentionInfo(COLOR_AQUA, COLOR_BLUE, 2, 1);
	}*/
	
	TickType_t ticks = xTaskGetTickCount();
	if((appLogData->change_count > 3) || ((ticks - last_log_ticks) >= (12*60*60*1000UL)))		// Every half a day store current log content, or when more than 6 changes are reported
	{
		AppLog_Set();				// Set can be seen if level is not 0!!
		State_SetAttentionInfo(COLOR_GREEN, COLOR_AQUA, 2, 1);
		last_log_ticks = xTaskGetTickCount();
	}
}

bool do_ff = false;
uint8_t last_freq = 0xAA;
uint8_t stimer_prs = 0;
uint8_t err_report = 0;
uint8_t sectimer_prs = 0;
uint32_t sec_after_pup = 0;		// 2 sec power-up

void StepDown_Timer()
{
	if(DAC->STATUS.bit.READY0)
		DAC->DATA[0].reg = stepdown_ctrl_chx[0].dac_data;
	if(DAC->STATUS.bit.READY1)
		DAC->DATA[1].reg = stepdown_ctrl_chx[2].dac_data;

	Mcp4725_WriteDac(false, stepdown_ctrl_chx[1].dac_data);
	Mcp4725_WriteDac(true, stepdown_ctrl_chx[3].dac_data);

	if(time_after_pup < 0xFF)
		++time_after_pup;
	
	if(++sectimer_prs >= (1000/STEPDOWN_TIMEROS_TICKS))
	{
		sectimer_prs = 0;
		stepdown_force_update = 3;
		sec_after_pup++;
	}
	
	if(++stimer_prs < 8)
		return;
	stimer_prs = 0;
	
	if(stepdown_ctrl_chx[0][0].show_level > 0)
		stepdown_ctrl_chx[0].show_level--;
	if(stepdown_ctrl_chx[1].show_level > 0)
		stepdown_ctrl_chx[1].show_level--;
	if(stepdown_ctrl_chx[2].show_level > 0)
		stepdown_ctrl_chx[2].show_level--;
	if(stepdown_ctrl_chx[3].show_level > 0)
		stepdown_ctrl_chx[3].show_level--;
	
	if((err_report == 1 || stepdown_force_update > 0) && (stepdown_debug_level > 0))
	{
		OS_TRACE_ERROR("{\"Cmd\":\"ERR\",\"OC1\":%d,\"OC2\":%d,\"ACL\":%d,\"Error\":%d,\"ErrStr\":\"%s\",\"Warning\":%d,\"WrnStr\":\"%s\"}\r\n", 
			0, 0, 0, State_GetErrors(), State_GetHighestErrorText(), State_GetWarnings(), State_GetHighestWarningText());	
		if(stepdown_force_update > 0)
			stepdown_force_update--;
	}
	if(++err_report > 16)
		err_report = 0;
}

void StepDown_ChannelEnable_Ch1(bool start)
{
	if(start)
	{
		// This probably does not work due to a errata that the enable protect of the register does not work OK, the complete CCL must be disabled: CCL->CTRL.reg = 0;
		CCL_LUT_CH1.reg = CCL_LUTCTRL_ENABLE | CCL_LUTCTRL_INSEL0_TCC | CCL_LUTCTRL_INSEL1_TC | CCL_LUTCTRL_INSEL2_MASK | CCL_LUTCTRL_LUTEI | CCL_LUTCTRL_LUTEO | CCL_LUTCTRL_TRUTH(1 << 0);
		TCCX_TIMER_EN_CH1->COUNT.reg = stepdown_ctrl_chx[0].per[0] - 1;
		TCCX_TIMER_EN_CH1->PER.reg = stepdown_ctrl_chx[0].per[0];
		TCCX_TIMER_EN_CH1->CCBUF[0].reg = stepdown_ctrl_chx[0].cc0[0];
		TCCX_TIMER_EN_CH1->CCBUF[DIM1_WO].reg = stepdown_ctrl_chx[0].ccx[0];
		
		TCCX_TIMER_EN_CH1->CTRLA.bit.ENABLE = true;
		TCCX_TIMER_EN_CH1->CTRLBSET.reg = TCC_CTRLBSET_CMD_RETRIGGER;
		
		gpio_set_pin_function(DIM1, DIM1_FUNC);
	}
	else
	{
		TCCX_TIMER_EN_CH1->CTRLA.bit.ENABLE = false;
		// This probably does not work due to a errata that the enable protect of the register does not work OK, the complete CCL must be disabled: CCL->CTRL.reg = 0;
		CCL_LUT_CH1.reg = CCL_LUTCTRL_INSEL0_TCC | CCL_LUTCTRL_INSEL1_TC | CCL_LUTCTRL_INSEL2_MASK | CCL_LUTCTRL_LUTEI | CCL_LUTCTRL_LUTEO | CCL_LUTCTRL_TRUTH(1 << 0);
		
		PORT->Group[DIM1_PORT].OUTSET.reg = 0x01 << DIM1_PIN;
		gpio_set_pin_direction(DIM1, GPIO_DIRECTION_OUT);
		gpio_set_pin_function(DIM1, GPIO_PIN_FUNCTION_OFF);

		gpio_set_pin_direction(SW1, GPIO_DIRECTION_OUT);
		PORT->Group[SW1_PORT].OUTCLR.reg = 0x01 << SW1_PIN;				// Set Low = off
	}	
}

void StepDown_ChannelEnable_Ch2(bool start)
{
	if(start)
	{
		// This probably does not work due to a errata that the enable protect of the register does not work OK, the complete CCL must be disabled: CCL->CTRL.reg = 0;
		CCL_LUT_CH2.reg = CCL_LUTCTRL_ENABLE | CCL_LUTCTRL_INSEL0_TCC | CCL_LUTCTRL_INSEL1_TC | CCL_LUTCTRL_INSEL2_MASK | CCL_LUTCTRL_LUTEI | CCL_LUTCTRL_LUTEO | CCL_LUTCTRL_TRUTH(1 << 0);
		TCCX_TIMER_EN_CH2->COUNT.reg = stepdown_ctrl_chx[1].per[0] - 1;
		TCCX_TIMER_EN_CH2->PER.reg = stepdown_ctrl_chx[1].per[0];
		TCCX_TIMER_EN_CH2->CCBUF[0].reg = stepdown_ctrl_chx[1].cc0[0];
		TCCX_TIMER_EN_CH2->CCBUF[DIM2_WO].reg = stepdown_ctrl_chx[1].ccx[0];
		
		TCCX_TIMER_EN_CH2->CTRLA.bit.ENABLE = true;
		TCCX_TIMER_EN_CH2->CTRLBSET.reg = TCC_CTRLBSET_CMD_RETRIGGER;
		
		gpio_set_pin_function(DIM2, DIM2_FUNC);
	}
	else
	{
		TCCX_TIMER_EN_CH2->CTRLA.bit.ENABLE = false;
		// This probably does not work due to a errata that the enable protect of the register does not work OK, the complete CCL must be disabled: CCL->CTRL.reg = 0;
		CCL_LUT_CH2.reg = CCL_LUTCTRL_INSEL0_TCC | CCL_LUTCTRL_INSEL1_TC | CCL_LUTCTRL_INSEL2_MASK | CCL_LUTCTRL_LUTEI | CCL_LUTCTRL_LUTEO | CCL_LUTCTRL_TRUTH(1 << 0);
		
		PORT->Group[DIM2_PORT].OUTSET.reg = 0x01 << DIM2_PIN;
		gpio_set_pin_direction(DIM2, GPIO_DIRECTION_OUT);
		gpio_set_pin_function(DIM2, GPIO_PIN_FUNCTION_OFF);

		gpio_set_pin_direction(SW2, GPIO_DIRECTION_OUT);
		PORT->Group[SW2_PORT].OUTCLR.reg = 0x01 << SW2_PIN;				// Set Low = off
	}
}

void StepDown_ChannelEnable_Ch3(bool start)
{
	if(start)
	{
		// This probably does not work due to a errata that the enable protect of the register does not work OK, the complete CCL must be disabled: CCL->CTRL.reg = 0;
		CCL_LUT_CH3.reg = CCL_LUTCTRL_ENABLE | CCL_LUTCTRL_INSEL0_TCC | CCL_LUTCTRL_INSEL1_TC | CCL_LUTCTRL_INSEL2_MASK | CCL_LUTCTRL_LUTEI | CCL_LUTCTRL_LUTEO | CCL_LUTCTRL_TRUTH(1 << 0);
		TCCX_TIMER_EN_CH3->COUNT.reg = stepdown_ctrl_chx[2].per[0] - 1;
		TCCX_TIMER_EN_CH3->PER.reg = stepdown_ctrl_chx[2].per[0];
		TCCX_TIMER_EN_CH3->CCBUF[0].reg = stepdown_ctrl_chx[2].cc0[0];
		TCCX_TIMER_EN_CH3->CCBUF[DIM3_WO].reg = stepdown_ctrl_chx[2].ccx[0];
		
		TCCX_TIMER_EN_CH3->CTRLA.bit.ENABLE = true;
		TCCX_TIMER_EN_CH3->CTRLBSET.reg = TCC_CTRLBSET_CMD_RETRIGGER;
		
		gpio_set_pin_function(DIM3, DIM3_FUNC);
	}
	else
	{
		TCCX_TIMER_EN_CH3->CTRLA.bit.ENABLE = false;
		// This probably does not work due to a errata that the enable protect of the register does not work OK, the complete CCL must be disabled: CCL->CTRL.reg = 0;
		CCL_LUT_CH3.reg = CCL_LUTCTRL_INSEL0_TCC | CCL_LUTCTRL_INSEL1_TC | CCL_LUTCTRL_INSEL2_MASK | CCL_LUTCTRL_LUTEI | CCL_LUTCTRL_LUTEO | CCL_LUTCTRL_TRUTH(1 << 0);
		
		PORT->Group[DIM3_PORT].OUTSET.reg = 0x01 << DIM3_PIN;
		gpio_set_pin_direction(DIM3, GPIO_DIRECTION_OUT);
		gpio_set_pin_function(DIM3, GPIO_PIN_FUNCTION_OFF);

		gpio_set_pin_direction(SW3, GPIO_DIRECTION_OUT);
		PORT->Group[SW3_PORT].OUTCLR.reg = 0x01 << SW3_PIN;				// Set Low = off
	}
}

void StepDown_ChannelEnable_Ch4(bool start)
{
	if(start)
	{
		// This probably does not work due to a errata that the enable protect of the register does not work OK, the complete CCL must be disabled: CCL->CTRL.reg = 0;
		CCL_LUT_CH4.reg = CCL_LUTCTRL_ENABLE | CCL_LUTCTRL_INSEL0_TCC | CCL_LUTCTRL_INSEL1_TC | CCL_LUTCTRL_INSEL2_MASK | CCL_LUTCTRL_LUTEI | CCL_LUTCTRL_LUTEO | CCL_LUTCTRL_TRUTH(1 << 0);
		//CCL->CTRL.reg = CCL_CTRL_ENABLE;
		TCCX_TIMER_EN_CH4->COUNT.reg = stepdown_ctrl_chx[3].per[0] - 1;
		TCCX_TIMER_EN_CH4->PER.reg = stepdown_ctrl_chx[3].per[0];
		TCCX_TIMER_EN_CH4->CCBUF[0].reg = stepdown_ctrl_chx[3].cc0[0];
		TCCX_TIMER_EN_CH4->CCBUF[DIM4_WO].reg = stepdown_ctrl_chx[3].ccx[0];
		
		TCCX_TIMER_EN_CH4->CTRLA.bit.ENABLE = true;
		TCCX_TIMER_EN_CH4->CTRLBSET.reg = TCC_CTRLBSET_CMD_RETRIGGER;
		
		gpio_set_pin_function(DIM4, DIM4_FUNC);
	}
	else
	{
		TCCX_TIMER_EN_CH4->CTRLA.bit.ENABLE = false;
		// This probably does not work due to a errata that the enable protect of the register does not work OK, the complete CCL must be disabled: CCL->CTRL.reg = 0;
		CCL_LUT_CH4.reg = CCL_LUTCTRL_INSEL0_TCC | CCL_LUTCTRL_INSEL1_TC | CCL_LUTCTRL_INSEL2_MASK | CCL_LUTCTRL_LUTEI | CCL_LUTCTRL_LUTEO | CCL_LUTCTRL_TRUTH(1 << 0);
		//CCL->CTRL.reg = CCL_CTRL_ENABLE;
		
		PORT->Group[DIM4_PORT].OUTSET.reg = 0x01 << DIM4_PIN;
		gpio_set_pin_direction(DIM4, GPIO_DIRECTION_OUT);
		gpio_set_pin_function(DIM4, GPIO_PIN_FUNCTION_OFF);

		gpio_set_pin_direction(SW4, GPIO_DIRECTION_OUT);
		PORT->Group[SW4_PORT].OUTCLR.reg = 0x01 << SW4_PIN;				// Set Low = off
	}
}


static void StepDown_SetPwm(volatile stepdown_control_t *ctrl)
{
	int32_t level_pwm_chx_t = ctrl->pwm_new;			// Store calculated value
	
	if(ctrl->level_curve == 0 || StepDown_IsClosed())	// Check if not in safety situation, if so, set to 0
	{
		ctrl->pwm_new = 0;
		ctrl->channel_enable(false);
		if(ctrl->vled_max_session > 0)
		{
			ctrl->vled_max_session = 0;
			ctrl->vled_max_session_prs = 0;
		}
		ctrl->dac_data = DAC_MIN;
	}
	else
	{
		ctrl->update_timer = true;													// Mark busy for interrupt
			
		ctrl->dac_data_org = ctrl->dac_data;
		ctrl->dac_data = (ctrl->dac_data * (0x4000 + ((ctrl->level_filter * 3) / 4))) / 65536UL;			// Lower DAC so there is more space to get more 'off times' to be able to control the vin voltage diffs (TODO: only half, can go lower?)
		if(ctrl->dac_data < DAC_MIN)																// Not know for sure if minimum is too high, can not get to low because of noise
			ctrl->dac_data = DAC_MIN;
			
		int div = 0;
		if(ctrl->freq_new > 1000)
			div = (PWM_END_FREQ * 10) / (ctrl->freq_new - (900));			// Calc divider for randomizer, low frequencies should not get much randomization (500Hz -> + 0 to 14Hz, 22000 -> + 0 to 3217Hz @ 7FFFF)
		ctrl->div = div;
		for(int i = 0; i < MAX_TABLE; i++)
		{
			ctrl->freq_shifted = ctrl->freq_new + (div > 0 && i > 0 ? ((rand_sync_read32(&RAND_0) & 0x7FFF)/ div) : 0);
			ctrl->per[i] = ((ctrl->tcc_freq) / ctrl->freq_shifted);
			
			uint32_t pwm_new = ((ctrl->per[i] * ctrl->level_curve) / 65536UL);
			//pwm_new = (pwm_new * ctrl->dac_data_org)/(uint32_t)ctrl->dac_data;
			//pwm_new = pwm_new + (((ctrl->pwm_offset)) - ((ctrl->level_curve * (ctrl->pwm_offset)) / 65536UL));
			if(ctrl->dac_data_real < ctrl->dac_data)
			{
				pwm_new = (pwm_new * ctrl->dac_data_real)/ctrl->dac_data;
			}
			if(pwm_new > ctrl->per[i])
				pwm_new = ctrl->per[i] - 1;
				
			pwm_new = ctrl->per[i] - pwm_new;
				
			uint32_t shunt_offset = ((ctrl->dac_data * CONST_H)/ctrl->vin_ad);
			shunt_offset = shunt_offset - ((((uint8_t)ctrl->level) * shunt_offset)/256);		// Should be half at 100%
			
			if(pwm_new > shunt_offset)
				ctrl->cc0[i] = pwm_new - shunt_offset;
			else
				ctrl->cc0[i] = 1;
			ctrl->ccx[i] = pwm_new;
		}
		ctrl->period = ctrl->per[0];
		ctrl->pwm_new = ctrl->ccx[0];
		if(level_pwm_chx_t == 0)
		{
			ctrl->cnt = 0;
			ctrl->channel_enable(true);
		}
			
		ctrl->update_timer = false;
	}
}

const uint16_t dmxTable[257] =
{
	0,	3,	19,	48,	87,	132,	183,	240,	302,	369,	440,	514,	593,	675,	761,	850,
	943,	1039,	1137,	1239,	1343,	1450,	1560,	1673,	1788,	1906,	2026,	2149,	2274,	2401,	2531,	2663,
	2797,	2933,	3071,	3212,	3355,	3499,	3646,	3795,	3945,	4098,	4252,	4409,	4567,	4727,	4889,	5053,
	5219,	5386,	5555,	5726,	5899,	6073,	6249,	6426,	6606,	6786,	6969,	7153,	7339,	7526,	7715,	7905,
	8097,	8291,	8486,	8682,	8880,	9080,	9281,	9483,	9687,	9893,	10099,	10308,	10517,	10728,	10941,	11154,
	11369,	11586,	11804,	12023,	12244,	12465,	12689,	12913,	13139,	13366,	13595,	13824,	14055,	14288,	14521,	14756,
	14992,	15229,	15468,	15708,	15949,	16191,	16434,	16679,	16925,	17172,	17420,	17669,	17920,	18172,	18425,	18679,
	18934,	19191,	19448,	19707,	19967,	20228,	20490,	20753,	21017,	21283,	21549,	21817,	22086,	22355,	22626,	22898,
	23172,	23446,	23721,	23997,	24275,	24553,	24833,	25113,	25395,	25678,	25961,	26246,	26532,	26819,	27106,	27395,
	27685,	27976,	28268,	28561,	28855,	29150,	29446,	29742,	30040,	30339,	30639,	30940,	31242,	31545,	31848,	32153,
	32459,	32765,	33073,	33382,	33691,	34002,	34313,	34626,	34939,	35253,	35568,	35884,	36202,	36520,	36838,	37158,
	37479,	37801,	38123,	38447,	38771,	39097,	39423,	39750,	40078,	40407,	40737,	41068,	41399,	41732,	42065,	42399,
	42734,	43070,	43407,	43745,	44084,	44423,	44764,	45105,	45447,	45790,	46134,	46479,	46824,	47171,	47518,	47866,
	48215,	48565,	48915,	49267,	49619,	49972,	50326,	50681,	51037,	51393,	51750,	52108,	52467,	52827,	53188,	53549,
	53911,	54274,	54638,	55003,	55368,	55735,	56102,	56469,	56838,	57208,	57578,	57949,	58321,	58693,	59067,	59441,
	59816,	60192,	60568,	60946,	61324,	61703,	62083,	62463,	62844,	63226,	63609,	63993,	64377,	64762,	65148,	65535,
	65535
};

static void StepDown_SetControl(uint16_t level_chx, volatile  stepdown_control_t *ctrl, uint8_t chan_idx)
{
	// Filter
	int32_t level_old = ctrl->level_filter;
	uint8_t filter_mode = CONFIG_PAR_FILTER(appConfig->config);
	uint16_t idx;
	
	ctrl->data_dir = (level_chx > ctrl->level);						// Store data direction, true is fade up
	
	int delta = abs((int)(level_chx >> 8) - (int)(ctrl->level >> 8));
	if(delta == 0)
	{
		if(ctrl->no_change_cnt < 255)
		ctrl->no_change_cnt++;
	}
	else
	ctrl->no_change_cnt = 0;
	
	int max = ((ctrl->no_change_cnt / 16) * 2) + 1;		// If there have been no changes for more than 16 ticks = 128ms, 2 extra loops can be done to avoid a real slow step when dmx is only set 1 raw step
	
	for(int i = 0; i < max; i++)						// There is a small delay, because it does work when a slow fade is done
	{
		// Do filtering
		if(filter_mode == CONFIG_FILTER_DYNAMIC || IziPlus_Module_IsIdentifying() || IziPlus_Module_IsModeSwitching())		// Dynamic mode, checks the change speed in level, if large steps are made in dmx, the filter will be made faster, so it is more responsive
		{
			int speed = (delta / 16);
			if(speed > 3)
			speed = 3;
			
			if(((speed >= ctrl->filter_fast_speed) || (ctrl->filter_fast_time == 0)) && time_after_pup > 250)	// No fast filter just after power-up
			{
				ctrl->filter_fast_time = 32;			// Use the speed for 32 ticks = 256ms
				ctrl->filter_fast_speed = speed;
			}
			ctrl->filter_shift = 4 - ctrl->filter_fast_speed;
			ctrl->level_filter = ((level_chx - ctrl->level_filter) >> ctrl->filter_shift) + ctrl->level_filter;		// Low pass filter
			
			if(ctrl->filter_fast_time > 0)
			ctrl->filter_fast_time--;
		}
		else if(filter_mode == CONFIG_FILTER_FAST && (time_after_pup > 250))		// Always fast filter (except just after power-up)
		{
			ctrl->level_filter = ((level_chx - ctrl->level_filter) / 4) + ctrl->level_filter;
			ctrl->filter_fast_time = 0;
			ctrl->filter_shift = 2;
		}
		else if(filter_mode == CONFIG_FILTER_SLOW)		// Always slow filter
		{
			ctrl->level_filter = ((level_chx - ctrl->level_filter) / 64) + ctrl->level_filter;
			ctrl->filter_fast_time = 0;
			ctrl->filter_shift = 6;
		}
		else
		{
			ctrl->level_filter = ((level_chx - ctrl->level_filter) / 16) + ctrl->level_filter;
			ctrl->filter_fast_time = 0;
			ctrl->filter_shift = 4;
		}
		
		if(ctrl->level_filter == level_old && level_chx != ctrl->level_filter)		// Make sure if last delta is divided to 0, that the real level is still reached in steps of 1
		{
			if(level_chx > ctrl->level_filter)
			ctrl->level_filter++;
			else
			ctrl->level_filter--;
		}
		
		ctrl->level = level_chx;
		
		uint16_t level_filter_old = ctrl->level_curve;
		#ifndef MINIMS_MEASURE
		idx = ((ctrl->level_filter >> 8) & 0xFF);								// High byte is the 8-bit level (low byte is just fraction for calculation in the next integrator)
		ctrl->level_curve = dmxTable[idx];									// Convert the level by the selected table to the pwm level
		uint16_t fine = dmxTable[idx + 1];
		ctrl->level_curve = ctrl->level_curve + (((fine - ctrl->level_curve) * ((uint8_t)ctrl->level_filter)) / 255);
		#else
		ctrl->level_curve = ctrl->level_filter;
		#endif //MINIMS_MEASURE
		
		
		if(level_chx != ctrl->level_filter && level_filter_old == ctrl->level_curve)		// In case the loop can be executed more times and the level has not changed at the input, but the goal is still not reached, speed up
		{
			continue;			// xtra loop if available (max)
		}
		break;
	}
	ctrl->level_curve = IziPlus_Module_GetTable(chan_idx, ctrl->level_curve);
	ctrl->level_curve = IziPlus_Module_TempLimit(ctrl->level_curve);				// Check if any temperature or power is too high
	ctrl->level_curve_correct_prev = ctrl->level_curve;						// Store value for next calculation of temp correction
}

uint8_t StepDown_DebugLevel()
{
	return stepdown_debug_level;
}

void StepDown_SetOutputs()
{
	for(int i = 0; i < iziplus_fixdef.max_channels; i++)
		StepDown_SetPwm(&stepdown_ctrl_chx[i]);	
}

extern boot_t boot_data;

static void StepDown_Task(void *p)
{
	TickType_t task_loop_stamp = 0;
	int task_loop_time = 0;
	
	hri_gclk_write_PCHCTRL_reg(GCLK, EIC_GCLK_ID, CONF_GCLK_EIC_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
	hri_mclk_set_APBAMASK_EIC_bit(MCLK);
	
	EIC->CTRLA.bit.SWRST = 1;
	while ((EIC->SYNCBUSY.reg) & EIC_SYNCBUSY_SWRST) {
	};
	EIC->CONFIG[0].reg = EIC->CONFIG[1].reg = 0;
	EIC->CONFIG[AC_EXT_IN1_EVENT_CFG].reg |= AC_EXT_IN1_EVENT_SENSE;
	EIC->CONFIG[AC_EXT_IN2_EVENT_CFG].reg |= AC_EXT_IN2_EVENT_SENSE;
	EIC->CONFIG[AC_EXT_IN3_EVENT_CFG].reg |= AC_EXT_IN3_EVENT_SENSE;
	EIC->CONFIG[AC_EXT_IN4_EVENT_CFG].reg |= AC_EXT_IN4_EVENT_SENSE;
	EIC->EVCTRL.reg = EIC_EVCTRL_EXTINTEO(1 << AC_EXT_IN1_EVENT_BIT) |  EIC_EVCTRL_EXTINTEO(1 << AC_EXT_IN2_EVENT_BIT) |  EIC_EVCTRL_EXTINTEO(1 << AC_EXT_IN3_EVENT_BIT) | EIC_EVCTRL_EXTINTEO(1 << AC_EXT_IN4_EVENT_BIT);
	
	gpio_set_pin_direction(AC_EXT_IN1, GPIO_DIRECTION_IN);
	gpio_set_pin_pull_mode(AC_EXT_IN1, GPIO_PULL_UP);
	gpio_set_pin_function(AC_EXT_IN1, AC_EXT_IN1_FUNC);
	gpio_set_pin_direction(AC_EXT_IN2, GPIO_DIRECTION_IN);
	gpio_set_pin_pull_mode(AC_EXT_IN2, GPIO_PULL_UP);
	gpio_set_pin_function(AC_EXT_IN2, AC_EXT_IN2_FUNC);
	gpio_set_pin_direction(AC_EXT_IN3, GPIO_DIRECTION_IN);
	gpio_set_pin_pull_mode(AC_EXT_IN3, GPIO_PULL_UP);
	gpio_set_pin_function(AC_EXT_IN3, AC_EXT_IN3_FUNC);
	gpio_set_pin_direction(AC_EXT_IN4, GPIO_DIRECTION_IN);
	gpio_set_pin_pull_mode(AC_EXT_IN4, GPIO_PULL_UP);
	gpio_set_pin_function(AC_EXT_IN4, AC_EXT_IN4_FUNC);
	
	EIC->CTRLA.bit.ENABLE = 1;
	
	Analog_Init();
	
	stepdown_ctrl_chx[0].freq_max = PWM_END_FREQ;
	stepdown_ctrl_chx[1].freq_max = PWM_END_FREQ;
	stepdown_ctrl_chx[2].freq_max = PWM_END_FREQ;
	stepdown_ctrl_chx[3].freq_max = PWM_END_FREQ;
	
	//StepDown_ForceCalibration();
	
	while(true)
	{
		vTaskDelay(STEPDOWN_TIMEROS_TICKS);
		boot_data.last_code = 'R';
		if(stepdown_closed > 0)
		{
			stepdown_closed--;
			continue;
		}
		if(++vled_prs >= 2)
			vled_prs = 0;		
		
		StepDown_CheckLimits();
		for(int i = 0; i < iziplus_fixdef.max_channels; i++)
		{
			uint8_t patch = iziplus_fixdef.patch[i];
			StepDown_SetControl(IziPlus_Module_GetDim(i), &stepdown_ctrl_chx[patch], patch);
			//StepDown_SetPwm(i);
		}
		StepDown_SetOutputs();
		
		if(!I2Cx_Check())
		{
			State_SetWarning(STATE_WARNING_EMITTER_COM);
			stepdown_i2c_warning_time = 200;			// Delay so warning is shortly shown
		}
		else if(stepdown_i2c_warning_time == 0)
			State_ClearWarning(STATE_WARNING_EMITTER_COM);
		else
			stepdown_i2c_warning_time--;
		
		StepDown_Timer();
		StepDown_CheckCalibration();
		IziPlus_NoComCheck();
		
		TickType_t task_loop_stamp_new = xTaskGetTickCount();
		if(task_loop_stamp > 0 && (!StepDown_SleepCheck()))
		{
			if((task_loop_stamp_new - task_loop_stamp) > 10)
			{
				State_SetWarning(STATE_WARNING_TIMING_WARN);
				task_loop_time = 500;			// 4 sec
			}
			else if(task_loop_time > 0)
			{
				if(--task_loop_time == 0)
					State_ClearWarning(STATE_WARNING_TIMING_WARN);
			}
		}
		task_loop_stamp = task_loop_stamp_new;
		
		REPORT_STACK(TASK_STEPDOWN_STACK_SIZE, TASK_STEPDOWN);
	}
}