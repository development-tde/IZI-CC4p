/*
 * at30tse.c
 *
 * Created: 5-12-2023 09:01:43
 *  Author: Milo
 */ 

#include "includes.h"
#include "at30tse.h"
#include "i2cx.h"
#include "hpl_i2c_m_sync.h"

SemaphoreHandle_t	at30tseSemaphore;

#ifndef AT30TSE_IC_ADDRESS
#define AT30TSE_IC_ADDRESS		0x00	
#endif
#define AT30TSE_REG_ADDRESS		(0x18|AT30TSE_IC_ADDRESS)
#define AT30TSE_EE_ADDRESS		(0x50|AT30TSE_IC_ADDRESS)
#define AT30TSE_SPA0_ADDRESS	(0x36)						// Set page address -> Page 0
#define AT30TSE_SPA1_ADDRESS	(0x37)						// Set page address -> Page 1

#define AT30TSE_BFR_MAX			16
#define AT30TSE_PAGE_MAX		0x100

uint8_t at30tse_bfr[AT30TSE_BFR_MAX + 1];
bool at30tse_init = false;

/************************************************************************/
/* Init I2C						                                        */
/************************************************************************/
void At30tse_Init()
{
	I2Cx_Init();
	at30tseSemaphore = xSemaphoreCreateMutex();
	at30tse_init = true;
}

/************************************************************************/
/* I2C init ready?				                                        */
/************************************************************************/
bool At30tse_InitReady()
{
	return at30tse_init;
}

/************************************************************************/
/* Read EEPROM					                                        */
/************************************************************************/
int32_t At30tse_ReadEeprom(uint8_t *bfr, uint16_t address, uint16_t amount)
{
	if(!at30tse_init)
		return AT30TSE_NO_INIT;
	
	if(xTaskGetSchedulerState() != taskSCHEDULER_NOT_STARTED)
		xSemaphoreTake (at30tseSemaphore, 25);
		
	int32_t res = -1;
	for(int i = 0; i < amount; i += (AT30TSE_PAGE_MAX/4))			// Read per 64 bytes
	{
		uint8_t some_bytes[1] = { 0 };
		res = I2Cx_Write_Bfr((address + i) >= 0x100 ? AT30TSE_SPA1_ADDRESS : AT30TSE_SPA0_ADDRESS, 0, some_bytes, 1);			// Send 2 dummy bytes, the slave address holds the page to select (page = 256 bytes)
	
		uint16_t amount_part = (i + (AT30TSE_PAGE_MAX/4)) > amount ? amount % (AT30TSE_PAGE_MAX/4) : (AT30TSE_PAGE_MAX/4);
		if(res == I2C_OK)
			res = I2Cx_Read_Bfr(AT30TSE_EE_ADDRESS, ((address + i) % AT30TSE_PAGE_MAX), bfr + i, amount_part);
	}
	
	if(xTaskGetSchedulerState() != taskSCHEDULER_NOT_STARTED)
		xSemaphoreGive(at30tseSemaphore);
		
	return res;
}

/************************************************************************/
/* Write EEPROM					                                        */
/************************************************************************/
int32_t At30tse_WriteEeprom(uint8_t *bfr, uint16_t address, uint16_t amount)
{
	if(!at30tse_init)
		return AT30TSE_NO_INIT;
	
	if(xTaskGetSchedulerState() != taskSCHEDULER_NOT_STARTED)
		xSemaphoreTake (at30tseSemaphore, 25);
	
	int32_t res = -1;
	
	for(int i = 0; i < amount; i += AT30TSE_BFR_MAX)
	{
		if(i > 0)
			vTaskDelay(5 + 1);			// Max 5ms write time
			
		uint8_t some_bytes[1] = { 0 };
		res = I2Cx_Write_Bfr((address + i) >= AT30TSE_PAGE_MAX ? AT30TSE_SPA1_ADDRESS : AT30TSE_SPA0_ADDRESS, 0, some_bytes, 1);			// Send 2 dummy bytes, the slave address holds the page to select (page = 256 bytes)
	
		if(res == I2C_OK)
		{
			at30tse_bfr[0] = (address + i) % AT30TSE_PAGE_MAX;
			uint16_t amount_part = (i + AT30TSE_BFR_MAX) > amount ? amount % AT30TSE_BFR_MAX : AT30TSE_BFR_MAX;
			memcpy(&at30tse_bfr[1], bfr + i, amount_part);
			res = I2Cx_Write_Sequence(AT30TSE_EE_ADDRESS, at30tse_bfr, amount_part + 1);
		}
		else
			break;
	}
	
	if(xTaskGetSchedulerState() != taskSCHEDULER_NOT_STARTED)
		xSemaphoreGive(at30tseSemaphore);

	if(res == I2C_OK)		
		vTaskDelay(5 + 1);			// Wait until write is complete
	
	return res;
}

static uint16_t at30tse_last_temp_read = 0x7FF;
static uint16_t at30tse_error_prs = 0;

/************************************************************************/
/* Return temp per 0.125 degrees                                        */
/************************************************************************/
uint16_t At30tse_GetTemperature()
{
	if(!at30tse_init)
		return AT30TSE_NO_INIT;
	
	if(xTaskGetSchedulerState() != taskSCHEDULER_NOT_STARTED)
		xSemaphoreTake (at30tseSemaphore, 25);
	
	uint16_t val = 0;
	int32_t res = I2Cx_Read_16b(AT30TSE_REG_ADDRESS, 5, &val);
	if(res == I2C_OK)
	{
		State_ClearError(STATE_ERROR_NO_EMITTER);
		val = ((val >> 1) & 0x7FF);
		at30tse_last_temp_read = val;
		at30tse_error_prs = 0;
	}
	else
	{
		if(++at30tse_error_prs > 5)
		{
			State_SetError(STATE_ERROR_NO_EMITTER);
			if(at30tse_last_temp_read < 0x7FF)
				at30tse_last_temp_read++;					// Increase last temp, because its not know any more (0.125 per sec)
		}
		val = at30tse_last_temp_read;
	}
	if(xTaskGetSchedulerState() != taskSCHEDULER_NOT_STARTED)
		xSemaphoreGive(at30tseSemaphore);
	
	return val;
}