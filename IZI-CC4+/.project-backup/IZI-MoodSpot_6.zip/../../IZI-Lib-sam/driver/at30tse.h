/*
 * at30tse.h
 *
 * Created: 5-12-2023 09:02:02
 *  Author: Milo
 */ 


#ifndef AT30TSE_H_
#define AT30TSE_H_

#define AT30TSE_DEGREES(t)		(t >> 3)
#define AT30TSE_MUL				8

#define AT30TSE_OK				0
#define AT30TSE_NO_INIT			-100
#define AT30TSE_NO_MEM			-101

// Proto
void At30tse_Init();
bool At30tse_InitReady();
uint16_t At30tse_GetTemperature();
int32_t At30tse_ReadEeprom(uint8_t *bfr, uint16_t address, uint16_t amount);
int32_t At30tse_WriteEeprom(uint8_t *bfr, uint16_t address, uint16_t amount);

#endif /* AT30TSE_H_ */