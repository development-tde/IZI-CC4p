/*
 * usart1.c
 *
 * Created: 8-3-2022 08:42:33
 *  Author: Milo
 */ 

#include "includes.h"
#include "usart2.h"

// Defines
#define USART2_CLK_APBXMASK			((Mclk *)MCLK)->APBBMASK.bit.SERCOM2_
#define USART2_CLK_GCLK_ID			SERCOM2_GCLK_ID_CORE				// Check PCHCTRL in datasheet for index of peripheral
#ifndef USART2_CLK_FREQ
#define USART2_CLK_FREQ				96000000.0
#endif
#ifndef USART2_CLK_PCHCTRL
#define USART2_CLK_PCHCTRL			GCLK_PCHCTRL_GEN_GCLK0_Val
#endif

#define USART2_HW					SERCOM2->USART
#ifndef USART2_TX_PAD
#define USART2_TX_PAD				0
#endif
#ifndef USART2_TX_PIN
#define USART2_TX_PIN				GPIO(GPIO_PORTA, 12), PINMUX_PA12C_SERCOM2_PAD0
#endif
#ifndef USART2_RX_PAD
#define USART2_RX_PAD				1
#endif
#ifndef USART2_RX_PIN
#define USART2_RX_PIN				GPIO(GPIO_PORTA, 13), PINMUX_PA13C_SERCOM2_PAD1
#endif
#ifndef USART2_BAUD	
#define USART2_BAUD					460800	//921600
#endif

#define USART2_INT0					SERCOM2_0_Handler			// DRE
#define USART2_INT1					SERCOM2_1_Handler			// TX
#define USART2_INT2					SERCOM2_2_Handler			// RX
#define USART2_INT3					SERCOM2_3_Handler			// ERR and others

#define USART2_INT0_NR				SERCOM2_0_IRQn			// DRE
#define USART2_INT1_NR				SERCOM2_1_IRQn			// TX
#define USART2_INT2_NR				SERCOM2_2_IRQn			// RX
#define USART2_INT3_NR				SERCOM2_3_IRQn			// ERR and others

#ifndef USART2_INT_PRIO
#define USART2_INT_PRIO				configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 1
#endif

#ifndef USART2_TX_BFR_SIZE
#define USART2_TX_BFR_SIZE			2*1024						// Max data in transmit buffer
#endif

// Globals
volatile uint8_t Usart2_TxBuffer[USART2_TX_BFR_SIZE];
volatile uint16_t Usart2_TxInWriteIdx, Usart2_TxOutWriteIdx;

static usartx_cb_func_txptr  Usart2_TxCb = NULL;
static usartx_cb_func_rxptr  Usart2_RxCb = NULL;
static usartx_cb_func_errptr  Usart2_ErrCb = NULL;

static bool Usart2_Ready = false;

void Usart2_Init(usartx_cb_func_txptr tx_cb, usartx_cb_func_rxptr rx_cb, usartx_cb_func_errptr err_cb)
{
	Usart2_TxCb = tx_cb;
	Usart2_RxCb = rx_cb;
	Usart2_ErrCb = err_cb;
	
	MCLK_CRITICAL_SECTION_ENTER();
	USART2_CLK_APBXMASK = 1;
	MCLK_CRITICAL_SECTION_LEAVE();
	
	hri_gclk_write_PCHCTRL_reg(GCLK, USART2_CLK_GCLK_ID, USART2_CLK_PCHCTRL | (1 << GCLK_PCHCTRL_CHEN_Pos));		// Set to Main clock (Generic clock generator 0) = CONF_CPU_FREQUENCY = 96MHz
	//hri_gclk_write_PCHCTRL_reg(GCLK, SERCOM2_GCLK_ID_SLOW, CONF_GCLK_SERCOM2_SLOW_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
	
	USART2_HW.CTRLA.bit.SWRST = SERCOM_USART_CTRLA_SWRST;
	while ((USART2_HW.SYNCBUSY.reg) & SERCOM_USART_SYNCBUSY_SWRST) {
	};
	
	USART2_HW.CTRLA.reg = SERCOM_USART_CTRLA_MODE(1) | SERCOM_USART_CTRLA_TXPO(USART2_TX_PAD) | SERCOM_USART_CTRLA_RXPO(USART2_RX_PAD) | SERCOM_USART_CTRLA_DORD;
	USART2_HW.CTRLB.reg = SERCOM_USART_CTRLB_TXEN | SERCOM_USART_CTRLB_RXEN;
	//USART2_HW.CTRLC.reg = SERCOM_USART_CTRLC_MAXITER(7) | SERCOM_USART_CTRLC_GTIME(2);
	USART2_HW.BAUD.reg = (uint16_t)(65536.0 * (1.0 - (16.0 * ((double)USART2_BAUD / USART2_CLK_FREQ))));
	USART2_HW.INTENSET.reg = SERCOM_USART_INTENSET_RXC | SERCOM_USART_INTENSET_ERROR;
	
#ifdef USART2_DMA	
	DMA_ChannelInit(0, (uint32_t)&SERCOM2->USART.DATA.reg, SERCOM2_DMAC_ID_TX);
#endif
	
	NVIC_DisableIRQ(USART2_INT0_NR);
	NVIC_ClearPendingIRQ(USART2_INT0_NR);
	NVIC_SetPriority(USART2_INT0_NR, USART2_INT_PRIO);					// Prio 0 is highest, 7 is lowest
	NVIC_EnableIRQ(USART2_INT0_NR);
	
	if(Usart2_TxCb != NULL)
	{
		NVIC_DisableIRQ(USART2_INT1_NR);
		NVIC_ClearPendingIRQ(USART2_INT1_NR);
		NVIC_SetPriority(USART2_INT1_NR, USART2_INT_PRIO);				// Prio 0 is highest, 7 is lowest
		NVIC_EnableIRQ(USART2_INT1_NR);
	}
	
	if(Usart2_RxCb != NULL)
	{
		NVIC_DisableIRQ(USART2_INT2_NR);
		NVIC_ClearPendingIRQ(USART2_INT2_NR);
		NVIC_SetPriority(USART2_INT2_NR, USART2_INT_PRIO);					// Prio 0 is highest, 7 is lowest
		NVIC_EnableIRQ(USART2_INT2_NR);
	}
	
	if(Usart2_ErrCb != NULL)
	{
		NVIC_DisableIRQ(USART2_INT3_NR);
		NVIC_ClearPendingIRQ(USART2_INT3_NR);
		NVIC_SetPriority(USART2_INT3_NR, USART2_INT_PRIO);					// Prio 0 is highest, 7 is lowest
		NVIC_EnableIRQ(USART2_INT3_NR);
	}
	
	USART2_HW.CTRLA.reg |= SERCOM_USART_CTRLA_ENABLE;

	Usart2_TxInWriteIdx = Usart2_TxOutWriteIdx = 0;
	
	gpio_set_pin_function(USART2_TX_PIN);
	gpio_set_pin_function(USART2_RX_PIN);
	
	Usart2_Ready = true;
}

/**
 * \internal Sercom interrupt handler DRE -> Data register empty
 */
void USART2_INT0(void)
{
	if(++Usart2_TxOutWriteIdx >= USART2_TX_BFR_SIZE)
		Usart2_TxOutWriteIdx = 0;
	if(Usart2_TxInWriteIdx != Usart2_TxOutWriteIdx)						// Buffer not empty?
		USART2_HW.DATA.reg = Usart2_TxBuffer[Usart2_TxOutWriteIdx];
	else
		USART2_HW.INTENCLR.reg = SERCOM_USART_INTENCLR_DRE;
	USART2_HW.INTFLAG.reg = SERCOM_USART_INTFLAG_DRE;
}

/**
 * \internal Sercom interrupt handler TXC -> Transmit complete
 */
void USART2_INT1(void)
{
	if(Usart2_TxCb != NULL && (Usart2_TxInWriteIdx == Usart2_TxOutWriteIdx))
	{
		Usart2_TxCb();
		USART2_HW.INTENCLR.reg = SERCOM_USART_INTENCLR_TXC;				// Disable interrupt until new data
	}
	USART2_HW.INTFLAG.reg = SERCOM_USART_INTFLAG_TXC;
}
/**
 * \internal Sercom interrupt handler RXC -> Receive complete
 */
void USART2_INT2(void)
{
	if(Usart2_RxCb != NULL)
		Usart2_RxCb(USART2_HW.DATA.reg);
	USART2_HW.INTFLAG.reg = SERCOM_USART_INTFLAG_RXC;
}
/**
 * \internal Sercom interrupt handler ERROR -> Error is detected
 */
void USART2_INT3(void)
{
	if(Usart2_ErrCb != NULL)
		Usart2_ErrCb();
	USART2_HW.STATUS.reg = SERCOM_USART_STATUS_BUFOVF | SERCOM_USART_STATUS_FERR;
	USART2_HW.INTFLAG.reg = SERCOM_USART_INTFLAG_ERROR;
	//USART2_HW.RXERRCNT
}

void Usart2_SendStart()
{
	if(!Usart2_Ready)
		return;
	
	if(!(USART2_HW.INTENSET.reg & SERCOM_USART_INTENSET_DRE))
	{
		while(!USART2_HW.INTFLAG.bit.DRE) ;
		
		USART2_HW.DATA.reg = Usart2_TxBuffer[Usart2_TxOutWriteIdx];
		if(Usart2_TxCb != NULL)
			USART2_HW.INTENSET.reg = SERCOM_USART_INTENSET_TXC | SERCOM_USART_INTENSET_DRE;			// Enable data register empty interrupt and transmit ready
		else
			USART2_HW.INTENSET.reg = SERCOM_USART_INTENSET_DRE;			// Enable data register empty interrupt
	}
}

void Usart2_Putx(uint8_t data)
{
	uint16_t idx = Usart2_TxInWriteIdx;
	if(++idx >= USART2_TX_BFR_SIZE)
		idx = 0;
	
	if(idx == Usart2_TxOutWriteIdx && Usart2_Ready)					// Overrun, buffer still full?
		vTaskDelay(2);								// Wait ff
	
	Usart2_TxBuffer[Usart2_TxInWriteIdx] = data;
	Usart2_TxInWriteIdx = idx;
}

void Usart2_Putc(uint8_t data)
{
	Usart2_Putx(data);
	Usart2_SendStart();
}

void Usart2_PutBfr(uint8_t *data, uint16_t length)
{
	for(uint16_t i = 0; i < length; i++)
		Usart2_Putx(data[i]);
	Usart2_SendStart();
}

#ifdef USART2_DMA
void Usart2_DmaTest()
{
	DMA_Send(0, "Pipo de clown\r\n", 16);
	DMA_Send(0, "Harry de clown\r\n", 16);
}
#endif	
