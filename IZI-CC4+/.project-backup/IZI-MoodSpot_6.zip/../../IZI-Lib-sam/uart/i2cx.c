/*
 * i2c1.c
 *
 * Created: 4-12-2023 13:37:11
 *  Author: Milo
 */ 

#include "includes.h"
#include "i2cx.h"
#include "hal_i2c_m_sync.h"

struct i2c_m_sync_desc I2C_x;
static uint16_t i2c_errors = 0;
static bool i2c_init = false;
// Proto

#ifndef I2C_SERCOMX
#define I2C_SERCOMX		I2C_SERCOM3
#endif

void I2Cx_Init()
{
	if(i2c_init)
	{
		i2c_m_sync_disable(&I2C_x);
		i2c_m_sync_deinit(&I2C_x);
	}
	
#if I2C_SERCOMX == I2C_SERCOM0
	hri_gclk_write_PCHCTRL_reg(GCLK, SERCOM1_GCLK_ID_CORE, CONF_GCLK_SERCOM0_CORE_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
	hri_mclk_set_APBAMASK_SERCOM0_bit(MCLK);
	i2c_m_sync_init(&I2C_x, SERCOM0);
#elif I2C_SERCOMX == I2C_SERCOM1
	hri_gclk_write_PCHCTRL_reg(GCLK, SERCOM1_GCLK_ID_CORE, CONF_GCLK_SERCOM1_CORE_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
	hri_mclk_set_APBAMASK_SERCOM1_bit(MCLK);
	i2c_m_sync_init(&I2C_x, SERCOM1);
#elif I2C_SERCOMX == I2C_SERCOM2
	hri_gclk_write_PCHCTRL_reg(GCLK, SERCOM2_GCLK_ID_CORE, CONF_GCLK_SERCOM2_CORE_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
	hri_mclk_set_APBBMASK_SERCOM2_bit(MCLK);
	i2c_m_sync_init(&I2C_x, SERCOM2);
#elif I2C_SERCOMX == I2C_SERCOM3
	hri_gclk_write_PCHCTRL_reg(GCLK, SERCOM3_GCLK_ID_CORE, CONF_GCLK_SERCOM3_CORE_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
	hri_mclk_set_APBBMASK_SERCOM3_bit(MCLK);
	i2c_m_sync_init(&I2C_x, SERCOM3);
#elif I2C_SERCOMX == I2C_SERCOM4
	hri_gclk_write_PCHCTRL_reg(GCLK, SERCOM4_GCLK_ID_CORE, CONF_GCLK_SERCOM4_CORE_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
	hri_mclk_set_APBDMASK_SERCOM4_bit(MCLK);
	i2c_m_sync_init(&I2C_x, SERCOM4);
#elif I2C_SERCOMX == I2C_SERCOM5
	hri_gclk_write_PCHCTRL_reg(GCLK, SERCOM5_GCLK_ID_CORE, CONF_GCLK_SERCOM5_CORE_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
	hri_mclk_set_APBDMASK_SERCOM5_bit(MCLK);
	i2c_m_sync_init(&I2C_x, SERCOM5);
#endif

	i2c_m_sync_enable(&I2C_x);
	
	gpio_set_pin_direction(SDA, GPIO_DIRECTION_IN);
	gpio_set_pin_pull_mode(SDA, GPIO_PULL_UP);
	gpio_set_pin_function(SDA, SDA_FUNC);
	
	gpio_set_pin_direction(SCL, GPIO_DIRECTION_IN);
	gpio_set_pin_pull_mode(SCL, GPIO_PULL_UP);
	gpio_set_pin_function(SCL, SCL_FUNC);
	
	i2c_init = true;
	i2c_errors = 0;
}

int32_t I2Cx_Write_Bfr(uint8_t address, uint8_t reg, uint8_t *bfr, uint16_t length)
{
	struct io_descriptor *I2C_x_io;

	i2c_m_sync_get_io_descriptor(&I2C_x, &I2C_x_io);
	i2c_m_sync_set_slaveaddr(&I2C_x, address, I2C_M_SEVEN);

	return i2c_m_sync_cmd_write(&I2C_x, reg, bfr, length);
}

// First byte of buffer is register
int32_t I2Cx_Write_Sequence(uint8_t address, uint8_t *bfr, uint16_t length)
{
	struct io_descriptor *I2C_x_io;

	i2c_m_sync_get_io_descriptor(&I2C_x, &I2C_x_io);
	i2c_m_sync_set_slaveaddr(&I2C_x, address, I2C_M_SEVEN);

	return i2c_m_sync_cmd_writeseq(&I2C_x, bfr, length);
}

bool I2Cx_Check()
{
	if(i2c_errors > 2)
	{
		I2Cx_Init();
		i2c_errors = 0;
		return false;
	}
	return true;
}

int32_t I2Cx_Read_Bfr(uint8_t address, uint8_t reg, uint8_t *bfr, uint16_t length)
{
	struct io_descriptor *I2C_x_io;

	i2c_m_sync_get_io_descriptor(&I2C_x, &I2C_x_io);
	i2c_m_sync_set_slaveaddr(&I2C_x, address, I2C_M_SEVEN);
	int32_t res = i2c_m_sync_cmd_read(&I2C_x, reg, bfr, length);
	if(res != I2C_OK)
		i2c_errors++;
	else
		i2c_errors = 0;
	return res;
}

int32_t I2Cx_Read_16b(uint8_t address, uint8_t reg, uint16_t *val)
{
	uint8_t bfr[2];
	struct io_descriptor *I2C_x_io;

	i2c_m_sync_get_io_descriptor(&I2C_x, &I2C_x_io);
	i2c_m_sync_set_slaveaddr(&I2C_x, address, I2C_M_SEVEN);
	int32_t res = i2c_m_sync_cmd_read(&I2C_x, reg, bfr, 2);
	*val = ((uint16_t)bfr[0] << 8) + (uint16_t)bfr[1];
	
	if(res != I2C_OK)
		i2c_errors++;
	else
		i2c_errors = 0;
	return res;
}

int32_t I2Cx_Read_8b(uint8_t address, uint8_t reg, uint8_t *val)
{
	uint8_t bfr[2];
	struct io_descriptor *I2C_x_io;

	i2c_m_sync_get_io_descriptor(&I2C_x, &I2C_x_io);
	i2c_m_sync_set_slaveaddr(&I2C_x, address, I2C_M_SEVEN);
	int32_t res = i2c_m_sync_cmd_read(&I2C_x, reg, bfr, 1);
	*val = bfr[0];
	
	if(res != I2C_OK)
		i2c_errors++;
	return res;
}