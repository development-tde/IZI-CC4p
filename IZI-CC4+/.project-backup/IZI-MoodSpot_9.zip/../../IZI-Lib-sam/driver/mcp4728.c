/*
 * mcp4728.c
 *
 * Created: 5-12-2023 09:01:43
 *  Author: Milo
 */ 

#include "includes.h"
#include "mcp4728.h"
#include "i2cx.h"
#include "hpl_i2c_m_sync.h"

#define MCP4728_I2C_FAIL_MAX		3

#ifdef MCP4728_SEM
SemaphoreHandle_t	mcp4728Semaphore;
#endif

#define MCP4728_BFR_MAX			16
#define MCP4728_PAGE_MAX		0x100

uint8_t mcp4728_bfr[MCP4728_BFR_MAX + 1];
uint8_t mcp4728_fail;
bool mcp4728_init = false;

// DAC channel values (12-bit: 0-4095)
uint16_t mcp4728_dac_values[4] = {0, 0, 0, 0}; // Example: mid-range values
	
/************************************************************************/
/* Init I2C						                                        */
/************************************************************************/
bool Mcp4728_Init()
{
	I2Cx_Init();
#ifdef MCP4728_SEM	
	mcp4728Semaphore = xSemaphoreCreateMutex();
#endif
	
	gpio_set_pin_direction(LDAC, GPIO_DIRECTION_OUT);
	gpio_set_pin_pull_mode(LDAC, GPIO_PULL_OFF);
	gpio_set_pin_function(LDAC, GPIO_PIN_FUNCTION_OFF);
	PORT->Group[LDAC].OUTCLR.reg = 0x01 << LDAC_PIN;
	
	gpio_set_pin_direction(RDY, GPIO_DIRECTION_IN);
	gpio_set_pin_pull_mode(RDY, GPIO_PULL_UP);
	gpio_set_pin_function(RDY, GPIO_PIN_FUNCTION_OFF);
	
	// Multi-Write Command: Write Multiple DAC Input Registers.
	for (int i = 0; i < 4; i++) {
		uint8_t config = 0b10000000; // VREF=internal, gain=1x, PD=normal
		uint16_t val = mcp4728_dac_values[i];

		mcp4728_bfr[i * 3] = 0b01000000 + (i << 1);		// UDAC low, channel and VREF
		mcp4728_bfr[i * 3 + 1] = config | ((val >> 8) & 0x0F); // Upper nibble = config, lower nibble = DAC[11:8]
		mcp4728_bfr[i * 3 + 2] = val & 0xFF;                   // DAC[7:0]
	}

	if (I2Cx_Write_Sequence(MCP4728_I2C_ADDR, mcp4728_bfr, 12) >= 0)
	{
		mcp4728_init = true;
		State_ClearError(STATE_ERROR_HW_ERROR);
		mcp4728_fail = 0;
		return true;
	}
	
	mcp4728_fail = MCP4728_I2C_FAIL_MAX;
	State_SetError(STATE_ERROR_HW_ERROR);					// Report HW error
	
	return false;
}

/************************************************************************/
/* I2C init ready?				                                        */
/************************************************************************/
bool Mcp4728_InitReady()
{
	return mcp4728_init;
}

/************************************************************************/
/* Write DACs					                                        */
/************************************************************************/
int32_t Mcp4728_WriteDacs(uint16_t *dac_values)
{
	if(!mcp4728_init)
		return MCP4728_NO_INIT;
	
#ifdef MCP4728_SEM	
	if(xTaskGetSchedulerState() != taskSCHEDULER_NOT_STARTED)
		xSemaphoreTake (mcp4728Semaphore, 25);
#endif //MCP4728_SEM	
	memcpy(mcp4728_dac_values, dac_values, sizeof(mcp4728_dac_values));
	
	for (int i = 0; i < 4; i++) {
		mcp4728_bfr[i * 2]     = (dac_values[i] >> 8) & 0x0F; // Upper 4 bits only
		mcp4728_bfr[i * 2 + 1] = dac_values[i] & 0xFF;
	}

	PORT->Group[LDAC].OUTCLR.reg = 0x01 << LDAC_PIN;					// Hold LDAC low, when any 16 bit value is ACKED, the value is directly set
	int32_t res = I2Cx_Write_Sequence(MCP4728_I2C_ADDR, mcp4728_bfr, 8);
	
	if(res != I2C_OK)
	{
		if(++mcp4728_fail >= MCP4728_I2C_FAIL_MAX)
		{
			State_SetError(STATE_ERROR_HW_ERROR);					// Report HW error, no or bad com with DAC
		}
	}
	else
	{
		if(mcp4728_fail >= MCP4728_I2C_FAIL_MAX && mcp4728_fail == 0)
			State_ClearError(STATE_ERROR_HW_ERROR);				// Clear error when both are OK and if error was (probably reported) by the MCP
	}	

#ifdef MCP4728_SEM		
	if(xTaskGetSchedulerState() != taskSCHEDULER_NOT_STARTED)
		xSemaphoreGive(mcp4728Semaphore);
#endif
	return res;
}

int32_t Mcp4728_Write_EEPROM_2V048(uint16_t *dac_values) 
{
	if(!mcp4728_init)
		return MCP4728_NO_INIT;

#ifdef MCP4728_SEM
	if(xTaskGetSchedulerState() != taskSCHEDULER_NOT_STARTED)
		xSemaphoreTake (mcp4728Semaphore, 25);
#endif //MCP4728_SEM

	// Command byte: C2:C0 = 010 (Sequential Write), W1:W0 = 10 (Write DAC + EEPROM)
	mcp4728_bfr[0] = 0x50;

	for (int i = 0; i < 4; i++) {
		uint8_t config = 0b10000000;  // VREF=internal, gain=1x, PD=normal

		// High nibble: config | DAC[11:8], Low byte: DAC[7:0]
		mcp4728_bfr[i * 2 + 1] = config | ((dac_values[i] >> 8) & 0x0F);
		mcp4728_bfr[i * 2 + 2] = dac_values[i] & 0xFF;
	}

	// Total = 1 (command) + 8 (4x2 bytes) = 9 bytes
	int res = I2Cx_Write_Sequence(MCP4728_I2C_ADDR, mcp4728_bfr, 9);

#ifdef MCP4728_SEM	
	if(res >= 0)
		vTaskDelay(pdMS_TO_TICKS(50));
	
	if(xTaskGetSchedulerState() != taskSCHEDULER_NOT_STARTED)
		xSemaphoreGive(mcp4728Semaphore);
#endif

	return res;
}

/*bool Mcp4728_ReadConfig(uint8_t *vref_flags) {
	if (!mcp4728_init) 
		return false;

	// Each channel returns 6 bytes, 4 channels = 24 bytes
	uint8_t read_buf[24];
	if (I2Cx_Read_Bfr(MCP4728_I2C_ADDR, read_buf, 24) < 0)
		return false;

	for (int i = 0; i < 4; i++) {
		// EEPROM config starts at offset 0, every 6 bytes
		// Byte 1 contains VREF, gain, and power-down bits
		uint8_t config = read_buf[i * 6 + 1];

		// Bit 7 = VREF (0 = external, 1 = internal)
		vref_flags[i] = (config & 0x80) ? 1 : 0;
	}
	return true;
}*/