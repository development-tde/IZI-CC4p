/*
 * at30tse.h
 *
 * Created: 5-12-2023 09:02:02
 *  Author: Milo
 */ 


#ifndef MCP4725_H_
#define MCP4725_H_

#define MCP4725_OK				0
#define MCP4725_NO_INIT			-100
#define MCP4725_NO_MEM			-101
#define MCP4725_ADDR_ERR		-102

// Proto
void Mcp4725_Init();
bool Mcp4725_InitReady();
int32_t Mcp4725_WriteDac(uint8_t nr, uint16_t data);

#endif /* MCP4725_H_ */