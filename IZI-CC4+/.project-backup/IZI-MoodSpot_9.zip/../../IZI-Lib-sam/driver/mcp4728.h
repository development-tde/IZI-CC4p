/*
 * at30tse.h
 *
 * Created: 5-12-2023 09:02:02
 *  Author: Milo
 */ 


#ifndef MCP4728_H_
#define MCP4728_H_

#define MCP4728_I2C_ADDR		0x60 // Default I2C address
#define MCP4728_GENERAL_CALL_ADDR 0x00
#define MCP4728_EEPROM_WRITE_CMD  0x50

#define MCP4728_OK				0
#define MCP4728_NO_INIT			-100
#define MCP4728_NO_MEM			-101
#define MCP4728_ADDR_ERR		-102

// Proto
bool Mcp4728_Init();
bool Mcp4728_InitReady();
int32_t Mcp4728_WriteDacs(uint16_t *dac_values);
int32_t MCP4728_Write_EEPROM_2V048(uint16_t *dac_values);

#endif /* MCP4728_H_ */