/*
 * izi_can_frame.h
 *
 *  Created on: 6 jul. 2020
 *      Author: Milo
 */

#ifndef IZI_CAN_FRAME_H_
#define IZI_CAN_FRAME_H_

// Device groups
#define DEVTYPE_GROUP_POWERLINE		0x01
//#define DEVTYPE_GROUP_POWERLINE_R	0x02		// Retro
#define DEVTYPE_GROUP_IO			0x04

#define DEVTYPE_GROUP_TEST			0x0E		// Used for tester at the moment
#define DEVTYPE_BROADCAST			0x0F

#define DEVTYPE_GROUP_DMX_INTERFACE	0x80

// Address
#define ADDRESS_GROUPCAST			0x3F
#define ADDRESS_BROADCAST			0x3F
#define ADDRESS_WILDCARD			0x3F
#define MAX_ADDRESS					0x3F

#define ADDRESS_STATIC				0x40		// Used for static (non CAN modules)

// Direction
#define DIRECTION_TO_SLAVE			0			// from master to slave
#define DIRECTION_FROM_SLAVE		1			// from slave to master

// Universe
#define MAX_CAN_UNIVERSES			4

// Length
#define MAX_LENGTH_SINGLE			0x40
#define MAX_LENGTH_MULTI			0x100
#define MAX_LENGTH_CHANNEL			0x200

// Command
#define IZI_CAN_CMD_HEARTBEAT		0x00
#define IZI_CAN_CMD_DISCOVER		0x01
#define IZI_CAN_CMD_ASSIGN			0x02
#define IZI_CAN_CMD_POSITION		0x03
#define IZI_CAN_CMD_TIMING			0x04
#define IZI_CAN_CMD_NETWORK_START	IZI_CAN_CMD_HEARTBEAT
#define IZI_CAN_CMD_NETWORK_END		0x0F

#define IZI_CAN_CMD_BASE_SETCONFIG	0x10
#define IZI_CAN_CMD_BASE_GETCONFIG	0x11
#define IZI_CAN_CMD_BASE_DFLTCONFIG	0x12

#define IZI_CAN_CMD_BASE_STATE		0x15
#define IZI_CAN_CMD_BASE_IO_STATE	0x16
#define IZI_CAN_CMD_BASE_SET_OUTPUT	0x17
#define IZI_CAN_CMD_POWER_REPORT	0x18
#define IZI_CAN_CMD_MONITOR_REPORT	0x19

#define IZI_CAN_CMD_BASE_START		IZI_CAN_CMD_BASE_SETCONFIG
#define IZI_CAN_CMD_BASE_END		0x1F

#define IZI_CAN_CMD_LINK_DISCOVER		0x20
#define IZI_CAN_CMD_LINK_SETCONFIG		0x21
#define IZI_CAN_CMD_LINK_SETIDENTIFY	0x22
#define IZI_CAN_CMD_LINK_GETMODULE		0x23
#define IZI_CAN_CMD_LINK_MODULEREPORT	0x24
#define IZI_CAN_CMD_LINK_STATE			0x25
#define IZI_CAN_CMD_LINK_GETMONITOR		0x26
#define IZI_CAN_CMD_LINK_MONITORREPORT	0x27
#define IZI_CAN_CMD_LINK_START			IZI_CAN_CMD_LINK_SETCONFIG
#define IZI_CAN_CMD_LINK_END			0x2F

#define IZI_CAN_CMD_DBG_ENABLE		0xD0
#define IZI_CAN_CMD_DBG				0xD1
#define IZI_CAN_CMD_LOG_REPORT		0xD2
#define IZI_CAN_CMD_DBG_START		IZI_CAN_CMD_DBG_ENABLE
#define IZI_CAN_CMD_DBG_END			0xDF

#define IZI_CAN_CMD_PRODDATA_WRITE	0xE0

#define IZI_CAN_CMD_FW_START		0xF0
#define IZI_CAN_CMD_FW_WRITE		0xF1
#define IZI_CAN_CMD_FW_VERIFY		0xF2
#define IZI_CAN_CMD_FW_OFFSET		0xF3
#define IZI_CAN_CMD_FW_REBOOT		0xF4
#define IZI_CAN_CMD_FW_REBOOT_FAR	0xF5

// Message types
#define IZI_CAN_MSGTYPE_REQ			0x00
#define IZI_CAN_MSGTYPE_RSP			0x01
#define IZI_CAN_MSGTYPE_NOT			0x02

typedef struct izi_can_stdid_s
{
	uint32_t sector0 : 3;
	uint32_t seq_id : 2;
	uint32_t start_channel : 3;
	uint32_t universe : 2;
	uint32_t master_id : 1;				// Master id = Highest dominance
}izi_can_stdid_t;

typedef union
{
	izi_can_stdid_t bit;
	uint32_t all;
}izi_can_stdid_u;

typedef struct izi_can_extid_s
{
	uint32_t seq_id : 3;
	uint32_t index : 2;
	uint32_t total : 2;
	uint32_t master_id : 1;				// Master id (not used (yet))
	uint32_t address : 6;				// Address of slave
	uint32_t msg_type : 2;				// 0 = req, 1 = rsp, 2 = notification, 3 = fe
	uint32_t command : 8;
	uint32_t devtype_group : 4;			// Device type group
	uint32_t dir : 1;					// 0 = from master to slave, 1 = from slave to master = Highest dominance
}izi_can_extid_t;						// Note: messages are sent in order of the Tx buffer with lowest message ID by he Tx handler!

typedef union
{
	izi_can_extid_t bit;
	uint32_t all;
}izi_can_extid_u;

//------------------------------------------------------------------------------------------------------------
// Command structs
//------------------------------------------------------------------------------------------------------------

// Heartbeat
struct izican_not_masterheartbeat_s {
	uint32_t serial_master;
	uint32_t datetime;
	int16_t state;
} __attribute__((packed));

typedef struct izican_not_masterheartbeat_s izican_not_masterheartbeat_t;

#define HB_MAX_MONITOR	4

struct izican_not_slaveheartbeat_s {
	uint32_t serial_slave;
	int16_t state;
	uint16_t module_cnt;
	uint32_t app_version;
	uint16_t link_state;
	uint16_t temperature;
	uint16_t supply_voltage;
	uint16_t output_current;
	uint8_t monitor[HB_MAX_MONITOR];
	uint32_t error_flags;
	uint32_t warning_flags;
} __attribute__((packed));

typedef struct izican_not_slaveheartbeat_s izican_not_slaveheartbeat_t;

// Discover
#define IZI_CAN_DISCOVER_OPTION_CLEAN		0x01

struct izican_req_discover_s {
	uint32_t serial_master;
	uint8_t session_id;
	uint8_t options;
	uint16_t random_rsp;			// random response window time in ms
} __attribute__((packed));

typedef struct izican_req_discover_s izican_req_discover_t;

struct izican_rsp_discover_s {
	uint32_t serial_slave;
	uint8_t session_id;
	uint8_t options;
	uint16_t cfg_version;
	uint32_t app_version;
	uint32_t boot_version;
	char name[32];
	uint16_t module_cnt;
	uint8_t hw_id;
	uint8_t dev_id;
	uint8_t pl_frequency;			// PowerCom only
	uint8_t pl_rate;				// PowerCom only
	uint8_t timing_offset;			// PowerCom only
	uint8_t cfg_len;
	uint8_t config[8];			// First most important config
} __attribute__((packed));

typedef struct izican_rsp_discover_s izican_rsp_discover_t;

// Assign
struct izican_req_assign_s {
	uint32_t serial_slave;
	uint32_t serial_master;
	uint8_t address;
	uint8_t timing_offset;
} __attribute__((packed));

typedef struct izican_req_assign_s izican_req_assign_t;

struct izican_rsp_assign_s {
	uint32_t serial_slave;
	int8_t result;
} __attribute__((packed));

typedef struct izican_rsp_assign_s izican_rsp_assign_t;

// Timing
struct izican_req_timing_s {
	uint8_t timing_offset;
	uint8_t master_idx;
	uint8_t master_total;
} __attribute__((packed));

typedef struct izican_req_timing_s izican_req_timing_t;

struct izican_rsp_timing_s {
	int8_t result;
} __attribute__((packed));

typedef struct izican_rsp_timing_s izican_rsp_timing_t;

// Position
struct izican_req_position_s {
	uint8_t activate;
} __attribute__((packed));

typedef struct izican_req_position_s izican_req_position_t;

struct izican_rsp_position_s {
	int8_t state;
} __attribute__((packed));

typedef struct izican_rsp_position_s izican_rsp_position_t;


#define IZICAN_STATE_ERROR				-3
#define IZICAN_STATE_WARNING			-2
#define IZICAN_STATE_NOT_ASSIGNED		-1
#define IZICAN_STATE_INIT				1
// 1 .. 5		Reserved for reset cause
#define IZICAN_STATE_RESET_UNKNOWN		6		// Is also max reset states

#define IZICAN_STATE_OK					0

#define IZICAN_STATE_IDENTIFY			10

// ************** Base section *****************

// IZI_CAN_CMD_BASE_SETCONFIG
#define IZI_CAN_CMD_BASE_MINCONFIG	32
#define IZI_CAN_CMD_BASE_NAME_SIZE	30
#define IZI_CAN_CMD_BASE_CFG_SIZE	64

struct izican_req_base_setconfig_s {
	uint8_t name[IZI_CAN_CMD_BASE_NAME_SIZE];
	uint16_t location_id;
	uint8_t config[IZI_CAN_CMD_BASE_CFG_SIZE];
} __attribute__((packed));

typedef struct izican_req_base_setconfig_s izican_req_base_setconfig_t;

struct izican_rsp_base_setconfig_s {
	int8_t state;
} __attribute__((packed));

typedef struct izican_rsp_base_setconfig_s izican_rsp_base_setconfig_t;


// IZI_CAN_CMD_BASE_GETCONFIG
struct izican_req_base_getconfig_s {
	uint8_t options;
} __attribute__((packed));

typedef struct izican_req_base_getconfig_s izican_req_base_getconfig_t;

struct izican_rsp_base_getconfig_s {
	uint8_t name[IZI_CAN_CMD_BASE_NAME_SIZE];
	uint16_t location_id;
	uint8_t config[IZI_CAN_CMD_BASE_CFG_SIZE];
} __attribute__((packed));

typedef struct izican_rsp_base_getconfig_s izican_rsp_base_getconfig_t;

// IZI_CAN_CMD_BASE_DFLTCONFIG
#define DFLT_CONFIG_OPTION_ALL		0xA5

struct izican_req_base_dfltconfig_s {
	uint8_t options;
} __attribute__((packed));

typedef struct izican_req_base_dfltconfig_s izican_req_base_dfltconfig_t;

struct izican_rsp_base_dfltconfig_s {
	int8_t state;
} __attribute__((packed));

typedef struct izican_rsp_base_dfltconfig_s izican_rsp_base_dfltconfig_t;

#define BASE_STATE_MIN_LENTGH		16
#define BASE_STATE_NAME_LENGTH		32
// Base state (change) notification
struct izican_not_base_state_s {
	uint16_t state;
	uint16_t fe;
	uint32_t errors;
	uint32_t warnings;
	uint32_t init;
	char txt[BASE_STATE_NAME_LENGTH];
} __attribute__((packed));

typedef struct izican_not_base_state_s izican_not_base_state_t;

// IZI_CAN_CMD_BASE_IO_STATE
#define BASE_IO_STATE_MIN_LENTGH		8
#define BASE_IO_STATE_MAX_LENGTH		32
#define BASE_IO_STATE_OUTPUT_FLAG		0x80

struct izican_not_base_io_state_item_s {
	uint8_t level;
	uint8_t vmap;
} __attribute__((packed));

typedef struct izican_not_base_io_state_item_s izican_not_base_io_state_item_t;

// Base state (change) notification
struct izican_not_base_io_state_s {
	izican_not_base_io_state_item_t state[BASE_IO_STATE_MAX_LENGTH];
} __attribute__((packed));

typedef struct izican_not_base_io_state_s izican_not_base_io_state_t;

// IZI_CAN_CMD_BASE_SET_OUTPUT
#define BASE_IO_OUTSET_MIN_LENTGH		2
#define BASE_IO_OUTSET_MAX_LENGTH		32		// Max length = *2

struct izican_req_base_io_outset_item_s {
	uint8_t nr;
	uint8_t level;
} __attribute__((packed));

typedef struct izican_req_base_io_outset_item_s izican_req_base_io_outset_item_t;

// Base state (change) notification
struct izican_req_base_io_outputset_s {
	izican_req_base_io_outset_item_t io[BASE_IO_STATE_MAX_LENGTH];
} __attribute__((packed));

typedef struct izican_req_base_io_outputset_s izican_req_base_io_outputset_t;
typedef struct izican_req_base_io_outputset_s izican_not_base_io_outputset_t;

struct izican_rsp_base_outset_s {
	int8_t state;
} __attribute__((packed));

typedef struct izican_rsp_base_outset_s izican_rsp_base_outset_t;

//IZI_CAN_CMD_POWER_REPORT
#define POWER_REPORT_MIN_LENTGH			8
#define POWER_REPORT_DATA_LENGTH		28

// Power report notification
struct izican_not_power_report_s {
	uint8_t  minute;		// Time %60 minutes of newest log
	uint8_t  flags;			// No use yet
	uint8_t  amount;		// Amount of log data (can be less than 32)
	uint8_t  offset;		// Time between every log in minutes
	uint32_t total_energy;	// Total energy in Wh (since power-up)
	uint16_t data[POWER_REPORT_DATA_LENGTH];	// 16-bit Average power in �offset� minutes (in 0.1W), most recent log is sent first
} __attribute__((packed));

typedef struct izican_not_power_report_s izican_not_power_report_t;

// IZI_CAN_CMD_MONITOR_REPORT
#define MONITOR_REPORT_MIN_LENTGH		3
#define MONITOR_REPORT_DATA_LENGTH		62

// Power report notification
struct izican_not_monitor_report_s {
	uint8_t  length;		// Number of monitor values
	uint8_t  page;			// No use yet
	uint8_t values[MONITOR_REPORT_DATA_LENGTH];	// Monitor values (can be 16-bit LE)
} __attribute__((packed));

typedef struct izican_not_monitor_report_s izican_not_monitor_report_t;


// ************** Link section *****************

// Link set configuration
struct izican_req_link_discover_s {
	uint16_t options;
	uint8_t pl_frequency;
	uint8_t pl_rate;
} __attribute__((packed));

typedef struct izican_req_link_discover_s izican_req_link_discover_t;

// Link set configuration
struct izican_req_link_setconfig_s {
	uint32_t serial;
	uint16_t address;
	uint8_t mode;
	uint8_t dmxfail;
	uint8_t config[32];
	uint8_t txt[24];
} __attribute__((packed));

typedef struct izican_req_link_setconfig_s izican_req_link_setconfig_t;

struct izican_rsp_link_discover_s {
	int8_t result;
	uint8_t clear;
} __attribute__((packed));

typedef struct izican_rsp_link_discover_s izican_rsp_link_discover_t;

struct izican_rsp_link_setconfig_s {
	uint32_t serial;
	int8_t result;
} __attribute__((packed));

typedef struct izican_rsp_link_setconfig_s izican_rsp_link_setconfig_t;

// Link set configuration
struct izican_req_link_setidentify_s {
	uint32_t serial;
	uint16_t time;
	uint16_t mode;
} __attribute__((packed));

typedef struct izican_req_link_setidentify_s izican_req_link_setidentify_t;

struct izican_rsp_link_setidentify_s {
	uint32_t serial;
	int8_t result;
} __attribute__((packed));

typedef struct izican_rsp_link_setidentify_s izican_rsp_link_setidentify_t;

#define IZICAN_GETMODULE_DATA_SIZE	88			// Also part of IZI-Access, also part of memory content in flash, do not change
// Link get (izi)module
struct izican_req_link_getmodule_s {
	uint16_t module_idx;
} __attribute__((packed));

typedef struct izican_req_link_getmodule_s izican_req_link_getmodule_t;

struct izican_rsp_link_getmodule_s {
	uint16_t module_idx;
	uint16_t module_amount;
	uint8_t data[IZICAN_GETMODULE_DATA_SIZE];
} __attribute__((packed));

typedef struct izican_rsp_link_getmodule_s izican_rsp_link_getmodule_t;

// Link report (new or changed izi) module
struct izican_req_link_modulereport_s {
	uint16_t module_idx;
	uint16_t module_amount;
	uint8_t data[IZICAN_GETMODULE_DATA_SIZE];
} __attribute__((packed));

typedef struct izican_req_link_modulereport_s izican_req_link_modulereport_t;

#ifndef IZI_MODULE_MAX_ENCODERMAP
#define IZI_MODULE_MAX_ENCODERMAP 4
#endif

struct izican_rsp_link_modulereport_s {
	uint16_t module_idx;
	uint8_t channels;
	uint8_t config_amount;
	uint8_t monitor_amount;
	uint8_t monitor_status_idx;
	uint8_t monitor_input_idx;				// Max 8 inputs (flags)
	uint8_t monitor_encoder_idx[IZI_MODULE_MAX_ENCODERMAP];
} __attribute__((packed));

typedef struct izican_rsp_link_modulereport_s izican_rsp_link_modulereport_t;

#define IZICAN_MAX_SCAN_RES				32
#define IZICAN_MIN_NOT_STATE_SIZE		12
// Link state (change) notification
struct izican_not_link_state_s {
	uint16_t state;
	uint16_t module_amount;
	uint8_t pl_frequency;
	uint8_t pl_rate;
	uint16_t dmx_per_sec;
	uint8_t req_per_sec;
	uint8_t rsp_quality;
	uint8_t scan_amount;
	uint8_t channels;
	uint8_t scan_res[IZICAN_MAX_SCAN_RES];
} __attribute__((packed));

typedef struct izican_not_link_state_s izican_not_link_state_t;

#define LINK_STATE_IDLE				0
#define LINK_STATE_STARTUP			1
#define LINK_STATE_DISCOVER			2
#define LINK_STATE_SWITCH_FREQ		3
#define LINK_STATE_CONFIG_SYNC		4
#define LINK_STATE_SWITCH_FREQ2		5		// Switch to discover frequency
#define LINK_STATE_POWER_OFF		6
#define LINK_STATE_POWER_PROTECT	7		// Power off by overcurrent
#define LINK_STATE_POWER_LIMIT		8		// Power limited by dmx master decrease
#define LINK_STATE_LEVEL_OVERRULE	9		// Level overruled (by switch)
#define LINK_STATE_QUALITYSCAN		10
#define LINK_STATE_UPDATING			11
#define LINK_STATE_UPDATEREBOOT		12

#define LINK_STATE_UPDATING_CODE_0		16
#define LINK_STATE_UPDATING_CODE_20		17
#define LINK_STATE_UPDATING_CODE_40		18
#define LINK_STATE_UPDATING_CODE_60		19
#define LINK_STATE_UPDATING_CODE_80		20
#define LINK_STATE_UPDATING_CODE_100	21


// Link get (izi)monitor
struct izican_req_link_getmonitor_s {
	uint16_t module_idx;
} __attribute__((packed));

typedef struct izican_req_link_getmonitor_s izican_req_link_getmonitor_t;

#define IZICAN_MODULEREPORT_DATA_SIZE	56

struct izican_rsp_link_getmonitor_s {
	uint16_t module_idx;
	uint16_t serial_short;
	uint8_t data[IZICAN_MODULEREPORT_DATA_SIZE];
} __attribute__((packed));

typedef struct izican_rsp_link_getmonitor_s izican_rsp_link_getmonitor_t;

// Link report (new or changed izi) module
struct izican_req_link_monitorreport_s {
	uint16_t module_idx;
	uint16_t serial_short;
	uint8_t data[IZICAN_MODULEREPORT_DATA_SIZE];
} __attribute__((packed));

typedef struct izican_req_link_monitorreport_s izican_req_link_monitorreport_t;

struct izican_rsp_link_monitorreport_s {
	uint16_t module_idx;
	int8_t result;
} __attribute__((packed));

typedef struct izican_rsp_link_monitorreport_s izican_rsp_link_monitorreport_t;

// Production data write of CAN module
#define PRODDATA_MIN_SIZE		16			// Info and time may be skipped
#define BATCH_SIZE				11
#define PRODINFO_SIZE			12
struct izican_req_link_proddata_write_s {
	uint32_t serial;
	char batch[BATCH_SIZE];
	char plant;
	uint32_t time;
	char info[PRODINFO_SIZE];
} __attribute__((packed));

typedef struct izican_req_link_proddata_write_s izican_req_link_proddata_write_t;

struct izican_rsp_link_proddata_writereport_s {
	uint32_t serial;
	int8_t result;
} __attribute__((packed));

typedef struct izican_rsp_link_proddata_writereport_s izican_rsp_link_proddata_writereport_t;

#define IZICAN_LOGREPORT_DATA_SIZE	62

// Link report (new or changed izi) module
struct izican_req_dbg_logreport_s {
	uint8_t data[IZICAN_LOGREPORT_DATA_SIZE];
} __attribute__((packed));

typedef struct izican_req_dbg_logreport_s izican_req_dbg_logreport_t;

struct izican_rsp_dbg_logreport_s {
	int8_t result;
} __attribute__((packed));

typedef struct izican_rsp_dbg_logreport_s izican_rsp_dbg_logreport_t;

// ************** Firmware section *****************

typedef enum fw_mem_location_e
{
	fw_mem_flash = 0,
	fw_mem_ram = 1,
	fw_mem_invalid = 0xFF,
}fw_mem_location_t;

// Firmware start
struct izican_req_fw_start_s {
	uint32_t start_address;
	uint32_t firmware_size;
	uint8_t mem_location;
} __attribute__((packed));

typedef struct izican_req_fw_start_s izican_req_fw_start_t;

struct izican_rsp_fw_start_s {
	int8_t result;
	// Todo: extra device info??
} __attribute__((packed));

typedef struct izican_rsp_fw_start_s izican_rsp_fw_start_t;

// Firmware write
struct izican_req_fw_write_s {
	uint8_t data[MAX_LENGTH_MULTI];
} __attribute__((packed));

typedef struct izican_req_fw_write_s izican_req_fw_write_t;

struct izican_rsp_fw_write_s {
	uint32_t address;
	int8_t result;
} __attribute__((packed));

typedef struct izican_rsp_fw_write_s izican_rsp_fw_write_t;

// Firmware verify
struct izican_req_fw_verify_s {
	uint8_t options;
} __attribute__((packed));

typedef struct izican_req_fw_verify_s izican_req_fw_verify_t;

struct izican_rsp_fw_verify_s {
	int8_t result;
} __attribute__((packed));

typedef struct izican_rsp_fw_verify_s izican_rsp_fw_verify_t;

// Firmware offset
struct izican_req_fw_offset_s {
	uint32_t address;
} __attribute__((packed));

typedef struct izican_req_fw_offset_s izican_req_fw_offset_t;

struct izican_rsp_fw_offset_s {
	uint32_t address;
	int8_t result;
} __attribute__((packed));

typedef struct izican_rsp_fw_offset_s izican_rsp_fw_offset_t;

// Firmware reboot
struct izican_req_fw_reboot_s {
	uint8_t options;
} __attribute__((packed));

typedef struct izican_req_fw_reboot_s izican_req_fw_reboot_t;

struct izican_rsp_fw_reboot_s {
	uint8_t result;
} __attribute__((packed));

typedef struct izican_rsp_fw_reboot_s izican_rsp_fw_reboot_t;

// Firmware reboot
struct izican_req_fw_reboot_far_s {
	uint32_t device_id;
	uint8_t options;
	uint8_t fe;
	uint16_t type;
} __attribute__((packed));

typedef struct izican_req_fw_reboot_far_s izican_req_fw_reboot_far_t;

struct izican_rsp_fw_reboot_far_s {
	uint8_t result;
} __attribute__((packed));

typedef struct izican_rsp_fw_reboot_far_s izican_rsp_fw_reboot_far_t;

// ************** Debug section *****************

// Link state (change) notification
struct izican_not_dbg_report_s {
	char txt[MAX_LENGTH_MULTI];
} __attribute__((packed));

typedef struct izican_not_dbg_report_s izican_not_dbg_report_t;

//------------------------------------------------------------------------------------------------------------
// General command unions
//------------------------------------------------------------------------------------------------------------

typedef struct {
	union {
		izican_not_masterheartbeat_t master_hb;
		izican_not_slaveheartbeat_t slave_hb;
		izican_req_link_modulereport_t link_modulereport;
		izican_req_dbg_logreport_t dbg_logreport;
		izican_not_link_state_t link_state;
		izican_not_dbg_report_t dbg_report;
		izican_not_base_state_t base_state;
		izican_not_base_io_state_t base_io_state;
		izican_not_power_report_t power_report;
		izican_not_base_io_outputset_t outputset_state;
		izican_not_monitor_report_t monitor_report;
	} data;
} izican_notification_data_t;

typedef struct {
	union {
		izican_req_discover_t discover;
		izican_req_assign_t assign;
		izican_req_timing_t timing;
		izican_req_position_t position;
		izican_req_base_setconfig_t base_setconfig;
		izican_req_base_getconfig_t base_getconfig;
		izican_req_base_dfltconfig_t base_dfltconfig;
		izican_req_fw_start_t fw_start;
		izican_req_fw_write_t fw_write;
		izican_req_fw_verify_t fw_verify;
		izican_req_fw_offset_t fw_offset;
		izican_req_fw_reboot_t fw_reboot;
		izican_req_fw_reboot_far_t fw_reboot_far;
		izican_req_link_setconfig_t link_setconfig;
		izican_req_link_setidentify_t link_setidentify;
		izican_req_link_getmodule_t link_getmodule;
		izican_req_link_modulereport_t link_modulereport;
		izican_req_link_discover_t link_discover;
		izican_req_link_getmonitor_t link_getmonitor;
		izican_req_link_monitorreport_t link_monitorreport;
		izican_req_dbg_logreport_t link_logreport;
		izican_req_link_proddata_write_t link_prodata_write;
		izican_req_base_io_outputset_t outputset_state;
	} data;
} izican_request_data_t;

typedef struct {
	union {
		izican_rsp_discover_t discover;
		izican_rsp_assign_t assign;
		izican_rsp_timing_t timing;
		izican_rsp_position_t position;
		izican_rsp_base_setconfig_t base_setconfig;
		izican_rsp_base_getconfig_t base_getconfig;
		izican_rsp_base_dfltconfig_t base_dfltconfig;
		izican_rsp_base_outset_t base_outset;
		izican_rsp_fw_start_t fw_start;
		izican_rsp_fw_write_t fw_write;
		izican_rsp_fw_verify_t fw_verify;
		izican_rsp_fw_offset_t fw_offset;
		izican_rsp_fw_reboot_t fw_reboot;
		izican_rsp_fw_reboot_far_t fw_reboot_far;
		izican_rsp_link_setconfig_t link_setconfig;
		izican_rsp_link_setidentify_t link_setidentify;
		izican_rsp_link_getmodule_t link_getmodule;
		izican_rsp_link_modulereport_t link_modulereport;
		izican_rsp_link_discover_t link_discover;
		izican_rsp_link_getmonitor_t link_getmonitor;
		izican_rsp_link_monitorreport_t link_monitorreport;
		izican_rsp_dbg_logreport_t link_logreport;
		izican_rsp_link_proddata_writereport_t link_prodatareport;
	} data;
} izican_response_data_t;


#endif /* IZI_CAN_FRAME_H_ */
