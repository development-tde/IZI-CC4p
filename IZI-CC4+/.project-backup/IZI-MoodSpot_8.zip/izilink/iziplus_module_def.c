/*
 * iziplus_module_def.c
 *
 * Created: 26-2-2022 17:28:14
 *  Author: Milo
 */ 

#include "includes.h"
#include "iziplus_module_def.h"
#include "version.h"
#include "appconfig.h"
#include "iziplus_dataframe.h"
#include "iziplus_driver.h"
#include "stepdown.h"
#include "analog.h"
#include "izi_output.h"
#include "at30tse.h"
#include "crc.h"
#include "11LC160.h"
#include "dmx.h"


#define TEMP_MAX_RESOLUTION			2000					// Max calculation for resolution of temp and power reduce, checked per 100ms
#define TEMP_LIMIT_START_OFFSET		5						// 5 degrees before limit the power reduce will start
#define MAX_INTERN_TEMP				100						// Max 100 degrees intern (110 = off, from 110 - TEMP_LIMIT_START_OFFSET reduce will start)
#define MAX_NTC_TEMP				90						// Max 90 degrees intern (95 = off, from 95 - TEMP_LIMIT_START_OFFSET reduce will start)
#define POWER_MAX_RESOLUTION		TEMP_MAX_RESOLUTION		// 0.05% per 100ms
#define POWER_MAX					70050					// in 1mW

#define MODE_CTRL_UNKNOWN		0
#define MODE_CTRL_RGBW			1
#define MODE_CTRL_TW			2
#define MODE_CTRL_WD			3
#define MODE_CTRL_DIRECT		4			// No RGBW/Tunable/WD just dim

uint8_t module_channels_amount = 0;			// AMount of channels in current mode
iziplus_cpustate_u module_cpu_state;
uint8_t module_monitor[IZI_MAX_MONITOR];
uint8_t module_config[IZI_MAX_CONFIG];
uint16_t module_identify_time = 0, module_identify_prs = 0, module_identify_mode = 0, module_identify_unlock_time = 0;
uint16_t module_pup_time  = 0;
uint16_t module_reset_report;
uint8_t module_mode_switch, module_mode = MODE_CTRL_UNKNOWN;
extern uint8_t reset_cause;

static bool iziplus_last_comcheck = false;
static uint8_t iziplus_prs_comcheck = 0;
static uint16_t iziplus_data_wasok = false;					// Has light data ever been received?

volatile uint8_t overrule_level_chx[MAX_DIM_CHANNELS];					// Overrule level, overriding channel level
volatile uint16_t overrule_time_chx = 0;								// Time to overrule channel level
volatile uint8_t overrule_prio_chx = 0;
static uint16_t iziplus_level_chx[MAX_DIM_CHANNELS];
static uint16_t iziplus_master_zero_time = 0;
uint16_t iziplus_devtype;
int16_t iziplus_emitter_state = 0;

uint16_t ntc_temp_master = TEMP_MAX_RESOLUTION;				// NTC reduce in promille
uint16_t intern_temp_master = TEMP_MAX_RESOLUTION;			// Intern temp reduce in promille

volatile int16_t max_intern_temp_raw = 0, limit_intern_temp_raw;
volatile int16_t max_ntc_temp_raw = 0, limit_ntc_temp_raw;

uint16_t power_master = TEMP_MAX_RESOLUTION;
uint32_t iziplus_maxpower;

uint8_t timer_prs = 0;

//uint8_t monitor_timer_idx_prs = 0;
uint8_t monitor_idx = 0, monitor_idx_ext = 0;

uint16_t monitor_avg_level[MAX_DIM_CHANNELS];

extern volatile stepdown_control_t stepdown_ctrl_chx[MAX_DIM_CHANNELS];

iziplus_fixture_def	iziplus_fixdef;
emitter_fixture_def emitter_fixdef;
bool emitter_fixdef_ok = false;
uint16_t  iziplus_config_size;
uint16_t  iziplus_monitor_size;
bool iziplus_init_rdy = false;

// Proto
void print_resetcause();
bool IziPlus_Module_CreateFixEmitter();

void IziPlus_Module_Fixture_Wrgb();
void IziPlus_Module_Fixture_Atw();
void IziPlus_Module_Fixture_Unknown();
bool IziPlus_Module_SetFixtureParameters();

extern const uint8_t ntc_table[512];
extern boot_t boot_data;

int16_t Adc_GetTempRaw(uint8_t degrees)
{
	for(uint16_t i = 0; i < 512; i++)
	{
		if(ntc_table[i] == degrees)
		{
			return (int16_t)(i << 3);				// Give back raw value of AD (convert 8 to 12 bit)
		}
	}
	return -1;
}

uint16_t Adc_GetTintRaw()
{
	return 3000;
}

/************************************************************************/
/* Code                                                                 */
/************************************************************************/
bool IziPlus_GetDevType()
{
	iziplus_devtype = (get_device_id() == 1 ? IZIPLUS_DEVTYPE_MS_HP : IZIPLUS_DEVTYPE_MS_MP) + emitter_fixdef.id;
	
	if(emitter_fixdef.max_channels > MAX_DIM_CHANNELS)
		return false;
	
	for(int i = 0; i < emitter_fixdef.max_channels; i++)
	{
		if(emitter_fixdef.patch_rgbw[i] > MAX_DIM_CHANNELS)
			return false;
	}
	
	return true;
}

// Init current parameters
bool IziPlus_Module_Init()
{
	bool res = true;
	//print_resetcause();
	
	module_reset_report = 30;		// Report reset cause for 3 seconds
	module_cpu_state.w = 0;
	if(reset_cause == RESET_CAUSE_POWER_UP)
		module_cpu_state.u.powerup = true;
	else if(reset_cause == RESET_CAUSE_EXTRST)
		module_cpu_state.u.extreset = true;
	else if(reset_cause == RESET_CAUSE_BOD)
		module_cpu_state.u.brownout = true;
	else if(reset_cause == RESET_CAUSE_SYSRST)
		module_cpu_state.u.sw_reset = true;
	else if(reset_cause == RESET_CAUSE_WATCHDOG)
		module_cpu_state.u.watchdog = true;
	
#ifndef MS_TEST_NO_EMITTER
	M11LC160_Init();
#endif
	
	//uint8_t variant = IziPlus_Module_GetVariant();
	//if(variant > VARIANT_EMITTER)
	//	IziPlus_Module_CreateVariant(variant);
	//else
		res = IziPlus_Module_CreateFixEmitter();
	
	emitter_fixdef_ok = res;
	
	if(emitter_fixdef_ok)
	{
		if(appConfig->default_ok != APPCFG_DFLT_OK || /*appConfig->variant != variant ||*/ appConfig->typeid != emitter_fixdef.id)		// Different emitter, different variant, default incomplete (when emitter was not known yet)
			AppConfig_Default();				// Do a default and set appConfig->typeid
		else
			AppConfig_CheckConfig();			// Check if all config is within limits
	}
	IziPlus_GetDevType();						// Make sure the right color tables are assigned
	IziPlus_Module_Update();
	
	iziplus_init_rdy = true;
	
#ifndef MS_TEST_NO_EMITTER
	memset(monitor_avg_level, 0, sizeof(monitor_avg_level));
	AppEmitterLog_Get();						// Read log when iziplus_init_rdy is set to true, so communication can start
#endif
	
	return res;
}

bool IziPlus_Module_InitReady()
{
	return iziplus_init_rdy;
}

void IziPlus_Module_CheckDefinitions()
{
	uint16_t crc = Crc16((uint8_t *)&emitter_fixdef, sizeof(emitter_fixdef) - 2, 0);
	if(crc != emitter_fixdef.crc)
	{
		State_SetError(STATE_ERROR_EMITTER_DATA);
		//uint8_t variant = IziPlus_Module_GetVariant();
		//if(variant > VARIANT_EMITTER)
		//	IziPlus_Module_CreateVariant(variant);
		//else
			emitter_fixdef_ok = IziPlus_Module_CreateFixEmitter();		// Todo: What todo if it fails
	}
	else
		State_ClearError(STATE_ERROR_EMITTER_DATA);
}

volatile int32_t res2 = 0;
bool IziPlus_Module_CreateFixEmitter()
{
#if !(defined(MS_MEASURE) || defined(MS_TEMPCORR_OFF) || defined(MS_TEST_NO_EMITTER))
	if((res2 = M11LC160_ReadMem((uint8_t *)&emitter_fixdef, EXT_EEPROM_ADRR_FIXTURE, sizeof(emitter_fixdef))) < 0)			// Read the emitter
	{
		res2 = M11LC160_ReadMem((uint8_t *)&emitter_fixdef, EXT_EEPROM_ADRR_FIXTURE, sizeof(emitter_fixdef));				// Retry once if needed
	}
	
	if(res2 >= 0)					// Read OK?
	{
		IziPlus_GetDevType();
#else
		IziPlus_GetDevType();
		if((iziplus_devtype & 0xFFE0) == IZIPLUS_DEVTYPE_MS_HP)
#ifdef 	MS_LOAD_TW
			IziPlus_Module_WriteEmitter_ATW_HP(true);
#else
			IziPlus_Module_WriteEmitter_WRGB_HP(true);
#endif			
		else
#ifdef 	MS_LOAD_TW		
			IziPlus_Module_WriteEmitter_ATW_MP(true);
#else			
			IziPlus_Module_WriteEmitter_WRGB_MP(true);
#endif
#endif
		uint16_t crc = Crc16((uint8_t *)&emitter_fixdef, sizeof(emitter_fixdef) - 2, 0);
		if(crc != emitter_fixdef.crc || emitter_fixdef.max_channels > MAX_DIM_CHANNELS)					// CRC in emitter OK? And doesn't it exceed the number of channels available?
		{
			State_SetError(STATE_ERROR_NO_EMITTER);
			iziplus_emitter_state = -2;											// Incorrect data
			IziPlus_Module_SetFixtureParameters();
		}
		else
		{
			if(emitter_fixdef.variant > 0 && emitter_fixdef.variant != (get_device_id() + 1))
			{
				State_SetError(STATE_ERROR_EMITTER_TYPE);
				iziplus_emitter_state = -4;										// No match with variant of PCB
			}
			else if(!IziPlus_Module_SetFixtureParameters())						// Set correct monitor and config parameters
			{																	// Type not known?
				State_SetError(STATE_ERROR_EMITTER_TYPE);
				iziplus_emitter_state = -3;										// Unknown type
			}
		}
#if !(defined(MS_MEASURE) || defined(MS_TEMPCORR_OFF) || defined(MS_TEST_NO_EMITTER))
	}
	else
	{
		State_SetError(STATE_ERROR_NO_EMITTER);
		iziplus_emitter_state = -1;												// No emitter
		IziPlus_Module_SetFixtureParameters();
	}
#endif
	
	return iziplus_emitter_state >= 0;
}

bool IziPlus_Module_SetFixtureParameters()
{
	if(emitter_fixdef.id == IZIPLUS_DEVOFFS_HP_WRGB || emitter_fixdef.id == IZIPLUS_DEVOFFS_MP_WRGB)	// WRGB emitter
		IziPlus_Module_Fixture_Wrgb();					// Load known settings
	else if(emitter_fixdef.id == IZIPLUS_DEVOFFS_HP_ATW || emitter_fixdef.id == IZIPLUS_DEVOFFS_MP_ATW)	// ATW emitter
		IziPlus_Module_Fixture_Atw();					// Load known settings
	else
	{
		IziPlus_Module_Fixture_Unknown();
		return false;
	}
	
	iziplus_config_size = 0;
	for(int i = 0; i < iziplus_fixdef.max_configs; i++)
		iziplus_config_size += iziplus_fixdef.configs[i].size;
	
	iziplus_monitor_size = 0;
	for(int i = 0; i < iziplus_fixdef.max_monitors; i++)
		iziplus_monitor_size += iziplus_fixdef.monitors[i].size;
		
	return true;
}


void IziPlus_Module_WriteEmitter_WRGB_HP(bool load_only)
{
#ifdef MS_MEASURE		
	emitter_fixdef.version = 99;
#else
	emitter_fixdef.version = 0x01;			// V0.1
#endif
	emitter_fixdef.id = IZIPLUS_DEVOFFS_HP_WRGB;					// WRGB
	emitter_fixdef.hwref = 1;
	emitter_fixdef.variant = 2;				// Variant to match (donut, 0 = all)
	emitter_fixdef.max_channels = 4;
	//iziplus_fixdef.max_current = 1458;		// Max current = 0.7A (not used, use max_current_ch!!!)
	emitter_fixdef.max_power = 70050;		// Max power = 70.05W (0.05 is offset for component deviations)
	emitter_fixdef.tw3000K = 122;			// 3000K level
	emitter_fixdef.tw4000K = 170;			// 4000K level
	emitter_fixdef.tw_gain = 100;			// 100% in TW mode, so the 70W is not reached over the complete range
	emitter_fixdef.wd_gain = 100;			// 100% in WD mode, so the 70W is not reached over the complete range
	
	const uint32_t test_lvls[MAX_DIM_CHANNELS] = {0x00000008, 0x00000800, 0x00080000, 0x08000000 };
	memcpy(emitter_fixdef.test_lvls, test_lvls, MAX_DIM_CHANNELS * 4);								// Button test levels
	
	// Channel 1: White
	// Channel 2: Red
	// Channel 3: Green
	// Channel 4: Blue
	
#ifdef MS_MEASURE	
	const uint8_t rgbw_sensitivity[MAX_DIM_CHANNELS] = { 255, 255, 255, 255 };
#else		
	const uint8_t rgbw_sensitivity[MAX_DIM_CHANNELS] = { 255, 224, 255, 184 };
#endif		
	memcpy(emitter_fixdef.rgbw_sensitivity, rgbw_sensitivity, MAX_DIM_CHANNELS);					// RGBW Sensitivity in channel order
	
#if defined(MS_MEASURE) || defined(MS_TEMPCORR_OFF)
	const uint16_t corr_tjc_tables[MAX_DIM_CHANNELS] = { 0, 0, 0, 0 };
#else
	const uint16_t corr_tjc_tables[MAX_DIM_CHANNELS] = { 0, 120, 22, 22 };
#endif
	memcpy(emitter_fixdef.corr_tjc_tables, corr_tjc_tables, MAX_DIM_CHANNELS * 2);                  // Constant for Dtjc calculation (in channel order)
	
#if defined(MS_MEASURE) || defined(MS_TEMPCORR_OFF)
	const int16_t corr_temp_tables[MAX_DIM_CHANNELS] = { 0, 0, 0, 0 };
#else
	const int16_t corr_temp_tables[MAX_DIM_CHANNELS] = { 0, 201, 36, -27 };
#endif
	memcpy(emitter_fixdef.corr_temp_tables, corr_temp_tables, MAX_DIM_CHANNELS * 2);                // Color correction factor (0 = no correction)
	
	const uint16_t fw_voltage_tables[MAX_DIM_CHANNELS] = { 39000, 39000, 30000, 18000 };
	memcpy(emitter_fixdef.fw_voltage_tables, fw_voltage_tables, MAX_DIM_CHANNELS * 2);				// Forward Voltage of the LEDs on DIM1 channel (in patched order!)
	const uint8_t fw_minvoltage_tables[MAX_DIM_CHANNELS] = { 31000 >> 8, 30000 >> 8, 28000 >> 8, 17000 >> 8 };	 
	memcpy(emitter_fixdef.fw_minvoltage_tables, fw_minvoltage_tables, MAX_DIM_CHANNELS);			// Min Forward Voltage of the LEDs on DIM1 channel (in patched order!)
	
	const uint16_t fw_max_current_tables[MAX_DIM_CHANNELS] = { 1600, 800, 800, 800 };
	memcpy(emitter_fixdef.max_current_ch, fw_max_current_tables, MAX_DIM_CHANNELS * 2);
	
	const uint8_t bbc_red[MAX_COLOR_ITEMS] = { 146,	146,	146,	146,	147,	146,	64,	46,	26,	9,	0,	0,	0,	0,	0,	0,	0 };
	memcpy(emitter_fixdef.bbc_chx[1], bbc_red, MAX_COLOR_ITEMS);
	const uint8_t bbc_green[MAX_COLOR_ITEMS] = { 38,	43,	49,	55,	64,	75,	45,	58,	70,	80,	94,	112,	126,	136,	146,	156,	171 };
	memcpy(emitter_fixdef.bbc_chx[2], bbc_green, MAX_COLOR_ITEMS);
	const uint8_t bbc_blue[MAX_COLOR_ITEMS] = { 0,	0,	0,	0,	3,	5,	7,	23,	40,	62,	82,	99,	119,	143,	164,	182,	228 };
	memcpy(emitter_fixdef.bbc_chx[3], bbc_blue, MAX_COLOR_ITEMS);
	const uint8_t bbc_white[MAX_COLOR_ITEMS] = { 0,	11,	23,	46,	65,	92,	185,	218,	230,	228,	224,	214,	205,	197,	189,	182,	169 };
	memcpy(emitter_fixdef.bbc_chx[0], bbc_white, MAX_COLOR_ITEMS);
	
	uint8_t t_idx = (emitter_fixdef.tw3000K + emitter_fixdef.tw4000K) >> 5;
	emitter_fixdef.indicate_lvl = (bbc_red[t_idx] << 0) + (bbc_green[t_idx] << 8) + (bbc_blue[t_idx] << 16) + (bbc_white[t_idx] << 24);
	
	const uint8_t patch_rgbw[MAX_DIM_CHANNELS] = { 3, 0, 1, 2 };		// Swapped, Patch is used to where the Red Green Blue and White come from in incoming data
	memcpy(emitter_fixdef.patch_rgbw, patch_rgbw, MAX_DIM_CHANNELS);
	
	emitter_fixdef.crc = Crc16((uint8_t *)&emitter_fixdef, sizeof(emitter_fixdef) - 2, 0);
	if(!load_only)
	{
		OS_TRACE_ERROR("Write emitter: %d\r\n", sizeof(emitter_fixdef));
		if(M11LC160_WriteMem((uint8_t *)&emitter_fixdef, EXT_EEPROM_ADRR_FIXTURE, sizeof(emitter_fixdef)) != 0)
			State_SetError(STATE_ERROR_NO_EMITTER);
	}
}

void IziPlus_Module_WriteEmitter_ATW_HP(bool load_only)
{
#ifdef MS_MEASURE
	emitter_fixdef.version = 99;
#else
	emitter_fixdef.version = 0x01;			// V0.1
#endif
	emitter_fixdef.id = IZIPLUS_DEVOFFS_HP_ATW;					// ATW HP
	emitter_fixdef.hwref = 1;
	emitter_fixdef.variant = 2;				// Variant to match (donut, 0 = all)
	emitter_fixdef.max_channels = 4;
	//iziplus_fixdef.max_current = 1458;		// Max current = 0.7A (not used, use max_current_ch!!!)
	emitter_fixdef.max_power = 70050;		// Max power = 70.05W (0.05 is offset for component deviations)
	emitter_fixdef.tw3000K = 122;			// 3000K level
	emitter_fixdef.tw4000K = 170;			// 4000K level
	emitter_fixdef.tw_gain = 100;			// 100% in TW mode, so the 70W is not reached over the complete range
	emitter_fixdef.wd_gain = 100;			// 100% in WD mode, so the 70W is not reached over the complete range
	
	const uint32_t test_lvls[MAX_DIM_CHANNELS] = {0x00000008, 0x00000800, 0x00080000, 0x08000000 };
	memcpy(emitter_fixdef.test_lvls, test_lvls, MAX_DIM_CHANNELS * 4);								// Button test levels
	
	// Channel 1: White
	// Channel 2: Green
	// Channel 3: Red
	// Channel 4: Red
	
#ifdef MS_MEASURE
	const uint8_t rgbw_sensitivity[MAX_DIM_CHANNELS] = { 255, 255, 255, 255 };
#else
	const uint8_t rgbw_sensitivity[MAX_DIM_CHANNELS] = { 255, 255, 255, 255 };
#endif
	memcpy(emitter_fixdef.rgbw_sensitivity, rgbw_sensitivity, MAX_DIM_CHANNELS);					// RGBW Sensitivity in channel order
	
#if defined(MS_MEASURE) || defined(MS_TEMPCORR_OFF)
	const uint16_t corr_tjc_tables[MAX_DIM_CHANNELS] = { 0, 0, 0, 0 };
#else
	const uint16_t corr_tjc_tables[MAX_DIM_CHANNELS] = { 0,  0, 0, 0 };
#endif
	memcpy(emitter_fixdef.corr_tjc_tables, corr_tjc_tables, MAX_DIM_CHANNELS * 2);                  // Constant for Dtjc calculation (in channel order)
	
#if defined(MS_MEASURE) || defined(MS_TEMPCORR_OFF)
	const int16_t corr_temp_tables[MAX_DIM_CHANNELS] = { 0, 0, 0, 0 };
#else
	const int16_t corr_temp_tables[MAX_DIM_CHANNELS] = { 0,  0, 0, 0 };
#endif
	memcpy(emitter_fixdef.corr_temp_tables, corr_temp_tables, MAX_DIM_CHANNELS * 2);                // Color correction factor (0 = no correction)
	
	const uint16_t fw_voltage_tables[MAX_DIM_CHANNELS] = { 36000, 30000, 24000, 24000 };
	memcpy(emitter_fixdef.fw_voltage_tables, fw_voltage_tables, MAX_DIM_CHANNELS * 2);				// Forward Voltage of the LEDs on DIM1 channel (in patched order!)
	const uint8_t fw_minvoltage_tables[MAX_DIM_CHANNELS] = { 28000 >> 8, 22000 >> 8, 19000 >> 8, 19000 >> 8 };
	memcpy(emitter_fixdef.fw_minvoltage_tables, fw_minvoltage_tables, MAX_DIM_CHANNELS);			// Min Forward Voltage of the LEDs on DIM1 channel (in patched order!)
	
	const uint16_t fw_max_current_tables[MAX_DIM_CHANNELS] = { 1600, 800, 800, 800 };
	memcpy(emitter_fixdef.max_current_ch, fw_max_current_tables, MAX_DIM_CHANNELS * 2);
	
	const uint8_t bbc_white[MAX_COLOR_ITEMS] = { 2,	6,	11,	21,	36,	55,	72,	88,	108,	127,	146,	166,	183,	201,	220,	236,	255 };
	memcpy(emitter_fixdef.bbc_chx[0], bbc_white, MAX_COLOR_ITEMS);
	const uint8_t bbc_green[MAX_COLOR_ITEMS] = {73,	105,	139,	170,	199,	222,	222,	221,	211,	197,	187,	168,	149,	129,	104,	86,	58 };
	memcpy(emitter_fixdef.bbc_chx[1], bbc_green, MAX_COLOR_ITEMS);
	const uint8_t bbc_red[MAX_COLOR_ITEMS] = { 249,	249,	249,	249,	249,	244,	218,	194,	172,	151,	129,	111,	91,	73,	59,	42,	30 };
	memcpy(emitter_fixdef.bbc_chx[2], bbc_red, MAX_COLOR_ITEMS);
	const uint8_t bbc_red2[MAX_COLOR_ITEMS] = { 249,	249,	249,	249,	249,	244,	218,	194,	172,	151,	129,	111,	91,	73,	59,	42,	30 };
	memcpy(emitter_fixdef.bbc_chx[3], bbc_red, MAX_COLOR_ITEMS);
	
	uint8_t t_idx = (emitter_fixdef.tw3000K + emitter_fixdef.tw4000K) >> 5;
	emitter_fixdef.indicate_lvl = (bbc_white[t_idx] << 0) + (bbc_green[t_idx] << 8) + (bbc_red[t_idx] << 16) + (bbc_red2[t_idx] << 24);
	
	const uint8_t patch_rgbw[MAX_DIM_CHANNELS] = { 2, 1, 0, 0 };		// Swapped, Patch is used to where the Red Green Blue and White come from in incoming data
	memcpy(emitter_fixdef.patch_rgbw, patch_rgbw, MAX_DIM_CHANNELS);
	
	emitter_fixdef.crc = Crc16((uint8_t *)&emitter_fixdef, sizeof(emitter_fixdef) - 2, 0);
	if(!load_only)
	{
		OS_TRACE_ERROR("Write emitter: %d\r\n", sizeof(emitter_fixdef));
		if(M11LC160_WriteMem((uint8_t *)&emitter_fixdef, EXT_EEPROM_ADRR_FIXTURE, sizeof(emitter_fixdef)) != 0)
			State_SetError(STATE_ERROR_NO_EMITTER);
	}
}

void IziPlus_Module_WriteEmitter_WRGB_MP(bool load_only)
{
#ifdef MS_MEASURE
	emitter_fixdef.version = 99;
#else
	emitter_fixdef.version = 0x01;			// V0.1
#endif
	emitter_fixdef.id = IZIPLUS_DEVOFFS_MP_WRGB;					// WRGB
	emitter_fixdef.hwref = 1;
	emitter_fixdef.variant = 1;				// Variant to match (donut, 0 = all)
	emitter_fixdef.max_channels = 4;
	//iziplus_fixdef.max_current = 1458;		// Max current = 0.7A (not used, use max_current_ch!!!)
	emitter_fixdef.max_power = 35050;		// Max power = 35.05W (0.05 is offset for component deviations)
	emitter_fixdef.tw3000K = 122;			// 3000K level
	emitter_fixdef.tw4000K = 170;			// 4000K level
	emitter_fixdef.tw_gain = 100;			// 100% in TW mode, so the 70W is not reached over the complete range
	emitter_fixdef.wd_gain = 100;			// 100% in WD mode, so the 70W is not reached over the complete range
	
	const uint32_t test_lvls[MAX_DIM_CHANNELS] = {0x00000008, 0x00000800, 0x00080000, 0x08000000 };
	memcpy(emitter_fixdef.test_lvls, test_lvls, MAX_DIM_CHANNELS * 4);								// Button test levels
	
	// Channel 1: Red
	// Channel 2: Green
	// Channel 3: Blue
	// Channel 4: White
	
#ifdef MS_MEASURE
	const uint8_t rgbw_sensitivity[MAX_DIM_CHANNELS] = { 255, 255, 255, 255 };
#else
	const uint8_t rgbw_sensitivity[MAX_DIM_CHANNELS] = { 224, 255, 184, 255 };
#endif
	memcpy(emitter_fixdef.rgbw_sensitivity, rgbw_sensitivity, MAX_DIM_CHANNELS);					// RGBW Sensitivity (in channel order)
	
#if defined(MS_MEASURE) || defined(MS_TEMPCORR_OFF)
	const uint16_t corr_tjc_tables[MAX_DIM_CHANNELS] = { 0, 0, 0, 0 };
#else
	const uint16_t corr_tjc_tables[MAX_DIM_CHANNELS] = { 120, 22, 22, 0 };
#endif
	memcpy(emitter_fixdef.corr_tjc_tables, corr_tjc_tables, MAX_DIM_CHANNELS * 2);                  // Constant for Dtjc calculation (in channel order)
	
#if defined(MS_MEASURE) || defined(MS_TEMPCORR_OFF)
	const int16_t corr_temp_tables[MAX_DIM_CHANNELS] = { 0, 0, 0, 0 };
#else
	const int16_t corr_temp_tables[MAX_DIM_CHANNELS] = { 201, 36, -27, 0 };
#endif
	memcpy(emitter_fixdef.corr_temp_tables, corr_temp_tables, MAX_DIM_CHANNELS * 2);                // Color correction factor (0 = no correction)
	
	const uint16_t fw_voltage_tables[MAX_DIM_CHANNELS] = { 20000, 12000, 9000, 39000 };
	memcpy(emitter_fixdef.fw_voltage_tables, fw_voltage_tables, MAX_DIM_CHANNELS * 2);				// Forward Voltage of the LEDs on DIM1 channel (in patched order!)
	const uint8_t fw_minvoltage_tables[MAX_DIM_CHANNELS] = { 13000 >> 8, 8000 >> 8, 6000 >> 8, 31000 >> 8 };
	memcpy(emitter_fixdef.fw_minvoltage_tables, fw_minvoltage_tables, MAX_DIM_CHANNELS);			// Min Forward Voltage of the LEDs on DIM1 channel (in patched order!)
	
	const uint16_t fw_max_current_tables[MAX_DIM_CHANNELS] = { 800, 800, 800, 800 };
	memcpy(emitter_fixdef.max_current_ch, fw_max_current_tables, MAX_DIM_CHANNELS * 2);
	
	const uint8_t bbc_red[MAX_COLOR_ITEMS] = { 142,	142,	142,	120,	93,	70,	40,	20,	0,	0,	0,	0,	0,	0,	0,	0,	0 };
	memcpy(emitter_fixdef.bbc_chx[0], bbc_red, MAX_COLOR_ITEMS);
	const uint8_t bbc_green[MAX_COLOR_ITEMS] = { 91,	119,	146,	141,	157,	172,	165,	163,	162,	177,	197,	210,	222,	227,	227,	227,	227 };
	memcpy(emitter_fixdef.bbc_chx[1], bbc_green, MAX_COLOR_ITEMS);
	const uint8_t bbc_blue[MAX_COLOR_ITEMS] = { 0,	0,	0,	0,	23,	43,	65,	86,	102,	127,	145,	163,	181,	192,	199,	205,	211 };
	memcpy(emitter_fixdef.bbc_chx[2], bbc_blue, MAX_COLOR_ITEMS);
	const uint8_t bbc_white[MAX_COLOR_ITEMS] = { 0,	13,	49,	178,	183,	185,	199,	205,	213,	202,	192,	184,	176,	166,	154,	145,	137 };
	memcpy(emitter_fixdef.bbc_chx[3], bbc_white, MAX_COLOR_ITEMS);
	
	uint8_t t_idx = (emitter_fixdef.tw3000K + emitter_fixdef.tw4000K) >> 5;
	emitter_fixdef.indicate_lvl = (bbc_red[t_idx] << 0) + (bbc_green[t_idx] << 8) + (bbc_blue[t_idx] << 16) + (bbc_white[t_idx] << 24);
	
	const uint8_t patch_rgbw[MAX_DIM_CHANNELS] = { 0, 1, 2, 3 };		// Normal, Patch is used to where the Red Green Blue and White come from in incoming data
	memcpy(emitter_fixdef.patch_rgbw, patch_rgbw, MAX_DIM_CHANNELS);
	
	emitter_fixdef.crc = Crc16((uint8_t *)&emitter_fixdef, sizeof(emitter_fixdef) - 2, 0);
	if(!load_only)
	{
		OS_TRACE_ERROR("Write emitter MP: %d\r\n", sizeof(emitter_fixdef));
		if(M11LC160_WriteMem((uint8_t *)&emitter_fixdef, EXT_EEPROM_ADRR_FIXTURE, sizeof(emitter_fixdef)) != 0)
			State_SetError(STATE_ERROR_NO_EMITTER);
	}
}

void IziPlus_Module_WriteEmitter_ATW_MP(bool load_only)
{
#ifdef MS_MEASURE
	emitter_fixdef.version = 99;
#else
	emitter_fixdef.version = 0x01;			// V0.1
#endif
	emitter_fixdef.id = IZIPLUS_DEVOFFS_MP_ATW;					// ATW MP
	emitter_fixdef.hwref = 1;
	emitter_fixdef.variant = 1;				// Variant to match (donut, 0 = all)
	emitter_fixdef.max_channels = 3;
	//iziplus_fixdef.max_current = 1458;		// Max current = 0.7A (not used, use max_current_ch!!!)
	emitter_fixdef.max_power = 35050;		// Max power = 35.05W (0.05 is offset for component deviations)
	emitter_fixdef.tw3000K = 122;			// 3000K level
	emitter_fixdef.tw4000K = 170;			// 4000K level
	emitter_fixdef.tw_gain = 100;			// 100% in TW mode, so the 70W is not reached over the complete range
	emitter_fixdef.wd_gain = 100;			// 100% in WD mode, so the 70W is not reached over the complete range
	
	const uint32_t test_lvls[MAX_DIM_CHANNELS] = {0x00000008, 0x00000800, 0x00080000, 0x08000000 };
	memcpy(emitter_fixdef.test_lvls, test_lvls, MAX_DIM_CHANNELS * 4);								// Button test levels
	
	// Channel 1: White
	// Channel 2: Red
	// Channel 3: Green
	// Channel 4: -
	
#ifdef MS_MEASURE
	const uint8_t rgbw_sensitivity[MAX_DIM_CHANNELS] = { 255, 255, 255, 255 };
#else
	const uint8_t rgbw_sensitivity[MAX_DIM_CHANNELS] = { 255, 255, 255, 255 };
#endif
	memcpy(emitter_fixdef.rgbw_sensitivity, rgbw_sensitivity, MAX_DIM_CHANNELS);					// RGBW Sensitivity in channel order
	
#if defined(MS_MEASURE) || defined(MS_TEMPCORR_OFF)
	const uint16_t corr_tjc_tables[MAX_DIM_CHANNELS] = { 0, 0, 0, 0 };
#else
	const uint16_t corr_tjc_tables[MAX_DIM_CHANNELS] = { 0,  0, 0, 0 };
#endif
	memcpy(emitter_fixdef.corr_tjc_tables, corr_tjc_tables, MAX_DIM_CHANNELS * 2);                  // Constant for Dtjc calculation (in channel order)
	
#if defined(MS_MEASURE) || defined(MS_TEMPCORR_OFF)
	const int16_t corr_temp_tables[MAX_DIM_CHANNELS] = { 0, 0, 0, 0 };
#else
	const int16_t corr_temp_tables[MAX_DIM_CHANNELS] = { 0,  0, 0, 0 };
#endif
	memcpy(emitter_fixdef.corr_temp_tables, corr_temp_tables, MAX_DIM_CHANNELS * 2);                // Color correction factor (0 = no correction)
	
	const uint16_t fw_voltage_tables[MAX_DIM_CHANNELS] = { 36000, 15000, 24000, 24000 };
	memcpy(emitter_fixdef.fw_voltage_tables, fw_voltage_tables, MAX_DIM_CHANNELS * 2);				// Forward Voltage of the LEDs on DIM1 channel (in patched order!)
	const uint8_t fw_minvoltage_tables[MAX_DIM_CHANNELS] = { 28000 >> 8, 11000 >> 8, 19000 >> 8, 19000 >> 8 };
	memcpy(emitter_fixdef.fw_minvoltage_tables, fw_minvoltage_tables, MAX_DIM_CHANNELS);			// Min Forward Voltage of the LEDs on DIM1 channel (in patched order!)
	
	const uint16_t fw_max_current_tables[MAX_DIM_CHANNELS] = { 800, 800, 800, 0 };
	memcpy(emitter_fixdef.max_current_ch, fw_max_current_tables, MAX_DIM_CHANNELS * 2);
	
	const uint8_t bbc_white[MAX_COLOR_ITEMS] = { 2, 6,	11,	21,	36,	55,	72,	88,	108, 127, 146, 164, 183, 200, 220, 236, 255 };
	memcpy(emitter_fixdef.bbc_chx[0], bbc_white, MAX_COLOR_ITEMS);
	const uint8_t bbc_green[MAX_COLOR_ITEMS] = {73, 105, 139, 170,	199, 222, 222, 221,	211, 197, 187, 167,	148, 129, 104, 86, 58 };
	memcpy(emitter_fixdef.bbc_chx[2], bbc_green, MAX_COLOR_ITEMS);
	const uint8_t bbc_red[MAX_COLOR_ITEMS] = { 249, 249, 249, 249, 249, 244, 218, 194, 172, 151, 129, 110, 91, 73, 59, 42, 30 };
	memcpy(emitter_fixdef.bbc_chx[1], bbc_red, MAX_COLOR_ITEMS);
	const uint8_t bbc_none[MAX_COLOR_ITEMS] = { 0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0 };
	memcpy(emitter_fixdef.bbc_chx[3], bbc_none, MAX_COLOR_ITEMS);
	
	uint8_t t_idx = (emitter_fixdef.tw3000K + emitter_fixdef.tw4000K) >> 5;
	emitter_fixdef.indicate_lvl = (bbc_white[t_idx] << 0) + (bbc_green[t_idx] << 8) + (bbc_red[t_idx] << 16) + (bbc_none[t_idx] << 24);
	
	const uint8_t patch_rgbw[MAX_DIM_CHANNELS] = { 2, 0, 1, 2 };		// Swapped, Patch is used to where the Red Green Blue and White come from in incoming data
	memcpy(emitter_fixdef.patch_rgbw, patch_rgbw, MAX_DIM_CHANNELS);
	
	emitter_fixdef.crc = Crc16((uint8_t *)&emitter_fixdef, sizeof(emitter_fixdef) - 2, 0);
	if(!load_only)
	{
		OS_TRACE_ERROR("Write emitter: %d\r\n", sizeof(emitter_fixdef));
		if(M11LC160_WriteMem((uint8_t *)&emitter_fixdef, EXT_EEPROM_ADRR_FIXTURE, sizeof(emitter_fixdef)) != 0)
			State_SetError(STATE_ERROR_NO_EMITTER);
	}
}

void IziPlus_Module_Fixture_Unknown()
{
	memset(&emitter_fixdef, 0, sizeof(emitter_fixdef));
	emitter_fixdef.id = appConfig->typeid != 0xFF ? (appConfig->typeid & 0x1F) : 0;					// Report as last detected type
	
	iziplus_fixdef.max_modes = 0;
	iziplus_fixdef.max_configs = 0;
	iziplus_config_size = 0;
	
	iziplus_fixdef.max_monitors = 0;
	iziplus_monitor_size = 0;
}

void IziPlus_Module_Fixture_Wrgb()
{
	strcpy(iziplus_fixdef.model_name, (get_device_id() == 1 ? "MoodSpot+ WRGB1465-HP" : "MoodSpot+ WRGB1465-MP"));
	iziplus_fixdef.max_modes = 10;
	const iziplus_mode_def modes[10] =
	{
		{ .channels = 5, .name = "Master RGBW",			.rgbw_chan = 1, .master_chan = 0, .tw_chan = -1, .control_chan = -1, .flags = 0 },
		{ .channels = 4, .name = "RGBW", 				.rgbw_chan = 0, .master_chan = -1, .tw_chan = -1, .control_chan = -1, .flags = 0 },
		{ .channels = 2, .name = "TrueTW", 				.rgbw_chan = -1, .master_chan = 0, .tw_chan = 1, .control_chan = -1, .flags = 0 },			// MODE_TRUE_TW
		{ .channels = 1, .name = "TrueWD", 				.rgbw_chan = -1, .master_chan = 0, .tw_chan = 0, .control_chan = -1, .flags = MODE_FLASH_WD_SINGLE },			// MODE_TRUE_WD
		{ .channels = 6, .name = "Dynamic Auto 6Ch",	.rgbw_chan = 2, .master_chan = 0, .tw_chan = 1, .control_chan = -2, .flags = MODE_FLASH_AUTO },
		{ .channels = 6, .name = "Dynamic Select 6Ch",  .rgbw_chan = 1, .master_chan = 0, .tw_chan = 4, .control_chan = 5, .flags = 0 },
		{ .channels = 7, .name = "Dynamic Select 7Ch",  .rgbw_chan = 2, .master_chan = 0, .tw_chan = 1, .control_chan = 6, .flags = 0 },
		{ .channels = 3, .name = "TrueTW 16-bit", 		.rgbw_chan = -1, .master_chan = 0, .tw_chan = 2, .control_chan = -1, .flags = MODE_FIRST_16B },			// MODE_TRUE_TW
		{ .channels = 2, .name = "TrueWD 16-bit", 		.rgbw_chan = -1, .master_chan = 0, .tw_chan = 0, .control_chan = -1, .flags = MODE_FLASH_WD_SINGLE | MODE_FIRST_16B },			// MODE_TRUE_WD
		{ .channels = 7, .name = "Dynamic Select 6Ch 16-bit",  .rgbw_chan = 2, .master_chan = 0, .tw_chan = 5, .control_chan = 6, .flags = MODE_FIRST_16B },
	};
	memcpy(iziplus_fixdef.modes, modes, sizeof(modes));
	
	iziplus_fixdef.max_configs = 3;
	const iziplus_config_def configs[3] =
	{
		{ .size = 1, .idx = 0, .ref = 26/*, .name = "Maximum Output"*/, .min = 0, .max = 100, .dflt = 100 },
		{ .size = 1, .idx = 1, .ref = 32/*, .name = "TTW CCT Color Range"*/, .min = 0, .max = 1, .dflt = 0},
		{ .size = 1, .idx = 2, .ref = 34/*, .name = "Filter mode"*/, .min = 0, .max = 3, .dflt = 0 },
	};		// check CONFIG_SIZE if changed
	memcpy(iziplus_fixdef.configs, configs, sizeof(configs));
	
	/*iziplus_config_size = 0;
	for(int i = 0; i < iziplus_fixdef.max_configs; i++)
		iziplus_config_size += iziplus_fixdef.configs[i].size;
	*/
	iziplus_fixdef.max_monitors = 19;
	const iziplus_monitor_def monitors[19] =
	{
		{ .size = 1, .idx = 0,  .ref = 1,  /*.name = "Supply Voltage" */ },
		{ .size = 1, .idx = 1,  .ref = 19, /*.name = "Com Quality" */ },
		{ .size = 1, .idx = 2,  .ref = 24  /*.name = "Power" */ },
		{ .size = 1, .idx = 3,  .ref = 23, /*.name = "Output" */ },
		{ .size = 1, .idx = 4,  .ref = 4,  /*.name = "Internal Temp" */ },
		{ .size = 1, .idx = 5,  .ref = 3,  /*.name = "LED Temp" */ },
		{ .size = 1, .idx = 6,  .ref = 13, /*.name = "Max IntTemp" */ },
		{ .size = 1, .idx = 7,  .ref = 12, /*.name = "Max LEDTemp" */ },
		{ .size = 2, .idx = 8,  .ref = 32, /*.name = "Uptime" */ },
		{ .size = 2, .idx = 10, .ref = 35, /*.name = "Operating time" */ },
		{ .size = 1, .idx = 12, .ref = 21, /*.name = "Status" */ },
		{ .size = 1, .idx = 13, .ref = 34, /*.name = "Min output" */ },
		{ .size = 1, .idx = 14, .ref = 31, /*.name = "Min supply voltage" */ },
		{ .size = 2, .idx = 15, .ref = 30, /*.name = "Forward voltage White" */ },
		{ .size = 2, .idx = 17, .ref = 33, /*.name = "On time per channel" */ },
		{ .size = 2, .idx = 19, .ref = 37, /*.name = "Average level per channel" */ },
		{ .size = 2, .idx = 21, .ref = 42, /*.name = "Operating temperature" */ },
		{ .size = 2, .idx = 23, .ref = 36, /*.name = "Frequency per channel" */ },
		{ .size = 2, .idx = 25, .ref = 43, /*.name = "Debug" */ },
	};		// MONITOR_SIZE
	memcpy(iziplus_fixdef.monitors, monitors, sizeof(monitors));
	/*iziplus_monitor_size = 0;
	for(int i = 0; i < iziplus_fixdef.max_monitors; i++)
		iziplus_monitor_size += iziplus_fixdef.monitors[i].size;	*/
}

void IziPlus_Module_Fixture_Atw()
{
	strcpy(iziplus_fixdef.model_name, (get_device_id() == 1 ? "MoodSpot+ WRGB1465-HP" : "MoodSpot+ WRGB1465-MP"));
	iziplus_fixdef.max_modes = 5;
	const iziplus_mode_def modes[5] =
	{
		{ .channels = 2, .name = "TrueTW", 		.rgbw_chan = -1, .master_chan = 0, .tw_chan = 1, .control_chan = -1, .flags = 0 },
		{ .channels = 1, .name = "TrueWD", 		.rgbw_chan = -1, .master_chan = 0, .tw_chan = 0, .control_chan = -1, .flags = MODE_FLASH_WD_SINGLE },
		{ .channels = 3, .name = "TrueTW 16-bit", 		.rgbw_chan = -1, .master_chan = 0, .tw_chan = 2, .control_chan = -1, .flags = MODE_FIRST_16B },
		{ .channels = 2, .name = "TrueWD 16-bit", 		.rgbw_chan = -1, .master_chan = 0, .tw_chan = 0, .control_chan = -1, .flags = MODE_FLASH_WD_SINGLE|MODE_FIRST_16B },
		{ .channels = 4, .name = "Master RLW",			.rgbw_chan = 1, .master_chan = 0, .tw_chan = -1, .control_chan = -1, .flags = 0 },
	};
	memcpy(iziplus_fixdef.modes, modes, sizeof(modes));
	
	iziplus_fixdef.max_configs = 3;
	const iziplus_config_def configs[3] =
	{
		{ .size = 1, .idx = 0, .ref = 26/*, .name = "Maximum Output"*/, .min = 0, .max = 100, .dflt = 100 },
		{ .size = 1, .idx = 1, .ref = 32/*, .name = "TTW CCT Color Range"*/, .min = 0, .max = 1, .dflt = 0},
		{ .size = 1, .idx = 2, .ref = 34/*, .name = "Filter mode"*/, .min = 0, .max = 3, .dflt = 0 },
	};		// check CONFIG_SIZE if changed
	memcpy(iziplus_fixdef.configs, configs, sizeof(configs));
	
	/*iziplus_config_size = 0;
	for(int i = 0; i < iziplus_fixdef.max_configs; i++)
		iziplus_config_size += iziplus_fixdef.configs[i].size;
	*/
	iziplus_fixdef.max_monitors = 19;
	const iziplus_monitor_def monitors[19] =
	{
		{ .size = 1, .idx = 0,  .ref = 1,  /*.name = "Supply Voltage" */ },
		{ .size = 1, .idx = 1,  .ref = 19, /*.name = "Com Quality" */ },
		{ .size = 1, .idx = 2,  .ref = 24  /*.name = "Power" */ },
		{ .size = 1, .idx = 3,  .ref = 23, /*.name = "Output" */ },
		{ .size = 1, .idx = 4,  .ref = 4,  /*.name = "Internal Temp" */ },
		{ .size = 1, .idx = 5,  .ref = 3,  /*.name = "LED Temp" */ },
		{ .size = 1, .idx = 6,  .ref = 13, /*.name = "Max IntTemp" */ },
		{ .size = 1, .idx = 7,  .ref = 12, /*.name = "Max LEDTemp" */ },
		{ .size = 2, .idx = 8,  .ref = 32, /*.name = "Uptime" */ },
		{ .size = 2, .idx = 10, .ref = 35, /*.name = "Operating time" */ },
		{ .size = 1, .idx = 12, .ref = 21, /*.name = "Status" */ },
		{ .size = 1, .idx = 13, .ref = 34, /*.name = "Min output" */ },
		{ .size = 1, .idx = 14, .ref = 31, /*.name = "Min supply voltage" */ },
		{ .size = 2, .idx = 15, .ref = 30, /*.name = "Forward voltage White" */ },
		{ .size = 2, .idx = 17, .ref = 33, /*.name = "On time per channel" */ },
		{ .size = 2, .idx = 19, .ref = 37, /*.name = "Average level per channel" */ },
		{ .size = 2, .idx = 21, .ref = 42, /*.name = "Operating temperature" */ },
		{ .size = 2, .idx = 23, .ref = 36, /*.name = "Frequency per channel" */ },
		{ .size = 2, .idx = 25, .ref = 43, /*.name = "Debug" */ },
	};		// MONITOR_SIZE
	memcpy(iziplus_fixdef.monitors, monitors, sizeof(monitors));
	/*iziplus_monitor_size = 0;
	for(int i = 0; i < iziplus_fixdef.max_monitors; i++)
		iziplus_monitor_size += iziplus_fixdef.monitors[i].size;	*/
}

/************************************************************************/
/* Call after every config write and after init                         */
/************************************************************************/
void IziPlus_Module_Update()
{
	if(appConfig->mode < MODE_AMOUNT)
		module_channels_amount = iziplus_fixdef.modes[appConfig->mode].channels;
	
	max_intern_temp_raw = Adc_GetTempRaw(MAX_INTERN_TEMP);
	limit_intern_temp_raw = Adc_GetTempRaw(MAX_INTERN_TEMP - TEMP_LIMIT_START_OFFSET);
	max_ntc_temp_raw = Adc_GetTempRaw(MAX_NTC_TEMP);
	limit_ntc_temp_raw = Adc_GetTempRaw(MAX_NTC_TEMP - TEMP_LIMIT_START_OFFSET);
	
	module_mode_switch = 0;					// Indicate to go off (while switching)
}

bool IziPlus_Module_TemperatureCheck(int16_t temp, uint16_t *temp_master, int16_t max_config, int16_t limit_config)
{
	if(temp <= limit_config)			// Temp above limit, reduce level (looks weird because value gets lower on a higher temperature, because the raw ad value is used)
	{
		if(temp > max_config)			// Still under max temp (where it should be 0)
		{
			uint16_t level_limit = (temp - max_config) * (TEMP_MAX_RESOLUTION / (limit_config - max_config));
			if(*temp_master > level_limit)
			{
				if(((*temp_master - level_limit) >= 128) && (*temp_master >= 4))
					*temp_master -= 4;		// -1 is 0.20% per 100ms
				else if(*temp_master > 0)
					*temp_master -= 1;		// -1 is 0.05% per 100ms
			}
			else if((*temp_master < level_limit) && (*temp_master < TEMP_MAX_RESOLUTION))
				*temp_master += 1;
		}
		else if(*temp_master > 10)		// Faster (max 10s) to 0% when on or over limit
			*temp_master -= 10;
		else
			*temp_master = 0;
		
		return true;					// Report temp too high, still reducing
	}
	else if(*temp_master < (TEMP_MAX_RESOLUTION - 10))
	{
		*temp_master += 10;
		return true;					// Report temp too high, still reducing
	}
	else
		*temp_master = TEMP_MAX_RESOLUTION;
	
	return false;					// Report temp too high, still reducing
}

bool IziPlus_Module_TemperatureCelciusCheck(int16_t temp, uint16_t *temp_master, int16_t max_config, int16_t limit_config)
{
	if(temp >= limit_config)			// Temp above limit, reduce level (looks weird because value gets lower on a higher temperature, because the raw ad value is used)
	{
		if(temp < max_config)			// Still under max temp (where it should be 0)
		{
			uint16_t level_limit = (max_config - temp) * (TEMP_MAX_RESOLUTION / (max_config - limit_config));
			if(*temp_master > level_limit)
			{
				if(((*temp_master - level_limit) >= 128) && (*temp_master >= 4))
					*temp_master -= 4;		// -1 is 0.20% per 100ms
				else if(*temp_master > 0)
					*temp_master -= 1;		// -1 is 0.05% per 100ms
			}
			else if((*temp_master < level_limit) && (*temp_master < TEMP_MAX_RESOLUTION))
				*temp_master += 1;
		}
		else if(*temp_master > 10)		// Faster (max 10s) to 0% when on or over limit
			*temp_master -= 10;
		else
			*temp_master = 0;
		
		return true;					// Report temp too high, still reducing
	}
	else if(*temp_master < (TEMP_MAX_RESOLUTION - 10))
	{
		*temp_master += 10;
		return true;					// Report temp too high, still reducing
	}
	else
		*temp_master = TEMP_MAX_RESOLUTION;
	
	return false;					// Report temp too high, still reducing
}

uint32_t IziPlus_Module_TempLimit(uint32_t level)
{
	uint16_t temp_master = intern_temp_master > ntc_temp_master ? ntc_temp_master : intern_temp_master;		// Take the lowest level
	if(power_master < temp_master)
		temp_master = power_master;
	
	if(temp_master < TEMP_MAX_RESOLUTION)
		level = (uint64_t)((uint64_t)level * (uint64_t)temp_master)/TEMP_MAX_RESOLUTION;
	
	return level;
}

//static uint16_t reducing = 0;
//static uint32_t last_power = 0;
bool IziPlus_Module_PowerCheck()
{
	uint16_t last_power_master = power_master;
	uint32_t power = StepDown_GetPower();
	uint16_t delta = 0;
	
	iziplus_maxpower = emitter_fixdef.max_power > POWER_MAX ? POWER_MAX : emitter_fixdef.max_power;
	if(power > iziplus_maxpower)
	{
		/*if(last_power < power)
		{
			if(reducing < 4)
				reducing++;
		}*/
			
		delta = (power - iziplus_maxpower) / 64; // (64 >> (reducing / 2));
		if(delta == 0)
			delta = 1;
		else if(delta > 256)
			delta = 256;
			
		if(power_master < delta)
			power_master = 0;
		else
			power_master -= delta;
		
		//power_master = (POWER_MAX_RESOLUTION * iziplus_maxpower) / power;
	}
	else if(power_master < POWER_MAX_RESOLUTION)
	{
		//reducing = 0;
		delta = (iziplus_maxpower - power) / 64; 
		if(delta == 0)
			delta = 1;
		else if(delta > 256)
			delta = 256;
		
		if(power_master + delta > POWER_MAX_RESOLUTION)
			power_master = POWER_MAX_RESOLUTION;
		else
			power_master += delta;
	}
	else
	{
		//reducing = 0;
		power_master = POWER_MAX_RESOLUTION;
	}
	//stepdown_ctrl_chx[0].test = power;
	//stepdown_ctrl_chx[0].test2 = delta;
	
	power_master = Filter_LowPass(last_power_master, power_master, 3);
	//last_power = power;
	
	return power_master != POWER_MAX_RESOLUTION;					// Report power too high, still reducing = true
}

/*
 * 100 ms timer timed by OS. Do not call OS routines from here
 */
void IziPlus_Module_Timer100ms()
{
	if(++module_identify_prs >= 10)
		module_identify_prs = 0;
	if(overrule_time_chx > 0)
		overrule_time_chx--;
		
	if(module_reset_report > 0)
	{
		if(--module_reset_report == 0)
		{
			module_cpu_state.u.powerup = false;		// Clear reset cause
			module_cpu_state.u.extreset = false;
			module_cpu_state.u.brownout = false;
			module_cpu_state.u.sw_reset = false;
			module_cpu_state.u.watchdog = false;
			IziPlus_Module_Update();
		}
	}
	
	if(Analog_Ready())
	{
		if(IziPlus_Module_TemperatureCheck(Adc_GetNtcRaw(), &ntc_temp_master,  max_ntc_temp_raw,  limit_ntc_temp_raw))
			State_SetWarning(STATE_WARNING_NTC1_HIGH);
		else
			State_ClearWarning(STATE_WARNING_NTC1_HIGH);
	
		if(IziPlus_Module_TemperatureCheck(Adc_GetTemperatureRaw(), &intern_temp_master, max_intern_temp_raw, limit_intern_temp_raw))
			State_SetWarning(STATE_WARNING_TEMP_HIGH);
		else
			State_ClearWarning(STATE_WARNING_TEMP_HIGH);
	}
		
	if(module_identify_time > 0)
	{
		if(--module_identify_time > 0)
		{
			if(module_identify_mode == IZIPLUS_IDENTMODE_BLINK)
			{
				if(module_identify_prs == 1)
					IziPlus_Module_Overrule_Ch1234(emitter_fixdef.indicate_lvl, 500, PRIO_OVERRULE_HIGH);
				else if(module_identify_prs == 6)
					IziPlus_Module_Overrule_Ch1234(0, 500, PRIO_OVERRULE_HIGH);
			}
			else if(module_identify_mode == IZIPLUS_IDENTMODE_SPOTON)
			{
				IziPlus_Module_Overrule_Ch1234(emitter_fixdef.indicate_lvl, 1000, PRIO_OVERRULE_HIGH);
			}
			else if(module_identify_mode == IZIPLUS_IDENTMODE_QUALITY)
			{
				for(int i = 0; i < emitter_fixdef.max_channels; i++)
				{
					uint8_t level = (iziplus_data_comquality() * (uint8_t)(emitter_fixdef.indicate_lvl >> (i * 8))) / 100;
					IziPlus_Module_Overrule_Chx(i, level, 1000, PRIO_OVERRULE_HIGH);
				}
			}
			else if(module_identify_unlock_time)
			{
				if(module_identify_mode == IZIPLUS_IDENTMODE_FACTORY_DFLT)
				{
					State_SetAttentionInfo(COLOR_RED, COLOR_WHITE, 4, 2);
					AppConfig_Default();
					AppLog_Default(false);
				}
				else if(module_identify_mode == IZIPLUS_IDENTMODE_MAX_DFLT)
				{
					State_SetAttentionInfo(COLOR_RED, COLOR_PINK, 4, 2);
					AppLog_Default(false);
				}
				else if(module_identify_mode == IZIPLUS_IDENTMODE_MAXALL_DFLT)
				{
					State_SetAttentionInfo(COLOR_RED, COLOR_BLUE, 4, 2);
					AppLog_Default(true);
				}
				else if(module_identify_mode == IZIPLUS_IDENTMODE_EMITTER_DFLT)
				{
					State_SetAttentionInfo(COLOR_BLUE, COLOR_WHITE, 4, 2);
					AppEmitterLog_Default();
				}
				else if(module_identify_mode == IZIPLUS_IDENTMODE_RESET)
				{
					StepDown_Close(1000);
					vTaskDelay(200);
					AppLog_Set();
					
					boot_data.action = BOOT_ACTION_STARTAPP;					// Reboot
					boot_data.magic = BOOT_MAGIC_VALUE;
					NVIC_SystemReset();
				}
			}
		}
		else
		{
			IziPlus_Module_Overrule_Ch1234(0, 0, PRIO_OVERRULE_HIGH);
			module_cpu_state.u.identify = 0;
		}
	}
	if(++timer_prs >= 10)
	{
		appLogData->operating_sec++;
		emitterLogData->operating_sec++;
		for(int i = 0; i < emitter_fixdef.max_channels; i++)
		{
			if(iziplus_level_chx[i])
			{
				appLogData->active_sec++;
				break;
			}
		}
		for(int i = 0; i < emitter_fixdef.max_channels; i++)
		{
			uint8_t patch_idx = emitter_fixdef.patch_rgbw[i];			// Show as WRGB
			uint8_t perc = StepDown_GetDutyPercentage(patch_idx);
			if(perc > 0)
			{
				emitterLogData->active_ch_sec[patch_idx]++;
				monitor_avg_level[patch_idx] += perc;
				//OS_TRACE_ERROR("Asec[%d]: %d, lvl: %d %d (%d)\r\n", patch_idx, emitterLogData->active_ch_sec[patch_idx], monitor_avg_level[patch_idx], perc, emitterLogData->level_sum_ch[patch_idx]);
				if((emitterLogData->active_ch_sec[patch_idx]) % 60 == 0)		// Minute passed while this channel was on?
				{
					emitterLogData->level_sum_ch[patch_idx] += (monitor_avg_level[patch_idx] / 60);
					monitor_avg_level[patch_idx] = 0;
				}
				uint16_t ntc = Adc_GetNtc();
				if(ntc < 40)
					emitterLogData->temp_sum_u40[patch_idx]++;
				else if(ntc < 60)
					emitterLogData->temp_sum_u60[patch_idx]++;
				else if(ntc < 80)
					emitterLogData->temp_sum_u80[patch_idx]++;
				else 
					emitterLogData->temp_sum_a80[patch_idx]++;
				//OS_TRACE_ERROR("Tsec[%d]: %d, %d, %d, %d (%d)\r\n", patch_idx, emitterLogData->temp_sum_u40[patch_idx], emitterLogData->temp_sum_u60[patch_idx], emitterLogData->temp_sum_u80[patch_idx], emitterLogData->temp_sum_a80[patch_idx], ntc);
			}
		}
		
		if(module_pup_time < (60 * 60))				// Keep the timer after power-up, clip at one hour
			module_pup_time++;
		timer_prs = 0;
		
		/*if(++monitor_timer_idx_prs >= 3)			// Change every 3 seconds
		{
			monitor_timer_idx_prs = 0;
			if(++monitor_idx >= 4)
				monitor_idx = 0;
		}*/
	}
	Dmx_Timer100ms();
}

void IziPlus_Module_IdentifySync()
{
	module_identify_prs = 0;
}

bool IziPlus_Module_IsIdentifying()
{
	return (module_identify_time > 0);
}

bool IziPlus_Module_IsModeSwitching()
{
	return (module_mode_switch > 0);
}

iziplus_cpustate_u IziPlus_Module_GetCpuState()
{
	return module_cpu_state;
}

bool IziPlus_EmitterOk()
{
	return iziplus_emitter_state >= 0;
}

uint8_t IziPlus_Module_MonitorValue(uint8_t ref, uint8_t *bfr)
{
	if(ref == 1)					// Supply Voltage in V
	{
		*bfr = (uint8_t)(Analog_GetSupplyVoltage()/1000);
		return 1;		
	}
	else if(ref == 19)				// Com Quality (0 to 100%)
	{
		*bfr = iziplus_data_comquality();
		return 1;
	}
	else if(ref == 24)				// Power per 0.333mV (div 3)
	{
		*bfr = (StepDown_GetPower() * 3) / 1000;
		return 1;
	}
	else if(ref == 23)				// Output (100% is no limiter active)
	{
		uint8_t temp_limit = intern_temp_master > ntc_temp_master ? (ntc_temp_master/(TEMP_MAX_RESOLUTION/100)) : (intern_temp_master/(TEMP_MAX_RESOLUTION/100));
		uint8_t power_limit = State_IsWarningActive(STATE_WARNING_POWER1_HIGH) ? (power_master/(TEMP_MAX_RESOLUTION/100)) : 100;
		*bfr = power_limit < temp_limit ? power_limit : temp_limit;
		if(module_monitor[3] < appLogData->min_output)
			appLogData->min_output = module_monitor[3];
		return 1;
	}
	else if(ref == 4)				// Internal Temp
	{
		*bfr = Adc_GetTemperature();
		return 1;
	}
	else if(ref == 3)				// LED Temp
	{
		*bfr = Adc_GetNtc();
		return 1;
	}
	else if(ref == 13)				// Max Intern Temp
	{
		*bfr = Adc_GetTemperatureMax();
		return 1;
	}
	else if(ref == 12)				// Max LED emitter Temp
	{
		*bfr = Adc_GetNtcMax();
		return 1;
	}
	else if(ref == 32)				// Up Time (time the device is powered and running) in seconds
	{
		uint16_t operating_days = appLogData->operating_sec / (24*60*60/10);		// Per 10th of day
		bfr[0] = (uint8_t)(operating_days >> 0);
		bfr[1] = (uint8_t)(operating_days >> 8);
		return 2;
	}
	else if(ref == 35)				// Up Time (time at least one channel is > 0%) in seconds
	{
		uint16_t active_days = appLogData->active_sec / (24*60*60/10);				// Per 10th of day
		bfr[0] = (uint8_t)(active_days >> 0);
		bfr[1] = (uint8_t)(active_days >> 8);
		return 2;
	}
	else if(ref == 21)				// Status index
	{
		int8_t error = State_GetHighestError();
		uint8_t state = 0;
		if(error >= 0)
		{
			if(error == STATE_ERROR_VIN_LOW)
				state = 132;
			else if(error == STATE_ERROR_OUTPUT_SHORT)
				state = 136;
			else if(error == STATE_ERROR_VIN_LOW)
				state = 132;
			else if(error == STATE_ERROR_NO_EMITTER)
				state = iziplus_emitter_state == -2 ? 147 : 152;
			else if(error == STATE_ERROR_EMITTER_DATA || error == STATE_ERROR_EMITTER_TYPE)
				state = 153;
		}
		int8_t warning = State_GetHighestWarning();
		if(warning >= 0 && state == 0)
		{
			if(warning == STATE_WARNING_TEMP_HIGH)
				state = 128;
			else if(warning == STATE_WARNING_NTC1_HIGH)
				state = 130;
			else if(warning == STATE_WARNING_SUPPLY_HIGH)
				state = 133;
			else if(warning == STATE_WARNING_BAD_COMQUAL)
				state = 148;
			else if(warning == STATE_WARNING_POWER1_HIGH)
				state = 145;
			else if(warning == STATE_WARNING_UART_OVW_WARN)
				state = 151;
		}
		*bfr = state;
		return 1;
	}
	else if(ref == 30)				// Forward voltage (all channels)
	{
		uint16_t vled = 0;
		if(monitor_idx == 0)			// Check current channel (order of WRGB)
		{
			vled = Adc_GetVled1();
		}
		else if(monitor_idx == 1)
		{
			vled = Adc_GetVled2();
		}
		else if(monitor_idx == 2)
		{
			vled = Adc_GetVled3();
		}
		else
		{
			vled = Adc_GetVled4();
		}
		
		if(vled < 1000)
			vled = 0;
		vled = (vled / 4) + (monitor_idx << 14);
		bfr[0] = (uint8_t)(vled >> 0);
		bfr[1] = (uint8_t)(vled >> 8);
		return 2;
	}
	else if(ref == 34)				// How much was it limited ever? (100% is never)
	{
		*bfr = appLogData->min_output;
		return 1;
	}
	else if(ref == 31)				// Lowest supply voltage (ever) in V
	{
		*bfr = (uint8_t)(appLogData->supply_min/1000);
		return 1;
	}
	else if(ref == 33)					// Active time per channel, per quarter of a day
	{
		uint8_t idx_offset = (monitor_idx << 6);
		uint16_t active_days_chx = emitterLogData->active_ch_sec[monitor_idx] / (24*60*60/4);
		bfr[0] = (uint8_t)(active_days_chx >> 0);
		bfr[1] = (uint8_t)(active_days_chx >> 8) + idx_offset;
		//OS_TRACE_INFO("Send active days[%d]: 0x%x%02x (%d)\r\n", monitor_idx, bfr[1], bfr[0], emitterLogData->active_ch_sec[monitor_idx]);
		return 2;
	}
	else if(ref == 36)					// Frequency per channel
	{
		uint8_t idx_offset = (monitor_idx << 6);
		uint16_t avg_level = stepdown_ctrl_chx[monitor_idx].level_curve > 0 ? stepdown_ctrl_chx[monitor_idx].freq_new / 10 : 0;		// Avg with two decimals
		bfr[0] = (uint8_t)(avg_level >> 0);
		bfr[1] = (uint8_t)(avg_level >> 8) + idx_offset;
		//OS_TRACE_INFO("Send avg level[%d]: 0x%x%02x (%d %d %d)\r\n", monitor_idx, bfr[1], bfr[0], avg_level, (emitterLogData->level_sum_ch[monitor_idx] * 10), (emitterLogData->active_ch_sec[monitor_idx] / 60));
		return 2;
	}
	else if(ref == 37)					// Lowest supply voltage (ever) in V
	{
		uint8_t idx_offset = (monitor_idx << 6);
		uint16_t avg_level = emitterLogData->active_ch_sec[monitor_idx] >= 60 ? ((emitterLogData->level_sum_ch[monitor_idx] * 10) / (emitterLogData->active_ch_sec[monitor_idx] / 60)) : 0;		// Avg with one decimal
		bfr[0] = (uint8_t)(avg_level >> 0);
		bfr[1] = (uint8_t)(avg_level >> 8) + idx_offset;
		//OS_TRACE_INFO("Send avg level[%d]: 0x%x%02x (%d %d %d)\r\n", monitor_idx, bfr[1], bfr[0], avg_level, (emitterLogData->level_sum_ch[monitor_idx] * 10), (emitterLogData->active_ch_sec[monitor_idx] / 60));
		return 2;
	}
	else if(ref == 42)				// Active time within temperature range per channel
	{
		uint8_t idx = monitor_idx_ext % 4;
		uint8_t sel = monitor_idx_ext / 4;
		uint8_t idx_offset = (monitor_idx_ext << 4);
		uint16_t temp_days = 0;
		if(sel == 0)
			temp_days = emitterLogData->temp_sum_u40[idx] / (24*60*60/2);		// Operating time within temperature range 0 - 40, per half day
		else if(sel == 1)
			temp_days = emitterLogData->temp_sum_u60[idx] / (24*60*60/2);		// Operating time within temperature range 40 - 60, per half day
		else if(sel == 2)
			temp_days = emitterLogData->temp_sum_u80[idx] / (24*60*60/2);		// Operating time within temperature range 60 - 80, per half day
		else 
			temp_days = emitterLogData->temp_sum_a80[idx] / (24*60*60/2);		// Operating time within temperature range 80 - 100, per half day
		
		bfr[0] = (uint8_t)(temp_days >> 0);
		bfr[1] = (uint8_t)(temp_days >> 8) + idx_offset;
		//OS_TRACE_INFO("Send temp days[%d]: 0x%x%02x\r\n", monitor_idx_ext, bfr[1], bfr[0]);
		return 2;
	}
	else if(ref == 43)			// Trace/Debug 16-bit value
	{
		uint16_t dbg = stepdown_ctrl_chx[0].test;
		bfr[0] = (uint8_t)(dbg >> 0);
		bfr[1] = (uint8_t)(dbg >> 8);
		return 2;
	}	
	
	return 0;
}

uint8_t *IziPlus_Module_GetMonitor()
{
	if(++monitor_idx >= emitter_fixdef.max_channels)
		monitor_idx = 0;
	if(++monitor_idx_ext >= emitter_fixdef.max_channels * 4)
		monitor_idx_ext = 0;
		
	for(int i = 0; i < iziplus_fixdef.max_monitors; i++)
	{
		IziPlus_Module_MonitorValue(iziplus_fixdef.monitors[i].ref, module_monitor + iziplus_fixdef.monitors[i].idx);
	}
	return module_monitor;
}

uint8_t IziPlus_Module_SetConfigValue(uint8_t ref, uint8_t *bfr, uint8_t len)
{
	if(len == 0)
		return 0;
	
	appconfig_t *appconfig = AppConfig_GetPtr();
	if(ref == 26)						// Maximum Output
	{
		appconfig->config[0] = bfr[0];
		return 1;
	}
	else if(ref == 32)					// TTW CCT Color Range
	{
		appconfig->config[1] = bfr[0];
		return 1;
	}
	else if(ref == 34)					// Filter mode
	{
		appconfig->config[2] = bfr[0];
		return 1;
	}
	return 0;
}

/************************************************************************/
/* Write one or multiple parameters received to memory, can be multiple 
  parameters if in the right order. Write is prepared, AppConfig_Set 
  has to be called elsewhere. Returns the amount of parameters written. */
/************************************************************************/
uint8_t IziPlus_Module_SetConfigByIndex(uint8_t idx, uint8_t *bfr, uint8_t len)
{
	uint8_t l = len, amount = 0;
	for(int i = 0; i < iziplus_fixdef.max_configs; i++)
	{
		if(iziplus_fixdef.monitors[i].idx == idx)
		{
			uint8_t size = iziplus_fixdef.configs[i].size;
			if(l >= size)
			{
				IziPlus_Module_SetConfigValue(iziplus_fixdef.configs[i].ref, bfr + idx, size);
				l -= size;
				amount++;
				idx += size;
			}
			else
				break;	
		}
	}
	return amount;
}

/************************************************************************/
/* Get config value by given reference                                  */
/************************************************************************/
uint8_t IziPlus_Module_ConfigValue(uint8_t ref, uint8_t *bfr)
{
	if(ref == 26)						// Maximum Output
	{
		*bfr = (uint8_t)(appConfig->config[0]);
		return 1;
	}
	else if(ref == 32)					// TTW CCT Color Range
	{
		*bfr = (uint8_t)(appConfig->config[1]);
		return 1;
	}
	else if(ref == 34)					// Filter mode
	{
		*bfr = (uint8_t)(appConfig->config[2]);
		return 1;
	}
	return 0;
}

uint8_t *IziPlus_Module_GetConfig()
{
	for(int i = 0; i < iziplus_fixdef.max_configs; i++)
	{
		IziPlus_Module_ConfigValue(iziplus_fixdef.configs[i].ref, module_config + iziplus_fixdef.configs[i].idx);
	}
	return module_config;
}

void IziPlus_Module_SetIdentify(uint8_t mode, uint8_t time)
{
	// Todo: Handle all modes
	if(time > 0)
	{
		State_SetAttentionInfo(COLOR_MAGENTA, COLOR_BLUE, ((uint16_t)time * 60), 2);
		module_cpu_state.u.identify = 1;
		module_identify_time = ((uint16_t)time * 600);
		module_identify_mode = mode;
		module_identify_unlock_time = time == IZIPLUS_IDENTMODE_MAGIC_TIME;
		module_identify_prs = 0;
	}
	else
	{
		State_ClearAttentionInfo();	
		module_identify_unlock_time = 0;
		module_cpu_state.u.identify = 0;
		module_identify_time = 1;
	}
}


__inline uint8_t IziPlus_Module_HasOutputMaster()
{
	return iziplus_fixdef.modes[appConfig->mode].master_chan >= 0;
	
}

__inline int8_t IziPlus_Module_OutputMasterChannel()
{
	return iziplus_fixdef.modes[appConfig->mode].master_chan;
	
}

__inline uint8_t IziPlus_Module_HasControl()
{
	return iziplus_fixdef.modes[appConfig->mode].control_chan >= 0 || (iziplus_fixdef.modes[appConfig->mode].flags & (MODE_FLASH_AUTO));
	
}

__inline int8_t IziPlus_Module_ControlChannel()
{
	return iziplus_fixdef.modes[appConfig->mode].control_chan;	
}

__inline uint8_t IziPlus_Module_HasTwChannel()
{
	return iziplus_fixdef.modes[appConfig->mode].tw_chan >= 0;
	
}

__inline int8_t IziPlus_Module_TwChannel()
{
	return iziplus_fixdef.modes[appConfig->mode].tw_chan;
}

__inline uint8_t IziPlus_Mode_IsRGBW()
{
	return module_mode == MODE_CTRL_RGBW;
}

__inline int8_t IziPlus_Module_OutputRgbwStartChannel()
{
	return iziplus_fixdef.modes[appConfig->mode].rgbw_chan;
}

__inline uint8_t IziPlus_Mode_UsesTable()
{
	return module_mode == MODE_CTRL_WD || module_mode == MODE_CTRL_TW;
}

__inline bool IziPlus_Mode_IsDirect()
{
	return module_mode == MODE_CTRL_DIRECT;
}

__inline uint8_t IziPlus_Module_IsWdSingle()
{
	return (iziplus_fixdef.modes[appConfig->mode].flags & (MODE_FLASH_WD_SINGLE)) ? 1 : 0;
}

__inline uint8_t IziPlus_Module_IsDirect()
{
	return (iziplus_fixdef.modes[appConfig->mode].flags & (MODE_FLASH_DIRECT)) ? 1 : 0;
}

__inline uint8_t IziPlus_Module_IsFirst16b()
{
	return (iziplus_fixdef.modes[appConfig->mode].flags & (MODE_FIRST_16B)) ? 1 : 0;
}

__inline uint8_t IziPlus_Module_IsAutoControl()
{
	return (iziplus_fixdef.modes[appConfig->mode].flags & (MODE_FLASH_AUTO)) ? 1 : 0;
}

__inline uint8_t IziPlus_Mode_IsWdSingle()
{
	return module_mode == MODE_CTRL_WD;
}

#define MODE_SWITCH_STABLE_TIME		180			// Per 10ms = 2.0 sec
#define MODE_SWITCH_SWITCH_TIME		(MODE_SWITCH_STABLE_TIME + 20)

static uint8_t mode_ctrl_prev;
static uint16_t mode_ctrl_stable;
static uint8_t mode_cct_last = 0;			// Some value it mostly not set to

uint8_t IzIPlus_GetModeFromLevel(uint8_t level)
{
	uint8_t mode = MODE_CTRL_UNKNOWN;
	if(level < 80)
		mode = MODE_CTRL_WD;
	else if(level >= 90 && level <= 160)
		mode = MODE_CTRL_TW;
	else if(level >= 170)
		mode = MODE_CTRL_RGBW;
		
	return mode;
}

static bool output_valid = false;
uint8_t IziPlus_CheckMode()
{
	if(IziPlus_Module_HasControl())
	{
		uint8_t ctrl = 0;
		if(IziPlus_Module_IsAutoControl())
		{
			bool rgbw_on = false;
			for(int i = 0; i < 4; i++)	
			{
				if(Izi_OutputGet(IziPlus_Module_OutputRgbwStartChannel() + i) > 0)
				{
					rgbw_on = true;
					mode_cct_last = Izi_OutputGet(IziPlus_Module_TwChannel());
					break;
				}
			}
			if(!rgbw_on && module_mode == MODE_CTRL_RGBW && module_mode_switch == 0 && mode_cct_last == Izi_OutputGet(IziPlus_Module_TwChannel()))
				rgbw_on = true;												// Do not change until CCT is changed
			ctrl = rgbw_on ? 200 : 100;			// Set value of RGBW or TW
			if(rgbw_on && module_mode != MODE_CTRL_RGBW && module_mode_switch == 0)
				mode_ctrl_stable = MODE_SWITCH_STABLE_TIME - 1;
			else if(!rgbw_on && module_mode != MODE_CTRL_TW && module_mode_switch == 0)
				mode_ctrl_stable = MODE_SWITCH_STABLE_TIME - 1;
		}
		else
		{
			ctrl = Izi_OutputGet(IziPlus_Module_ControlChannel());
			if(iziplus_master_zero_time >= 100)								// At least one sec idle?
			{
				uint8_t mode = IzIPlus_GetModeFromLevel(ctrl);
				if(mode != MODE_CTRL_UNKNOWN && mode != module_mode)		// Mode changed?
				{
					mode_ctrl_prev = ctrl;									// Force direct switch of mode
					mode_ctrl_stable = MODE_SWITCH_SWITCH_TIME - 1;
				}
			}
		}
		
		if(!output_valid && output_valid != IziOutput_IsValid())						// If input is valid first time after startup, switch to mode directly
		{
			mode_ctrl_stable = MODE_SWITCH_SWITCH_TIME - 1;								// Force fast mode update after startup
			mode_ctrl_prev = ctrl;
			output_valid = true;														// Power-up check handled, don't do it any more
		}
		
		if(ctrl == mode_ctrl_prev)
		{
			if(++mode_ctrl_stable == MODE_SWITCH_STABLE_TIME)				// Called every 10ms, so 2 second stable
			{
				uint8_t mode = IzIPlus_GetModeFromLevel(ctrl);
				if(mode != MODE_CTRL_UNKNOWN && mode != module_mode)
					module_mode_switch = 1;									// Indicate to go off (while switching)			
			}
			else if(mode_ctrl_stable == MODE_SWITCH_SWITCH_TIME)			// Called every 10ms, so 2.2 second stable
			{
				module_mode_switch = 0;
				uint8_t mode = IzIPlus_GetModeFromLevel(ctrl);
				if(mode != MODE_CTRL_UNKNOWN)
					module_mode = mode;
					
				mode_ctrl_stable--;						// Clip here
			}
		}
		else
			mode_ctrl_stable = 0;
			
		mode_ctrl_prev = ctrl;
	}
	else if(iziplus_fixdef.modes[appConfig->mode].rgbw_chan >= 0)
		module_mode = MODE_CTRL_RGBW;
	else if(IziPlus_Module_IsDirect())
		module_mode = MODE_CTRL_DIRECT;
	else if(IziPlus_Module_IsWdSingle())
		module_mode = MODE_CTRL_WD;
	else
		module_mode = MODE_CTRL_TW;
		
	return module_mode;
}

uint16_t IziPlus_Module_GetDim(uint8_t chan_idx)
{
	uint16_t level_chx;
	bool first = chan_idx == 0;
	uint8_t chan_idx_org = chan_idx;
	bool tunable_wd = true;
	uint8_t master = IziPlus_Module_HasOutputMaster();
	
	if(first)								// Only do it once per loop
		IziPlus_CheckMode();				// Check mode switches
	
	if(module_mode_switch || ((module_pup_time < 3 && !output_valid) && IziPlus_Module_HasControl()))		// If switching modes or if mode has control channel and it is less than 3 sec after power-up (unless valid data came in)
		return 0;
	
	if(master)
	{
		if(IziPlus_Mode_IsRGBW())
		{
			chan_idx += IziPlus_Module_OutputRgbwStartChannel();
			tunable_wd = false;
		}
		else
		{
			chan_idx = IziPlus_Module_OutputMasterChannel();
		}
	}
	
	uint16_t lvl_ch_in = overrule_time_chx == 0 ? Izi_OutputGet(chan_idx) : overrule_level_chx[chan_idx_org];
	uint16_t master_level = 0;
	if(master)
	{
		master_level = Izi_OutputGet(IziPlus_Module_OutputMasterChannel());
		if(IziPlus_Module_IsFirst16b())
			master_level = (master_level << 8) | Izi_OutputGet(IziPlus_Module_OutputMasterChannel() + 1);
		else
			master_level |= (master_level << 8) + master_level;
		if(first)
		{
			if(master_level == 0)
			{
				if(iziplus_master_zero_time < 60000)
					iziplus_master_zero_time++;
			}
			else
				iziplus_master_zero_time = 0;
		}
	}

	if(master && !tunable_wd)					// Is there a master in this mode? If tunable/warm dimming don't use master
	{
		uint16_t lvl_master = overrule_time_chx == 0 ? master_level : 0xFFFF;				// If so, merge them. If overruled, set master to full
		if(lvl_master != 0xFFFF || lvl_ch_in != 0xFF)
		{
			uint32_t level_chx32 = (lvl_master * lvl_ch_in);
			if((uint8_t)level_chx > 0x80)
				level_chx += 0x100;
			level_chx = level_chx32 >> 8;
		}
		else
			level_chx = 0xFFFF;
	}
	else if(chan_idx == 0 && IziPlus_Module_IsFirst16b())
	{
		level_chx = (lvl_ch_in << 8) | Izi_OutputGet(chan_idx + 1);
	}
	else
		level_chx = (lvl_ch_in << 8) | lvl_ch_in;
	
	iziplus_level_chx[chan_idx_org] = level_chx;
	
	return level_chx;
}

uint16_t tw_channel_virtual = 0;
uint32_t dtj_store[MAX_EMITTER_MODES];
int8_t corrtemp_ovw_chan_idx = -1;
uint32_t corrtemp_ovw_val;

#define CONST_T1	266
#define CONST_T2	127

static uint32_t rgbw_master = 0;

uint32_t IziPlus_Module_GetTable(uint8_t chan_idx, uint32_t val)
{
	if(IziPlus_Mode_UsesTable() && overrule_time_chx == 0)				// Check if table is used in current mode
	{
		uint16_t tw_chan;
		if(chan_idx == 0)
		{
			if(IziPlus_Mode_IsWdSingle())
			{
				tw_chan = ((uint32_t)(val >> 8) * (uint32_t)emitter_fixdef.tw3000K) >> 8;
			}
			else
			{
				uint8_t data = CONFIG_CCT_COLOR_RANGE(appConfig->config) == 0 ? (Izi_OutputGet((IziPlus_Module_TwChannel())) * emitter_fixdef.tw4000K)/256 : Izi_OutputGet(IziPlus_Module_TwChannel());
			
				int32_t tw_chan_goal = (data << 8) + data;
				tw_chan = Filter_LowPass(tw_channel_virtual, tw_chan_goal, stepdown_ctrl_chx[0].filter_shift);
				/*tw_chan = ((tw_chan_goal - (int32_t)tw_channel_virtual) / (int32_t)stepdown_ctrl_chx[0].filter_shift) + (int32_t)tw_channel_virtual;		// TODO: if in dynamic, and only Tunable is changed fast it won't be fast (when level fast is also changed it will be ok)
				if(tw_chan == tw_channel_virtual && tw_chan_goal != tw_chan)		// Make sure if last delta is divided to 0, that the real level is still reached in steps of 1
				{
					if(tw_chan_goal > tw_chan)
						tw_chan++;
					else
						tw_chan--;
				}
				tw_channel_virtual = tw_chan;*/
			}
			tw_channel_virtual = tw_chan;
		}
		else
			tw_chan = tw_channel_virtual;
			
		uint16_t tw = tw_chan / 4096;
		uint16_t tw_offset = tw_chan - (tw * 4096);
		
		uint8_t tw_val = emitter_fixdef.bbc_chx[chan_idx][tw];
		uint8_t tw_val_next = emitter_fixdef.bbc_chx[chan_idx][tw + 1];
		if(tw_val <= tw_val_next)
			val = (uint64_t)((uint64_t)((tw_val << 8) + (((tw_val_next - tw_val) * (tw_offset >> 4)))) * (uint64_t)val) >> 16;// * (val))/256L;
		else
			val = (uint64_t)((uint64_t)((tw_val << 8) - (((tw_val - tw_val_next) * (tw_offset >> 4)))) * (uint64_t)val) >> 16;// * (val))/256L;
		
		if(!IziPlus_Mode_IsWdSingle())
			val = (val * emitter_fixdef.tw_gain)/100;			// Limit so 75W is never reached
		else
			val = (val * emitter_fixdef.wd_gain)/100;
	}	
	else if(!IziPlus_Mode_IsDirect())
	{
		val = ((uint32_t)val * (uint32_t)emitter_fixdef.rgbw_sensitivity[chan_idx]) / 256;
	}
	
	if(IziPlus_Mode_IsRGBW())																		// RGBW modes use the highest level for DAC and period
	{
		if(chan_idx == 0 || stepdown_ctrl_chx[chan_idx].level_curve > rgbw_master)		// Search for highest value in RGBW modes (clear on first in loop)
		{
			rgbw_master = stepdown_ctrl_chx[chan_idx].level_curve;
			for(int i = 0; i < MAX_DIM_CHANNELS; i++)
				stepdown_ctrl_chx[i].level_curve_master = rgbw_master;								// Set all master to highest value (used for DAC and Period)
		}
	}
	else
		stepdown_ctrl_chx[chan_idx].level_curve_master = stepdown_ctrl_chx[chan_idx].level_curve;				// Store here without limitations (in TW en WD its the 'master' value)
	
	uint8_t max_output = CONFIG_MAX_OUTPUT(appConfig->config);		// Check if max output is configured reduced
	if(max_output < 100)
		val = (val * max_output)/100;								// Less than 100%, scale it
	
	uint16_t temp = Adc_GetNtc();
	stepdown_ctrl_chx[chan_idx].e_temp = temp;
	if(temp < (25))				// Temperature corrections
		temp = (25);				// Clip at 25 degrees (if lower)
	
	int16_t corr_temp = emitter_fixdef.corr_temp_tables[chan_idx];
	if(corr_temp != 0)				// Any correction on this channel?
	{
		uint16_t corr_tjc = emitter_fixdef.corr_tjc_tables[chan_idx];
		uint32_t dtj = corr_tjc > 0 ? (((((((uint64_t)(uint64_t)stepdown_ctrl_chx[chan_idx].dac_data * (uint64_t)(stepdown_ctrl_chx[chan_idx].level_curve_correct_prev >> 8)) >> 16) * corr_tjc) >> 4) * (chan_idx == 0 ? CONST_T1 : CONST_T2)) >> 16) + (temp - (25)) : (temp - (25) );
		uint32_t dtj_temp = Filter_LowPass(dtj_store[chan_idx], dtj * abs(corr_temp), 5);		// Do filter with correction temp to create some more resolution
		
		//stepdown_ctrl_chx[chan_idx].test = val;	
		uint32_t calc = corr_temp > 0 ? (val + ((uint64_t)(((uint64_t)dtj_temp) * (uint64_t)val) >> 17)) :  (val - ((uint64_t)(((uint64_t)dtj_temp) * (uint64_t)val) >> 17));
		if(calc > 0xFFFFFF)							// Check for overflow
		{
			if(chan_idx < 0 || corrtemp_ovw_chan_idx != chan_idx)		// Check if no or other channel has claimed the overflow reduce
			{
				if(calc > corrtemp_ovw_val)					// If larger than the other or there was no overflow yet
				{											// Store it
					corrtemp_ovw_val = calc;				// Store overflow calculation, to reduce other channels
					corrtemp_ovw_chan_idx = chan_idx;		// Set chan idx that causes overflow
					calc = 0xFFFFFF;						// Clip at 24-bit
				}
				// else leave calc as is (above 24-bit), but it will be reduced below
			}
			else
			{
				corrtemp_ovw_val = calc;				// Store overflow calculation, to reduce other channels
				corrtemp_ovw_chan_idx = chan_idx;		// Set chan idx that causes overflow
				calc = 0xFFFFFF;						// Clip at 24-bit
			}
		}
		else if(corrtemp_ovw_chan_idx == chan_idx)	// Overflowing channels ok now?
		{
			corrtemp_ovw_chan_idx = -1;				// Stop reducing other channels
			corrtemp_ovw_val = 0;
		}
		val = calc;									// Store calculated value
			
		dtj_store[chan_idx] = dtj_temp;				// Store value for filter
	}
	if(corrtemp_ovw_chan_idx >= 0 && corrtemp_ovw_chan_idx != chan_idx && corrtemp_ovw_val > 0)
	{
		val = ((uint64_t)val << 24) / corrtemp_ovw_val;
		//stepdown_ctrl_chx[chan_idx].test = val;	
	}
	
	return val;
}

uint8_t IziPlus_Module_GetChannelAmount()
{
	return module_channels_amount;
}

uint8_t IziPlus_Module_GetChannelAmountTemp()
{
	if(appConfig->mode < MODE_AMOUNT)
		return iziplus_fixdef.modes[appConfig->mode].channels;
	return module_channels_amount;
}

uint8_t IziPlus_Module_GetHwRevision()
{
	return get_hw_id();			
}

uint8_t IziPlus_Module_GetVariant()
{
	return get_device_id();			
}

izi_versionplus_u IziPlus_Module_GetAppVersion()
{
	izi_versionplus_u appversion = { .v.major = firmare_info.version.v.major, .v.minor = firmare_info.version.v.minor, .v.build = firmare_info.version.v.build };
	return appversion;			
}

izi_versionplus_u IziPlus_Module_GetBootVersion()
{
	version_u *boot_version = (version_u *)BOOT_VERSION_ADDRESS;
	izi_versionplus_u bootversion = { .v.major = boot_version->v.major, .v.minor = boot_version->v.minor, .v.build = boot_version->v.build };
	return bootversion;			
}

izi_versionplus_u IziPlus_Module_GetImageVersion()
{
	firmware_t *image_info = (firmware_t *)(FLASH_APP_MIRROR_END - FLASH_APP_FW_INFO_SIZE - FLASH_APP_MIRROR_SHIFT);
	izi_versionplus_u imageversion = { .v.major = image_info->version.v.major, .v.minor = image_info->version.v.minor, .v.build = image_info->version.v.build };
	return imageversion;
}

izi_version_u IziPlus_Module_GetTypedefVersion()
{
	izi_version_u typedefversion = { .v.major = 2, .v.minor = 2 };
	return typedefversion;			// Min version of TDE file
}

izi_version_u IziPlus_Module_GetLedtableVersion()
{
	izi_version_u ledtableversion = { .v.major = emitter_fixdef.version >> 5, .v.minor = emitter_fixdef.version & 0x1F };
	return ledtableversion;			// Todo: real led table version
}

uint8_t IziPlus_Module_GetMemoryVersion()
{
	return CONFIG_VERSION;		
}

bool IziPlus_Module_IsOverruled()
{
	return overrule_time_chx > 0;
}

bool IziPlus_Module_Test(uint8_t idx, uint32_t time, uint8_t prio)
{
	IziPlus_Module_Overrule_Ch1234(emitter_fixdef.test_lvls[idx], time, prio);
	idx++;
	if(idx >= emitter_fixdef.max_channels || emitter_fixdef.test_lvls[idx] == 0)
		return true;
	return false;
}

void IziPlus_Module_Overrule_Chx(uint8_t chan_idx, uint8_t level, uint32_t time, uint8_t prio)
{
	if(prio >= overrule_prio_chx || overrule_time_chx == 0)
	{
		overrule_prio_chx = prio;
		overrule_level_chx[chan_idx] = level;
		overrule_time_chx = time / 100;
		
		//OS_TRACE_ERROR("Overrule channel[%d]: l:%d p:%d t:%d\r\n", chan_idx, level, prio, time);
	}
}

void IziPlus_Module_Overrule_Ch1234(uint32_t dim1234, uint32_t time, uint8_t prio)
{
	if(prio >= overrule_prio_chx || overrule_time_chx == 0)
	{
		overrule_prio_chx = prio;
		for(int i = 0; i < emitter_fixdef.max_channels; i++)
			overrule_level_chx[i] = (uint8_t)(dim1234 >> (i * 8));
		overrule_time_chx = time / 100;
		//OS_TRACE_ERROR("Overrule channel1234: l:%d p:%d t:%d\r\n", dim1234, prio, time);
	}
}

void IziPlus_NoComCheck()
{
	bool isok = IziPlus_LightDataOk();
	if(!isok)
	{
		if(xTaskGetTickCount() < 5000)				// Do nothing if shorter than 5 sec after power-up (should not go on during discover)
			return;
		
		if((iziplus_data_wasok && (DMXFAIL_OPERATE(appConfig->dmxfail) == DMXFAIL_MAX)) || (!iziplus_data_wasok && (DMXFAIL_PUP(appConfig->dmxfail) == DMXFAIL_MAX)))
		{
			if(iziplus_prs_comcheck == 0)
			{
				for(int i = 0; i < emitter_fixdef.max_channels; i++)
				{
					if(IziPlus_Module_HasOutputMaster())
					{
						uint8_t master_chan = IziPlus_Module_OutputMasterChannel();
						uint8_t master_val = Izi_OutputGet(master_chan);
						if(master_val < 0xFF)
						{
							Izi_OutputSet(master_chan, master_val + 1);	// Set new decreased master value
							if(IziPlus_Module_IsFirst16b())
								Izi_OutputSet(master_chan + 1, 0xFF);
						}
					}
					if(module_mode == MODE_CTRL_TW)
					{
						uint8_t tw_chan = IziPlus_Module_TwChannel();
						uint8_t tw = Izi_OutputGet(tw_chan);
						if(tw > 128)
							Izi_OutputSet(tw_chan, tw - 1);					// Goto 50% if Tunable
						else if(tw < 128)
							Izi_OutputSet(tw_chan, tw + 1);
						break;
					}
					else if(module_mode == MODE_CTRL_RGBW)
					{
						uint8_t start = IziPlus_Module_OutputRgbwStartChannel();
						for(int i = 0; i < IziPlus_Module_GetChannelAmount(); i++)
						{
							uint8_t any_val = Izi_OutputGet(start + i);
							if(any_val > ((uint8_t)(emitter_fixdef.indicate_lvl >> (i*8))))
								Izi_OutputSet(start + i, any_val - 1);
							else if(any_val < ((uint8_t)(emitter_fixdef.indicate_lvl >> (i*8))))
								Izi_OutputSet(start + i, any_val + 1);
						}
					}
					else
						break;		// WD only has one channel
				}
			}
		}
		else if((iziplus_data_wasok && (DMXFAIL_OPERATE(appConfig->dmxfail) == DMXFAIL_OFF)) || (!iziplus_data_wasok && (DMXFAIL_PUP(appConfig->dmxfail) == DMXFAIL_OFF)))
		{
			if(iziplus_prs_comcheck == 0)
			{
				for(int i = 0; i < emitter_fixdef.max_channels; i++)
				{
					if(IziPlus_Module_HasOutputMaster())
					{
						uint8_t master_chan = IziPlus_Module_OutputMasterChannel();
						uint8_t master_val = Izi_OutputGet(master_chan);
						if(master_val > 0)
						{
							Izi_OutputSet(master_chan, master_val - 1);			// Set new decreased master value
							if(IziPlus_Module_IsFirst16b())
								Izi_OutputSet(master_chan + 1, 0);
							if(master_val == 1)
								IziOutput_Init();								// Set all to zero
						}
						break;	// Do it once, not for all channels
					}	
					else
					{
						for(int i = 0; i < IziPlus_Module_GetChannelAmount(); i++)
						{
							uint8_t any_val = Izi_OutputGet(i);
							if(any_val > 0)
								Izi_OutputSet(i, any_val - 1);
						}
					}				
				}
			}
		}
		
		if(++iziplus_prs_comcheck >= 2)
			iziplus_prs_comcheck = 0;
	}
	else
		iziplus_data_wasok = true;			// Mark it has been ok once since power-up, and so DMXFAIL_OPERATE should be used
	
	iziplus_last_comcheck = isok;
}
