/*
 * appconfig.h
 *
 *  Created on: 15 jun. 2020
 *      Author: Milo
 */

#ifndef SOURCE_APPCONFIG_H_
#define SOURCE_APPCONFIG_H_

#include "izi_module.h"

#define CONFIG_VERSION	6
#define CALIB_VERSION	1
#define LOG_VERSION		1
#define LOGE_VERSION	1

#define NAME_SIZE		32
#define PROJECT_SIZE	16

#define APPSETTING_SECTOR_SIZE		512

#define APPCFG_DFLT_INCOMPLETE		0xA5
#define APPCFG_DFLT_OK				0xCD


typedef struct appconfig_s {
	// General
	uint32_t crc;
	uint32_t ref;				// time of file (used in code as first after crc, so do not move)
	uint32_t version;
	uint32_t serial;
	char name[NAME_SIZE];
	uint32_t pan_id;
	uint8_t pl_frequency;
	uint8_t pl_rate;
	uint8_t dbg_on;
	uint8_t short_id;
	uint16_t location_id;
	uint16_t channel;
	uint8_t mode;
	uint8_t dmxfail;
	uint8_t offset;
	uint8_t pl_txlevel;
	uint8_t config[IZI_MAX_CONFIG];		
	char dummy[APPSETTING_SECTOR_SIZE-100];				// Filler (page), check AppConfig_Set if larger than 128 (is page size)
	uint8_t res;
	uint8_t default_ok;		// Check if default was incomplete because emitter was not known yet
	uint8_t variant;		// Last variant detected at PUP
	uint8_t typeid;			// Last type detected at PUP
} appconfig_t;

#define APPCFG_TXMODE			0


#define APPCFG_TXMODE_DYNAMIC		0
#define APPCFG_TXMODE_DYNAMIC_BOOST	1
#define APPCFG_TXMODE_FAST			2
#define APPCFG_TXMODE_FAST_BOOST	3
#define APPCFG_TXMODE_MAX			3
#define APPCFG_TXMODE_MAX_DYNAMIC	1
#define APPCFG_TXMODE_BOOST_MASK	1

#define APPCALIB_SECTOR_SIZE		128

typedef struct appcalib_s {
	// General
	uint32_t crc;
	uint32_t ref;										// time of file (used in code as first after crc, so do not move)
	uint32_t version;
	uint16_t pwm1_offset;
	uint16_t pwm2_offset;
	uint16_t vled1_max_mv;
	uint16_t vled2_max_mv;
	char dummy[APPCALIB_SECTOR_SIZE-20];				// Filler (page), check AppCalib_Set if larger than 128 (is page size)
} appcalib_t;

#define APPLOG_SECTOR_SIZE		128

typedef struct applog_s {
	// General
	uint32_t crc;
	uint32_t ref;										// time of file (used in code as first after crc, so do not move)
	uint32_t version;
	uint32_t operating_sec;
	uint32_t active_sec;
	uint16_t intern_temp_max;
	uint16_t ntc_temp_max;
	uint16_t supply_min;
	uint16_t change_count;
	uint8_t min_output;
	char dummy[APPLOG_SECTOR_SIZE-35];					// Filler (page), check AppCalib_Set if larger than 64 (is page size)
} applog_t;

typedef struct emitterlog_s {
	// General
	uint32_t crc;
	uint32_t ref;										// time of file (used in code as first after crc, so do not move)
	uint32_t version;
	uint32_t operating_sec;								// Total time fixture was on
	uint32_t active_sec;								// Total time at least one channel was on
	uint16_t ntc_temp_max;
	uint16_t change_count;
	uint32_t active_ch_sec[4];							// Time time the channel was on (on > 0%)
	uint32_t temp_sum_u40[4];							// 0 to 40 (counts per second if within reach)
	uint32_t temp_sum_u60[4];							// 40 to 60 (counts per second if within reach)
	uint32_t temp_sum_u80[4];							// 60 to 80 (counts per second if within reach)
	uint32_t temp_sum_a80[4];							// Above 80 (counts per second if within reach)
	uint32_t level_sum_ch[4];							// Sum of level (1 to 100%) (adds up every minute), divide by active_ch_sec[x]/60 to get average. Level is calculated by actual duty cycle
	uint8_t dummy[8];
} emitterlog_t;


extern appcalib_t *appCalibData;
extern applog_t *appLogData;

extern appconfig_t *appConfig;

extern emitterlog_t *emitterLogData;

#define APPMODULES_MAX		32
typedef struct appmodule_s {
	izi_module_base_t modules[APPMODULES_MAX];
}appmodule_t;

// Proto
void AppConfig_Init();
void AppConfig_Default();
void AppConfig_Print();
appconfig_t *AppConfig_Get();
appconfig_t *AppConfig_GetPtr();
bool AppConfig_Set();
void AppConfig_CheckConfig();
void AppCalib_Default();
appcalib_t *AppCalib_Get();
bool AppCalib_Set();
applog_t *AppLog_Get();
void AppLog_Default(bool all);
bool AppLog_Set();
void AppEmitterLog_Default();
bool AppEmitterLog_Set();
emitterlog_t *AppEmitterLog_Get();

#endif /* SOURCE_APPCONFIG_H_ */
