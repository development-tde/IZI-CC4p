/*
 * usartx.h
 *
 * Created: 8-3-2022 08:42:52
 *  Author: Milo
 */ 


#ifndef USART2_H_
#define USART2_H_

#include "usartx.h"

void Usart2_Init(usartx_cb_func_txptr tx_cb, usartx_cb_func_rxptr rx_cb,  usartx_cb_func_errptr err_cb);
void Usart2_Putc(uint8_t data);
void Usart2_PutBfr(uint8_t *data, uint16_t length);
void Usart2_BreakOn();
void Usart2_BreakOff();

#endif /* USART2_H_ */