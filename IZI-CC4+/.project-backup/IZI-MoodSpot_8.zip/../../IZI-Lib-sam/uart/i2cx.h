/*
 * i2c1.h
 *
 * Created: 4-12-2023 13:37:41
 *  Author: Milo
 */ 


#ifndef I2CX_H_
#define I2CX_H_

#define I2C_SERCOM0		0
#define I2C_SERCOM1		1
#define I2C_SERCOM2		2
#define I2C_SERCOM3		3
#define I2C_SERCOM4		4
#define I2C_SERCOM5		5

// Proto
void I2Cx_Init();
int32_t I2Cx_Write_Bfr(uint8_t address, uint8_t reg, uint8_t *bfr, uint16_t length);
int32_t I2Cx_Write_Sequence(uint8_t address, uint8_t *bfr, uint16_t length);
int32_t I2Cx_Read_Bfr(uint8_t address, uint8_t reg, uint8_t *bfr, uint16_t length);
int32_t I2Cx_Read_16b(uint8_t address, uint8_t reg, uint16_t *val);
int32_t I2Cx_Read_8b(uint8_t address, uint8_t reg, uint8_t *val);
bool I2Cx_Check();

#endif /* I2CX_H_ */