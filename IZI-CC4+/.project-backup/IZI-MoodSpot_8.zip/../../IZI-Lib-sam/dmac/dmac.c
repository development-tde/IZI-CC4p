/*
 * usart1.c
 *
 * Created: 17-5-2022 08:59:33
 *  Author: Milo
 */ 

#include "includes.h"

#if DMA_CHANNELS > 0
#include "dmac.h"

#ifndef DMAC_MAX_CHANNEL
#define DMAC_MAX_CHANNEL		3		// 32 max by hardware
#endif

#ifndef DMAC_MAX_DATA_LEN
#define DMAC_MAX_DATA_LEN		512
#endif

#if DMA_CHANNELS > DMAC_MAX_CHANNEL
#error "More than 3 DMA channels not supported by driver"
#endif

#define DMA_TIMEROS_TICKS		10		// Amount of ticks for second timer

volatile DmacDescriptor dmaDescriptorArray[DMAC_CH_NUM] __attribute__ ((aligned (16)));
volatile DmacDescriptor dmaDescriptorWritebackArray[DMAC_CH_NUM] __attribute__ ((aligned (16)));
volatile uint32_t dmac_dst[DMAC_CH_NUM];
volatile uint32_t dmac_pending[DMAC_CH_NUM];

volatile uint8_t dmac_txbfr[DMAC_MAX_CHANNEL][DMAC_MAX_DATA_LEN] __attribute__ ((aligned (16)));

static dma_cb_func_txptr  dmac_tx_cb[DMAC_MAX_CHANNEL] = { NULL, NULL };
static dma_cb_func_errptr  dmac_err_cb[DMAC_MAX_CHANNEL] = { NULL, NULL };
	
// Proto


void DMA_Init(void)
{
	MCLK_CRITICAL_SECTION_ENTER();
	MCLK->AHBMASK.reg |= MCLK_AHBMASK_DMAC;
	MCLK_CRITICAL_SECTION_LEAVE();
	
	DMAC->CTRL.bit.SWRST = 1;	
	while (DMAC->CTRL.bit.SWRST);							// Wait for synchronization
	
	DMAC->BASEADDR.reg = (uint32_t)dmaDescriptorArray;
	DMAC->WRBADDR.reg = (uint32_t)dmaDescriptorWritebackArray;
	
	DMAC->CTRL.reg = DMAC_CTRL_DMAENABLE | DMAC_CTRL_LVLEN(0xf);
	
	//strcpy(dmac_txbfr, "Pipo!!\r\n*****");		// https://github.com/MartinL1/I2C_DMAC/blob/master/I2C_DMAC.cpp

#ifdef DMA_SINGLE
	NVIC_DisableIRQ(DMAC_IRQn);
	NVIC_ClearPendingIRQ(DMAC_IRQn);
	NVIC_SetPriority(DMAC_IRQn, configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY+1);					// Prio 0 is highest, 7 is lowest
	NVIC_EnableIRQ(DMAC_IRQn);
#else	
	NVIC_DisableIRQ(DMAC_0_IRQn);
	NVIC_ClearPendingIRQ(DMAC_0_IRQn);
	NVIC_SetPriority(DMAC_0_IRQn, configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY+1);					// Prio 0 is highest, 7 is lowest
	NVIC_EnableIRQ(DMAC_0_IRQn);
#endif
}

#ifdef DMA_SINGLE
void DMAC_Handler(void)				/* DMAC_SUSP_0, DMAC_TCMPL_0, DMAC_TERR_0 */
#else
void DMAC_0_Handler(void)			/* DMAC_SUSP_0, DMAC_TCMPL_0, DMAC_TERR_0 */
#endif
{
#ifdef DMA_SINGLE
	if(DMAC->CHINTFLAG.bit.TCMPL)
	{
		DMAC->CHINTFLAG.reg = DMAC_CHINTFLAG_TCMPL;
		dmac_pending[0] = false;
		if(dmac_tx_cb[0] != NULL)
		dmac_tx_cb[0]();
	}
	if(DMAC->CHINTFLAG.bit.SUSP)
	DMAC->CHINTFLAG.reg = DMAC_CHINTFLAG_SUSP;
	if(DMAC->CHINTFLAG.bit.TERR)
	{
		DMAC->CHINTFLAG.reg = DMAC_CHINTFLAG_TERR;
		if(dmac_err_cb[0] != NULL)
		dmac_err_cb[0]();
	}
#else	
	
#if DMA_CHANNELS > 0	
	if(DMAC->Channel[0].CHINTFLAG.bit.TCMPL)
	{
		DMAC->Channel[0].CHINTFLAG.reg = DMAC_CHINTFLAG_TCMPL;
		dmac_pending[0] = false;
		if(dmac_tx_cb[0] != NULL)
			dmac_tx_cb[0]();
	}
	if(DMAC->Channel[0].CHINTFLAG.bit.SUSP)
		DMAC->Channel[0].CHINTFLAG.reg = DMAC_CHINTFLAG_SUSP;
	if(DMAC->Channel[0].CHINTFLAG.bit.TERR)
	{
		DMAC->Channel[0].CHINTFLAG.reg = DMAC_CHINTFLAG_TERR;
		if(dmac_err_cb[0] != NULL)
			dmac_err_cb[0]();
	}
#endif		
#if DMA_CHANNELS > 1		
	if(DMAC->Channel[1].CHINTFLAG.bit.TCMPL)
	{
		DMAC->Channel[1].CHINTFLAG.reg = DMAC_CHINTFLAG_TCMPL;
		dmac_pending[1] = false;
		if(dmac_tx_cb[1] != NULL)
			dmac_tx_cb[1]();
	}
	if(DMAC->Channel[1].CHINTFLAG.bit.SUSP)
		DMAC->Channel[1].CHINTFLAG.reg = DMAC_CHINTFLAG_SUSP;
	if(DMAC->Channel[1].CHINTFLAG.bit.TERR)
	{
		DMAC->Channel[1].CHINTFLAG.reg = DMAC_CHINTFLAG_TERR;
		if(dmac_err_cb[1] != NULL)
			dmac_err_cb[1]();
	}
#endif	
#if DMA_CHANNELS > 2
	if(DMAC->Channel[2].CHINTFLAG.bit.TCMPL)
	{
		DMAC->Channel[2].CHINTFLAG.reg = DMAC_CHINTFLAG_TCMPL;
			dmac_pending[2] = false;
		if(dmac_tx_cb[2] != NULL)
			dmac_tx_cb[2]();
	}
	if(DMAC->Channel[2].CHINTFLAG.bit.SUSP)
		DMAC->Channel[2].CHINTFLAG.reg = DMAC_CHINTFLAG_SUSP;
	if(DMAC->Channel[2].CHINTFLAG.bit.TERR)
	{
		DMAC->Channel[2].CHINTFLAG.reg = DMAC_CHINTFLAG_TERR;
		if(dmac_err_cb[2] != NULL)
			dmac_err_cb[2]();
	}
#endif
#endif
}

void DMA_ChannelInit(uint8_t channel, uint32_t dst, uint8_t trigsrc, dma_cb_func_txptr dma_tx, dma_cb_func_errptr dma_err)		
{
#ifdef DMA_SINGLE
	DMAC->CHCTRLA.bit.SWRST = DMAC_CHCTRLA_SWRST;
#else	
	DMAC->Channel[channel].CHCTRLA.bit.SWRST = DMAC_CHCTRLA_SWRST;
#endif
	dmac_dst[channel] = dst;
	dmac_tx_cb[channel] = dma_tx;
	dmac_err_cb[channel] = dma_err;
	
#ifdef DMA_SINGLE
	DMAC->CHCTRLA.reg = DMAC_CHCTRLA_ENABLE | DMAC_CTRL_LVLEN(0xf);//DMAC_CHCTRLA_BURSTLEN_SINGLE | DMAC_CHCTRLA_THRESHOLD_1BEAT | DMAC_CHCTRLA_BURSTLEN_SINGLE | DMAC_CHCTRLA_TRIGACT_BURST | DMAC_CHCTRLA_TRIGSRC(trigsrc);
	DMAC->CHCTRLB.reg = DMAC_CHCTRLB_LVL(0) | DMAC_CHCTRLB_TRIGSRC(trigsrc) | DMAC_CHCTRLB_TRIGACT_BEAT;
	DMAC->CHINTENSET.reg = DMAC_CHINTENSET_MASK;			// Enable all
#else	
	DMAC->Channel[channel].CHCTRLA.reg = DMAC_CHCTRLA_BURSTLEN_SINGLE | DMAC_CHCTRLA_THRESHOLD_1BEAT | DMAC_CHCTRLA_BURSTLEN_SINGLE | DMAC_CHCTRLA_TRIGACT_BURST | DMAC_CHCTRLA_TRIGSRC(trigsrc);
	DMAC->Channel[channel].CHINTENSET.reg = DMAC_CHINTENSET_MASK;			// Enable all
#endif
}

/************************************************************************/
/*						                                                */
/************************************************************************/
bool DMA_Send(uint8_t channel, uint8_t *bfr, uint16_t length)	
{
	DmacDescriptor dmac_descriptor;
	bool result = true;
	if(channel >= DMAC_MAX_CHANNEL || length > DMAC_MAX_DATA_LEN)
		return false;

#ifdef DMA_SINGLE	
	NVIC_DisableIRQ(DMAC_IRQn);
#else	
	NVIC_DisableIRQ(DMAC_0_IRQn);
#endif	
	if(!dmac_pending[channel])
	{	
		dmac_pending[channel] = true;
		memcpy(dmac_txbfr[channel], bfr, length);
	
		dmac_descriptor.BTCTRL.reg = DMAC_BTCTRL_VALID |  // VALID: Descriptor Valid
										DMAC_BTCTRL_BLOCKACT_NOACT |  // BLOCKACT=NOACT: Block Action
										DMAC_BTCTRL_SRCINC | // SRCINC: Source Address Increment Enable
										DMAC_BTCTRL_STEPSEL_DST | // STEPSEL=SRC: Step Selection
										DMAC_BTCTRL_STEPSIZE_X1;  // STEPSIZE=X1: Address Increment Step Size*/
		dmac_descriptor.BTCNT.reg = length; // beat count
		dmac_descriptor.DSTADDR.reg = dmac_dst[channel];
		dmac_descriptor.DESCADDR.reg = 0;
		dmac_descriptor.SRCADDR.reg = (uint32_t)dmac_txbfr[channel] + length;
	
		memcpy(&dmaDescriptorArray[channel], &dmac_descriptor, sizeof(dmac_descriptor));
#ifdef DMA_SINGLE	
		DMAC->CHCTRLA.reg |= DMAC_CHCTRLA_ENABLE;		// Enable the DMAC write channel
#else		
		DMAC->Channel[channel].CHCTRLA.reg |= DMAC_CHCTRLA_ENABLE;		// Enable the DMAC write channel
#endif
	}
	else
		result = false;

#ifdef DMA_SINGLE
	NVIC_EnableIRQ(DMAC_IRQn);
#else
	NVIC_EnableIRQ(DMAC_0_IRQn);
#endif	
	
	return result;
}

#endif