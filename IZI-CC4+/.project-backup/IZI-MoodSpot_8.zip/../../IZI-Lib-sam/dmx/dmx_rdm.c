/*
 * dmx_rdm.c
 *
 *  Created on: 23 jan. 2025
 *      Author: Milo
 */

#include "includes.h"
#include "dmx_rdm_models.h"
#include "dmx_rdm.h"
#include "rdm.h"
#include "esta.h"
#include "appconfig.h"
#include "state.h"
#include "dmx_rdm_module.h"
#include "timers.h"
#include "dmx.h"
#include "timing.h"

/*******************************************************************************
 * Variables
 ******************************************************************************/
volatile uint8_t dmx_rdm_state;
volatile RDM_MEM dmx_rdm_data __attribute__((aligned(4)));;
volatile uint16_t dmx_in_rdm_cs;
volatile uint16_t dmx_in_data_idx, dmx_in_data_test;
volatile uint16_t dmx_rdm_rx_time;
trace_level_t dmxrdm_trace_lvl = 0;

// Defines
// The Device ID for addressing all devices of a manufacturer.
const DEVICEID dmx_rdm_group = { ESTA_MANUFACTURER_ID_H, ESTA_MANUFACTURER_ID_L, 0xFF, 0xFF, 0xFF, 0xFF };

// The Device ID for addressing all devices: 6 times 0xFF.
const DEVICEID dmx_rdm_all = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };


// compare 2 DeviceIDs
#define DeviceIDCmp(id1, id2) memcmp((uint8_t *)id1, (uint8_t *)id2, sizeof(DEVICEID))

// copy an DeviceID id2 to id1
#define DeviceIDCpy(id1, id2) memcpy((uint8_t *)id1, (uint8_t *)id2, sizeof(DEVICEID))

const char manufacturerLabel[] = ESTA_MANUFACTURER_NAME;

// Proto
void DmxRdm_SendResponse(bool is_handled, uint16_t nack_reason, int16_t idx);
bool DmxRdm_SendData(uint8_t *data, uint16_t len, bool is_discover);
bool DmxRdm_CheckFormat(int16_t expected_length, int16_t expected_sub, uint16_t *nackReason);
bool DmxRdm_CheckFormatL(int16_t expected_length, int16_t expected_sub, uint16_t *nackReason);
bool DmxRdm_CheckFormatS(int16_t expected_length, int16_t expected_sub, uint16_t *nackReason);

extern char *last_code;
/**
 * Initialise RDM (device ID)
 */
void DmxRdm_Init()
{
	DmxRdm_Module_Init();
}


/**
 * Start byte of RDM received
 */
void DmxRdm_Start()
{
	dmx_rdm_data.buffer[0] = E120_SC_RDM;
	dmx_in_rdm_cs = E120_SC_RDM;
	dmx_in_data_idx = 1;
	dmx_rdm_data.packet.length = 0;			// Wait for real length
	dmx_rdm_state = RDM_DATA;
}

/**
 * New RDM data came in
 */
uint8_t DmxRdm_DataIn(uint8_t data)
{
	if (dmx_rdm_state == RDM_DATA)
	{
		if (dmx_in_data_idx >= (int)sizeof(dmx_rdm_data.buffer)) {
		  // too much data ...
			dmx_rdm_state = RDM_IDLE;
		} else {
			dmx_rdm_data.buffer[dmx_in_data_idx++] = data;
			dmx_in_rdm_cs += data;

			if (dmx_in_data_idx == dmx_rdm_data.packet.length) {
				// all data received. Now getting checksum !
				dmx_rdm_state = RDM_CSH; // wait for checksum High Byte
			}
		}
	}
	else if (dmx_rdm_state == RDM_CSH)
	{
		// High byte of RDM checksum -> subtract from checksum
		dmx_in_rdm_cs -= (uint16_t)data << 8;
		dmx_rdm_state = RDM_CSL;
	}
	else if (dmx_rdm_state == RDM_CSL)
	{
		// High byte of RDM checksum -> subtract from checksum
		dmx_in_rdm_cs -= (uint16_t)data;
		dmx_rdm_state = RDM_CSL;
		if ((dmx_in_rdm_cs == 0) && (dmx_rdm_data.packet.sub_start_code == E120_SC_SUB_MESSAGE))
		{
			dmx_rdm_state = RDM_READY;
			dmx_rdm_rx_time = timing_get_count();			// Store time that the last slot was received (for timing of sending break for response)
			return RDM_RX_READY;
		}
	}

	if(dmx_rdm_state == RDM_IDLE)
		return RDM_RX_IDLE;

	return RDM_RX_BUSY;
}

// Addressing modes
#define AM_DEST_NONE	0x00			// Not for us
#define AM_DEST_UC		0x01			// Unicast
#define AM_DEST_GC		0x02			// Groupcast
#define	AM_DEST_BC		0x03			// Broadcast

/**
 * Check if new frame has to be handled
 */
void DmxRdm_FrameHandler()
{
	if(dmx_rdm_state == RDM_READY)
	{
		uint8_t addr_mode = AM_DEST_NONE;
		int16_t idx = -100;
		uint8_t sub_devices = 0;
		// in the ISR only some global conditions are checked: DestID
		if (DeviceIDCmp(dmx_rdm_data.packet.dest_id, dmx_rdm_all) == 0) {
			addr_mode = AM_DEST_BC;
			idx = DMX_RDM_BC_INDEX;
		} else if (DeviceIDCmp(dmx_rdm_data.packet.dest_id, dmx_rdm_group) == 0) {
			addr_mode = AM_DEST_GC;
			idx = DMX_RDM_BC_INDEX;
		} else  {
			idx = DmxRdm_Module_SearchSerial(READINT32((dmx_rdm_data.packet.dest_id + 2)), &sub_devices);
			if(idx >= 0)
				addr_mode = AM_DEST_UC;
		}

		uint16_t parameter = READINT(dmx_rdm_data.packet.parameter);
		uint8_t cmd_class = dmx_rdm_data.packet.cmd_class;

		if(addr_mode == AM_DEST_NONE)			// Not for us
		{
			dmx_rdm_state = RDM_IDLE;
#ifdef DMX_RDM_THRU_MONITOR
			char txt[96 + 1];

			for(int i = 0; i < 32; i++)
			{
				if(i >= dmx_rdm_data.packet.data_length)
				{
					txt[(i * 3)] = 0;
					break;
				}
				sprintf(&txt[i * 3], "%02X ", dmx_rdm_data.packet.data[i]);
			}
			OS_TRACE_INFO("*** RDM Tx -> Par: 0x%04X | Cmd: %s | Len: %d | Data: %s *****\r\n", parameter, (cmd_class & 0xFE) == 0x30 ? "SET" : (cmd_class & 0xFE) == 0x20 ? "GET" : "DISCOVER", dmx_rdm_data.packet.data_length, txt);
#endif
			return;
		}

		int16_t sub_dev = (dmx_rdm_data.packet.sub_dev[0] << 8) + dmx_rdm_data.packet.sub_dev[1];
		uint16_t nackReason = E120_NR_UNKNOWN_PID;
		bool handled = false, skip_send = false;
		//DMXRDM_TRACE_INFO("Par: 0x%x Cmd: 0x%x (%d)\r\n", parameter, cmd_class, idx);
		
		dmx_in_data_test++;
		
		// Handled queued first, to be able to fake all PIDs
		if (parameter == E120_QUEUED_MESSAGE) { // 0x0020
			if (cmd_class == E120_SET_COMMAND) {
				// Unexpected set
				nackReason = E120_NR_UNSUPPORTED_COMMAND_CLASS;
			} else if (cmd_class == E120_GET_COMMAND) {
				if (DmxRdm_CheckFormat(1, sub_devices, &nackReason)) { // No extra data expected
					uint16_t queued_pid;
					uint8_t queued_data[8];
					uint8_t data_length, queue_len;

					// Try to fetch the next queued message
					if (DmxRdm_Module_GetQueuedMessage(idx, sub_dev, &queued_pid, queued_data, &data_length, &queue_len)) {
						// Fake input for correct output
						parameter = queued_pid;
						WRITEINT(dmx_rdm_data.packet.parameter, parameter);
						dmx_rdm_data.packet.data_length = data_length;
						if(data_length > 0)
							dmx_rdm_data.packet.data[0] = queued_data[0];
						//handled = true;
					} else {
						// No messages in queue, return E120_STATUS_MESSAGES
						parameter = E120_STATUS_MESSAGES;
						WRITEINT(dmx_rdm_data.packet.parameter, parameter);
						//dmx_rdm_data.packet.data[0] = E120_STATUS_ADVISORY;		// Leave data as is
					}
					DMXRDM_TRACE_WARNING("Queued msg[%d.%d] 0x%x: %d (l:%d)\r\n", idx, sub_dev, parameter, dmx_rdm_data.packet.data[0], dmx_rdm_data.packet.data_length);
				}
			}
		}
		if(cmd_class == E120_DISCOVERY_COMMAND)
		{
			if (parameter == E120_DISC_UNIQUE_BRANCH) { // 0x0001
				if((idx = DmxRdm_Module_GetUnmuted()) >= 0)		// Get first unmuted module with lowest serial
				{
					DEVICEID dmx_rdm_devid;
					DmxRdm_Module_GetDeviceID(idx, dmx_rdm_devid);
					bool responded = true;
					if ((DeviceIDCmp(dmx_rdm_data.packet.data, dmx_rdm_devid) <= 0) && (DeviceIDCmp(dmx_rdm_devid, dmx_rdm_data.packet.data+6) <= 0)) {
						// respond with a special discovery message !
						volatile DISCOVERYMSG *disc = (volatile DISCOVERYMSG *)dmx_rdm_data.buffer;
						uint16_t cs = 0;

						// fill in the dmx_rdm_data.discovery response structure
						for (uint8_t i = 0; i < 7; i++)
							disc->headerFE[i] = 0xFE;

						disc->headerAA = 0xAA;
						for (uint8_t i = 0; i < 6; i++) {
							disc->maskedDevID[i+i]   = dmx_rdm_devid[i] | 0xAA;
							disc->maskedDevID[i+i+1] = dmx_rdm_devid[i] | 0x55;
						}
						for(uint8_t i = 0; i < 12; i++)
							cs += disc->maskedDevID[i];

						disc->checksum[0] = (cs >> 8)   | 0xAA;
						disc->checksum[1] = (cs >> 8)   | 0x55;
						disc->checksum[2] = (cs & 0xFF) | 0xAA;
						disc->checksum[3] = (cs & 0xFF) | 0x55;

						DmxRdm_SendData((uint8_t *)disc, sizeof(DISCOVERYMSG), true);
					}
					else
						responded = false;

					DMXRDM_TRACE_INFO("Discover cmd(%d) %c (%x%x): 0x%02X%02X%02X%02X%02X%02X  >= 0x%02X%02X%02X%02X%02X%02X <= 0x%02X%02X%02X%02X%02X%02X\r\n", idx, responded ? '*' : '.', dmx_rdm_data.buffer[0], dmx_rdm_data.buffer[1],
													dmx_rdm_devid[0], dmx_rdm_devid[1], dmx_rdm_devid[2], dmx_rdm_devid[3], dmx_rdm_devid[4], dmx_rdm_devid[5],
													dmx_rdm_data.packet.data[0], dmx_rdm_data.packet.data[1], dmx_rdm_data.packet.data[2], dmx_rdm_data.packet.data[3], dmx_rdm_data.packet.data[4], dmx_rdm_data.packet.data[5],
													dmx_rdm_data.packet.data[6], dmx_rdm_data.packet.data[7], dmx_rdm_data.packet.data[8], dmx_rdm_data.packet.data[9], dmx_rdm_data.packet.data[10], dmx_rdm_data.packet.data[11]);
				}
				else
					DMXRDM_TRACE_DEBUG("Discover all modules muted\r\n");

				skip_send = true;
			}
			else if (parameter == E120_DISC_UN_MUTE) { // 0x0003
				if(dmx_rdm_data.packet.data_length == 0)		// No data expected
				{
					DmxRdm_Module_Mute(false, idx);
					DMXRDM_TRACE_INFO("Unmute cmd: %d (%d)\r\n", addr_mode, idx);
					if (addr_mode == AM_DEST_UC) { // Only actually respond if it's sent direct to us
						// Control field
						dmx_rdm_data.packet.data[0] = 0b00000000;
						dmx_rdm_data.packet.data[1] = 0b00000000;
						dmx_rdm_data.packet.data_length = 2;
						handled = true;
					}
				}
			}
			else if (parameter == E120_DISC_MUTE) { // 0x0002
				if(dmx_rdm_data.packet.data_length == 0)		// No data expected
				{
					DmxRdm_Module_Mute(true, idx);
					DMXRDM_TRACE_INFO("Mute cmd: %d (%d)\r\n", addr_mode, idx);
					if (addr_mode == AM_DEST_UC) { // Only actually respond if it's sent direct to us
						// Control field
						dmx_rdm_data.packet.data[0] = 0b00000000;
						dmx_rdm_data.packet.data[1] = 0b00000000;
						dmx_rdm_data.packet.data_length = 2;
						handled = true;
					}
				}
			}
		}
		else if(cmd_class == E120_DISCOVERY_COMMAND_RESPONSE || cmd_class == E120_GET_COMMAND_RESPONSE || cmd_class == E120_SET_COMMAND_RESPONSE)
		{
			skip_send = true;
			DMXRDM_TRACE_WARNING("Response of a neighbour received, par: 0x%02x cmd: %02x\r\n", parameter, cmd_class);
		}
		else if (parameter == E120_IDENTIFY_DEVICE) { 	// 0x1000
			if (cmd_class == E120_SET_COMMAND) { 		// 0x30
				if (dmx_rdm_data.packet.data[0] > 1) {
					// Out of range data
					nackReason = E120_NR_DATA_OUT_OF_RANGE;
				}
				else if(DmxRdm_CheckFormat(1, sub_devices, &nackReason)) {
					DmxRdm_Module_SetIdentify(idx, sub_dev, dmx_rdm_data.packet.data[0] != 0);
					dmx_rdm_data.packet.data_length = 0;
					DMXRDM_TRACE_INFO("Device identify SET[%d]: %d\r\n", idx, dmx_rdm_data.packet.data[0] != 0);
					handled = true;
				}
			} else if (cmd_class == E120_GET_COMMAND) { // 0x20
				if (DmxRdm_CheckFormat(0, 0, &nackReason))
				{
					dmx_rdm_data.packet.data[0] = DmxRdm_Module_GetIdentify(idx, sub_dev);
					dmx_rdm_data.packet.data_length = 1;
					DMXRDM_TRACE_INFO("Device identify GET[%d]: %d\r\n", idx, dmx_rdm_data.packet.data[0]);
					handled = true;
				}
			} // if
		} if (parameter == E120_RESET_DEVICE) { 	// 0x1001
			if (cmd_class == E120_SET_COMMAND) { 		// 0x30
				if(DmxRdm_CheckFormat(1, sub_devices, &nackReason)) {
					DmxRdm_Module_SetReset(idx, sub_dev, dmx_rdm_data.packet.data[0]);
					dmx_rdm_data.packet.data_length = 0;
					DMXRDM_TRACE_INFO("Device reset SET[%d]: %d\r\n", idx, dmx_rdm_data.packet.data[0]);
					handled = true;
				}
			} else if (cmd_class == E120_GET_COMMAND) { // 0x20
				//if (DmxRdm_CheckFormat(0, 0, &nackReason))
				//{
					nackReason = E120_NR_UNSUPPORTED_COMMAND_CLASS;
					DMXRDM_TRACE_INFO("Device reset GET not supported\r\n");
				//}
			} // if
		} else if (parameter == E120_DEVICE_INFO) { // 0x0060
			if (cmd_class == E120_GET_COMMAND) {
				if (DmxRdm_CheckFormat(0, sub_devices, &nackReason))
				{
					// return all device info data
					DEVICEINFO *devInfo = (DEVICEINFO *)(dmx_rdm_data.packet.data); // The data has to be responded in the Data buffer.

					bool res = DmxRdm_Module_GetDeviceInfo(idx, sub_dev, devInfo);

					dmx_rdm_data.packet.data_length = sizeof(DEVICEINFO);
					DMXRDM_TRACE_INFO("Device info[%d.%d]: %d (%d)\r\n", idx, sub_dev, sizeof(DEVICEINFO), res);
					handled = true;
				}
			}
		}
		else if (parameter == E120_MANUFACTURER_LABEL) { // 0x0081
			if (cmd_class == E120_GET_COMMAND) {
		        if (DmxRdm_CheckFormat(0, sub_devices, &nackReason)) {
		          // return the manufacturer label
		          uint8_t len = strlen(manufacturerLabel);
		          if(len > DMXSERIAL_MAX_RDM_STRING_LENGTH)
		        	  len = DMXSERIAL_MAX_RDM_STRING_LENGTH;
		          dmx_rdm_data.packet.data_length = len;
		          memcpy((uint8_t *)dmx_rdm_data.packet.data, manufacturerLabel, dmx_rdm_data.packet.data_length);
		          handled = true;
		        }
		      } else if (cmd_class == E120_SET_COMMAND) {
		        // Unexpected set
		        nackReason = E120_NR_UNSUPPORTED_COMMAND_CLASS;
		      }
		}
		else if (parameter == E120_DEVICE_MODEL_DESCRIPTION) { // 0x0080
			if (cmd_class == E120_GET_COMMAND) {
				if (DmxRdm_CheckFormat(0, sub_devices, &nackReason)) {
					// return the DEVICE MODEL DESCRIPTION
					char name[DMXSERIAL_MAX_RDM_STRING_LENGTH + 1];
					uint8_t len = DmxRdm_Module_GetModelName(idx, sub_dev, name, DMXSERIAL_MAX_RDM_STRING_LENGTH);
					if(len > DMXSERIAL_MAX_RDM_STRING_LENGTH)
					  len = DMXSERIAL_MAX_RDM_STRING_LENGTH;
					dmx_rdm_data.packet.data_length = len;
					memcpy((uint8_t *)dmx_rdm_data.packet.data, name, len);

					DMXRDM_TRACE_INFO("Device model[%d.%d]: %s\r\n", idx, sub_dev, name);
					handled = true;
				}
			} else if (cmd_class == E120_SET_COMMAND) {
				// Unexpected set
				nackReason = E120_NR_UNSUPPORTED_COMMAND_CLASS;
			}

		} else if (parameter == E120_DEVICE_LABEL) { // 0x0082
			if (cmd_class == E120_SET_COMMAND) {
				if (DmxRdm_CheckFormatL(DMXSERIAL_MAX_RDM_STRING_LENGTH, sub_devices, &nackReason)) {
					dmx_rdm_data.packet.data[dmx_rdm_data.packet.data_length] = 0;
					DmxRdm_Module_SetLabel(idx, sub_dev, (char *)dmx_rdm_data.packet.data, dmx_rdm_data.packet.data_length);
					DMXRDM_TRACE_INFO("Set label[%d](%d): %s\r\n", idx, dmx_rdm_data.packet.data_length, dmx_rdm_data.packet.data);
					dmx_rdm_data.packet.data_length = 0;
					// Store new label
					handled = true;
				}
			} else if (cmd_class == E120_GET_COMMAND) {
				if (DmxRdm_CheckFormat(0, 0, &nackReason))
				{
					char name[DMXSERIAL_MAX_RDM_STRING_LENGTH + 1];
					uint8_t len = DmxRdm_Module_GetLabel(idx, sub_dev, name, DMXSERIAL_MAX_RDM_STRING_LENGTH);
					if(len > DMXSERIAL_MAX_RDM_STRING_LENGTH)
					  len = DMXSERIAL_MAX_RDM_STRING_LENGTH;

					name[len] = 0;
					dmx_rdm_data.packet.data_length = len;
					memcpy((uint8_t *)dmx_rdm_data.packet.data, name, len);

					DMXRDM_TRACE_INFO("Get label[%d](%d): %s\r\n", idx, dmx_rdm_data.packet.data_length, name);
					handled = true;
				}
			}
		} else if (parameter == E120_SOFTWARE_VERSION_LABEL || parameter == E120_BOOT_SOFTWARE_VERSION_LABEL) { // 0x00C0/0x00C2
			if (cmd_class == E120_GET_COMMAND) {
				if (DmxRdm_CheckFormat(0, sub_devices, &nackReason)) {
					// return the SOFTWARE_VERSION_LABEL
					char version[DMXSERIAL_MAX_RDM_STRING_LENGTH + 1];
					uint8_t len = DmxRdm_Module_GetVersionLabel(idx, sub_dev, version, DMXSERIAL_MAX_RDM_STRING_LENGTH, parameter == E120_BOOT_SOFTWARE_VERSION_LABEL);
					if(len > DMXSERIAL_MAX_RDM_STRING_LENGTH)
						len = DMXSERIAL_MAX_RDM_STRING_LENGTH;
					dmx_rdm_data.packet.data_length = len;
					memcpy((uint8_t *)dmx_rdm_data.packet.data, version, dmx_rdm_data.packet.data_length);
					handled = true;
				}
			} else if (cmd_class == E120_SET_COMMAND) {
				// Unexpected set
				nackReason = E120_NR_UNSUPPORTED_COMMAND_CLASS;
			}

		} else if (parameter == E120_DMX_START_ADDRESS) { // 0x00F0
			if (cmd_class == E120_SET_COMMAND) {
				if (DmxRdm_CheckFormat(2, sub_devices, &nackReason)) {
				  uint16_t address = READINT(dmx_rdm_data.packet.data);
				  if (address == 0 || !DmxRdm_Module_SetAddress(idx, sub_dev, address - 1)) {
					  nackReason = E120_NR_DATA_OUT_OF_RANGE;
				  } else {
					  dmx_rdm_data.packet.data_length = 0;
					  DMXRDM_TRACE_INFO("Start address set: %d\r\n", address);
					  handled = true;
				  }
				}
			} else if (cmd_class == E120_GET_COMMAND) {
				if (DmxRdm_CheckFormat(0, 0, &nackReason)) {
					uint16_t address = DmxRdm_Module_GetAddress(idx, sub_dev);
					WRITEINT(dmx_rdm_data.packet.data, (address + 1));
					dmx_rdm_data.packet.data_length = 2;
					handled = true;
				}
			}
		} else if (parameter == E120_SUPPORTED_PARAMETERS) { // 0x0050
			  if (cmd_class == E120_GET_COMMAND) {
		    	  if (DmxRdm_CheckFormat(0, sub_devices, &nackReason)) {
					  // Some supported PIDs shouldn't be returned as per the standard, these are:
					  // E120_DISC_UNIQUE_BRANCH
					  // E120_DISC_MUTE
					  // E120_DISC_UN_MUTE
					  // E120_SUPPORTED_PARAMETERS
					  // E120_IDENTIFY_DEVICE
					  // E120_DEVICE_INFO
					  // E120_DMX_START_ADDRESS
					  // E120_SOFTWARE_VERSION_LABEL
		    		  uint16_t parameters[32];
		    		  uint8_t amount = 0;
		    		  if((amount = DmxRdm_Module_GetSupportedParameters(idx, sub_dev, parameters, 32)) > 0)
		    		  {
		    			  for(int i = 0; i < amount; i++)
		    			  {
		    				  WRITEINT((dmx_rdm_data.packet.data + (i * 2)), parameters[i]);
		    			  }
		    			  dmx_rdm_data.packet.data_length = 2 * amount;
		    		  }
		    		  else
		    			  nackReason = E120_NR_UNSUPPORTED_COMMAND_CLASS;

					  DMXRDM_TRACE_WARNING("Supported parameters[%d]: %d\r\n", idx, dmx_rdm_data.packet.data_length);
					  handled = true;
					}
			  } else if (cmd_class == E120_SET_COMMAND) {
				// Unexpected set
				nackReason = E120_NR_UNSUPPORTED_COMMAND_CLASS;
			  }
		} else if (parameter == E120_PARAMETER_DESCRIPTION) { // 0x0051
			  if (cmd_class == E120_GET_COMMAND) {
				  uint16_t r_pid = READINT(dmx_rdm_data.packet.data);
		    	  if (DmxRdm_CheckFormat(2, sub_devices, &nackReason)) {
		    		  PARAMETER_DESCRIPTION *par_description;
		    		  if((par_description = DmxRdm_Module_GetDescriptionParameters(idx, sub_dev, r_pid)) != NULL)
		    		  {
		    			  uint8_t len = strlen(par_description->description);
		    			  memcpy((uint8_t *)dmx_rdm_data.packet.data, &par_description->pid, 20 + len);
						  dmx_rdm_data.packet.data_length = 20 + len;
						  DMXRDM_TRACE_INFO("Description parameters[%d]: 0x%x %d -> 0x%x %s\r\n", idx, r_pid, dmx_rdm_data.packet.data_length, par_description->pid, par_description->description);
						  handled = true;
		    		  }
		    		  else
		    			  nackReason = E120_NR_UNKNOWN_PID;
					}
			  } else if (cmd_class == E120_SET_COMMAND) {
				// Unexpected set
				nackReason = E120_NR_UNSUPPORTED_COMMAND_CLASS;
			  }
		} else if (parameter == E120_DMX_PERSONALITY) { // 0x00E0
			if (cmd_class == E120_SET_COMMAND) {
				if (DmxRdm_CheckFormat(1, sub_devices, &nackReason)) {
					uint8_t pers = dmx_rdm_data.packet.data[0];
				  if (pers == 0 || !DmxRdm_Module_SetPersonality(idx, sub_dev, pers - 1)) {
					  nackReason = E120_NR_DATA_OUT_OF_RANGE;
				  } else {
					  dmx_rdm_data.packet.data_length = 0;
					  DMXRDM_TRACE_INFO("Personality set: %d\r\n", pers);
					  handled = true;
				  }
				}
			} else if (cmd_class == E120_GET_COMMAND) {
				if (DmxRdm_CheckFormat(0, sub_devices, &nackReason)) {
					int8_t res = (DmxRdm_Module_GetPersonality(idx, sub_dev, (uint8_t *)&dmx_rdm_data.packet.data[1]));
					if(res >= 0)
						dmx_rdm_data.packet.data[0] = res + 1;
					else
						dmx_rdm_data.packet.data[0] = 0;
					dmx_rdm_data.packet.data_length = 2;
					DMXRDM_TRACE_INFO("Personality get %d\r\n", dmx_rdm_data.packet.data[0]);
					handled = true;
				}
			}
		} else if (parameter == E120_DMX_PERSONALITY_DESCRIPTION) { // 0x00E1
			if (cmd_class == E120_GET_COMMAND) {
				if (DmxRdm_CheckFormat(1, sub_devices, &nackReason)) {
					uint8_t channels = 0;
					uint8_t personality_idx = dmx_rdm_data.packet.data[0] - 1;
					uint8_t len = 0;
					if((len = DmxRdm_Module_GetPersonalityDescription(idx, sub_dev, personality_idx, (char *)&dmx_rdm_data.packet.data[3], DMXSERIAL_MAX_RDM_STRING_LENGTH, &channels)) > 0)
					{
						dmx_rdm_data.packet.data[0] = personality_idx + 1;
						dmx_rdm_data.packet.data[1] = 0;				// High byte channel amount
						dmx_rdm_data.packet.data[2] = channels;
						dmx_rdm_data.packet.data_length = len + 3;
						handled = true;
					}
					else
						nackReason = E120_NR_DATA_OUT_OF_RANGE;
				}
			} else if (cmd_class == E120_SET_COMMAND) {
				// Unexpected set
				nackReason = E120_NR_UNSUPPORTED_COMMAND_CLASS;
			}
		}
		else if (parameter == E120_LAMP_STATE ) { // 0x0403
			if (cmd_class == E120_SET_COMMAND) {
				if (DmxRdm_CheckFormat(1, sub_devices, &nackReason)) {
					uint8_t state = dmx_rdm_data.packet.data[0];
					  if (!DmxRdm_Module_SetLampState(idx, sub_dev, state)) {
						  nackReason = E120_NR_DATA_OUT_OF_RANGE;
					  } else {
						  dmx_rdm_data.packet.data_length = 0;
						  DMXRDM_TRACE_INFO("Lamp state set: %d\r\n", state);
						  handled = true;
					  }
				}
			} else if (cmd_class == E120_GET_COMMAND) {
				if (DmxRdm_CheckFormat(0, sub_devices, &nackReason)) {
					dmx_rdm_data.packet.data[0] = (DmxRdm_Module_GetLampState(idx, sub_dev));
					dmx_rdm_data.packet.data_length = 1;
					DMXRDM_TRACE_INFO("Lamp state get %d\r\n", dmx_rdm_data.packet.data[0]);
					handled = true;
				}
			}
		}
		else if (parameter == E120_DEVICE_HOURS ) { // 0x0400
			if (cmd_class == E120_SET_COMMAND) {
				if (DmxRdm_CheckFormat(4, sub_devices, &nackReason)) {
				  //uint32_t new_device_hours = READINT32(dmx_rdm_data.packet.data);
				  //if (new_device_hours > 0) {
					// Out of range start address
					// TODO: Add footprint
					nackReason = E120_NR_DATA_OUT_OF_RANGE;
				  /*} else {
					  dmx_rdm_operating_hours = new_device_hours;
					  dmx_rdm_data.packet.data_length = 0;
					  DMXRDM_TRACE_ERROR("Clear operation time: %d\r\n", new_device_hours);
					  handled = true;
				  }*/
				}
			} else if (cmd_class == E120_GET_COMMAND) {
				if (DmxRdm_CheckFormat(0, 0, &nackReason)) {
					uint32_t operation_hours = DmxRdm_Module_GetDeviceHours(idx, sub_dev);
					WRITEINT32(dmx_rdm_data.packet.data, operation_hours);
				    dmx_rdm_data.packet.data_length = 4;
				    handled = true;
				}
			}
		}
		else if (parameter == E120_LAMP_HOURS ) { // 0x0401
			if (cmd_class == E120_SET_COMMAND) {
				if (DmxRdm_CheckFormat(4, sub_devices, &nackReason)) {
				  //uint32_t new_burning_hours = READINT32(dmx_rdm_data.packet.data);
				  //if (new_burning_hours > 0) {
					// Out of range start address
					// TODO: Add footprint
					nackReason = E120_NR_DATA_OUT_OF_RANGE;
				  /*} else {
					  dmx_rdm_burning_hours = new_burning_hours;
					  dmx_rdm_data.packet.data_length = 0;
					  DMXRDM_TRACE_ERROR("Clear burning hours: %d\r\n", new_burning_hours);
					  handled = true;
				  }*/
				}
			} else if (cmd_class == E120_GET_COMMAND) {
				if (DmxRdm_CheckFormat(0, 0, &nackReason)) {
				    uint32_t burning_hours = DmxRdm_Module_GetBurnHours(idx, sub_dev);
					WRITEINT32(dmx_rdm_data.packet.data, burning_hours);
				    dmx_rdm_data.packet.data_length = 4;
				    handled = true;
				}
			}
		}
		else if (parameter == E120_SENSOR_DEFINITION) { // 0x0200
			if (cmd_class == E120_GET_COMMAND) {
				if (DmxRdm_CheckFormat(1, sub_devices, &nackReason)) {
					SENSORDEF* sensor_def = DmxRdm_Module_GetSensorDef(idx, sub_dev, dmx_rdm_data.packet.data[0]);
					DMXRDM_TRACE_INFO("Sensor desc get: %d\r\n", dmx_rdm_data.packet.data[0]);
					if(sensor_def != NULL)
					{
						uint8_t len = strlen(sensor_def->description);
						memcpy((uint8_t *)dmx_rdm_data.packet.data, &sensor_def->sensorNumber, 13 + len);
						dmx_rdm_data.packet.data_length = len + 13;
						handled = true;
					}
					else
						nackReason = E120_NR_DATA_OUT_OF_RANGE;
				}
			} else if (cmd_class == E120_SET_COMMAND) {
				// Unexpected set
				nackReason = E120_NR_UNSUPPORTED_COMMAND_CLASS;
			}
		}
		else if (parameter == E120_SENSOR_VALUE ) { // 0x0201
			if (cmd_class == E120_SET_COMMAND) {
				// Unexpected set
				nackReason = E120_NR_UNSUPPORTED_COMMAND_CLASS;
			} else if (cmd_class == E120_GET_COMMAND) {
				if (DmxRdm_CheckFormat(1, sub_devices, &nackReason)) {
					uint16_t data;
					uint8_t len = DmxRdm_Module_GetSensorValue(idx, sub_dev, dmx_rdm_data.packet.data[0], &data);
					if(len > 0)
					{
						WRITEINT(dmx_rdm_data.packet.data + 1, data);
						WRITEINT(dmx_rdm_data.packet.data + 3, 0);		// Highest
						WRITEINT(dmx_rdm_data.packet.data + 5, 0);		// Lowest
						WRITEINT(dmx_rdm_data.packet.data + 7, 0);		// recorded
						dmx_rdm_data.packet.data_length = 9;
						handled = true;
					}
					else
						nackReason = E120_NR_DATA_OUT_OF_RANGE;
				}
			}
		} else if (parameter >= E120_TDE_SPECIFIC_START && parameter <= E120_TDE_SPECIFIC_END) { // TDE specific > 0x8000
			if (cmd_class == E120_SET_COMMAND) {
				if (DmxRdm_CheckFormatS(1, sub_devices, &nackReason)) {
				  uint16_t data = 0;
				  if(dmx_rdm_data.packet.data_length == 1)
					  data = dmx_rdm_data.packet.data[0];
				  else if(dmx_rdm_data.packet.data_length == 2)
					  data = READINT(dmx_rdm_data.packet.data);

				  if (!DmxRdm_Module_SetTdeSpecific(idx, sub_dev, parameter, data)) {
					  nackReason = E120_NR_DATA_OUT_OF_RANGE;
				  } else {
					  dmx_rdm_data.packet.data_length = 0;
					  DMXRDM_TRACE_INFO("TDE set 0x%x: %d\r\n", parameter, data);
					  handled = true;
				  }
				}
			} else if (cmd_class == E120_GET_COMMAND) {
				if (DmxRdm_CheckFormat(0, 0, &nackReason)) {
					uint16_t data;
					uint8_t size = DmxRdm_Module_GetTdeSpecific(idx, sub_dev, parameter, &data);
					DMXRDM_TRACE_INFO("TDE get 0x%x: %d %d\r\n", parameter, data, size);
					if(size > 0)
					{
						if(size == 4)
						{
							WRITEINT32(dmx_rdm_data.packet.data, (data));
						}
						else if(size == 2)
						{
							WRITEINT(dmx_rdm_data.packet.data, (data));
						}
						else
							dmx_rdm_data.packet.data[0] = (uint8_t)data;

						dmx_rdm_data.packet.data_length = size;
						handled = true;
					}
				}
			}
		} else if (parameter == E120_STATUS_ID_DESCRIPTION) { // 0x0032
		    if (cmd_class == E120_GET_COMMAND) {
		        if (DmxRdm_CheckFormat(2, sub_devices, &nackReason)) { // Expecting 2 bytes for Status ID
		            uint16_t status_id = READINT(dmx_rdm_data.packet.data); // Read the requested Status ID

		            const char *description = DmxRdm_Module_GetStatusDescription(status_id); // Lookup description
		            if (description) {
		                size_t desc_len = strlen(description);
		                if (desc_len > DMXSERIAL_MAX_RDM_STRING_LENGTH)
		                	desc_len = DMXSERIAL_MAX_RDM_STRING_LENGTH; // Max length per RDM spec

		                memcpy((uint8_t *)dmx_rdm_data.packet.data, description, desc_len);
		                dmx_rdm_data.packet.data_length = desc_len;
		                DMXRDM_TRACE_INFO("Status desc msg[%d]: %d of %d -> %s\r\n", idx, desc_len, status_id, description);
		                handled = true;
		            } else {
		                nackReason = E120_NR_DATA_OUT_OF_RANGE; // Invalid Status ID
		            }
		        }
		    }
		} /*else if (parameter == E120_CLEAR_STATUS_ID) { // 0x0033
		    if (cmd_class == E120_SET_COMMAND) {
		    	if (DmxRdm_CheckFormat(0, sub_devices, &nackReason)) { // Expecting 0 bytes of data
		    		DmxRdm_Module_ClearAllStatusMessages(); // Clears all stored status messages
					handled = true;
				}
		    }
		} */else if (parameter == E120_STATUS_MESSAGES) { // 0x0030
			if (cmd_class == E120_GET_COMMAND) {
				if (DmxRdm_CheckFormat(1, sub_devices, &nackReason)) {
					uint8_t status_type;
					uint16_t status_id, sub_dev;
					uint8_t status_data[MAX_STATUS_DATA_SIZE];
					uint8_t data_length;

					dmx_rdm_data.packet.data_length = 0;

					uint8_t req_type = dmx_rdm_data.packet.data[0];
					if(dmx_rdm_data.packet.data[0] != E120_STATUS_NONE)
					{
						for(int i = 0; i < 25; i++)
						{
							uint8_t res = DmxRdm_Module_GetStatusMessage(idx, req_type, &sub_dev, &status_type, &status_id, status_data, &data_length);
							if (res > 0) {
								WRITEINT(dmx_rdm_data.packet.data + dmx_rdm_data.packet.data_length + 0, sub_dev);
								dmx_rdm_data.packet.data[dmx_rdm_data.packet.data_length + 2] = status_type;
								WRITEINT(dmx_rdm_data.packet.data + dmx_rdm_data.packet.data_length + 3, status_id);
								memcpy((uint8_t *)(dmx_rdm_data.packet.data + dmx_rdm_data.packet.data_length + 5), status_data, data_length);

								dmx_rdm_data.packet.data_length += 9;
								if(res == 1)
									break;
							}
							else
								break;
						}
					}

					DMXRDM_TRACE_INFO("Status msg 0x%x: %d, ret len: %d, t: %d, id: %d\r\n", parameter, req_type, dmx_rdm_data.packet.data_length, status_type, status_id);

					handled = true;
				}
			}
		}

		// dmx_rdm_sensors
		if(addr_mode == AM_DEST_UC && !skip_send)
		{
			dmx_rdm_data.packet.message_count = DmxRdm_Module_GetQueuedLength(idx, sub_devices);			// Add queued message count (if > 0 more to come)
			DmxRdm_SendResponse(handled, nackReason, idx);
#ifdef DMX_RDM_THRU_MONITOR
			char txt[96 + 1];

			for(int i = 0; i < 32; i++)
			{
				if(i >= dmx_rdm_data.packet.data_length)
				{
					txt[(i * 3)] = 0;
					break;
				}
				sprintf(&txt[i * 3], "%02X ", dmx_rdm_data.packet.data[i]);
			}
			OS_TRACE_INFO("### RDM Tx -> Par: 0x%04X | Cmd: %s | Len: %d | Sub: %d | Data: %s ####\r\n", parameter, (cmd_class & 0xFE) == 0x30 ? "SET" : (cmd_class & 0xFE) == 0x20 ? "GET" : "DISCOVER", (dmx_rdm_data.packet.sub_dev[0] << 8) + dmx_rdm_data.packet.sub_dev[1], dmx_rdm_data.packet.data_length, txt);
#endif
		}
		if(!skip_send && !handled && addr_mode == AM_DEST_UC)
		{
			DMXRDM_TRACE_WARNING("RDM frame nacked: %d, par: 0x%02X class: 0x%02X\r\n", nackReason, parameter, cmd_class);

			DMXRDM_TRACE_WARNING("RDM frame received-> Cmd:%d, Len:%d (%d), Par: 0x%x, Sub: %d, Source: 0x%02X%02X%02X%02X%02X%02X, Dest: 0x%02X%02X%02X%02X%02X%02X Data: %02X %02X\r\n", dmx_rdm_data.packet.cmd_class, dmx_rdm_data.packet.length, dmx_rdm_data.packet.data_length, parameter,sub_dev,
					dmx_rdm_data.packet.source_id[0], dmx_rdm_data.packet.source_id[1], dmx_rdm_data.packet.source_id[2], dmx_rdm_data.packet.source_id[3], dmx_rdm_data.packet.source_id[4], dmx_rdm_data.packet.source_id[5],
					dmx_rdm_data.packet.dest_id[0], dmx_rdm_data.packet.dest_id[1], dmx_rdm_data.packet.dest_id[2], dmx_rdm_data.packet.dest_id[3], dmx_rdm_data.packet.dest_id[4], dmx_rdm_data.packet.dest_id[5],
					dmx_rdm_data.packet.data[0], dmx_rdm_data.packet.data[1]);
		}
		dmx_rdm_state = RDM_IDLE;
	}
}

/**
 * Check if length is equal to given number and if sub device is OK
 */
bool DmxRdm_CheckFormat(int16_t expected_length, int16_t expected_sub, uint16_t *nackReason)
{
	if(expected_length >= 0)
	{
		if(dmx_rdm_data.packet.data_length != expected_length)		// Incorrect data length?
		{
			*nackReason = E120_NR_FORMAT_ERROR;
			return false;
		}
	}
	if(expected_sub >= 0)
	{
		if(dmx_rdm_data.packet.sub_dev[0] > expected_sub)				// Not the correct sub device?
		{
			DMXRDM_TRACE_WARNING("RDM %d %d\r\n", dmx_rdm_data.packet.sub_dev[0], expected_sub);
			*nackReason = E120_NR_SUB_DEVICE_OUT_OF_RANGE;
			return false;
		}
	}
	return true;
}

/**
 * Check if length is not larger than given number and if sub device is OK
 */
bool DmxRdm_CheckFormatL(int16_t expected_length, int16_t expected_sub, uint16_t *nackReason)
{
	if(expected_length >= 0)
	{
		if(dmx_rdm_data.packet.data_length > expected_length)		// Incorrect data length?
		{
			*nackReason = E120_NR_FORMAT_ERROR;
			return false;
		}
	}
	if(expected_sub >= 0)
	{
		if(dmx_rdm_data.packet.sub_dev[0] > expected_sub)				// Not the correct sub device?
		{
			DMXRDM_TRACE_WARNING("RDM %d %d\r\n", dmx_rdm_data.packet.sub_dev[0], expected_sub);
			*nackReason = E120_NR_SUB_DEVICE_OUT_OF_RANGE;
			return false;
		}
	}
	return true;
}

/**
 * Check if length is larger or equal than given number and if sub device is OK
 */
bool DmxRdm_CheckFormatS(int16_t expected_length, int16_t expected_sub, uint16_t *nackReason)
{
	if(expected_length >= 0)
	{
		if(dmx_rdm_data.packet.data_length < expected_length)		// Incorrect data length?
		{
			*nackReason = E120_NR_FORMAT_ERROR;
			return false;
		}
	}
	if(expected_sub >= 0)
	{
		if(dmx_rdm_data.packet.sub_dev[0] > expected_sub)				// Not the correct sub device?
		{
			DMXRDM_TRACE_WARNING("RDM %d %d\r\n", dmx_rdm_data.packet.sub_dev[0], expected_sub);
			*nackReason = E120_NR_SUB_DEVICE_OUT_OF_RANGE;
			return false;
		}
	}
	return true;
}

void DmxRdm_SendReady()
{
	Dmx_Direction(false);						// Turn the port to input again
}

void DmxRdm_SendStart()
{
	Dmx_Send();									// Enable interrupt/dma to send
}

void DmxRdm_BreakStop()
{
	Dmx_BreakStop();
	timing_set_callback1(14, DmxRdm_SendStart);		// Send MAB 14us (12 is minimum)
}

void DmxRdm_StartBreak(void)
{
	Dmx_BreakStart();								// Send break
	Dmx_Direction(true);							// Turn the port to output here (may be done 88us before here)
	timing_set_callback0(178, DmxRdm_BreakStop);	// Start sending after break end, break now 178us (176us is minimum)
}

void DmxRdm_SendStartDirect()
{
	Dmx_Direction(true);							// Turn the port to output here (may be done 88us before here)
	DmxRdm_SendStart();
}

bool DmxRdm_SendData(uint8_t *data, uint16_t len, bool is_discover)
{
	if(Dmx_SendPrepare(data, len) == 0)			// Prepare frame
	{
		return false;							// Not OK, stop
	}

	// TIMING: don't send too fast, min: 176 microseconds
	uint16_t d = timing_get_count() - dmx_rdm_rx_time;
	if (d <= 176)								// Response must wait at least 176us after receiving request
	{
		uint32_t delay = 176 - d;				// Calculate extra delay
		if(delay < 8)							// If too short, add some extra
			delay = 8;
		timing_set_callback1(delay, !is_discover ? DmxRdm_StartBreak : DmxRdm_SendStartDirect);			// Call start break delayed (or send direct when its a discover)
		DMXRDM_TRACE_DEBUG("Add RDM delay %d + %d (%d %d)!!\r\n", d, delay, len, sizeof(dmx_rdm_data));
	}
	else if(d <= 2000)							// Check if not too long, max is 2.8ms according to protocol
	{
		if(!is_discover)
			DmxRdm_StartBreak();				// Call start break direct
		else
			DmxRdm_SendStartDirect();			// Start sending direct (without break) when discover
		DMXRDM_TRACE_DEBUG("RDM delay = %d!! (%d %d)\r\n", d, len, sizeof(dmx_rdm_data));
	}
	else
	{
		Dmx_SendFlush();
		DMXRDM_TRACE_WARNING("RDM too late, frame dropped: %d\r\n", d);
		return false;
	}
	return true;
}

void DmxRdm_SendResponse(bool is_handled, uint16_t nack_reason, int16_t idx)
{
	uint16_t checkSum = 0;

	// no need to set these data fields:
	// StartCode, SubStartCode
	if (is_handled) {
		dmx_rdm_data.packet.response_type = E120_RESPONSE_TYPE_ACK; // 0x00
	} else {
		dmx_rdm_data.packet.response_type = E120_RESPONSE_TYPE_NACK_REASON; // 0x02
		dmx_rdm_data.packet.data_length = 2;
		dmx_rdm_data.packet.data[0] = (nack_reason >> 8) & 0xFF;
		dmx_rdm_data.packet.data[1] = nack_reason & 0xFF;
	}
	dmx_rdm_data.packet.length = dmx_rdm_data.packet.data_length + 24; // total packet length (including checksum)
	if(dmx_rdm_data.packet.data_length > 231)
		return;

	// swap SrcID into DestID for sending back.
	DeviceIDCpy(dmx_rdm_data.packet.dest_id, dmx_rdm_data.packet.source_id);

	DEVICEID devid;
	DmxRdm_Module_GetDeviceID(idx, devid);
	DeviceIDCpy(dmx_rdm_data.packet.source_id, devid);

	dmx_rdm_data.packet.cmd_class++;
	// parameter

	// prepare buffer and Checksum
	for (uint8_t i = 0; i < dmx_rdm_data.packet.length; i++) {
		checkSum += dmx_rdm_data.buffer[i];
	}
	dmx_rdm_data.packet.data[dmx_rdm_data.packet.data_length] = (uint8_t)(checkSum >> 8);
	dmx_rdm_data.packet.data[dmx_rdm_data.packet.data_length + 1] = (uint8_t)(checkSum >> 0);

	DmxRdm_SendData((uint8_t *)dmx_rdm_data.buffer, dmx_rdm_data.packet.length + 2, false);
}


