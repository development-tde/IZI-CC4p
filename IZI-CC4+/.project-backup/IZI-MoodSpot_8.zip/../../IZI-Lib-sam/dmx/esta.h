/*
 * esta.h
 *
 *  Created on: 24 jan. 2025
 *      Author: Milo
 */

#ifndef ESTA_H_
#define ESTA_H_

// Manufacturer ID
#define ESTA_MANUFACTURER_ID	0x5459	// ESTA Mfg Code (5459h -> TI: TDE IZI)
#define ESTA_MANUFACTURER_ID_H	0x54	// 'T'
#define ESTA_MANUFACTURER_ID_L	0x59	// 'Y' oops

#define ESTA_MANUFACTURER_NAME	"TDE-lighttech"

#endif /* ESTA_H_ */
