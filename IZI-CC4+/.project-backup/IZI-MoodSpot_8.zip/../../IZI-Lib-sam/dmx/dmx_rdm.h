/*
 * dmx_rdm.h
 *
 *  Created on: 23 jan. 2025
 *      Author: Milo
 */

#ifndef DMX_RDM_H_
#define DMX_RDM_H_

// ----- Enumerations -----
// current state of receiving or sending DMX/RDM Bytes
typedef enum {
  RDM_IDLE,     // ignoring everything and wait for the next BREAK
             	// or a valid RDM packet arrived, need for processing !
  RDM_DATA,   	// receiving RDM data into the _rdm.buffer
  RDM_CSH, 		// received the High byte of the _rdm.buffer checksum
  RDM_CSL,  	// received the Low byte of the _rdm.buffer checksum
  RDM_READY		// Frame ready to be handled
} DMXReceivingState;

typedef enum {
  RDM_RX_BUSY,
  RDM_RX_IDLE,
  RDM_RX_READY,
} RdmParseState;

// ----- structures -----

// the special discovery response message
typedef struct DISCOVERYMSG_s {
	uint8_t headerFE[7];
	uint8_t headerAA;
	uint8_t maskedDevID[12];
	uint8_t checksum[4];
}DISCOVERYMSG; // struct DISCOVERYMSG

/**
 * @brief The RDMDATA structure defines the RDM network packages.
 *
 * This structure has the size of (24+data) and is used by all GET/SET RDM commands.
 * The maximum permitted data length according to the spec is 231 bytes.
 */

#pragma pack(push, 1) // Ensure no padding in the structure
typedef struct RDMDATA_s {
	uint8_t     start_code;			// Start Code 0xCC for RDM
	uint8_t     sub_start_code;		// Start Code 0x01 for RDM
	uint8_t     length;				// packet length
	uint8_t     dest_id[6];
	uint8_t     source_id[6];

	uint8_t     trans_no;			// transaction number, not checked
	uint8_t     response_type;		// ResponseType
	uint8_t     message_count;		// not used unless we support queued messages
	uint8_t 	sub_dev[2];			// sub device number (root = 0)
	uint8_t     cmd_class;			// command class
	uint8_t 	parameter[2];		// parameter ID, can not be uint16 due to alignment
	uint8_t     data_length;		// parameter data length in bytes
	uint8_t     data[231 + 2];		// data byte field
}RDMDATA;
#pragma pack(pop)

// This is the buffer for RDM packets being received and sent.
// This structure is needed to separate RDM data from DMX data.
typedef union RDMMEM_u {
  // the most common RDM packet layout for commands
  RDMDATA packet;

  // the layout of the RDM packet when returning a discovery message
  DISCOVERYMSG discovery;

  // the byte array used while receiving and sending.
  // This is the max size of any RDM packet and it's max PDL, to allow an
  // aribitrary length packet to be received. Thanks to the union it doesn't
  // need any more memory
  uint8_t buffer[sizeof(RDMDATA)];
}RDM_MEM; // union RDMMEM



#define DMXRDM_PREFIX	"[rdm]\t"

#undef DMXRDM_TRACE_BUILD_LVL
#define DMXRDM_TRACE_BUILD_LVL 2

#if DMXRDM_TRACE_BUILD_LVL >= 0
#define DMXRDM_TRACE_ERROR(...)		{ if(dmxrdm_trace_lvl >= TRACE_LEVEL_ERROR)		{ esp_printf(Debug_Putc, DMXRDM_PREFIX, __VA_ARGS__); } }
#else
#define DMXRDM_TRACE_ERROR(...)
#endif
#if DMXRDM_TRACE_BUILD_LVL >= 1
#define DMXRDM_TRACE_WARNING(...)		{ if(dmxrdm_trace_lvl >= TRACE_LEVEL_WARNING)	{ esp_printf(Debug_Putc, DMXRDM_PREFIX, __VA_ARGS__); } }
#else
#define DMXRDM_TRACE_WARNING(...)
#endif
#if DMXRDM_TRACE_BUILD_LVL >= 2
#define DMXRDM_TRACE_INFO(...)		{ if(dmxrdm_trace_lvl >= TRACE_LEVEL_INFO)		{ esp_printf(Debug_Putc, DMXRDM_PREFIX, __VA_ARGS__); } }
#else
#define DMXRDM_TRACE_INFO(...)
#endif
#if DMXRDM_TRACE_BUILD_LVL >= 3
#define DMXRDM_TRACE_DEBUG(...)		{ if(dmxrdm_trace_lvl >= TRACE_LEVEL_DEBUG)		{ esp_printf(Debug_Putc, DMXRDM_PREFIX, __VA_ARGS__); } }
#else
#define DMXRDM_TRACE_DEBUG(...)
#endif
#if DMXRDM_TRACE_BUILD_LVL >= 4
#define DMXRDM_TRACE_VERBOSE(...)		{ if(dmxrdm_trace_lvl >= TRACE_LEVEL_DEBUG)		{ esp_printf(Debug_Putc, DMXRDM_PREFIX, __VA_ARGS__); } }
#else
#define DMXRDM_TRACE_VERBOSE(...)
#endif

// Proto
void DmxRdm_Init();
void DmxRdm_Start();
uint8_t DmxRdm_DataIn(uint8_t data);
void DmxRdm_FrameHandler();
void DmxRdm_SendReady();
void DmxRdm_StartBreak();
void DmxRdm_ThruData(uint8_t data);
void DmxRdm_ThruDataReady();

extern volatile uint8_t dmx_rdm_state;

#endif /* DMX_RDM_H_ */
