/*
 * dmx_rdm_models.h
 *
 *  Created on: 28 jan. 2025
 *      Author: Milo
 */

#ifndef DMX_RDM_MODELS_H_
#define DMX_RDM_MODELS_H_

// ----- Constants -----

#define DMXSERIAL_MAX 512                  ///< The max. number of supported DMX data channels
#define DMXSERIAL_MIN_SLOT_VALUE 0         ///< The min. value a DMX512 slot can take
#define DMXSERIAL_MAX_SLOT_VALUE 255       ///< The max. value a DMX512 slot can take
#define DMXSERIAL_MAX_RDM_STRING_LENGTH 32 ///< The max. length of a string in RDM

// ----- Types -----

/**
 * @brief Type definition for a unique DEVICE ID.
 *
 * DEVICEID[0..1] contains a ESTA Manufacturer ID.
 * DEVICEID[2..5] contains a unique number per device.
 */
typedef uint8_t DEVICEID[6];

#pragma pack(push, 1) // Ensure no padding in the structure
// The DEVICEINFO structure (length = 19) has to be responded for E120_DEVICE_INFO
// See http://rdm.openlighting.org/pid/display?manufacturer=0&pid=96
typedef struct DEVICEINFO_s {
	uint8_t protocolMajor;
	uint8_t protocolMinor;
	uint16_t deviceModel;
	uint16_t productCategory;
	uint32_t softwareVersion;
	uint16_t footprint;
	uint8_t currentPersonality;
	uint8_t personalityCount;
	uint16_t startAddress;
	uint16_t subDeviceCount;
	uint8_t sensorCount;
}DEVICEINFO; // struct DEVICEINFO
#pragma pack(pop)

#pragma pack(push, 1) // Ensure no padding in the structure
typedef struct SENSORDEF_s {
    uint8_t sensorNumber;     // Sensor ID (starting at 0)
    uint8_t sensorType;       // Type of sensor (e.g., temperature, voltage)
    uint8_t units;            // Units (e.g., °C, Volts)
    uint8_t prefix;           // Unit prefix (e.g., milli, kilo)
    int16_t rangeMin;         // Minimum possible value for the sensor
    int16_t rangeMax;         // Maximum possible value for the sensor
    int16_t normalMin;        // Normal operating minimum value
    int16_t normalMax;        // Normal operating maximum value
    uint8_t recordedValueSupport; // 1 = Supports recorded values, 0 = No support
    char description[DMXSERIAL_MAX_RDM_STRING_LENGTH];     // ASCII description (null-terminated)
} SENSORDEF;
#pragma pack(pop)

#pragma pack(push, 1) // Ensure no padding in the structure
typedef struct PARAMETER_DESCRIPTION_s {
    uint16_t pid;                // Manufacturer-specific PID requested (2 bytes)
    uint8_t pdlSize;             // PDL Size (Defines max length for variable-sized data like ASCII string) (1 byte)
    uint8_t dataType;            // Data Type (Defines the size of data entries in the parameter description) (1 byte)
    uint8_t commandClass;        // Command Class (Defines GET/SET support for the PID) (1 byte)
    uint8_t type;                // Always 0x00, to be ignored by the controller (1 byte)
    uint8_t unit;                // Unit of the data (SI unit value, from Table A-13) (1 byte)
    uint8_t prefix;              // Prefix for the unit (SI prefix value, from Table A-14) (1 byte)
    uint32_t minValidValue;      // Minimum valid value (32-bit, padded if less than 32 bits) (4 bytes)
    uint32_t maxValidValue;      // Maximum valid value (32-bit, padded if less than 32 bits) (4 bytes)
    uint32_t defaultValue;       // Default value (32-bit, padded if less than 32 bits) (4 bytes)
    char description[32];        // Description text (up to 32 characters) (variable size)
} PARAMETER_DESCRIPTION;
#pragma pack(pop)


// ----- macros -----

/// @brief Use SWAPINT to swap the 2 bytes of an 16-bit int to match the byte order on the DMX Protocol.
///
/// 16-bit and 32-bit integers in the RDM protocol are transmitted highbyte - lowbyte.
/// but the ATMEGA processors store them in highbyte - lowbyte order.
/// avoid using this macro on variables but use it on the constant definitions.
#define SWAPINT(i) (((i&0x00FF)<<8) | ((i&0xFF00)>>8))

/// Use SWAPINT32 to swap the 4 bytes of a 32-bit int to match the byte order on the DMX Protocol.
#define SWAPINT32(i) ((i&0x000000ff)<<24) | ((i&0x0000ff00)<<8) | ((i&0x00ff0000)>>8) | ((i&0xff000000)>>24)

/// read a 16 bit number from a data buffer location
#define READINT(p) ((p[0]<<8) | (p[1]))
/// read a 32 bit number from a data buffer location
#define READINT32(p) (((uint32_t)(p[0]) << 24) | ((uint32_t)(p[1]) << 16) | ((uint32_t)(p[2]) << 8) | (p[3]))

/// write a 16 bit number to a data buffer location
#define WRITEINT(p, d) (p)[0] = (d&0xFF00)>>8; (p)[1] = (d&0x00FF);
/// write a 32 bit number to a data buffer location
#define WRITEINT32(p, d) \
    (p)[0] = ((d) & 0xFF000000) >> 24; \
    (p)[1] = ((d) & 0x00FF0000) >> 16; \
    (p)[2] = ((d) & 0x0000FF00) >> 8;  \
    (p)[3] = ((d) & 0x000000FF);

#endif /* DMX_RDM_MODELS_H_ */
