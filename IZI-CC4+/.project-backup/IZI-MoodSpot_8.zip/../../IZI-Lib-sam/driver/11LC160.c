/*
 * 11LC160.c
 *
 * Created: 9-1-2025 09:01:43
 *  Author: Milo
 */ 

#include "includes.h"
#include "11LC160.h"

typedef enum start_header_e
{
	START_HDR_IDLE	= 0,
	START_HDR_STANDBY = 1,
	START_HDR_PRESTART = 2,
	START_HDR_HEADER = 3,
}start_header_t;

typedef enum write_mode_flags_e
{
	WRITE_MODE_IDLE	= 0,
	WRITE_MODE_START = 1,
	WRITE_MODE_DEV_ADDR = 2,
	WRITE_MODE_CMD = 4,
	WRITE_MODE_WRITE = 8,
	WRITE_MODE_WRITE_END = 16,
	WRITE_MODE_READ_END = 32,
	WRITE_MODE_RW_RDY = 64,
}write_mode_flags_t;

#define WRITE_MODE_READ		WRITE_MODE_IDLE

typedef enum data_error_e
{
	DATA_ERROR_IDLE	= 0,
	DATA_ERROR_SAK = 1,
	DATA_ERROR_NOSAK = 2,
	DATA_ERROR_DATA = 3,
}data_error_t;

#define SCIO_INIT()			gpio_set_pin_direction(SCIO, GPIO_DIRECTION_IN);	\
							gpio_set_pin_pull_mode(SCIO, GPIO_PULL_UP);	\
							gpio_set_pin_function(SCIO, GPIO_PIN_FUNCTION_OFF)
						
#define SCIO_HIGH			gpio_set_pin_direction(SCIO, GPIO_DIRECTION_IN);		\
							gpio_set_pin_pull_mode(SCIO, GPIO_PULL_UP)
#define SCIO_LOW			PORT->Group[SCIO_PORT].OUTCLR.reg = 0x01 << SCIO_PIN;	\
							gpio_set_pin_direction(SCIO, GPIO_DIRECTION_OUT)

#define SCIO_GET			gpio_get_pin_level(SCIO)

#define START_HEADER_DATA	0x55
#define DEV_ADDR_DATA		0xA0

#define SCIO_DATA_ONE		0x02
#define SCIO_DATA_ZERO		0x01
#define SCIO_DATA_NOSAK		0x03
#define SCIO_DATA_SAK		SCIO_DATA_ONE

#define	CMD_READ			0x03		// Read data from memory array beginning at specified address
#define	CMD_CRRD			0x06		// Read data from current location in memory array
#define	CMD_WRITE			0x6C		// Write data to memory array beginning at specified address
#define	CMD_WREN			0x96		// Set the write enable latch (enable write operations)
#define	CMD_WRDI			0x91		// Reset the write enable latch (disable write operations)
#define	CMD_RDSR			0x05		// Read STATUS register
#define	CMD_WRSR			0x6E		// Write STATUS register
#define	CMD_ERAL			0x6D		// Write �0x00� to entire array
#define	CMD_SETAL			0x67		// Write �0xFF� to entire array

// Status READ
#define BIT_RDSR_WIP		0x01		// Write in process
#define BIT_RDSR_WEL		0x02		// Write enable latch
#define BIT_RDSR_BP0		0x04		// Block protection 0
#define BIT_RDSR_BP1		0x08		// Block protection 1

#define PAGE_SIZE			0x10		// 16 byte pages
#define MEM_SIZE			0x800		// 2k mem

#ifndef SCIO_TIMER_SPEED_US
#define SCIO_TIMER_SPEED_US	5
#endif 
#define SCIO_TIMER_SPEED	(1000000/SCIO_TIMER_SPEED_US)	// Timer speed in us, every 5us

#ifndef SCIO_TIMER
#define SCIO_TIMER				TC5
#endif
#ifndef SCIO_TIMER_INT
#define SCIO_TIMER_INT			TC5_Handler
#endif
#ifndef SCIO_TIMER_IRQN
#define SCIO_TIMER_IRQN			TC5_IRQn
#endif
#ifndef SCIO_TIMER_IRQ_PRIO
#define SCIO_TIMER_IRQ_PRIO		0		// Highest
#endif
#ifndef SCIO_TIMER_FREQ
#define SCIO_TIMER_FREQ			CONF_GCLK_TC5_FREQUENCY		
#endif
#ifndef SCIO_TIMER_ABX_MASK
#define SCIO_TIMER_ABX_MASK		hri_mclk_set_APBCMASK_TC5_bit
#endif
#ifndef SCIO_TIMER_GCLK_ID
#define SCIO_TIMER_GCLK_ID		TC5_GCLK_ID
#endif
#ifndef SCIO_TIMER_SRC
#define SCIO_TIMER_SRC			CONF_GCLK_TC5_SRC
#endif


volatile bool clock_second_state = false;
volatile uint8_t byte_data = 0;
volatile uint8_t bit_index = 0;
volatile uint8_t write_mode = 0; // 1 for write, 0 for read
volatile uint8_t start_header = 0; // If 1 start header is send before read or write
volatile uint8_t current_byte = 0;
volatile uint8_t *data_wptr = NULL, *data_rptr = NULL;
volatile uint16_t data_wlen = 0;
volatile uint16_t data_idx = 0;
volatile uint8_t data_phase = 0;
volatile uint8_t data_in = 0;
volatile uint8_t data_error = 0;
volatile uint8_t data_check_sak = 0;
volatile uint8_t data_cmd;
volatile uint8_t data_bfr[PAGE_SIZE + 2];
volatile uint8_t data_bfr_test[PAGE_SIZE*4];
volatile uint16_t data_rlen = 0;
volatile uint32_t data_timeout = 0;
volatile uint16_t data_idle_time;
volatile uint16_t data_idle_time_trans;
volatile bool m11c160_busy = false;

// Proto
int32_t M11LC160_CommandReadSingle(uint8_t command, uint8_t *bfr);
int32_t M11LC160_Command(uint8_t command);
int32_t M11LC160_CommandWriteSingle(uint8_t command, uint8_t *bfr);

volatile uint32_t res2;

/************************************************************************/
/* Init interface						                                        */
/************************************************************************/
void M11LC160_Init()
{
	SCIO_INIT();
	SCIO_HIGH;  // Drive bit high
	
	data_idle_time = 800 / SCIO_TIMER_SPEED_US;			// Min 600us high -> 800us for safety (and after 100us a pulse is given)
	data_idle_time_trans = 700 / SCIO_TIMER_SPEED_US;	// Do a H->L L->H transition after 100us (needed according to datasheet)
	
	SCIO_TIMER_ABX_MASK(MCLK);
	hri_gclk_write_PCHCTRL_reg(GCLK, SCIO_TIMER_GCLK_ID, SCIO_TIMER_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));

	SCIO_TIMER->COUNT16.CTRLA.reg = TC_CTRLA_SWRST;
	while ((SCIO_TIMER->COUNT16.SYNCBUSY.reg) & TC_SYNCBUSY_SWRST) {
	};

	// Init timer @ 200kHz -> Meaning the bitrate will be 50kHz -> Time per byte is 200us
	SCIO_TIMER->COUNT16.CTRLA.reg = TC_CTRLA_PRESCALER_DIV1 | TC_CTRLA_MODE_COUNT16;		// 96MHz
	SCIO_TIMER->COUNT16.INTENSET.reg = TC_INTENSET_MC0;
	SCIO_TIMER->COUNT16.WAVE.reg = TC_WAVE_WAVEGEN_MFRQ;									// Match frequency
	SCIO_TIMER->COUNT16.CC[0].reg = ((SCIO_TIMER_FREQ) / SCIO_TIMER_SPEED);					// Max 16-bit (for 32-BIT second timer is also used!!)
	SCIO_TIMER->COUNT16.CTRLA.reg |= TC_CTRLA_ENABLE;										// Use 16-bit, CC = period
	SCIO_TIMER->COUNT16.CTRLBSET.reg = TC_CTRLBSET_CMD_STOP;								// Stop running
	
	NVIC_DisableIRQ(SCIO_TIMER_IRQN);
	NVIC_ClearPendingIRQ(SCIO_TIMER_IRQN);
	NVIC_SetPriority(SCIO_TIMER_IRQN, SCIO_TIMER_IRQ_PRIO);							// Prio 0 is highest, 7 is lowest
	NVIC_EnableIRQ(SCIO_TIMER_IRQN);
}

/************************************************************************/
/* Interrupt every 10us                                                 */
/************************************************************************/
void SCIO_TIMER_INT(void)
{
	SCIO_TIMER->COUNT16.INTFLAG.reg = TC_INTFLAG_MC0;				// Clear
	
	M11LC160_Timer();
}

/************************************************************************/
/* Start transmission, all has to be prepared before                    */
/************************************************************************/
void  M11LC160_StartTranmission()
{
	start_header = START_HDR_STANDBY;
	SCIO_HIGH;  // Drive bit high
	data_error = 0;
	data_check_sak = 0;
	data_phase = 0;
	data_timeout = 0;
	data_idx = 0;
	
	if(data_idle_time == 0)								// Don't overwrite initial standby delay
		data_idle_time = 1;								// Make sure it's idle for 10us between commands
		
	// Enable timer
	SCIO_TIMER->COUNT16.COUNT.reg = 0;							// By setting the counter to 0, the first bit will be send after 10us which is enough to cover the Tss (Start header setup time)
	SCIO_TIMER->COUNT16.CTRLBSET.reg = TC_CTRLBSET_CMD_RETRIGGER;								// Stop running
}

/************************************************************************/
/* Wait for a transmission to finish with timeout of 500ms
  Reading more than 1k at once will cause timeout!!			            */
/************************************************************************/
int32_t M11LC160_WaitTransmission()
{
	uint32_t timeout = 0, last_data_timeout = 0;
	int32_t res = 0;
	if(xTaskGetSchedulerState() != taskSCHEDULER_NOT_STARTED)		// If scheduler is started, use delays to give other tasks some time
	{
		while(!(write_mode & WRITE_MODE_RW_RDY))
		{
			vTaskDelay(2);
			if(++timeout >= 250)			// More than 0.5s, is too long
			{
				res = -100;
				break;
			}
				
			if(last_data_timeout == data_timeout)
			{
				res = -102;				// Timer not running?
				break;
			}
			else
				last_data_timeout = data_timeout;
		}
	}	
	else
	{
		while(!(write_mode & WRITE_MODE_RW_RDY))
		{
			if(data_timeout > (500 * 100))		// More than 0.5s, is too long
			{
				res = -101;
				break;
			}
				
			if(last_data_timeout == data_timeout)
			{
				if(++timeout >= 60000)			// Timer not running?
				{
					res = -103;
					break;
				}
			}
			else
			{
				last_data_timeout = data_timeout;
				timeout = 0;
			}
		}
	}
	if((data_error > 0) || (res < 0))
	{
		SCIO_TIMER->COUNT16.CTRLBSET.reg = TC_CTRLBSET_CMD_STOP;
		if(res < 0)
			return res;
		if(write_mode & WRITE_MODE_START)
			return -1;
		if(write_mode & WRITE_MODE_DEV_ADDR)
			return -2;
		if(write_mode & WRITE_MODE_CMD)
			return -3;
		return -4;
	}
	return 0;
}

/************************************************************************/
/* Read from memory from given address 'length bytes'                   */
/************************************************************************/
int32_t M11LC160_Read(uint8_t *bfr, uint16_t address, uint16_t length)
{
	if(length > MEM_SIZE)
		return -10;
	
	write_mode = WRITE_MODE_READ|WRITE_MODE_START|WRITE_MODE_DEV_ADDR|WRITE_MODE_CMD;
	data_bfr[0] = (uint8_t)(address >> 8);
	data_bfr[1] = (uint8_t)(address >> 0);
	data_wptr = data_bfr;
	data_wlen = 2;				// First write 2 bytes
	data_rptr = bfr;
	data_rlen = length;			// Read amount
	data_cmd = CMD_READ;
	M11LC160_StartTranmission();	
	
	int32_t res = M11LC160_WaitTransmission();
	return res;
}

/************************************************************************/
/* Write to memory to given address 'length' bytes from bfr             */
/************************************************************************/
int32_t M11LC160_Write(uint8_t *bfr, uint16_t address, uint16_t length)
{
	if(length > PAGE_SIZE)
		return -10;
	
	write_mode = WRITE_MODE_WRITE|WRITE_MODE_START|WRITE_MODE_DEV_ADDR|WRITE_MODE_CMD;
	data_bfr[0] = (uint8_t)(address >> 8);
	data_bfr[1] = (uint8_t)(address >> 0);
	memcpy((uint8_t *)&data_bfr[2], bfr, length);
	data_wptr = data_bfr;
	data_wlen = length + 2;
	data_rlen = 0;
	data_cmd = CMD_WRITE;
	M11LC160_StartTranmission();
	
	int32_t res = M11LC160_WaitTransmission();
	return res;
}

/************************************************************************/
/* Send a command with no extra data to write or read                   */
/************************************************************************/
int32_t M11LC160_Command(uint8_t command)
{
	write_mode = WRITE_MODE_WRITE|WRITE_MODE_START|WRITE_MODE_DEV_ADDR|WRITE_MODE_CMD;
	data_wlen = 0;
	data_rlen = 0;
	data_cmd = command;
	
	M11LC160_StartTranmission();
	
	int32_t res = M11LC160_WaitTransmission();
	return res;
}

/************************************************************************/
/* Send a command and add a single byte to write                        */
/************************************************************************/
int32_t M11LC160_CommandWriteSingle(uint8_t command, uint8_t *bfr)
{
	write_mode = WRITE_MODE_WRITE|WRITE_MODE_START|WRITE_MODE_DEV_ADDR|WRITE_MODE_CMD;
	data_cmd = command;
	data_wptr = bfr;
	data_wlen = 1;
	data_rlen = 0;
	
	M11LC160_StartTranmission();
	
	int32_t res = M11LC160_WaitTransmission();
	return res;
}

/************************************************************************/
/* Send a command and read a single byte                                */
/************************************************************************/
int32_t M11LC160_CommandReadSingle(uint8_t command, uint8_t *bfr)
{
	write_mode = WRITE_MODE_START|WRITE_MODE_DEV_ADDR|WRITE_MODE_CMD;
	data_cmd = command;
	data_rptr = bfr;
	data_wlen = 0;
	data_rlen = 1;
	
	M11LC160_StartTranmission();
	
	int32_t res = M11LC160_WaitTransmission();
	return res;
}

/************************************************************************/
/* Read memory from given address                                       */
/************************************************************************/
int32_t M11LC160_ReadMem(uint8_t *bfr, uint16_t address, uint16_t length)
{
	if(m11c160_busy)			// Semaphore is better
		return -999;
		
	m11c160_busy = true;
	int32_t res = M11LC160_Read(bfr, address, length);
	m11c160_busy = false;
	
	return res;
}

/************************************************************************/
/* Write memory (per page), including Write enable and wait for finish  
  Beware to start at an address multiple of PAGE_SIZE or don't cross page
  border																*/
/************************************************************************/
int32_t M11LC160_WriteMem(uint8_t *bfr, uint16_t address, uint16_t length)
{
	int32_t res = 0;
	uint16_t len;
	
	if(m11c160_busy)			// Semaphore is better
		return -999;
	
	m11c160_busy = true;
	for(int i = 0; i < length; i += PAGE_SIZE)
	{
		res = M11LC160_Command(CMD_WREN);					// Enable write every time
		if(res < 0)
		{
			m11c160_busy = false;
			return res;
		}
		
		len = length - i;
		if(len > PAGE_SIZE)
			len = PAGE_SIZE;
		res = M11LC160_Write(bfr + i, address + i, len);	// Write max page size to memory
		if(res < 0)
		{
			m11c160_busy = false;
			return res;
		}
			
		uint8_t state;
		for(int w = 0; w < 16; w++)							// Wait for ready max 16 times for write to complete (1.2ms *16)
		{
			res = M11LC160_CommandReadSingle(CMD_RDSR, &state);
			if(res < 0)
			{
				m11c160_busy = false;
				return -99;
			}
				
			if((state & BIT_RDSR_WIP) == 0)			// Not busy?
				break;
		}
	}
	m11c160_busy = false;
	return res;
}

/************************************************************************/
/* Write lock bits (BP0 and BP1, bit 2 and 3                            */
/************************************************************************/
int32_t M11LC160_WriteLock(uint8_t statusw)
{
	int32_t res;
	
	if(m11c160_busy)			// Semaphore is better
		return -999;
	
	m11c160_busy = true;
	res = M11LC160_Command(CMD_WREN);
	if(res < 0)
	{
		m11c160_busy = false;
		return res;
	}
	uint8_t wr = statusw;
	res = M11LC160_CommandWriteSingle(CMD_WRSR, &wr);
	
	uint8_t state;
	for(int w = 0; w < 16; w++)							// Wait for ready max 16 times for write to complete (1.2ms *16)
	{
		res = M11LC160_CommandReadSingle(CMD_RDSR, &state);
		if(res < 0)
		{
			m11c160_busy = false;
			return -99;
		}
		
		if((state & BIT_RDSR_WIP) == 0)			// Not busy?
			break;
	}
	m11c160_busy = false;
	return res;
}

/************************************************************************/
/* The communication timer that should be called 
	between every 2.5us and 40us (10kHz/100kHz, 
	timer runs 4x faster for input read									*/
/************************************************************************/
void M11LC160_Timer()
{
	data_timeout++;
	if(data_idle_time)				// Check for setup delay
	{
		if(data_idle_time == data_idle_time_trans)
		{	SCIO_LOW;	}
		else
		{	SCIO_HIGH;	}
		data_idle_time--;
		return;
	}
	
	if(data_phase == 2)			// 2nd half of the byte?
	{
		// Alternate the clock signal (high or low)
		if (clock_second_state) {
			SCIO_HIGH; // Drive the clock pin high
			} else {
			SCIO_LOW; // Drive the clock pin low
		}
		data_phase++;
		return;
	}
	else if(data_phase & 0x01)
	{
		if(++data_phase >= 3)
		{
			data_phase = 0;
			data_in |= SCIO_GET ? 2 : 0;
		}
		else
		{
			data_in = SCIO_GET ? 1 : 0;
		}
		return;
	}
	data_phase++;
	// If dataphase == 0 the next code will be executed
	
	if(start_header > START_HDR_IDLE)
	{
		if(start_header == START_HDR_STANDBY)
		{
			SCIO_HIGH;  // Drive bit high
			clock_second_state = true;
			start_header = START_HDR_PRESTART;
			return;
		}
		else if(start_header == START_HDR_PRESTART)
		{
			SCIO_LOW;  // Drive bit low
			clock_second_state = false;
			start_header = START_HDR_HEADER;
			return;
		}
		current_byte = START_HEADER_DATA;	// Store the byte to be sent
		bit_index = 0;						// Start from the first bit of the byte
		write_mode |= WRITE_MODE_START;
		start_header = START_HDR_IDLE;
	}
	else if(data_check_sak > 0)				// Check for correct (No) SAK?
	{
		if(data_in != data_check_sak)
		{
			data_error = data_check_sak == SCIO_DATA_NOSAK ? DATA_ERROR_NOSAK : DATA_ERROR_SAK;
			write_mode |= WRITE_MODE_RW_RDY;
			SCIO_TIMER->COUNT16.CTRLBSET.reg = TC_CTRLBSET_CMD_STOP;
			return;
		}
		else if (write_mode == 0 && data_idx >= data_wlen)			// Read action?
		{
			data_check_sak = 0;
			return;													// Wait one cycle to clock in first byte
		}	
		else if(write_mode & (WRITE_MODE_WRITE_END|WRITE_MODE_READ_END))		
		{
			data_error = 0;
			write_mode |= WRITE_MODE_RW_RDY;
			SCIO_TIMER->COUNT16.CTRLBSET.reg = TC_CTRLBSET_CMD_STOP;		// Write OK
			return;
		}
		data_check_sak = 0;
	}
	
	// Handle communication: Read/Write data
	if (write_mode || data_idx < data_wlen) {
		// Send next bit of data
		if (bit_index < 8) {
			if (current_byte & (1 << (7 - bit_index))) {
				SCIO_LOW;   // Drive bit low
				clock_second_state = true;
			} else {
				SCIO_HIGH;  // Drive bit high
				clock_second_state = false;
			}
			bit_index++;
		} 
		else if (bit_index < 9)			// Send (No)Mak
		{
			if(((write_mode == WRITE_MODE_WRITE) && ((data_idx + 1) >= data_wlen)) ||
				((write_mode == (WRITE_MODE_WRITE|WRITE_MODE_CMD)) && ((data_wlen + data_rlen) == 0)))		// Last byte of write only? 
			{
				SCIO_HIGH;						// Send NoMAK
				clock_second_state = false;		
			}
			else
			{
				SCIO_LOW;						// Send MAK
				clock_second_state = true;		
			}
			bit_index++;
		}
		else 								// (No)Sak (just before)
		{
			SCIO_HIGH;						// Keep it input
			clock_second_state = true;
			
			bit_index = 0;
			
			if(write_mode & WRITE_MODE_START)
			{
				data_check_sak = SCIO_DATA_NOSAK;		// Check for NoSAK next bit
				current_byte = DEV_ADDR_DATA;			// Send Device address
				write_mode &= ~WRITE_MODE_START;
			}
			else if(write_mode & WRITE_MODE_DEV_ADDR)
			{
				data_check_sak = SCIO_DATA_SAK;			// Check for SAK next bit
				current_byte = data_cmd;				// Send command byte
				write_mode &= ~WRITE_MODE_DEV_ADDR;
			}
			else if(write_mode & WRITE_MODE_CMD)
			{
				data_check_sak = SCIO_DATA_SAK;			// Check for SAK next bit
				if(data_wlen + data_rlen == 0)
					write_mode |= WRITE_MODE_WRITE_END;			// Report ready after SAK
				else if(data_wlen)
					current_byte = data_wptr[0];				// Prepare first byte
				write_mode &= ~WRITE_MODE_CMD;
			}
			else
			{
				data_check_sak = SCIO_DATA_SAK;			// Check for SAK next bit
				
				// In write mode, check if we need to move to the next byte or end the operation
				if (++data_idx < data_wlen) 
					current_byte = data_wptr[data_idx];				// Send next bytes
				else if((write_mode & WRITE_MODE_WRITE))			// Write action? 
					write_mode |= WRITE_MODE_WRITE_END;				// Report ready after SAK
				else 
				{
					data_wlen = 0;
					data_idx = 0;						// Reset for use in read
				}
			}
		}
	} 
	else {
		SCIO_HIGH;
		clock_second_state = true;
		if (bit_index < 8) {
			if(bit_index == 0)
				byte_data = 0;
			if (data_in == SCIO_DATA_ONE) {
				byte_data |= (1 << (7 - bit_index));  // Sample bit (high)
			}
			else if(data_in != SCIO_DATA_ZERO)
			{
				data_error = DATA_ERROR_DATA;
				// STOP
			}
			if(++bit_index == 8)
			{
				if((data_idx + 1) >= data_rlen)		// Last byte of read?
				{
					SCIO_HIGH;						// Send NoMAK
					clock_second_state = false;
				}
				else
				{
					SCIO_LOW;						// Send MAK
					clock_second_state = true;
				}
			}
		} else {
			bit_index = 0;
			// Process the byte 
			data_rptr[data_idx] = byte_data;
			
			data_check_sak = SCIO_DATA_SAK;			// Check for SAK next bit
			
			if(++data_idx >= data_rlen)
				write_mode |= WRITE_MODE_READ_END;				// Report ready after SAK
		}
	}
	gpio_set_pin_level(LED_B, 0);
}

