/*
 * 11LC160.h
 *
 * Created: 9-11-2025 09:02:02
 *  Author: Milo
 */ 


#ifndef M11LC160_H_
#define M11LC160_H_

#define EXT_EEPROM_ADRR_FIXTURE			0
#define EXT_EEPROM_ADRR_LOG				1024
#define EXT_EEPROM_ADRR_PRODUCTION		1536

void M11LC160_Init();
void M11LC160_Timer();
int32_t M11LC160_ReadMem(uint8_t *bfr, uint16_t address, uint16_t length);
int32_t M11LC160_WriteMem(uint8_t *bfr, uint16_t address, uint16_t length);
int32_t M11LC160_WriteLock(uint8_t statusw);

#endif /* M11LC160_H_ */