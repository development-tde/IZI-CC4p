/*
 * mcp4725.c
 *
 * Created: 5-12-2023 09:01:43
 *  Author: Milo
 */ 

#include "includes.h"
#include "mcp4725.h"
//#include "i2cx.h"
#include "hpl_i2c_m_sync.h"

#define MCP4725_I2C_FAIL_MAX		5

SemaphoreHandle_t	mcp4725Semaphore;

#define MCP4725_IC_ADDRESS		0x60	

#define MCP4725_BFR_MAX			16
#define MCP4725_PAGE_MAX		0x100

uint8_t mcp4725_bfr[MCP4725_BFR_MAX + 1];
uint8_t mcp4725_fails[2];
bool mcp4725_init = false;

/************************************************************************/
/* Init I2C						                                        */
/************************************************************************/
void Mcp4725_Init()
{
	I2Cx_Init();
	mcp4725Semaphore = xSemaphoreCreateMutex();
	mcp4725_fails[0] = mcp4725_fails[1] = 0;
	mcp4725_init = true;
}

/************************************************************************/
/* I2C init ready?				                                        */
/************************************************************************/
bool Mcp4725_InitReady()
{
	return mcp4725_init;
}

/************************************************************************/
/* Write EEPROM					                                        */
/************************************************************************/
int32_t Mcp4725_WriteDac(bool second, uint16_t data)
{
	if(!mcp4725_init)
		return MCP4725_NO_INIT;
	
	if(xTaskGetSchedulerState() != taskSCHEDULER_NOT_STARTED)
		xSemaphoreTake (mcp4725Semaphore, 25);
	
	uint8_t bfr[2];
	bfr[0] = (uint8_t)(data >> 8);
	bfr[1] = (uint8_t)data;
	int32_t res = I2Cx_Write_Sequence(second ? (MCP4725_IC_ADDRESS + 1) : MCP4725_IC_ADDRESS, bfr, 2);
	
	//OS_TRACE_ERROR("MCP write[%d] %d: %d\r\n", second, data, res);
	if(res != I2C_OK)
	{
		if(++mcp4725_fails[second ? 1 : 0] >= MCP4725_I2C_FAIL_MAX)
		{
			State_SetError(STATE_ERROR_HW_ERROR);					// Report HW error, no or bad com with DAC
		}
	}
	else
	{
		if(mcp4725_fails[second ? 1 : 0] >= MCP4725_I2C_FAIL_MAX && mcp4725_fails[second ? 0 : 1] == 0)
			State_ClearError(STATE_ERROR_HW_ERROR);				// Clear error when both are OK and if error was (probably reported) by the MCP
	}	
	
	if(xTaskGetSchedulerState() != taskSCHEDULER_NOT_STARTED)
		xSemaphoreGive(mcp4725Semaphore);
	
	return res;
}
