/*
 * dcbm1_driver.c
 *
 *  Created on: 4 sep. 2020
 *      Author: Milo
 */

#include "includes.h"
#include "dcbm1_driver.h"
#include "appconfig.h"
#include "uart/usart1.h"
#include "hal_ext_irq.h"

/*******************************************************************************
 * Defines
 ******************************************************************************/
#define TASK_DCBM1_ENABLE				0
#define TASK_DCBM1_STACK_SIZE 			(2048 / sizeof(portSTACK_TYPE))
#define TASK_DCBM1_TASK_PRIORITY 		(tskIDLE_PRIORITY + 4)

#define DCBM1_UART_INIT					Usart1_Init
#define DCBM1_UART_PUTC					Usart1_Putc
#define DCBM1_UART_PUTBFR				Usart1_PutBfr

#define DCBM1_HDC(level)				gpio_set_pin_level(PLC_HDC, level)  
#define DCBM1_RST(level)				gpio_set_pin_level(PLC_RST, level)	
#define DCBM1_CSEL0(level)				gpio_set_pin_level(PLC_CSEL0, level)
#define DCBM1_CSEL1(level)				gpio_set_pin_level(PLC_CSEL1, level)
#define DCBM1_EN_TX(level)				DCBM1_CSEL0(level)

#define DCBM1_CSEL0_DIR(dir)			gpio_set_pin_direction(PLC_CSEL0, dir);
#define DCBM1_CSEL1_DIR(dir)			gpio_set_pin_direction(PLC_CSEL1, dir);
#define DCBM1_CSEL1_BUS_BUSY			gpio_get_pin_level(PLC_CSEL1)

/*******************************************************************************
 * Prototypes
 ******************************************************************************/
bool dcbm1_writereg(uint8_t reg, uint8_t data);
bool dcbm1_writesync();
bool dcbm1_readreg(uint8_t reg, uint8_t *data);


/*******************************************************************************
 * Variables
 ******************************************************************************/
#define DCBM1_MAX_TX_BUFFER	1024
static volatile uint8_t tx_buffer[DCBM1_MAX_TX_BUFFER];
static volatile uint16_t tx_in_idx, tx_out_idx;
static volatile uint8_t tx_busy;

#define DCBM1_MAX_RX_BUFFER	1024
#define DCBM1_MAX_RX_SEL	2
static volatile char rx_buffer[DCBM1_MAX_RX_SEL][DCBM1_MAX_RX_BUFFER];
static volatile uint16_t rx_index = 0;
static volatile uint8_t rx_select = 0;
static volatile int8_t rx_select_read = -1;
static volatile uint16_t rx_index_read = -1;
static volatile int8_t rx_select_overflow = 0;
static volatile uint8_t rx_commandmode = 0;
static volatile uint8_t tx_loop = 0;

static volatile uint8_t if_pin_func = 0;		// Interface pin functionality

trace_level_t dcbm1_trace_lvl = DCBM1_DFLT_TRACE_LVL;

#if TASK_DCBM1_ENABLE > 0
static TaskHandle_t		xDcbm1_Task;
#endif
static SemaphoreHandle_t xDcbm1_RxSemaphore = NULL;
static SemaphoreHandle_t xDcbm1_TxSemaphore = NULL;
static dcbm1_cb_func_rxptr dcbm1_cb_func_rx = NULL;
static dcbm1_cb_func_txptr dcbm1_cb_func_tx = NULL;
static volatile int dcbm1_extint_cnt, dcbm1_extint_dly;
static volatile bool dcbm1_delayed_tx = false;


static void tx_cb_USART_1()
{
	if(tx_busy)
	{
		if(if_pin_func == 0x01)
		{
			//bool bus_busy = DCBM1_CSEL1_BUS_BUSY;
			//if(!bus_busy)
			if(!rx_commandmode)
			{
				DCBM1_EN_TX(1);			// Indicate it can be send
			}
			//else
			//	dcbm1_delayed_tx = true;
			xSemaphoreGiveFromISR(xDcbm1_TxSemaphore, NULL);
			portEND_SWITCHING_ISR(true);		// Make sure the semaphore is directly handled (iso the next tick)
			
			if(!rx_commandmode)
			{
				DCBM1_EN_TX(0);
			}
		}
		tx_busy = 0;
	}
}

static void err_cb_USART_1()
{
	dcbm1_extint_cnt++;
}

static void rx_cb_USART_1(unsigned char c)
{
	if(!rx_commandmode)
	{
		if(dcbm1_cb_func_rx != NULL)
			dcbm1_cb_func_rx(c, true);
		return;
	}
			
	rx_buffer[rx_select][rx_index++] = c;
	if(c == '\n' || rx_commandmode || (rx_index >= (DCBM1_MAX_RX_BUFFER - 1)))
	{
		xSemaphoreGiveFromISR(xDcbm1_RxSemaphore, NULL);
		portEND_SWITCHING_ISR(true);		// Make sure the semaphore is directly handled (iso the next tick)
		if(rx_select_read >= 0)
			rx_select_overflow++;
		rx_select_read = rx_select;
		rx_index_read = rx_index;
		rx_buffer[rx_select][rx_index] = 0;

		if(++rx_select >= DCBM1_MAX_RX_SEL)			// Select other buffer
			rx_select = 0;

		rx_index = 0;
	}
	if(rx_index >= DCBM1_MAX_RX_BUFFER)
		rx_index = 0;
}

#define USART_1_BUFFER_SIZE 1024


void dcbm1_flexcomm_init(void)
{
	DCBM1_UART_INIT(tx_cb_USART_1, rx_cb_USART_1, err_cb_USART_1);
}

//void dcbm1_pint_intr_callback(const struct adc_async_descriptor *const descr, const uint8_t channel)
void EIC_4_Handler(void)
{
	if(dcbm1_cb_func_tx != NULL)
		dcbm1_cb_func_tx();
		
	EIC->INTFLAG.reg = EIC_INTFLAG_EXTINT(1 << 4);
}

void dcbm1_pin_interrupt_init()
{
	//NVIC_SetPriority(EIC_4_IRQn, configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY);
	
	//ext_irq_register(PIN_PA20, dcbm1_pint_intr_callback);
}

void dcbm1_set_rx_callback(dcbm1_cb_func_rxptr ptr)
{
	dcbm1_cb_func_rx = ptr;
}

void dcbm1_set_txready_callback(dcbm1_cb_func_txptr ptr)
{
	dcbm1_cb_func_tx = ptr;
}

bool dcbm1_checkerror()
{
	bool errorlog = false;
	if(dcbm1_extint_cnt && xTaskGetTickCount() > 2000)
	{
		State_SetWarning(STATE_WARNING_UART_OVW_WARN);
		dcbm1_extint_cnt = 0;
		if(dcbm1_extint_dly == 0)
			errorlog = true;
		dcbm1_extint_dly = 10;
	}
	else if(dcbm1_extint_dly == 0)
	{
		State_ClearWarning(STATE_WARNING_UART_OVW_WARN);
	}
	else
		dcbm1_extint_dly--;
		
	return errorlog;
}

// Command is 'd'
void dcbm1_debug(uint8_t *data, uint8_t length)
{
	if(data[0] == 't' && length >= 2)
	{
		dcbm1_trace_lvl = data[1] - '0';
		DCBM1_TRACE_ERROR("Trace level: %d\r\n", dcbm1_trace_lvl);
	}
	else if(data[0] == 'w' && length >= 2)
	{
		if(data[1] == 'i')
		{
			if(dcbm1_writesync())
				DCBM1_TRACE_ERROR("Send OK %d\r\n", tx_busy);
		}
		else if(data[1] == '0')
		{
			if(dcbm1_writereg(0, 0))
				DCBM1_TRACE_ERROR("Send OK %d\r\n", tx_busy);
		}
		else if(data[1] == 'w')
		{
			uint16_t res = dcbm1_send(&data[2], length - 2);
			DCBM1_TRACE_ERROR("Send %d bytes (%d)\r\n", res, dcbm1_extint_cnt)
		}
	}
	else if(data[0] == 'r' && length >= 2)
	{
		if(data[1] >= '0')
		{
			uint8_t bfr;
			if(dcbm1_readreg(data[1] - '0', &bfr))
				DCBM1_TRACE_ERROR("Read 0x%02x OK -> %02x\r\n", data[1] - '0', bfr);
		}
	}
	else if(data[0] == 'i' && length > 2)
	{
		int val = 0, max_wait = 1000;
		for(int i = 2; i < length; i++)
		{
			val *= 10;
			val += data[i] - '0';
		}

		while(tx_busy && max_wait-- > 0)
			vTaskDelay(2);

		if(data[1] == 'f')
			dcbm1_setfrequency(val);
		else if(data[1] == 'r')
			dcbm1_setrate(val);
	}
	else if(data[0] == 'l' && length >= 2)
	{
		tx_loop = data[1] - '0';
		DCBM1_TRACE_ERROR("Loop %d\r\n", tx_loop);
	}
	else if(data[0] == 'q' && length >= 1)
	{
		DCBM1_EN_TX(1);			// Indicate it can be send
		vTaskDelay(1);
		DCBM1_EN_TX(0);			// Indicate it can be send
		DCBM1_TRACE_ERROR("Send empty\r\n");
	}
}

uint16_t dcbm1_send(volatile uint8_t *bfr, uint16_t length)
{
	uint16_t amount = 0;
	if(length >= DCBM1_MAX_TX_BUFFER)
		return 0;

	if(tx_busy)
		DCBM1_TRACE_ERROR("Oeioei still busy\r\n");
			
	memcpy((uint8_t *)tx_buffer, bfr, length);
	
	tx_busy = 1;
	//DCBM1_FLEXCOMM->INTENSET |= USART_INTENSET_TXIDLEEN_MASK;
	DCBM1_UART_PUTBFR((uint8_t *)tx_buffer, length);
	
	if(if_pin_func == 1)
	{
		xQueueReset(xDcbm1_TxSemaphore);
		if(xSemaphoreTake(xDcbm1_TxSemaphore, 20))		// Max wait 400 bytes, just a time
		{
			amount = length;
			if(dcbm1_delayed_tx)
			{
				uint8_t i = 0;
				for(i = 0; i < 4; i++)			// Wait for bus not busy
				{
					if(!DCBM1_CSEL1_BUS_BUSY)
					{
						DCBM1_EN_TX(1);					// Indicate it can be send
						break;
					}
					vTaskDelay(i + 1);
				}
				if(i >= 4)
				{
					DCBM1_EN_TX(1);						// Do it any way
					DCBM1_TRACE_ERROR("Delayed Fifo send: %d\r\n", i);
				}
				DCBM1_EN_TX(0);							// Set to idle again
			}
			return amount;
		}
	}
	return 0;
}

/**
 * Non blocking send
 */
uint16_t dcbm1_send_nb(volatile uint8_t *bfr, uint16_t length)
{
	uint16_t amount = 0;
	if(length >= DCBM1_MAX_TX_BUFFER)
		return 0;

	memcpy((uint8_t *)tx_buffer, bfr, length);
	
	tx_busy = 1;
	amount = length;
	DCBM1_UART_PUTBFR((uint8_t *)tx_buffer, length);

	return amount;
}

#define REG_WRITE_CMD	0xF5
#define REG_READ_CMD	0xFD

bool dcbm1_writesync()
{
	DCBM1_HDC(0);
	rx_commandmode = 1;

	uint8_t reg = REG_WRITE_CMD;
	uint8_t amount = dcbm1_send(&reg, 1);

	rx_commandmode = 0;
	vTaskDelay(1);
	DCBM1_HDC(1);

	return amount == 1;
}

bool dcbm1_writereg(uint8_t reg, uint8_t data)
{
	uint8_t bfr[3];
	bfr[0] = REG_WRITE_CMD;
	bfr[1] = reg;
	bfr[2] = data;

	DCBM1_HDC(0);
	rx_commandmode = 1;
	uint8_t amount = dcbm1_send(bfr, sizeof(bfr));

	vTaskDelay(1);
	rx_commandmode = 0;
	//DCBM1_HDC(1);

	return amount == 3;
}

bool dcbm1_readreg(uint8_t reg, uint8_t *data)
{
	uint8_t bfr[2];
	bool res = false;

	bfr[0] = REG_READ_CMD;
	bfr[1] = reg;

	rx_index = rx_index_read = 0;

	DCBM1_HDC(0);
	rx_commandmode = 1;
	xQueueReset(xDcbm1_RxSemaphore);
	dcbm1_send(bfr, 2);

	if(xSemaphoreTake(xDcbm1_RxSemaphore, 10))
	{
		//DCBM1_TRACE_ERROR("Rec OK [%d][%d]: %02x\r\n", rx_select_read, rx_index_read, rx_buffer[rx_select_read][0]);
		if(rx_index_read > 0)
		{
			*data = rx_buffer[rx_select_read][0];
			res = true;
		}
	}
	rx_commandmode = 0;
	DCBM1_HDC(1);

	return res;
}

int8_t dcbm1_writeverifyreg(uint8_t reg, uint8_t data_write)
{
	if(dcbm1_writereg(reg, data_write))
	{
		uint8_t data_read;
		if(reg == 2)							// Setting Frequency select?
			vTaskDelay(2);						// Wait ff so it can stabilize, it won't react for 1ms

		if(dcbm1_readreg(reg, &data_read))		//
		{
			return data_write == data_read ? 0 : -3;
		}
		return -2;
	}
	return -1;
}

int8_t dcbm1_setfrequency(uint8_t frequency)
{
	int8_t res = dcbm1_writeverifyreg(2, frequency);
	DCBM1_TRACE_INFO("Changed frequency to: %d.%dMHz -> %s\r\n", (frequency/10) + 5, frequency % 10, res >= 0 ? "OK" : "Error");
	return res;
}

bool dcbm1_checkfrequency(uint8_t frequency, char c)
{
	uint8_t data_read;
	if(dcbm1_readreg(2, &data_read))
	{
		DCBM1_TRACE_INFO("Read reg2 (%c): 0x%02x <-> 0x%02x\r\n", c, data_read, frequency);
		
		return data_read == frequency;
	}
	else
		DCBM1_TRACE_INFO("Read fail\r\n");
	return false;
}

int dcbm1_getfrequency_h(uint8_t frequency)
{
	return (frequency/10) + 5;
}

int dcbm1_getfrequency_l(uint8_t frequency)
{
	return frequency % 10;
}

const int csel_rates[4] = { 1400000, 1000000, 490000, 225000 };

int8_t dcbm1_setrate(uint8_t rate)
{
	int8_t res = dcbm1_writeverifyreg(0, 0x60 | (rate & 0x03));
	DCBM1_TRACE_INFO("Changed rate to: %d -> %s\r\n", csel_rates[(rate & 0x03)], res >= 0 ? "OK" : "Error");

	return res;
}

const uint8_t tx_levels[] = 
{ 
	0x10,			// 5MHz
	0x10,			// 6MHz
	0x10,
	0x10,
	0x10,
	0x10,
	0x10,
	0x10,
	0x10,
	0x10,
	0x10,
	0x10,
	0x10,
	0x10,
	0x10,
	0x10,
	0x10,
	0x10,
	0x10,
	0x10,
	0x10,
	0x10,
	0x10,
	0x10,
	0x10,
	0x10			// 30MHz
 };		// 0xF0 is Vpp, 0xF8 is 2Vpp
 
uint8_t dcbm1_gettxlevel(uint8_t frequency_reg)
{
	if(!(appConfig->pc_config[APPCFG_TXMODE] & APPCFG_TXMODE_BOOST_MASK))
	{
		uint8_t txlevel_idx = frequency_reg/10;
		if(txlevel_idx >= sizeof(tx_levels))
			txlevel_idx = 0;
		return tx_levels[txlevel_idx];
	}
	return 0xF0;		// 0xF0 is 1 Vpp
}
 
int8_t dcbm1_settxlevel(uint8_t frequency_reg)
{
	uint8_t txlevel_idx = frequency_reg/10;
	if(txlevel_idx >= sizeof(tx_levels))
		txlevel_idx = 0;
	int8_t res = dcbm1_writeverifyreg(1, tx_levels[txlevel_idx]);
	DCBM1_TRACE_INFO("Changed tx level to: %d -> %s\r\n", tx_levels[txlevel_idx], res >= 0 ? "OK" : "Error");

	return res;
}

int8_t dcbm1_settxlevelraw(uint8_t txlevel)
{
	int8_t res = dcbm1_writeverifyreg(1, txlevel);
	DCBM1_TRACE_INFO("Changed tx level raw to: %d -> %s\r\n", txlevel, res >= 0 ? "OK" : "Error");

	return res;
}

int dcbm1_getrate_kHz(uint8_t rate)
{
	return csel_rates[(rate & 0x03)]/1000;
}

int8_t dcbm1_init(uint8_t frequency, uint8_t rate)
{
	uint8_t csel = rate & 0x03;
	int8_t res = 0;

	if_pin_func = 0x00;				// 1 = EN_TX/BUS_BUSY, 0 = CSEL0/CSEL1
	tx_in_idx = tx_out_idx = 0;
	tx_busy = 0;

	dcbm1_flexcomm_init();
	dcbm1_pin_interrupt_init();

	DCBM1_HDC(1);
	DCBM1_EN_TX(0);						
	
	/*if(if_pin_func)
	{
		DCBM1_CSEL0_DIR(GPIO_DIRECTION_OUT);	// EN_TX
		DCBM1_CSEL1_DIR(GPIO_DIRECTION_IN);		// BUS_BUSY
		DCBM1_EN_TX(0);
	}
	else
	{
		DCBM1_CSEL0_DIR(GPIO_DIRECTION_OUT);	
		DCBM1_CSEL1_DIR(GPIO_DIRECTION_OUT);	
		DCBM1_CSEL0(csel & 0x01);		// Set lowest speed
		DCBM1_CSEL1((csel & 0x02) >> 1);
	}*/
	
	DCBM1_RST(0);
	vTaskDelay(3);
	DCBM1_RST(1);
	vTaskDelay(5);
		
	dcbm1_writesync();				// Sync on our bitrate
		
	vTaskDelay(2);
	
	if_pin_func = 0x01;				// 1 = EN_TX/BUS_BUSY, 0 = CSEL0/CSEL1 (check dcbm1_setrate if changed)
	if(if_pin_func)
	{
		if((res = dcbm1_writeverifyreg(3, 0x1C)) < 0)			// Default + EN_TX mode
		{
			DCBM1_TRACE_ERROR("Write verify fail on reg %d : %02x\r\n", 3, res);
		}
		DCBM1_CSEL0_DIR(GPIO_DIRECTION_OUT);	// EN_TX
		DCBM1_CSEL1_DIR(GPIO_DIRECTION_IN);		// BUS_BUSY
	}

	//uint8_t reg_write = 0x48 | csel | (if_pin_func ? 0x20 : 0x00);	// Loop back off, CS (carrier sense) on, tx_en on/off
	
	if(res >= 0)
		res = dcbm1_setrate(rate);
	if(res >= 0)			// Just a test to see if chip is ok
	{
		res = dcbm1_setfrequency(frequency);		// Set to default frequency
		if(res >= 0)
		{
			DCBM1_TRACE_ERROR("Init powerline OK @ bit-rate=%d (f: %d)\r\n", csel_rates[rate], frequency);
			res = dcbm1_settxlevelraw(dcbm1_gettxlevel(frequency));
		}
		else
		{
			DCBM1_TRACE_ERROR("Init powerline Err2: %d\r\n", res);
		}
	}
	else
	{
		DCBM1_TRACE_ERROR("Init powerline Err: %d\r\n", res);
	}
	if(res < 0)
		State_SetError(STATE_ERROR_HW_ERR);
	else
		State_ClearError(STATE_ERROR_HW_ERR);
	
	DCBM1_HDC(1);
	
	return res;
}

#if TASK_DCBM1_ENABLE > 0
/************************************************************************/
/* DCBM1 task														        */
/************************************************************************/
static void dcbm1_task(void *p)
{

	rx_select_overflow = 0;
	xQueueReset(xDcbm1_RxSemaphore);
	while(1)
	{
		if(xSemaphoreTake(xDcbm1_RxSemaphore, 50))
		{
			if(rx_select_read >= 0 && rx_index_read > 0)
			{
				if(dcbm1_trace_lvl > TRACE_LEVEL_INFO)
				{
					uint8_t bfr[DCBM1_MAX_RX_BUFFER], i;
					for(i = 0; i < rx_select_read; i++)
					{
						uint8_t c = rx_buffer[rx_select_read][i];
						if(c >= 0x20 && c < 0x7F)
							bfr[i] = c;
						else
							bfr[i] = '?';
					}
					bfr[i] = 0;
					DCBM1_TRACE_ERROR("Rx[%d] %s\r\n", rx_index_read, bfr);
				}
				rx_select_read = -1;		// Mark read
				rx_index_read = 0;
			}
		}
		if(rx_select_overflow > 0)
		{
			DCBM1_TRACE_DEBUG("Rx overflow2: %d\r\n", rx_select_overflow);
			rx_select_overflow = 0;
		}
	}
}
#endif

/************************************************************************/
/* Start the DCBM1 task and init uart								        */
/************************************************************************/
void dcbm1_driver_init(void)
{
	xDcbm1_RxSemaphore = xSemaphoreCreateBinary();
	if(xDcbm1_RxSemaphore == NULL)
		DCBM1_TRACE_ERROR("Semaphore not created DCBM1 Rx");			// Todo: what to do

	xDcbm1_TxSemaphore = xSemaphoreCreateBinary();
	if(xDcbm1_TxSemaphore == NULL)
		DCBM1_TRACE_ERROR("Semaphore not created DCBM1 Tx");			// Todo: what to do

#if TASK_DCBM1_ENABLE > 0
	if (xTaskCreate(dcbm1_task, "Dcbm1 tsk", TASK_DCBM1_STACK_SIZE, NULL, TASK_DCBM1_TASK_PRIORITY, &xDcbm1_Task) != pdPASS) {
		while (1) {
			;
		}
	}
#endif
}

