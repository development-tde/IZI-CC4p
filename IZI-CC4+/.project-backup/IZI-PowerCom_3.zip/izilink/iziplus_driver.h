/*
 * iziplus_driver.h
 *
 *  Created on: 22 apr. 2021
 *      Author: Milo
 */

#ifndef IZIPLUS_DRIVER_H_
#define IZIPLUS_DRIVER_H_

#include "includes.h"
#include "izi_module.h"
#include "iziplus_network.h"

typedef enum iziplus_state_e {
	IZIPLUS_STATE_IDLE		= 0,
	IZIPLUS_STATE_DISCOVER	= 1,
	IZIPLUS_STATE_DMX  		= 2,
	IZIPLUS_STATE_CONFIG	= 3,
	IZIPLUS_STATE_OFF  		= 4,
	IZIPLUS_STATE_ASSIGN_CHAN = 5,
	IZIPLUS_STATE_PROTECT 	= 6,		// Overcurrent protection
	IZIPLUS_STATE_PROTECT2 	= 7,		// Overcurrent protection
	IZIPLUS_STATE_SCAN 		= 8,		// Scan quality
} iziplus_state_t;

typedef enum iziplus_substate_e {
	IZIPLUS_SUBSTATE_IDLE	= 0,
	IZIPLUS_SUBSTATE_UPDATE	= 1,
} iziplus_substate_t;

typedef enum iziplus_req_state_e {
	IZIPLUS_REQ_IDLE		= 0,
	IZIPLUS_REQ_DISCOVER	= 1,
	IZIPLUS_REQ_REDISCOVER  = 2,
	IZIPLUS_REQ_SYNC  		= 3,
	IZIPLUS_REQ_OFF  		= 4,
} iziplus_req_state_t;

typedef enum iziplus_discover_option_e {
	IZIPLUS_OPTION_ADD		= 0,
	IZIPLUS_OPTION_CLEAN	= 2,
	IZIPLUS_OPTION_SWITCH	= 3,			// Only switch frequency
	IZIPLUS_OPTION_OFF		= 4,			// Used to powerdown, so other modules can discover without possible interference
	IZIPLUS_OPTION_ON		= 5,				// Turn power on and lock
	IZIPLUS_OPTION_REPLACE	= 6
} iziplus_discover_option_t;

#define IZIPLUS_OPTION_MASK			0x0F	// To get real dicover option
#define IZIPLUS_OPTION_SCAN_FLAG	0x10	// Can be masked over iziplus_discover_option_t to add a scan when ready

typedef enum iziplus_requests_e {
	IZIPLUS_REQ_VERSION		= 0,
	IZIPLUS_REQ_CONFIG		= 1,
	IZIPLUS_REQ_CHANNELMODE	= 2,
	IZIPLUS_REQ_TEXT		= 3,
	IZIPLUS_REQ_PRODUCTION_R= 4,
	IZIPLUS_REQ_PRODUCTION  = 5,			// Test
	IZIPLUS_REQ_FACTORY     = 6,			// Test
} iziplus_requests_t;

typedef struct iziplus_fifo_join_s {
	uint32_t device_id;				// Serial of module that wants to join
	izi_version_u prot_version;		// Protocol version of module
	uint16_t device_type;			// Device type of module
} iziplus_fifo_join_t;

struct iziplus_fifo_config_s {
	uint16_t index;
	uint8_t config_change;
	uint8_t text_change;
} __attribute__((packed));

typedef struct iziplus_fifo_config_s iziplus_fifo_config_t;

struct iziplus_fifo_identify_s {
	uint16_t index;
	uint16_t time;
	uint16_t mode;
} __attribute__((packed));
typedef struct iziplus_fifo_identify_s iziplus_fifo_identify_t;

struct iziplus_fifo_update_s {
	uint16_t index;
	uint16_t type;
	uint32_t size;
} __attribute__((packed));
typedef struct iziplus_fifo_update_s iziplus_fifo_update_t;

struct iziplus_light_data_s {
	uint16_t amount;
	uint16_t channel;
} __attribute__((packed));

typedef struct iziplus_light_data_s iziplus_light_data_t;

struct iziplus_error_text_s {
	uint8_t code;
	int8_t type;
	char text[32];
} __attribute__((packed));

typedef struct iziplus_error_text_s iziplus_error_text_t;

#define IZIPLUS_MAX_MODULES			32		// Max 32 modules per powercom

#define IZIPLUS_DISCOVER_ATTEMPTS	4		// Amount of discover requests
#define IZIPLUS_DISCOVER_WAIT_TIME	500		// Time to wait for all answers on discover

#define IZIPLUS_FIFO_CONFIG_MAX		IZIPLUS_MAX_MODULES
#define IZIPLUS_FIFO_IDENTIFY_MAX	IZIPLUS_MAX_MODULES
#define IZIPLUS_FIFO_UPDATE_MAX		IZIPLUS_MAX_MODULES
#define IZIPLUS_FIFO_JOIN_MAX		IZIPLUS_MAX_MODULES

#define IZIPLUS_LIGHTDATA_RATE			40
#define IZIPLUS_LIGHTDATA_TICKS 		(1000 / IZIPLUS_LIGHTDATA_RATE)
#define IZIPLUS_LIGHTDATA_FAST_LONG		400				// 10 second increase of speed (if enabled) to 40Hz
#define IZIPLUS_LIGHTDATA_FAST_SHORT	40				// 1 second increase of speed (if enabled) to 40Hz

#define IZIPLUS_RESEND_OPERATION_MODE	20	// 20x resend of operation mode discover (= 1sec)

#define IDENTIFY_ACTION_CLEARMAX	254
#define IDENTIFY_ACTION_CANCEL		255

#ifndef PCB_REV6
#define IZI_POWER_OUT_ENABLE	gpio_set_pin_level(OUT_EN, false)
#define IZI_POWER_OUT_DISABLE	gpio_set_pin_level(OUT_EN, true)
#else
#define IZI_POWER_OUT_ENABLE	gpio_set_pin_level(OUT_EN, true)
#define IZI_POWER_OUT_DISABLE	gpio_set_pin_level(OUT_EN, false)
#define IZI_5V_OFF				gpio_set_pin_level(OUT_5V_OFF, true)
#define IZI_5V_ON				gpio_set_pin_level(OUT_5V_OFF, false)
#endif

#define IZI_PREFIX	"[izi]\t"

#ifndef  IZI_TRACE_BUILD_LVL
#define IZI_TRACE_BUILD_LVL		2
#endif

#if IZI_TRACE_BUILD_LVL >= 0
#define IZI_TRACE_ERROR(...)	{ if(izi_trace_lvl >= TRACE_LEVEL_ERROR)		{ esp_printf(Debug_Putc, IZI_PREFIX, __VA_ARGS__); } }
#else
#define IZI_TRACE_ERROR(...)
#endif
#if IZI_TRACE_BUILD_LVL >= 1
#define IZI_TRACE_WARNING(...)	{ if(izi_trace_lvl >= TRACE_LEVEL_WARNING)		{ esp_printf(Debug_Putc, IZI_PREFIX, __VA_ARGS__); } }
#else
#define IZI_TRACE_WARNING(...)
#endif
#if IZI_TRACE_BUILD_LVL >= 2
#define IZI_TRACE_INFO(...)		{ if(izi_trace_lvl >= TRACE_LEVEL_INFO)		{ esp_printf(Debug_Putc, IZI_PREFIX, __VA_ARGS__); } }
#else
#define IZI_TRACE_INFO(...)
#endif
#if IZI_TRACE_BUILD_LVL >= 3
#define IZI_TRACE_DEBUG(...)	{ if(izi_trace_lvl >= TRACE_LEVEL_DEBUG)		{ esp_printf(Debug_Putc, IZI_PREFIX, __VA_ARGS__); } }
#else
#define IZI_TRACE_DEBUG(...)
#endif

void IziPlus_Init();
int8_t IziPlus_DiscoverStart(uint16_t option, uint8_t pl_frequency, uint8_t pl_rate, uint8_t *clear);
void IziPlus_ReportMonitor(void);
void IziPlus_ReportConfig(void);
int8_t IziPlus_Identify(uint32_t serial, uint16_t time, uint16_t mode);
uint16_t IziPlus_ModuleAmount();
izi_module_t *IziPlus_GetModule(int index);
bool IziPlus_SetChannelMode(uint32_t serial, uint16_t address, uint8_t mode, uint8_t dmxfail, uint8_t *cfg, uint8_t cfg_length, uint8_t *txt);
bool IziPlus_StartUpdate(uint32_t serial, uint32_t firmware_size, uint16_t type);
void IziPlus_Debug(uint8_t *data, uint8_t length);
void IziPlus_SyncTimers(uint32_t time);
void IziPlus_PowerProtectShutdown();
void IziPlus_VoltageProtectShutdown();
void IziPlus_ReportOverrule(bool is_overruled);
void IziPlus_ReportPowerLimit(bool is_limited);
void IziPlus_SetMaster(uint8_t master_lvl);
void IziPlus_IncMaster(uint8_t step_size);
void IziPlus_DecMaster(uint8_t step_size);
void IziPlus_ReportPowerLimit(bool is_limited);
void IziPlus_ReportShutdown();
bool IziPlus_FastReportPending();

#endif /* IZIPLUS_DRIVER_H_ */
