/*
 * appconfig.c
 *
 *  Created on: 15 jun. 2020
 *      Author: Milo
 */

#include "includes.h"
#include "appconfig.h"
#include "crc.h"
#include "smart_eeprom.h"

#define APPCFG_GEN			1
#define APPCFG_NETWORK		8

uint32_t AppConfig_Changes = 0;

//const uint8_t  __attribute__ ((section (".appsettingsection"))) appsettings;
appconfig_t appCfg;
appconfig_t *appConfig;

void AppConfig_Init()
{
	appconfig_t *cfg = AppConfig_Get();
	appConfig = cfg;
	
	uint16_t crc = Crc16((uint8_t *)&cfg->ref, (uint16_t)(sizeof(appconfig_t) - sizeof(cfg->crc)), 0xFFFF);
	if(cfg->crc != crc)
	{
		GEN_TRACE_INFO("App settings crc fail\r\n");
		AppConfig_Default();
	}
	else
	{
		GEN_TRACE_INFO("App settings OK\r\n");
		if(cfg->version < CONFIG_VERSION)
		{
			if(cfg->version < 2)
			{
				cfg->location_id = 0;
			}
			else if(cfg->version < 3)
			{
				cfg->pan_id = PRODUCTION_SERIAL;
			}
			else if(cfg->version < 6)
			{
				cfg->pc_config[APPCFG_TXMODE] = APPCFG_TXMODE_DYNAMIC;
			}
			cfg->version = CONFIG_VERSION;
			AppConfig_Set();
		}
	}

	/*char serial[18];
	sprintf(serial, "%016d", PRODUCTION_SERIAL);
	for(uint8_t i = 0; i < 16; i++)
	{
		g_UsbDeviceString3[(i * 2) + 2] = serial[i];
	}*/
}

void AppConfig_Default()
{
	appconfig_t *cfg = &appCfg;
	
	// General
	cfg->ref = 0;
	cfg->version = CONFIG_VERSION;
	
	strcpy(cfg->name, "IZI-PowerCom-0000");
	strcpy(cfg->project, "TDE");
	
	cfg->can_slave_id = 0xFF;
	cfg->pl_frequency = (9 - 5) * 10;		// Band 2 = 9MHz
	cfg->pl_rate = 0x03;
	cfg->app_modules = 0;
	
	cfg->timing_offset = 0;
	cfg->master_idx = 0;
	cfg->master_total = 0;
	cfg->pan_id = PRODUCTION_SERIAL;
	cfg->pc_config[APPCFG_TXMODE] = APPCFG_TXMODE_DYNAMIC;
	
	cfg->dbg_on = 0;
	
	uint16_t crc = Crc16((uint8_t *)&cfg->ref, (uint16_t)(sizeof(appconfig_t) - sizeof(cfg->crc)), 0xFFFF);
	cfg->crc = crc;
	
	if(Eeprom_Write(EEPROM_APPCFG, (uint8_t *)cfg, APPSETTING_SECTOR_SIZE))
	{
		GEN_TRACE_INFO("App default OK\r\n");
		AppConfig_Get();
	}
	else
		GEN_TRACE_INFO("App default error\r\n");
}

appconfig_t *AppConfig_Get()
{
	Eeprom_Read(EEPROM_APPCFG, (uint8_t *)&appCfg, APPSETTING_SECTOR_SIZE);
	return &appCfg;
}

bool AppConfig_Set()
{
	TickType_t ticks = xTaskGetTickCount();

	if(appCfg.pc_config[APPCFG_TXMODE] > APPCFG_TXMODE_MAX)				// Valid value?
	{
		appCfg.pc_config[APPCFG_TXMODE] = APPCFG_TXMODE_DYNAMIC;		// If not, set to default
	}

	uint16_t crc = Crc16((uint8_t *)&appCfg.ref, (uint16_t)(sizeof(appconfig_t) - sizeof(appCfg.crc)), 0xFFFF);
	appCfg.crc = crc;
	
	if(Eeprom_Write(EEPROM_APPCFG, (uint8_t *)&appCfg, APPSETTING_SECTOR_SIZE))
	{
		GEN_TRACE_INFO("App write ram settings %d ms\r\n", xTaskGetTickCount() - ticks);
		return true;
	}
	else
		GEN_TRACE_INFO("App write error\r\n");
	return false;
}

void AppConfig_Print()
{
	GEN_TRACE_INFO("General\r\n");
	GEN_TRACE_INFO("Serial    : %08x\r\n", PRODUCTION_SERIAL);
	GEN_TRACE_INFO("Batch     : %s\r\n", PRODUCTION_BATCH);
	GEN_TRACE_INFO("Plant     : %c\r\n", PRODUCTION_PLANT);
	GEN_TRACE_INFO("Version   : %d\r\n", appConfig->version);
	GEN_TRACE_INFO("Name      : %s\r\n", appConfig->name);
	GEN_TRACE_INFO("Project   : %s\r\n", appConfig->project);
	GEN_TRACE_INFO("Modules   : %d\r\n", appConfig->app_modules);
	GEN_TRACE_INFO("PAN ID    : %d\r\n", appConfig->pan_id);
	GEN_TRACE_INFO("CAN\r\n");
	GEN_TRACE_INFO("Network id: %d\r\n", appConfig->can_network_id);
	GEN_TRACE_INFO("Slave id  : %d\r\n", appConfig->can_slave_id);
	GEN_TRACE_INFO("Power line\r\n");
	GEN_TRACE_INFO("Frequency : %d\r\n", appConfig->pl_frequency);
	GEN_TRACE_INFO("Rate      : %d\r\n", appConfig->pl_rate);
	GEN_TRACE_INFO("Timing ms : %d\r\n", appConfig->timing_offset);
	GEN_TRACE_INFO("Master idx: %d\r\n", appConfig->master_idx);
	GEN_TRACE_INFO("Masters nr: %d\r\n", appConfig->master_total);
}
