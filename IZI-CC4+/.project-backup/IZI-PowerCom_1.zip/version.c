/*
 * version.c
 *
 *  Created on: 4 aug. 2020
 *      Author: Milo
 */

#include "version.h"

const firmware_t __attribute__ ((section (".firmwareinfosection"))) firmare_info = 
{ 
	.version.v.major = 1, 
	.version.v.minor = 0, 
	.version.v.build = 1878, 
	.image.start = 0x4000, 
	.image.marker = IMAGE_MARKER, 
	.image.device_type = SLAVE_DEVTYPE_GROUP,
#ifdef PCB_REV6
	.image.hw_version_start = 2,
	.image.hw_version_end = 6,
#else
	.image.hw_version_start = 5,
	.image.hw_version_end = 5,
#endif
};

