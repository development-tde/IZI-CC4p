/*
 * iziplus_driver.c
 *
 *  Created on: 22 apr. 2021
 *      Author: Milo
 */

#include "includes.h"
#include "iziplus_driver.h"
#include "iziplus_dataframe.h"
//#include "virtual_com.h"
#include "powerline/dcbm1_driver.h"
#include "appconfig.h"
//#include "izi_driver.h"
#include "izi_can_frame.h"
#include "iziplus_dataframe.h"
#include "izican/izi_can_slave.h"
#include "izican/izi_can_slave_handler.h"
#include "iziplus_networkframe.h"
#include "izi_transparent.h"
#include "izi_can_frame.h"
#include "izican/izi_can_slave.h"
#include "izican/izi_can_slave_handler.h"
#include "fifo.h"
#include "rtctime.h"
#include "izi_output.h"
#include "smart_eeprom.h"
#include "misc/analog.h"
#include "version.h"

/*******************************************************************************
 * Defines
 ******************************************************************************/
#define TASK_PLUS_STACK_SIZE (2*1024 / sizeof(portSTACK_TYPE))
#define TASK_PLUS_TASK_PRIORITY (tskIDLE_PRIORITY + 4)

#define IDENTIFY_BUTTON_TIMEOUT		30			// Amount of seconds the button identify press will be reported
#define UPDATE_FAIL_TIMEOUT			30			// Amount of seconds a failed update will be shown

#define IZIPLUS_TIMEROS_TICKS		1000		// Amount of ticks for second timer

#define PROTECT_TIMEOUT				5			// Overcurrent shutdown 5 sec and then retry
#define PROTECT_SAMPLE_TIMEOUT		2			// Overcurrent shutdown 2 sec and then retry (used voltage check before power-up)

#define ADDRESS_MODE_SET_DELAY		2			// Delay to wait for more modules, to see if light data content must be recalculated 

#define FIRMWARE_XTRA_RETRY			3			// 3 extra retries (= 3 * 3 = 9 xtra messages) when previous firmware message was confirmed
#define CONFIG_CHANGE_RETRY			3			// 3 extra retries when config write fails (= 3 * 3 = 9 xtra messages) only done when module is still online
#define TEXT_CHANGE_RETRY			3			// 3 extra retries when text write fails (= 3 * 3 = 9 xtra messages) only done when module is still online

/*******************************************************************************
 * Globals
 ******************************************************************************/
static TaskHandle_t		xIziPlus_Task;
static TimerHandle_t  	xIziPlus_Timer = NULL;

static uint8_t iziplus_pl_freq;
static uint8_t iziplus_pl_rate;

static uint8_t iziplus_discover_phase = 0;
static uint8_t iziplus_discover_session = 0;
static uint8_t iziplus_discover_newcount = 0;

static bool fast_report = false;

trace_level_t izi_trace_lvl = IZI_DFLT_TRACE_LVL;

izi_module_t iziplus_modules[IZI_MAX_MODULES] __attribute__((aligned(4)));
izi_module_base_t *iziplus_module_sort[IZI_MAX_MODULES] __attribute__((aligned(4)));
iziplus_light_data_t iziplus_module_lightdata[IZI_MAX_MODULES] __attribute__((aligned(4)));
uint8_t iziplus_module_lightdata_amount = 0;
uint8_t iziplus_module_amount = 0;
uint8_t iziplus_module_extra = 0;

static volatile iziplus_state_t iziplus_state;
static iziplus_substate_t iziplus_substate;
static uint16_t iziplus_substate_delay = 0;
static uint8_t iziplus_discover_option = 0;
static bool iziplus_discover_scan = false;
static volatile int16_t iziplus_powerdown_timeout = 0;
static volatile int16_t iziplus_protect_timeout = 0;
static volatile bool iziplus_power_on = false;

static uint8_t iziplus_lightdata_cnt_store = 0, iziplus_lightdata_cnt = 0;
static uint8_t iziplus_rsp_quality = 0, iziplus_rsp_quality_low_cnt = 0;

static fifo_t iziplus_fifo_config;
static fifo_t iziplus_fifo_identify;
static fifo_t iziplus_fifo_update;
static fifo_t iziplus_fifo_join_items;

static izi_module_t *iziplus_update_module, *iziplus_update_module_backup;
static bool iziplus_update_module_removed = false;
static uint16_t iziplus_update_type;
static uint16_t iziplus_update_cnt;
static uint32_t iziplus_update_flags;
static uint16_t iziplus_update_apply, iziplus_update_allow;
static uint32_t iziplus_update_address = 0;
static uint16_t iziplus_update_size = 0;
static uint32_t iziplus_update_length = 0;
static uint32_t iziplus_update_image_size = 0;
static bool iziplus_update_reboot = false, iziplus_update_allow_start = false;

uint8_t iziplus_lightdata_tokenprs = 0, iziplus_lightdata_tokenoverrule = 0;
uint8_t iziplus_scan_token = 0, iziplus_scan_cnt, iziplus_scan_total, iziplus_scan_attempts, iziplus_scan_result[IZI_MAX_MODULES];
uint8_t iziplus_channel_amount = 0;

static iziplus_cpustate_u last_cpu_state[IZI_MAX_MODULES];
static iziplus_multimaster_t iziplus_multimaster[IZIPLUS_MAX_MASTER];
static uint8_t iziplus_multimaster_amount = 0;

static uint16_t iziplus_send_errors = 0;
static uint16_t iziplus_send_error_prs = 0;
uint16_t iziplus_local_identify_time = 0;

static volatile uint8_t iziplus_token_pending = 0;
static volatile uint32_t iziplus_token_serial = 0;

static TickType_t iziplus_last_lightdata;

static TickType_t iziplus_sync_time;

static uint16_t iziplus_addressmode_set_delay = 0;
static bool iziplus_addressmode_set = false;

static uint8_t iziplus_master_lvl = 255;
static uint16_t iziplus_offline_count = 0, iziplus_offline_log_dly = 0;
static int32_t iziplus_offline_idx = 0;

static contacttriggerack_t iziplus_contacttrigger_acks[IZIPLUS_MAX_CONTACTTRIGGER_ACKS];
static uint8_t iziplus_contacttrigger_acks_count = 0;

static izi_versionplus_u iziplus_image_version;

uint8_t iziplus_nwdata[IZIPLUS_MAX_DATA];
uint8_t iziplus_nwdata_notification[IZIPLUS_MAX_DATA];
char text[LOG_TEXT_SIZE + 8];		// 8 bonus...

#define DISCOVER_OPTION_DEFINED	8
char *IziPlus_DiscoverOptionText[DISCOVER_OPTION_DEFINED] =
{
	"Add new",				// IZI_OPTION_ADD
	"??",
	"Clean",				// IZI_OPTION_CLEAN
	"Switch only",			// IZI_OPTION_SWITCH
	"Power Off",			// IZI_OPTION_OFF
	"Power On",				// STATE_WARNING_BAD_COMQUAL
	"Replace",
	"Scan"
};

#define ERROR_TEXT_MAX		22
typedef enum error_type_e {
	ERROR_TYPE_OK		= 0,
	ERROR_TYPE_ERROR	= 1,
	ERROR_TYPE_WARNING	= 2,
	ERROR_TYPE_NOTFOUND		= -1,
} error_type_t;

const iziplus_error_text_t ErrorTexts[ERROR_TEXT_MAX] = 
{
	{ .code = 129, .type = ERROR_TYPE_ERROR, .text = "LED OverTemp" },
	{ .code = 130, .type = ERROR_TYPE_ERROR, .text = "LED1 OverTemp" },
	{ .code = 131, .type = ERROR_TYPE_ERROR, .text = "LED2 OverTemp" },
	{ .code = 132, .type = ERROR_TYPE_ERROR, .text = "UnderVoltage" },
	{ .code = 133, .type = ERROR_TYPE_ERROR, .text = "OverVoltage" },
	{ .code = 134, .type = ERROR_TYPE_ERROR, .text = "OverCurrent" },
	{ .code = 135, .type = ERROR_TYPE_WARNING, .text = "Output Open" },
	{ .code = 136, .type = ERROR_TYPE_ERROR, .text = "Output Short" },
	{ .code = 137, .type = ERROR_TYPE_WARNING, .text = "Output1 Open" },
	{ .code = 138, .type = ERROR_TYPE_ERROR, .text = "Output1 Short" },
	{ .code = 139, .type = ERROR_TYPE_WARNING, .text = "Output2 Open" },
	{ .code = 140, .type = ERROR_TYPE_ERROR, .text = "Output2 Short" },
	{ .code = 141, .type = ERROR_TYPE_WARNING, .text = "Output3 Open" },
	{ .code = 142, .type = ERROR_TYPE_ERROR, .text = "Output3 Short" },
	{ .code = 143, .type = ERROR_TYPE_ERROR, .text = "Output4 Open" },
	{ .code = 144, .type = ERROR_TYPE_ERROR, .text = "Output4 Short" },
	{ .code = 145, .type = ERROR_TYPE_ERROR, .text = "OverLoad" },
	{ .code = 146, .type = ERROR_TYPE_ERROR, .text = "PLC Error" },
	{ .code = 147, .type = ERROR_TYPE_ERROR, .text = "Table Error" },
	{ .code = 148, .type = ERROR_TYPE_WARNING, .text = "Bad com quality" },
	{ .code = 149, .type = ERROR_TYPE_ERROR, .text = "DAC error" },
	{ .code = 151, .type = ERROR_TYPE_WARNING, .text = "Uart ovw" },
};

/*******************************************************************************
 * Proto
 ******************************************************************************/
static void IziPlus_Task(void *p);
void IziPlus_Reportlinkstate(uint16_t state, uint16_t amount);
bool IziPlus_Discover();
void IziPlus_Discover_Operation();
int16_t IziPlus_Request(izi_module_t *module, uint8_t *nw_data, uint16_t nw_length);
int16_t IziPlus_Notification(uint32_t dest, uint16_t devtype, uint8_t *nw_data, uint16_t nw_length);
void IziPlus_ReportLinkState(uint16_t state, uint16_t amount);
bool IziPlus_Powerup();
void IziPlus_Powerdown();
void IziPlus_ModuleLoad();
void IziPlus_ReportConfigFlag(izi_module_t *module);
void IziPlus_ReportMonitorFlag(izi_module_t *module);
void IziPlus_FastReport();
void IziPlus_HandleRx(iziplus_data_frame_t *frame, bool handled);
void IziPlus_HandleOnline(izi_module_t *module, bool online);
bool IziPlus_HandleToken(izi_module_t *module);
bool IziPlus_SendLightData();
void IziPlus_Requests();
bool IziPlus_Updates();
bool IziPlus_Actions();
bool IziPlus_Acks();
void IziPlus_TimerSec(TimerHandle_t xTimer);
bool IziPlus_SendLightDataRaw(uint8_t token);
bool IziPlus_SetState(uint8_t state);
//extern uint8_t can_prog_ram_bfr[RAM_APP_PROG_SIZE];

bool IziPlus_Request_Version(izi_module_t *module, bool add_retries);
bool IziPlus_Response_Version(izi_module_t *module, uint8_t *payload);
bool IziPlus_Request_ChannelMode(izi_module_t *module, bool add_retries);
bool IziPlus_Response_ChannelMode(izi_module_t *module, uint8_t *payload);
bool IziPlus_Request_Config(izi_module_t *module, bool add_retries, uint16_t *length);
bool IziPlus_Response_Config(izi_module_t *module, uint8_t *payload, uint16_t length);
bool IziPlus_Request_Text(izi_module_t *module, bool add_retries, uint16_t *length);
bool IziPlus_Response_Text(izi_module_t *module, uint8_t *payload, uint16_t length);
bool IziPlus_Request_WriteConfig(izi_module_t *module, uint16_t idx);
bool IziPlus_Request_WriteText(izi_module_t *module, uint16_t idx);
bool IziPlus_Request_WriteChannelMode(izi_module_t *module, uint16_t idx);

bool IziPlus_AssignNetwork(uint16_t module_idx, bool is_new_module);

bool IziPlus_PowerOn();
void IziPlus_PowerOff();
void IziPlus_ModuleSort();
void IziPlus_LightDataCreate(bool assign);
bool IziPLus_FirmwareApply(izi_module_t *module);
bool IziPLus_FirmwareAllow(izi_module_t *module);

/*******************************************************************************
 * Code
 ******************************************************************************/
void IziPlus_Init()
{
	if(xIziPlus_Task == NULL)
	{
		if (xTaskCreate(IziPlus_Task, "IziPlus", TASK_PLUS_STACK_SIZE, NULL, TASK_PLUS_TASK_PRIORITY, &xIziPlus_Task) != pdPASS) {
			while (1) {
				;
			}
		}
		if(xIziPlus_Timer == NULL)			// Init can be called multiple times
		{
			xIziPlus_Timer = xTimerCreate("IziPlusTimer", IZIPLUS_TIMEROS_TICKS, pdTRUE, ( void * ) 0, IziPlus_TimerSec);
			if(xIziPlus_Timer == NULL)
			{
				while (1);				// Todo: what to do
			}
			else if( xTimerStart(xIziPlus_Timer, 0) != pdPASS )
			{
				while (1);				// Todo: what to do
			}
		}
		else if( xTimerStart(xIziPlus_Timer, 0) != pdPASS )
		{
			while (1);				// Todo: what to do
		}
	}
}

void IziPlus_SyncTimers(uint32_t time)
{
	if(iziplus_state == IZIPLUS_STATE_SCAN || iziplus_state == IZIPLUS_STATE_DISCOVER)
	{
		iziplus_sync_time = (xTaskGetTickCount() + IZIPLUS_LIGHTDATA_TICKS) + 20;		// If multiple modules already active on this frequency, use end of timing to avoid collision with other masters (not bullet proof, but helps)
	}
	else if(appConfig->master_total > 1)
	{
		iziplus_sync_time = (xTaskGetTickCount() + IZIPLUS_LIGHTDATA_TICKS);
		if(appConfig->timing_offset < IZIPLUS_LIGHTDATA_TICKS)
			iziplus_sync_time += appConfig->timing_offset;
	}
	if(time % 5 == 0)
		iziplus_networkframe_setsync();

	//IZIPLUS_TRACE_INFO("Sync %d\r\n", iziplus_sync_time);
}

/*
 * Second timer
 */
void IziPlus_TimerSec(TimerHandle_t xTimer)
{
	RtcTime_Tick();
	if(iziplus_state != IZIPLUS_STATE_DISCOVER)
	{
		iziplus_offline_count = 0;
		iziplus_offline_idx = -1;
	
		for(uint16_t i = 0; i < iziplus_module_amount; i++)
		{
			if(iziplus_modules[i].helper.flag_clear_timer > 0)
			{
				if(--iziplus_modules[i].helper.flag_clear_timer == 0)
				{
					iziplus_modules[i].var.flags &= ~(iziplus_modules[i].helper.flag_clear_req);			// Clear will be reported next time IZIPLUS_CMD_STATE is received
					iziplus_modules[i].helper.flag_clear_req = 0;
				}
			}
			if(iziplus_modules[i].var.offline_prs >= 10)
			{
				iziplus_offline_count++;
				iziplus_offline_idx = i;
			}
		}
		if(iziplus_offline_count >= 1)
		{
			if(++iziplus_offline_log_dly == 4)		// Wait 4 sec before log
			{
				sprintf(text, "%d of %d module(s) offline", iziplus_offline_count, iziplus_module_amount);		// Overflow after 18 hours will repeat log (is ok)
				LOGWRITE_WARNING(ERRCODE_IZI_MODULE_MISSING, text, log_src_task_postpone);
				iziplus_offline_log_dly = 4;			// Clip here
			}
			State_SetWarning(STATE_WARNING_MODULES_MISSING);
		}
		else
		{
			if(iziplus_offline_log_dly > 0)
			{
				if(--iziplus_offline_log_dly == 0)
					LOGWRITE_INFO(ERRCODE_IZI_MODULE_MISSING, "All modules online", log_src_task_postpone);
			}
			State_ClearWarning(STATE_WARNING_MODULES_MISSING);
		}
	}
		
	if(iziplus_multimaster_amount > 0)
	{
		uint32_t time = RtcTime_GetSeconds();
		uint8_t amount = 0;
		for(uint8_t m = 0; m < IZIPLUS_MAX_MASTER; m++)
		{
			if(iziplus_multimaster[m].serial > 0)
			{
				if(time - iziplus_multimaster[m].time > 60)		// 60 sec no frames from this master?
				{
					sprintf(text, "Master removed 0x%X (count: %d)", iziplus_multimaster[m].serial, --iziplus_multimaster_amount);
					iziplus_multimaster[m].serial = 0;
					LOGWRITE_TRACE(ERRCODE_IZI_MULTI_MASTER_REMOVE, text, log_src_task_postpone);
				}
				else
					amount++;
			}
		}
		iziplus_multimaster_amount = amount;
		if(amount <= IZIPLUS_MAX_MASTER_WARN)
			State_ClearWarning(STATE_WARNING_MASTER_HIGH);
	}
	if(++iziplus_send_error_prs >= (15 * 60))			// Clear every 15 minutes
	{
		iziplus_send_error_prs = 0;
		iziplus_send_errors = 0;
		State_ClearWarning(STATE_WARNING_PL_SEND);
	}

	if(iziplus_addressmode_set_delay > 0)
	{
		if(--iziplus_addressmode_set_delay == 0)
			iziplus_addressmode_set = true;
	}	
	if(iziplus_local_identify_time)
	{
		iziplus_local_identify_time--;
	}
	if(dcbm1_checkerror())
	{
		LOGWRITE_WARNING(ERRCODE_HW_UART_OVERFLOW, "Hw notification: uart overflow", log_src_task_postpone);
	}
	
	//IZIPLUS_TRACE_INFO("ADC: %dmV\r\n", Analog_GetOutputVoltage());
}

/************************************************************************/
/* Search for error text by code                                        */
/************************************************************************/
int8_t IziPlus_GetErrorText(char *txt, int8_t code)
{
	for(int i = 0; i < ERROR_TEXT_MAX; i++)
	{
		if((uint8_t)code == ErrorTexts[i].code)
		{
			strcpy(txt, ErrorTexts[i].text);
			return ErrorTexts[i].type;
		}
	}
	return ERROR_TYPE_NOTFOUND;
}

/************************************************************************/
/* Rx handler task														        */
/************************************************************************/
static void IziPlus_Task(void *p)
{
	TickType_t quality_ticks = xTaskGetTickCount();
	iziplus_last_lightdata = quality_ticks;

	iziplus_fifo_config = fifo_create(IZIPLUS_FIFO_CONFIG_MAX, sizeof(iziplus_fifo_config_t));
	iziplus_fifo_identify = fifo_create(IZIPLUS_FIFO_IDENTIFY_MAX, sizeof(iziplus_fifo_identify_t));
	iziplus_fifo_update = fifo_create(IZIPLUS_FIFO_UPDATE_MAX, sizeof(iziplus_fifo_update_t));
	iziplus_fifo_join_items = fifo_create(IZIPLUS_FIFO_JOIN_MAX, sizeof(iziplus_fifo_join_t));

	iziplus_state = IZIPLUS_STATE_IDLE;
	iziplus_substate = IZIPLUS_SUBSTATE_IDLE;

	iziplus_dataframe_set_rx_callback(IziPlus_HandleRx);
	iziplus_dataframe_set_online_callback(IziPlus_HandleOnline);
	iziplus_dataframe_set_token_callback(IziPlus_HandleToken);
	iziplus_dataframe_init();

	Analog_Init();
	
	dcbm1_driver_init();
	IziPlus_ModuleLoad();
	
	vTaskDelay(1000);
	IziPlus_Powerup();

	IziPlus_LightDataCreate(false);			// Calculate light data for current modules
	for(int i = 0; i < iziplus_module_amount; i++)
	{
		iziplus_modules[i].helper.requests |= (1 << IZIPLUS_REQ_VERSION)|(1 << IZIPLUS_REQ_CONFIG)|(1 << IZIPLUS_REQ_CHANNELMODE)|(1 << IZIPLUS_REQ_TEXT);
		iziplus_modules[i].var.flags = FLAG_ONLINE;			// Assume online (will also help, that at least one attempt is done to do a request)
	}

	if(IziPlus_SetState(IZIPLUS_STATE_DMX))
		IziPlus_ReportLinkState(LINK_STATE_IDLE, 0);
	
	while(true)
	{
		if(iziplus_state == IZIPLUS_STATE_PROTECT || iziplus_state == IZIPLUS_STATE_PROTECT2)
		{
			if(iziplus_protect_timeout > 0)
			{
				if(iziplus_protect_timeout == PROTECT_TIMEOUT)
				{
					IziPlus_ReportLinkState(LINK_STATE_POWER_PROTECT, iziplus_module_amount);
					State_SetError(STATE_ERROR_CURRENT_PEAK);
					//State_SetAttentionInfo(COLOR_RED, COLOR_MAGENTA, 5, 4);
					LOGWRITE_ERROR(ERRCODE_IZI_OVERCURRENT, "Overcurrent protection activated", log_src_task_postpone);
					IZIPLUS_TRACE_INFO("Overcurrent protection for 10 seconds\r\n");
				}
				else if(iziplus_protect_timeout == PROTECT_SAMPLE_TIMEOUT)
				{
					IziPlus_ReportLinkState(LINK_STATE_POWER_PROTECT, iziplus_module_amount);		// Report (also on shorter error times)
				}
				
				if(--iziplus_protect_timeout == 0)
				{
					if(IziPlus_Powerup())
					{
						if(IziPlus_SetState(IZIPLUS_STATE_DMX))
							State_ClearError(STATE_ERROR_CURRENT_PEAK);
					}
				}
				else
				{
					for(int i = 0; i < iziplus_module_amount; i++)
					{
						bool online = iziplus_modules[i].var.flags & FLAG_ONLINE;
						iziplus_modules[i].var.flags = 0;
						iziplus_modules[i].var_shadow.flags = 0;
						if(online)
							IziPlus_ReportMonitorFlag(&iziplus_modules[i]);
					}
					vTaskDelay(1000);
				}
					
				continue;
			}
		}
		else if(iziplus_state == IZIPLUS_STATE_DISCOVER)
		{
			if(IziPlus_Discover())
				State_SetAttentionInfo(COLOR_GREEN, COLOR_GREEN, 2, 1);
			else
				State_SetAttentionInfo(COLOR_RED, COLOR_RED, 2, 1);
				
			if(iziplus_state != IZIPLUS_STATE_OFF)
			{
				if(iziplus_lightdata_tokenoverrule > 0)
				{
					IziPlus_ReportLinkState(LINK_STATE_QUALITYSCAN, iziplus_module_amount);
					IziPlus_SetState(IZIPLUS_STATE_SCAN);
				}
				else
				{
					IziPlus_ReportLinkState(LINK_STATE_IDLE, iziplus_module_amount);
					IziPlus_SetState(IZIPLUS_STATE_DMX);
				}
			}
		}
		else if(iziplus_state == IZIPLUS_STATE_SCAN)
		{
			if(iziplus_lightdata_tokenoverrule == 0)
			{
				uint16_t quality = 0, min_quality = 100;
				for(int i = 0; i < iziplus_module_amount; i++)
				{
					quality += iziplus_scan_result[i];
					if(iziplus_scan_result[i] < min_quality)
						min_quality = iziplus_scan_result[i];
				}
				sprintf(text, "Discover quality avg: %d, min: %d", quality / iziplus_module_amount, min_quality);
				LOGWRITE_INFO(ERRCODE_IZI_DISCOVER_RESULT, text, log_src_task_postpone);			
				
				IziPlus_SetState(IZIPLUS_STATE_DMX);
				IziPlus_ReportLinkState(LINK_STATE_IDLE, iziplus_module_amount);
			}
		}
		else if(iziplus_state == IZIPLUS_STATE_OFF)
		{
			if(iziplus_powerdown_timeout > 0)
			{
				if(--iziplus_powerdown_timeout == 0)
				{
					if(IziPlus_Powerup())
					{
						IziPlus_SetState(IZIPLUS_STATE_DMX);
					}
				}
				else
					vTaskDelay(1000);
				continue;
			}
		}
		else if(iziplus_state == IZIPLUS_STATE_DMX)
		{
			static iziplus_fifo_update_t iziplus_fifo_update_item;
			if(iziplus_substate != IZIPLUS_SUBSTATE_UPDATE && iziplus_substate_delay == 0 && fifo_get(iziplus_fifo_update, &iziplus_fifo_update_item)) 
			{
				bool broadcast = iziplus_fifo_update_item.index == 0xFFFF && iziplus_fifo_update_item.type > 0;
				if(((iziplus_fifo_update_item.index >= 0 && iziplus_fifo_update_item.index < iziplus_module_amount) || (broadcast && iziplus_module_amount > 0)))
				{
					uint8_t idx = iziplus_fifo_update_item.index;
					iziplus_update_image_size = iziplus_fifo_update_item.size;
					firmware_t *fw_info = (firmware_t *)((FLASH_APP_MIRROR_BASE + iziplus_update_image_size) - FLASH_APP_FW_INFO_SIZE);
					iziplus_substate = IZIPLUS_SUBSTATE_UPDATE;
					IziPlus_ReportLinkState(LINK_STATE_UPDATING, iziplus_module_amount);
					iziplus_update_type = iziplus_fifo_update_item.type;
					iziplus_update_flags = 0;
					if(broadcast)
					{
						int quality = 101;
						iziplus_update_module = NULL;
						for(int i = 0; i < iziplus_module_amount; i++)
						{
							if((iziplus_modules[i].base.device_type == iziplus_update_type) && (iziplus_modules[i].helper.response_quality < quality) && (iziplus_modules[i].helper.response_quality > 30))
							{
								iziplus_update_module = &iziplus_modules[i];					// Set to the module with the lowest quality (as ling as its higher than 30%)
							}
						}
						if(iziplus_update_module == NULL)
							iziplus_update_module = &iziplus_modules[0];						// Take first if all quality is bad
					}
					else
					{
						iziplus_update_module = &iziplus_modules[idx];
						iziplus_update_flags = 1 << idx;
						iziplus_update_cnt = 1;
						for(int i = 0; i < (IZI_MAX_MODULES - 1); i++)
						{
							if(fifo_get(iziplus_fifo_update, &iziplus_fifo_update_item))
							{
								iziplus_update_flags |= 1 << iziplus_fifo_update_item.index;
								iziplus_update_cnt++;
							}
							else break;
						}
						iziplus_update_allow_start = iziplus_update_cnt > 1;
					}
					
					izi_versionplus_u image_version = { .v.major = fw_info->version.v.major, .v.minor = fw_info->version.v.minor, .v.build = fw_info->version.v.build };
					iziplus_image_version.d = image_version.d;
					iziplus_update_length = fw_info->image.end - fw_info->image.start; //can_prog_ram_bfr[RAM_APP_PROG_SIZE - 4] + (can_prog_ram_bfr[RAM_APP_PROG_SIZE - 3] << 8);			// Get length
					iziplus_update_length = ((iziplus_update_length / IZIPLUS_FW_SIZE) + 1)*IZIPLUS_FW_SIZE;		// Do whole page/write length
					if(iziplus_update_length > (FLASH_APP_END - FLASH_APP_START))
						iziplus_update_length = (FLASH_APP_END - FLASH_APP_START);
					iziplus_update_address = 0;
					iziplus_update_size = appConfig->master_total > 1 ? IZIPLUS_FW_SIZE / (1 << (appConfig->master_total - 1)) : IZIPLUS_FW_SIZE;
					if(iziplus_update_size == IZIPLUS_FW_SIZE && !broadcast)
					{
						if(iziplus_modules[idx].helper.response_quality < 50)
							iziplus_update_size = IZIPLUS_FW_SIZE / 4;
						else if(iziplus_modules[idx].helper.response_quality < 90)
							iziplus_update_size = IZIPLUS_FW_SIZE / 2;
					}
					else if(iziplus_update_size < (IZIPLUS_FW_SIZE / 4))
						iziplus_update_size = IZIPLUS_FW_SIZE / 4;
					iziplus_update_reboot = false;
				
					iziplus_update_apply = 0;
					iziplus_update_allow = 0;
					iziplus_update_module_removed = false;
					iziplus_update_module_backup = NULL;
					if(broadcast)
					{
						iziplus_update_cnt = 0;
						for(int i = 0; i < iziplus_module_amount; i++)
						{
							if(iziplus_modules[i].base.device_type == iziplus_update_type)
							{
								iziplus_modules[i].var.flags &= ~FLAG_UPDATE_FAIL;
								iziplus_update_cnt++;
								iziplus_update_flags |= (1 << i);
							}
						}
						iziplus_update_allow_start = iziplus_update_cnt > 1;
					}
					else
					{
						iziplus_update_module->var.flags &= ~FLAG_UPDATE_FAIL;
						//iziplus_update_allow_start = false;
					}
					IZIPLUS_TRACE_INFO("Start updating: 0x%x, s: 0x%x, e: 0x%x, b: %d (%d %d 0x%x)\r\n", !broadcast ? iziplus_update_module->base.device_id : 0, fw_info->image.start, fw_info->image.end, fw_info->version.v.build, iziplus_update_cnt, iziplus_update_allow_start, iziplus_update_flags);
				}
			}
			else if(iziplus_substate_delay > 0)
				iziplus_substate_delay--;
		}

		TickType_t delay = 1;
		TickType_t now_tick = xTaskGetTickCount();
		if(iziplus_sync_time > 0)
		{
			if(iziplus_sync_time > now_tick)
			{
				delay = iziplus_sync_time - now_tick;
				if(delay >= IZIPLUS_LIGHTDATA_TICKS)
					delay -= IZIPLUS_LIGHTDATA_TICKS;
			}
			iziplus_sync_time = 0;
		}
		if((delay == 1) && (now_tick - iziplus_last_lightdata) < IZIPLUS_LIGHTDATA_TICKS)		// Delay == 1 is no sync time or 'almost' in sync
		{
			delay = (IZIPLUS_LIGHTDATA_TICKS - (now_tick - iziplus_last_lightdata));
		}
		/*else if(delay != 1)
		{
			IZIPLUS_TRACE_INFO("Oeoi: %d\r\n", (now_tick - iziplus_last_lightdata));
		}*/

		vTaskDelay(delay);

		TickType_t quality_ticks_now = xTaskGetTickCount();
		if(quality_ticks_now - quality_ticks >= 5000)						// Check quality every 5 sec
		{
			quality_ticks = quality_ticks_now;
			iziplus_req_per_sec = iziplus_req_amount / 5;
			iziplus_lightdata_cnt_store = iziplus_lightdata_cnt / 5;			// Amount of light frames
			iziplus_lightdata_cnt = 0;
			iziplus_rsp_quality = (iziplus_rsp_amount * 100)/iziplus_req_amount;
			//IZI_TRACE_INFO("Req: %d / Rsp: %d\r\n", iziplus_req_amount, iziplus_rsp_amount);
			if(iziplus_rsp_quality < 25)
			{
				if(++iziplus_rsp_quality_low_cnt == 3)						// 15 sec low COM quality?
				{
					if(iziplus_module_amount > 0)
					{
						State_SetWarning(STATE_WARNING_BAD_COMQUAL);
						if(iziplus_rsp_quality == 0)
							dcbm1_init(iziplus_pl_freq, iziplus_pl_rate);		// Make sure the modem chip is OK
					}
					else 
						State_ClearWarning(STATE_WARNING_BAD_COMQUAL);
						
					iziplus_rsp_quality_low_cnt = 0;
				}
			}
			else if(iziplus_rsp_quality > 30)
			{
				iziplus_rsp_quality_low_cnt = 0;
				State_ClearWarning(STATE_WARNING_BAD_COMQUAL);
			}
			if(iziplus_state != IZIPLUS_STATE_SCAN && (iziplus_substate != IZIPLUS_SUBSTATE_UPDATE))
				IziPlus_ReportLinkState(iziplus_master_lvl < 255 ? LINK_STATE_POWER_LIMIT : LINK_STATE_IDLE, iziplus_module_amount);
			iziplus_req_amount = iziplus_rsp_amount = 0;
		}
		
		iziplus_last_lightdata = xTaskGetTickCount();
		if(IziPlus_SendLightData())				// Send light data and check if requests may be send on the bus
		{
			if(!IziPlus_Acks())
				if(!IziPlus_Updates())				// Perform pending updates, if no updates check for pending actions
					if(!IziPlus_Actions())			// Perform pending actions, if no action check for pending requests
						IziPlus_Requests();			// Perform pending requests
		}
		
		REPORT_STACK(TASK_PLUS_STACK_SIZE, TASK_IZIPLUS);
	}
}

void IziPlus_ReportOverrule(bool is_overruled)
{
	if(iziplus_protect_timeout == 0)
	{
		if(is_overruled)
			IziPlus_ReportLinkState(LINK_STATE_LEVEL_OVERRULE, iziplus_module_amount);
		else
			IziPlus_ReportLinkState(LINK_STATE_IDLE, iziplus_module_amount);
	}
}

bool IziPlus_StartUpdate(uint32_t serial, uint32_t firmware_size, uint16_t type)
{
	if(iziplus_state == IZIPLUS_STATE_DMX && (iziplus_substate == IZIPLUS_SUBSTATE_UPDATE || iziplus_substate == IZIPLUS_SUBSTATE_IDLE))
	{
		int i;
		if(serial > 0)
		{
			izi_module_t *update_module = NULL;
			for(i = 0; i < iziplus_module_amount; i++)
			{
				if(iziplus_modules[i].base.device_id == serial)
				{
					update_module = &iziplus_modules[i];
					break;
				}
			}
			if(update_module == NULL)
				return false;
			if(!(update_module->var.flags & FLAG_ONLINE))		// Check if module is online
				return false;
			
			iziplus_substate_delay = IZIPLUS_LIGHTDATA_TICKS;	// Wait one sec to check for other unicast requests...
		}
		else
		{
			if(type == 0)
				return false;
			i = 0xFFFF;				// Broadcast
		}

		iziplus_fifo_update_t iziplus_fifo_update_item;
		iziplus_fifo_update_item.index = i;
		iziplus_fifo_update_item.type = type;
		iziplus_fifo_update_item.size = firmware_size;

		bool added = fifo_add(iziplus_fifo_update, &iziplus_fifo_update_item);
		IZI_TRACE_INFO("Update req add: %d (%d, 0x%x, size: 0x%08x, type: %d)\r\n", i, added, (i == 0xFFFF) ? 0 : iziplus_modules[i].base.device_id, firmware_size, type);

		return true;
	}
	return false;
}

bool IziPlus_HandleToken(izi_module_t *module)
{
	TickType_t delay = 12;
	if(iziplus_state != IZIPLUS_STATE_DISCOVER)
	{
		TickType_t now_tick = xTaskGetTickCount();
		if(iziplus_sync_time > 0)
		{
			if(iziplus_sync_time > now_tick)
			{
				delay = iziplus_sync_time - now_tick;
			}
			iziplus_sync_time = 0;
		}
		else if((now_tick - iziplus_last_lightdata) < IZIPLUS_LIGHTDATA_TICKS)
		{
			delay = (IZIPLUS_LIGHTDATA_TICKS - (now_tick - iziplus_last_lightdata));
		}
		else
		{
			IZIPLUS_TRACE_INFO("Oeoi2: %d\r\n", (now_tick - iziplus_last_lightdata));
		}
	}
	vTaskDelay(delay);

	iziplus_last_lightdata = xTaskGetTickCount();
	if(iziplus_state == IZIPLUS_STATE_DISCOVER || iziplus_state == IZIPLUS_STATE_ASSIGN_CHAN)
	{
		uint16_t nw_length = iziplus_networkframe_poll(iziplus_nwdata_notification, module->base.short_id);
		if(iziplus_data_notification(module->base.device_id, module->base.device_type, iziplus_nwdata_notification, nw_length) >= 0)
		{
			return true;
		}
	}
	else
		return IziPlus_SendLightDataRaw(module->base.short_id);

	return false;
}

void IziPlus_HandleOnline(izi_module_t *module, bool online)
{
	if(online)
	{
		module->var.update_time = RtcTime_GetSeconds();
		module->var.offline_prs = 0;
		if(!(module->var.flags & FLAG_ONLINE))
		{
			IZIPLUS_TRACE_INFO("Module online 0x%08x\r\n", module->base.device_id);
			IziPlus_ReportMonitorFlag(module);		// Report online/offline change
			module->helper.requests |= (1 << IZIPLUS_REQ_VERSION)|(1 << IZIPLUS_REQ_CONFIG)|(1 << IZIPLUS_REQ_CHANNELMODE);		// Check all config and versions for this module
		}
		module->var.flags |= FLAG_ONLINE;

		if(module->var.flags & FLAG_REPROGRAMMING)
		{
			module->helper.requests |= (1 << IZIPLUS_REQ_VERSION)|(1 << IZIPLUS_REQ_CONFIG)|(1 << IZIPLUS_REQ_CHANNELMODE);		// Request version and config, if first response after update
			module->var.flags |= FLAG_UPDATE_VERSION;
		}

		module->var.flags &= ~FLAG_REPROGRAMMING;
		iziplus_rsp_amount++;
		
		if(iziplus_lightdata_tokenoverrule > 0)
		{
			iziplus_scan_cnt++;
			iziplus_scan_total++;
			
			IZIPLUS_TRACE_INFO("Scan[%d]: %d|%d\r\n", iziplus_scan_token, iziplus_scan_cnt, iziplus_scan_total);
		}
	}
	else if(iziplus_module_amount > 0)
	{
		// Token frequency of state requests is 10Hz, 10Hz is used to check all connected modules, so if only one module is connected, this is much faster than with 32 modules
		// A module may not be reacting for 2 seconds
		// Routine is not bullet proof, if many requests are send to a specific module it won't work...
		// Todo: Could do something with timing
		uint8_t offline_cnt = ((20 / iziplus_module_amount));
		if(offline_cnt < 3)			// Never less than 3 retries
			offline_cnt = 3;
		else if(module->var.flags & FLAG_REPROGRAMMING)			// Longer time when reprogramming
			offline_cnt *= 2;

		if(++module->var.offline_prs > offline_cnt)
		{
			if(module->var.flags & FLAG_ONLINE)
			{
				IZIPLUS_TRACE_INFO("Module offline 0x%08x (%d of %d)\r\n", module->base.device_id, module->var.offline_prs, offline_cnt);
				IziPlus_ReportMonitorFlag(module);		// Report online/offline change
			}
			module->var.flags &= ~(FLAG_ONLINE|FLAG_REPROGRAMMING);
			if(module->var.offline_prs > 250)
				module->var.offline_prs = 250;			// Clip
		}
		if(iziplus_lightdata_tokenoverrule > 0)
		{
			iziplus_scan_total++;
		}
	}
	if((iziplus_lightdata_tokenoverrule > 0) && (iziplus_scan_total >= iziplus_scan_attempts))
	{
		iziplus_scan_result[iziplus_scan_token] = (iziplus_scan_cnt * 100) / iziplus_scan_total;
		IZIPLUS_TRACE_INFO("Scan[%d] (0x%08x): %d%% (ok: %d total: %d attempt:%d)\r\n", iziplus_scan_token, module->base.device_id, iziplus_scan_result[iziplus_scan_token], iziplus_scan_cnt, iziplus_scan_total, iziplus_scan_attempts);
		if(++iziplus_scan_token >= iziplus_module_amount)
		{
			iziplus_lightdata_tokenoverrule = 0;
		}
		IziPlus_ReportLinkState(LINK_STATE_QUALITYSCAN, iziplus_module_amount);
		iziplus_scan_total = 0;
		iziplus_scan_cnt = 0;
	}
}

void IziPlus_HandleRx(iziplus_data_frame_t *frame, bool handled)
{
	if(handled)
		return;

	iziplus_network_data_t *nw_data = ((iziplus_network_data_t *)frame->data);
	if(iziplus_discover_phase == 1)
	{
		// Ignore PAN ID
		if(nw_data->cmd == IZIPLUS_CMD_DISCOVER && nw_data->msgtype.u.frame_type == IZIPLUS_FRAMETYPE_RSP)
		{
			if(frame->lengthdir.u.length >= (sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_discover_rsp_t)))
			{
				bool searchModule = false;
				uint8_t idx = iziplus_module_amount;
				for(uint16_t i = 0; i < iziplus_module_amount; i++)
					if(iziplus_modules[i].base.device_id == frame->destination)
					{
						searchModule = true;				// Check if already in list
						idx = i;
						break;
					}

				if(!searchModule && iziplus_module_amount >= IZI_MAX_MODULES)
				{
					iziplus_module_extra++;
					uint16_t nw_length = iziplus_networkframe_operationmode(iziplus_nwdata, IZIPLUS_OPERATIONMODE_NORMAL, true);
					iziplus_data_notification(frame->destination, frame->device_type, iziplus_nwdata, nw_length);			// Do not respond any more (only possible to use notification from here)
					State_SetError(STATE_ERROR_MODULE_MAX);
					return;
				}
				if(!searchModule && ((iziplus_discover_option == IZIPLUS_OPTION_SWITCH) || (iziplus_discover_newcount > 0 && iziplus_discover_option == IZIPLUS_OPTION_REPLACE)))	// Only replace one module
				{
					uint16_t nw_length = iziplus_networkframe_operationmode(iziplus_nwdata, IZIPLUS_OPERATIONMODE_NORMAL, true);
					iziplus_data_notification(frame->destination, frame->device_type, iziplus_nwdata, nw_length);			// Do not respond any more (only possible to use notification from here)
					IZIPLUS_TRACE_INFO("Ignore new module: %08x\r\n", frame->destination);
					return;			// New modules are not added in this mode
				}
				
				iziplus_modules[idx].var.flags |= FLAG_ASSIGN_INCOMPLETE;						// Mark assign to network must be completed
					
				iziplus_modules[idx].base.prot_version = ((iziplus_cmd_discover_rsp_t *)(&frame->data[4]))->protocol_version;
				iziplus_modules[idx].base.device_type = frame->device_type;
				if(!searchModule)
				{
					iziplus_modules[idx].base.device_id = frame->destination;
					iziplus_modules[idx].helper.discover_new = ++iziplus_discover_newcount;
					iziplus_module_amount++;
					iziplus_module_extra = 0;
					State_ClearError(STATE_ERROR_MODULE_MAX);
					IZIPLUS_TRACE_INFO("New module: %08x (%d)\r\n", frame->destination, idx);
				}
				else
				{
					iziplus_modules[idx].helper.discover_new = 0;
					iziplus_modules[idx].var.flags |= FLAG_ONLINE;
					iziplus_modules[idx].var.update_time = RtcTime_GetSeconds();
					IZIPLUS_TRACE_INFO("Discover module responded again: %08x (%d %d)\r\n", frame->destination, iziplus_modules[idx].var.flags, idx);
				}
			}
		}
	}
	else if(frame->pan_id != appConfig->pan_id && frame->pan_id != IZIPLUS_PANID_WILDCARD)
	{
		uint8_t free = 0xFF, m, amount = 0;
		for(m = 0; m < IZIPLUS_MAX_MASTER; m++)
		{
			if(iziplus_multimaster[m].serial == frame->pan_id)
			{
				iziplus_multimaster[m].time = RtcTime_GetSeconds();
				amount++;
				break;
			}
			else if(iziplus_multimaster[m].serial == 0)
			{
				if(free == 0xFF)
					free = m;				// Store first free slot
			}
			else
				amount++;
		}
		if(m == IZIPLUS_MAX_MASTER && free != 0xFF)
		{
			iziplus_multimaster_amount = amount + 1;
			iziplus_multimaster[free].serial = frame->pan_id;
			iziplus_multimaster[free].time = RtcTime_GetSeconds();
			sprintf(text, "Master detected 0x%X (count: %d)", iziplus_multimaster[free].serial, iziplus_multimaster_amount);
			if(iziplus_multimaster_amount > IZIPLUS_MAX_MASTER_WARN)
				LOGWRITE_WARNING(ERRCODE_IZI_MULTI_MASTER_ADD, text, log_src_task_postpone);
			else
				LOGWRITE_TRACE(ERRCODE_IZI_MULTI_MASTER_ADD, text, log_src_task_postpone);

			if(iziplus_multimaster_amount > IZIPLUS_MAX_MASTER_WARN)
				State_SetWarning(STATE_WARNING_MASTER_HIGH);
		}
		return;
	}
	else if(frame->pan_id == IZIPLUS_PANID_WILDCARD)
		return;


	if(nw_data->msgtype.u.frame_type == IZIPLUS_FRAMETYPE_NOT && frame->lengthdir.u.length >= sizeof(iziplus_network_data_t))
	{
		izi_module_t *izi_module = NULL;
		uint16_t i;
		for(i = 0; i < iziplus_module_amount; i++)
			if(iziplus_modules[i].base.device_id == frame->destination)
			{
				izi_module = &iziplus_modules[i];
				IziPlus_HandleOnline(izi_module, true);
				if(iziplus_token_pending > 0 && iziplus_token_serial == izi_module->base.device_id)
				{
					if(iziplus_token_pending <= iziplus_module_amount)
						iziplus_modules[iziplus_token_pending - 1].helper.response_count++;
					iziplus_token_pending = 0;				// Report token was answered
				}
				else if(iziplus_token_pending == 0)
				{
					IZIPLUS_TRACE_INFO("Late token rsp -> Exp:%X - Rx:%X (sq: %d, tok: %d)\r\n", iziplus_token_serial, izi_module->base.device_id, nw_data->seqid, iziplus_token_pending);
				}
				else 
					IZIPLUS_TRACE_INFO("Wrong token rsp -> Exp:%X - Rx:%X (sq: %d, tok: %d)\r\n", iziplus_token_serial, izi_module->base.device_id, nw_data->seqid, iziplus_token_pending);
				break;
			}

		if(izi_module != NULL)
		{
			uint16_t p_len = frame->lengthdir.u.length - sizeof(iziplus_network_data_t);
			if(nw_data->cmd == IZIPLUS_CMD_VERSIONS && nw_data->msgtype.u.cmd_type == IZIPLUS_CMDTYPE_READ)
			{
				if(p_len >= (sizeof(iziplus_cmd_versions_rrsp_t)))
				{
					if(IziPlus_Response_Version(izi_module, &frame->data[sizeof(iziplus_network_data_t)]))
						IziPlus_ReportConfigFlag(izi_module);
				}
			}
			else if(nw_data->cmd == IZIPLUS_CMD_ASSIGN_CHANMODE && nw_data->msgtype.u.cmd_type == IZIPLUS_CMDTYPE_READ)
			{
				if(p_len >= (sizeof(iziplus_cmd_versions_rrsp_t)))
				{
					if(IziPlus_Response_ChannelMode(izi_module, &frame->data[sizeof(iziplus_network_data_t)]))
						IziPlus_ReportConfigFlag(izi_module);
				}
			}
			else if(nw_data->cmd == IZIPLUS_CMD_CONFIG && nw_data->msgtype.u.cmd_type == IZIPLUS_CMDTYPE_READ)
			{
				//if(p_len >= 0)
				{
					if(IziPlus_Response_Config(&iziplus_modules[i], &iziplus_nwdata_rx[sizeof(iziplus_network_data_t)], p_len))
						IziPlus_ReportConfigFlag(&iziplus_modules[i]);
				}
			}
			else if(nw_data->cmd == IZIPLUS_CMD_TEXT && nw_data->msgtype.u.cmd_type == IZIPLUS_CMDTYPE_READ)
			{
				//if(p_len >= 0)
				{
					if(IziPlus_Response_Text(&iziplus_modules[i], &iziplus_nwdata_rx[sizeof(iziplus_network_data_t)], p_len))
						IziPlus_ReportConfigFlag(&iziplus_modules[i]);
				}
			}
			else if(nw_data->cmd == IZIPLUS_CMD_STATE && nw_data->msgtype.u.cmd_type == IZIPLUS_CMDTYPE_READ)
			{
				if(p_len > 0)
				{
					if(p_len > (IZI_MAX_MONITOR + 2))
						p_len = IZI_MAX_MONITOR + 2;

					izi_module->var.monitor_rec_amount = p_len - 2;
					if(p_len > 2)
					{
						memcpy(izi_module->var.monitor, (&frame->data[6]), p_len - 2);
						if((izi_module->base.monitor_status_idx != 255) && (izi_module->base.monitor_status_idx < izi_module->var.monitor_rec_amount))
						{
							int8_t status = izi_module->var.monitor[izi_module->base.monitor_status_idx];
							if(izi_module->var.status != status)
							{
								izi_module->var.status = status;
								/*if(status < 0)
								{
									int8_t res = IziPlus_GetErrorText(text, status);
									if(res < 0)
										sprintf(text, "Error report: %d", status);
									
									if(res == ERROR_TYPE_WARNING)
										LOGWRITE_WARNING_S(ERRCODE_IZI_MODULE_WARNING, text, log_src_task_postpone, izi_module->base.device_id);
									else
										LOGWRITE_ERROR_S(ERRCODE_IZI_MODULE_ERR, text, log_src_task_postpone, izi_module->base.device_id);
								}
								else
								{
									sprintf(text, "Module OK");
									LOGWRITE_INFO_S(ERRCODE_IZI_MODULE_ERR, text, log_src_task_postpone, izi_module->base.device_id);
								}*/
							}
						}
					}

					iziplus_cpustate_u cpu_state;
					cpu_state.w = frame->data[4] + (frame->data[5] << 8);
					izi_module->var.cpu_state = cpu_state.w;
					izi_module->var.flags &= ~FLAG_RESET_MASK;			// Clear reset flags
					if(cpu_state.u.powerup && !last_cpu_state[i].u.powerup)
					{
						izi_module->var.flags |= FLAG_RESET_POWERON;
						sprintf(text, "Power-up");
						LOGWRITE_INFO_S(ERRCODE_IZI_RESET_PUP, text, log_src_task_postpone, izi_module->base.device_id);
						izi_module->helper.contact_eventid = 0xAA;		// Probably the first send is 0, make sure first trigger is handled
					}
					if(cpu_state.u.extreset)
						izi_module->var.flags |= FLAG_RESET_EXT;
					if(cpu_state.u.brownout && !last_cpu_state[i].u.brownout)
					{
						if(!cpu_state.u.powerup)
						{
							sprintf(text, "Brown out reset");
							LOGWRITE_INFO_S(ERRCODE_IZI_RESET_BROWNOUT, text, log_src_task_postpone, izi_module->base.device_id);
						}
						izi_module->var.flags |= FLAG_RESET_BROWNOUT;
					}
					if(cpu_state.u.watchdog && !last_cpu_state[i].u.watchdog)
					{
						sprintf(text, "Watchdog reset");
						LOGWRITE_INFO_S(ERRCODE_IZI_RESET_BROWNOUT, text, log_src_task_postpone, izi_module->base.device_id);
						izi_module->var.flags |= FLAG_RESET_WATCHDOG;
						izi_module->helper.contact_eventid = 0xAA;		// Probably the first send is 0, make sure first trigger is handled
					}
					if(cpu_state.u.sw_reset)
						izi_module->var.flags |= FLAG_RESET_SWRESET;

					if(cpu_state.u.settings_fail && !last_cpu_state[i].u.settings_fail)
					{
						sprintf(text, "Settings memory corrupt");
						LOGWRITE_ERROR_S(ERRCODE_IZI_MEMSET_FAIL, text, log_src_task_postpone, izi_module->base.device_id);
					}
					if(cpu_state.u.text_fail && !last_cpu_state[i].u.text_fail)
					{
						sprintf(text, "Text memory corrupt");
						LOGWRITE_ERROR_S(ERRCODE_IZI_MEMTEXT_FAIL, text, log_src_task_postpone, izi_module->base.device_id);
					}
					if(cpu_state.u.max_fail && !last_cpu_state[i].u.max_fail)
					{
						sprintf(text, "Max value memory corrupt");
						LOGWRITE_ERROR_S(ERRCODE_IZI_MEMMAX_FAIL, text, log_src_task_postpone, izi_module->base.device_id);
					}
					if(cpu_state.u.prod_fail && !last_cpu_state[i].u.prod_fail)
					{
						sprintf(text, "Production memory corrupt");
						LOGWRITE_CRITICAL_S(ERRCODE_IZI_PROD_FAIL, text, log_src_task_postpone, izi_module->base.device_id);
					}
					if(cpu_state.u.plt_fail && !last_cpu_state[i].u.plt_fail)
					{
						sprintf(text, "Powerline transceiver recovered");
						LOGWRITE_WARNING_S(ERRCODE_IZI_PLT_FAIL, text, log_src_task_postpone, izi_module->base.device_id);
					}
					last_cpu_state[i].w = cpu_state.w;

					izi_module->var.flags &= ~FLAG_IDENTIFY_MASK;
					if(cpu_state.u.identify == 1)
						izi_module->var.flags |= FLAG_IDENTIFY_BLINK;
					else if(cpu_state.u.identify == 2)
						izi_module->var.flags |= FLAG_IDENTIFY_SPOTON;
					else if(cpu_state.u.identify == 3)
						izi_module->var.flags |= FLAG_IDENTIFY_QUALITY;

					if(izi_module->var.flags != izi_module->var_shadow.flags)
						IziPlus_FastReport();
						
					// Check for diffs to report
					if(izi_module->var.cpu_state != izi_module->var_shadow.cpu_state ||
						izi_module->var.flags != izi_module->var_shadow.flags ||
						((izi_module->var.monitor_rec_amount > 0) && (memcmp(izi_module->var.monitor, izi_module->var_shadow.monitor, IZI_MAX_MONITOR) != 0)))
					{
						IziPlus_ReportMonitorFlag(izi_module);
						izi_module->var_shadow.cpu_state = izi_module->var.cpu_state;				// Copy to compare shadow area
						memcpy(izi_module->var_shadow.monitor, izi_module->var.monitor, izi_module->var.monitor_rec_amount);
						izi_module->var_shadow.flags = izi_module->var.flags;
						if(izi_module->base.monitor_input_idx < izi_module->var.monitor_rec_amount)
						{
							uint8_t contact_state = izi_module->var.monitor[izi_module->base.monitor_input_idx];
							if(contact_state != izi_module->var.contact_state)
							{
								izi_module->var.contact_state = contact_state;
								IziPlus_FastReport();
								IZIPLUS_TRACE_INFO("Contact trigger correction: %d\r\n", contact_state);
							}
						}
					}
				}
			}
			else if(nw_data->cmd == IZIPLUS_CMD_IDENTIFY)
			{
				izi_module->var.flags |= FLAG_IDENTIFY_BUTTON;
				izi_module->helper.flag_clear_req |= FLAG_IDENTIFY_BUTTON;
				izi_module->helper.flag_clear_timer = IDENTIFY_BUTTON_TIMEOUT;
			}
			else if(nw_data->cmd == IZIPLUS_CMD_CONTACTTRIGGER)
			{
				izi_module->var.contact_state = frame->data[5];
				if(p_len > 3)
					izi_module->var.encoder_state[0] = frame->data[7];
				else
					izi_module->var.encoder_state[0] = 0;
					
				if(p_len > 2)
					izi_module->var.encoder_contact = frame->data[6];
				else
					izi_module->var.encoder_contact = 0;
					
				if(izi_module->helper.contact_eventid != frame->data[4])
				{
					izi_module->helper.contact_eventid = frame->data[4];
					IziPlus_ReportMonitorFlag(&iziplus_modules[i]);				// Report new state
					IZIPLUS_TRACE_INFO("Contact trigger: %d (enc: %d %d)\r\n", frame->data[5], izi_module->var.encoder_state[0], izi_module->var.encoder_contact);
					
					if(iziplus_contacttrigger_acks_count < IZIPLUS_MAX_CONTACTTRIGGER_ACKS)
					{
						iziplus_contacttrigger_acks[iziplus_contacttrigger_acks_count].event_id = frame->data[4];
						iziplus_contacttrigger_acks[iziplus_contacttrigger_acks_count].short_id = izi_module->base.short_id;
						iziplus_contacttrigger_acks_count++;
						IZIPLUS_TRACE_INFO("Contact trigger ack: %d %d\r\n", iziplus_contacttrigger_acks_count, iziplus_contacttrigger_acks[iziplus_contacttrigger_acks_count - 1].event_id);
					}
					IziPlus_FastReport();
				}
				else if(iziplus_contacttrigger_acks_count == 0)			// Ack not received by the module, Ack again
				{
					if(iziplus_contacttrigger_acks_count < IZIPLUS_MAX_CONTACTTRIGGER_ACKS)
					{
						iziplus_contacttrigger_acks[iziplus_contacttrigger_acks_count].event_id = frame->data[4];
						iziplus_contacttrigger_acks[iziplus_contacttrigger_acks_count].short_id = izi_module->base.short_id;
						iziplus_contacttrigger_acks_count++;
						IZIPLUS_TRACE_INFO("Contact trigger ack repeat: %d %d\r\n", iziplus_contacttrigger_acks_count, iziplus_contacttrigger_acks[iziplus_contacttrigger_acks_count - 1].event_id);
					}
				}
			}
		}
		else
		{
			if((nw_data->cmd == IZIPLUS_CMD_JOINNETWORK) && (nw_data->msgtype.u.cmd_type == IZIPLUS_CMDTYPE_ACTION))
			{
				iziplus_fifo_join_t join_item;
				
				join_item.device_id = frame->destination;
				join_item.device_type = frame->device_type;
				join_item.prot_version = ((iziplus_cmd_discover_rsp_t *)(&frame->data[4]))->protocol_version;
				bool r = fifo_add(iziplus_fifo_join_items, &join_item);
				
				IZIPLUS_TRACE_INFO("Join network of %08x: %d (%d)\r\n", join_item.device_id, r);
			}
		}
	}
}

static uint8_t light_data[256];

void IziPlus_SetMaster(uint8_t master_lvl)
{
	iziplus_master_lvl = master_lvl;
}

void IziPlus_IncMaster(uint8_t step_size)
{
	if(iziplus_master_lvl < (255 - step_size))
		iziplus_master_lvl += step_size;
	else if(iziplus_master_lvl < 255)
		iziplus_master_lvl = 255;
}

void IziPlus_DecMaster(uint8_t step_size)
{
	if(iziplus_master_lvl >= step_size)
		iziplus_master_lvl -= step_size;
	else
		iziplus_master_lvl = 0;
}

bool IziPlus_SendLightDataRaw(uint8_t token)
{
	uint8_t *level_data = Izi_OutputGetMerge();
	uint16_t size = 0;
	uint8_t overrule_level = IziInput_GetLevelOverrule();
	for(uint16_t i = 0; i <	iziplus_module_lightdata_amount; i++)
	{
		uint16_t sz = iziplus_module_lightdata[i].amount;
		if(sz + size > sizeof(light_data))
			break;
		if(IziInput_GetActiveOverrule())
			memset(&light_data[size], overrule_level, sz);
		else
			memcpy(&light_data[size], &level_data[iziplus_module_lightdata[i].channel], sz);
		
		if(iziplus_master_lvl != 255)
		{
			for(int i = 0; i < sz; i++)
				light_data[size + i] = (uint8_t)(((uint16_t)light_data[size + i] * (uint16_t)iziplus_master_lvl) / 255);
		}
		size += sz;
	}
	iziplus_channel_amount = size;

	uint16_t nw_length = iziplus_networkframe_lightdata(iziplus_nwdata_notification, light_data, size, token, izican_slave_nodata());
	if(iziplus_data_notification(0, IZIPLUS_DEVTYPE_BROADCAST, iziplus_nwdata_notification, nw_length) < 0)
	{
		if(++iziplus_send_errors == IZIPLUS_REPORT_TX_ERROR)
		{
			LOGWRITE_WARNING(ERRCODE_IZI_POWERLINE_TX_ERROR, "Powerline send failures high", log_src_task_postpone);
			State_SetWarning(STATE_WARNING_PL_SEND);
		}
		else if(iziplus_send_errors == IZIPLUS_REPORT_TX_ERROR_INIT)
		{
			LOGWRITE_ERROR(ERRCODE_IZI_POWERLINE_TX_ERROR, "Powerline send fail too high (re-init)", log_src_task_postpone);
			dcbm1_init(iziplus_pl_freq, iziplus_pl_rate);		// Make sure the modem chip is OK
		}
		else if(iziplus_send_errors > (IZIPLUS_REPORT_TX_ERROR_INIT))
			iziplus_send_errors = IZIPLUS_REPORT_TX_ERROR_INIT;

		return false;
	}
	return true;
}

bool IziPlus_SendLightData()
{
	iziplus_lightdata_cnt++;
	uint8_t token = IZIPLUS_TOKEN_FREE;
	bool token_request_pending = false;

	if(iziplus_token_pending > 0)
	{
		if(iziplus_token_pending <= iziplus_module_amount)
			IziPlus_HandleOnline(&iziplus_modules[iziplus_token_pending - 1], false);	// Module did not answer, because token var was not cleared, report possible offline
		//IZIPLUS_TRACE_INFO("Offline: %d\r\n", iziplus_token_pending);
		iziplus_token_pending = 0;
	}

	if(((iziplus_lightdata_tokenprs & 0x03) == 0 && iziplus_module_amount > 0) || (iziplus_lightdata_tokenoverrule > 0))
	{
		token = (iziplus_lightdata_tokenoverrule > 0 ? iziplus_scan_token : (iziplus_lightdata_tokenprs >> 2)) + 1;					// Set token for a module (increasing index)
		token_request_pending = true;
		if(iziplus_modules[token - 1].helper.request_count >= 10)
		{
			iziplus_modules[token - 1].helper.response_quality = (iziplus_modules[token - 1].helper.response_count * 100) / iziplus_modules[token - 1].helper.request_count;
			//IZI_TRACE_INFO("Module[%d] quality: %d (%d %d)\r\n", token - 1, iziplus_modules[token - 1].helper.response_quality, iziplus_modules[token - 1].helper.request_count, iziplus_modules[token - 1].helper.response_count);
			iziplus_modules[token - 1].helper.request_count = 0;
			iziplus_modules[token - 1].helper.response_count = 0;
		}
		iziplus_modules[token - 1].helper.request_count++;
		iziplus_req_amount++;
	}
	else if((iziplus_lightdata_tokenprs & 0x03) == 2 || ((iziplus_substate == IZIPLUS_SUBSTATE_UPDATE) && (iziplus_lightdata_tokenprs & 0x03) == 3))
		token = IZIPLUS_TOKEN_BLOCK;													// Used when requests must be send by this powercom (when updating extra is assigned)

	if(token_request_pending)
	{
		iziplus_token_pending = token;
		iziplus_token_serial = iziplus_modules[token - 1].base.device_id;
		//IZIPLUS_TRACE_INFO("Rq: %d 0x%x\r\n", token, iziplus_token_serial);
	}
	
	if(!IziPlus_SendLightDataRaw(token) && token_request_pending)
	{
		iziplus_token_pending = 0;
	}
	
	uint16_t max_prs = (iziplus_module_amount * 4);
	if(max_prs == 0)
		max_prs = 3;		// Also send Block
	if(++iziplus_lightdata_tokenprs >= max_prs)
		iziplus_lightdata_tokenprs = 0;

	return token == IZIPLUS_TOKEN_BLOCK;												// Return true if requesting is permitted
}

void IziPlus_ReportLinkState(uint16_t state, uint16_t amount)
{
	izican_slave_state(state, amount, iziplus_pl_freq, iziplus_pl_rate, iziplus_lightdata_cnt_store, iziplus_req_per_sec, iziplus_rsp_quality, iziplus_scan_token, iziplus_channel_amount, iziplus_scan_result);			// Report on can bus
}


/*
 * Start a discover session
 */
int8_t IziPlus_DiscoverStart(uint16_t option, uint8_t pl_frequency, uint8_t pl_rate, uint8_t *clear)
{
	*clear = 0;
	if(iziplus_state != IZIPLUS_STATE_CONFIG)
	{
		uint16_t option_clean = option & IZIPLUS_OPTION_MASK;
		if((iziplus_offline_count != 1) && (option_clean == IZIPLUS_OPTION_REPLACE))
			return -3;
		if(!IziPlus_SetState(IZIPLUS_STATE_DISCOVER))
			return -2;
			
		if(pl_frequency != 0xFF || pl_rate != 0xFF || (option_clean == IZIPLUS_OPTION_CLEAN) || (option_clean == IZIPLUS_OPTION_REPLACE))		// 0xFF means don't change
		{
			appconfig_t *cfgram = AppConfig_Get();
			if(pl_frequency != 0xFF)
				cfgram->pl_frequency = pl_frequency;
			if(pl_rate != 0xFF)
				cfgram->pl_rate = pl_rate & 0x03;
			
			if((option_clean == IZIPLUS_OPTION_CLEAN) || (option_clean == IZIPLUS_OPTION_REPLACE))			// Clean and replace discover increase the pan id, to ensure offline modules do not participate in the network, when they come online again (then first a join is needed)
			{
				cfgram->pan_id = (PRODUCTION_SERIAL & 0xFFFFFF) + (((cfgram->pan_id >> IZIPLUS_PANID_BASE_SERIAL_SHIFT) + 1) << IZIPLUS_PANID_BASE_SERIAL_SHIFT);
			}
			AppConfig_Set();
		}
		iziplus_discover_option = option_clean;
		iziplus_discover_scan = option & IZIPLUS_OPTION_SCAN_FLAG;
		if(option == IZIPLUS_OPTION_ADD || option == IZIPLUS_OPTION_CLEAN)
			*clear = 1;
			
		if(iziplus_discover_scan)
		{
			iziplus_scan_token = 0;				// Clear here, to report empty scan before starting new scan (else old result will be reported shortly)
			iziplus_scan_total = 0;
		}

		State_SetAttentionInfo(COLOR_AQUA, COLOR_YELLOW, 10, 1);
		IZIPLUS_TRACE_INFO("Discover request -> option: %d, clear: %d\r\n", option, *clear);
		return 0;
	}
	return -1;
}

void IziPlus_PowerProtectShutdown()
{
	if(iziplus_power_on)
	{
		IziPlus_PowerOff();
		
		iziplus_protect_timeout = PROTECT_TIMEOUT;				// Max 10 sec
		iziplus_state = IZIPLUS_STATE_PROTECT;
	}
}

void IziPlus_VoltageProtectShutdown()
{
	if(iziplus_power_on)
		IziPlus_PowerOff();
	
	iziplus_protect_timeout = PROTECT_SAMPLE_TIMEOUT;			// Max 2 sec (or extend timeout)
	iziplus_state = IZIPLUS_STATE_PROTECT2;
}

void IziPlus_Powerdown()
{
	IziPlus_PowerOff();
	IziPlus_ReportLinkState(LINK_STATE_POWER_OFF, iziplus_module_amount);
	State_SetAttentionInfo(COLOR_YELLOW, COLOR_BLUE, 0xFFFF, 4);
	IZI_TRACE_INFO("Power off for 2 minutes\r\n");
	iziplus_powerdown_timeout = 120;			// Max 2 minutes

	iziplus_state = IZIPLUS_STATE_OFF;
}

void IziPlus_PowerOff()
{
	iziplus_power_on = false;
	IZI_POWER_OUT_DISABLE;
	gpio_set_pin_level(OUT_OC, true);
	gpio_set_pin_direction(OUT_OC, GPIO_DIRECTION_OUT);
}

bool IziPlus_PowerOn()
{
#ifdef PCB_REV6	
	if(Analog_GetOutputVoltage() < 2500)								// Check fr short by measure output voltage should be above 2.5V
	{
		iziplus_protect_timeout = PROTECT_SAMPLE_TIMEOUT;				// Max 2 sec
		iziplus_state = IZIPLUS_STATE_PROTECT2;
		State_SetError(STATE_ERROR_CURRENT_PEAK);
		return false;
	}
	NVIC_DisableIRQ(EIC_14_IRQn);
	
	IZI_5V_OFF;
	vTaskDelay(500);														// Make sure the Modules are completely powered down (can go into weird state on 5V)
	IZI_5V_ON;
	
	gpio_set_pin_level(OUT_OC, true);
	gpio_set_pin_direction(OUT_OC, GPIO_DIRECTION_OUT);
#endif
	iziplus_power_on = true;
	IZI_POWER_OUT_ENABLE;
	vTaskDelay(2);						// Small delay to check for short

#ifdef PCB_REV6
	gpio_set_pin_direction(OUT_OC, GPIO_DIRECTION_IN);
	EIC->INTFLAG.reg = EIC_INTFLAG_EXTINT(1 << 14);
	NVIC_ClearPendingIRQ(EIC_14_IRQn);
	NVIC_SetPriority(EIC_14_IRQn, 0);
	NVIC_EnableIRQ(EIC_14_IRQn);
	
	gpio_set_pin_function(OUT_OC, PINMUX_PB14A_EIC_EXTINT14);
#endif
	IZIPLUS_TRACE_INFO("Power-On: %s (%dmV)\r\n", iziplus_protect_timeout == 0 ? "OK" : "FAIL", Analog_GetOutputVoltage());
	return iziplus_protect_timeout == 0;
}

bool IziPlus_SetState(uint8_t state)
{
	if(iziplus_protect_timeout == 0)
	{
		iziplus_state = state;
		return true;
	}
	return false;
}

bool IziPlus_Powerup()
{
	IziPlus_ReportLinkState(LINK_STATE_SWITCH_FREQ, iziplus_module_amount);

	iziplus_pl_freq = appConfig->pl_frequency;
	iziplus_pl_rate = appConfig->pl_rate;
	dcbm1_init(iziplus_pl_freq, iziplus_pl_rate);

	iziplus_dataframe_wildcard(false);
	
	if(!iziplus_power_on)
		vTaskDelay(1000);					// Wait for Boost to stabilize
	if(!IziPlus_PowerOn())
		return false;
	
	//izi_discover_req = IZIPLUS_REQ_SYNC;
	iziplus_powerdown_timeout = 0;

	sprintf(text, "Power on -> Freq: %d.%dMHz Rate: %dkHz", dcbm1_getfrequency_h(iziplus_pl_freq), dcbm1_getfrequency_l(iziplus_pl_freq), dcbm1_getrate_kHz(iziplus_pl_rate));
	LOGWRITE_INFO(ERRCODE_IZI_POWERON_OPERATION, text, log_src_task_postpone);

	IZI_TRACE_INFO(text); GEN_TRACE_INFO("\r\n");

	if(iziplus_state != IZIPLUS_STATE_DISCOVER)
		vTaskDelay(1100);			// Some time for power-up of all modules started (skip config frequency)
	else
		vTaskDelay(500);			// Some time to report switch frequency

	uint8_t iziplus_state_old = iziplus_state;
	if(IziPlus_SetState(IZIPLUS_STATE_IDLE))
	{
		IZI_TRACE_INFO("** End PUP: %d %d\r\n", iziplus_state, iziplus_state_old);
		if(!((iziplus_state_old == IZIPLUS_STATE_DISCOVER) && (iziplus_discover_scan)))		// If discover scan is active, don't report idle, first scan modules com quality
			IziPlus_ReportLinkState(LINK_STATE_IDLE, iziplus_module_amount);
		return true;
	}
	
	return false;
}

void IziPlus_ReportShutdown()
{
	for(int i = 0; i < 3; i++)
	{
		uint16_t nw_length = iziplus_networkframe_shutdown(iziplus_nwdata_notification, 150 - (i * 50));
		iziplus_data_notification(0, IZIPLUS_DEVTYPE_BROADCAST, iziplus_nwdata_notification, nw_length);
		vTaskDelay(50);
	}
	vTaskDelay(50);		// Extra time in case of collision or other problems, to make sure no shutdown occurs while saving data
}

void IziPlus_Discover_Operation()
{
	IziPlus_ReportShutdown();
	
	IziPlus_ReportLinkState(LINK_STATE_SWITCH_FREQ2, iziplus_module_amount);

	IziPlus_PowerOff();
	IZIPLUS_TRACE_INFO("Power-Off discover\r\n");
	
	vTaskDelay(1000);
	
	int8_t res = dcbm1_setfrequency(IZIPLUS_DISCOVER_FREQ);
	if(res < 0 || dcbm1_setrate(IZIPLUS_DISCOVER_RATE) < 0)
	{
		vTaskDelay(10);
		dcbm1_init(IZIPLUS_DISCOVER_FREQ, IZIPLUS_DISCOVER_RATE);	
	}
	else
		dcbm1_settxlevelraw(IZIPLUS_DISCOVER_TXLEVEL);
		
	if(!IziPlus_PowerOn())
		return;
	
	iziplus_dataframe_wildcard(true);		// Use wildcard network ID

	iziplus_powerdown_timeout = 0;
	for(int i = 0; i < IZIPLUS_RESEND_OPERATION_MODE; i++)
	{
		vTaskDelay(50);			// First is sort of boot time of modules

		uint16_t nw_length = iziplus_networkframe_operationmode(iziplus_nwdata, IZIPLUS_OPERATIONMODE_DISCOVER, true);
		iziplus_data_notification(0x00000000, IZIPLUS_DEVTYPE_BROADCAST, iziplus_nwdata, nw_length);
	}
	vTaskDelay(50);		// Wait for processing
}

bool IziPlus_AssignNetwork(uint16_t module_idx, bool is_new_module)
{
	iziplus_modules[module_idx].base.short_id = module_idx + 1;											// Store assigned short id
	
	uint16_t nw_length = iziplus_networkframe_assign_network(iziplus_nwdata, iziplus_discover_session, appConfig->pl_frequency, appConfig->pl_rate, module_idx + 1, appConfig->pan_id, dcbm1_gettxlevel(appConfig->pl_frequency));
	int16_t res = iziplus_data_request(&iziplus_modules[module_idx], iziplus_nwdata, nw_length);		// Assign (new) network settings, and make sure the module does not respond the next discover
	//IZI_TRACE_INFO("Assign network: %d\r\n", res);
	if(res >= (int16_t)(sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_assign_network_wrsp_t)))			
	{
		uint16_t payload_len = 0;
		if(IziPlus_Request_ChannelMode(&iziplus_modules[module_idx], true))
		{
			if(IziPlus_Response_ChannelMode(&iziplus_modules[module_idx], &iziplus_nwdata_rx[sizeof(iziplus_network_data_t)]))
			{
				if(!is_new_module)											// Only if it is not a new module, and the value is not the same as our content
					IziPlus_Request_WriteChannelMode(&iziplus_modules[module_idx], module_idx);			// Correct values
				IziPlus_ReportConfigFlag(&iziplus_modules[module_idx]);
			}
		}
		else
		{
			iziplus_modules[module_idx].helper.requests |= (1 << IZIPLUS_REQ_CHANNELMODE);				// On fail, try later
			if(is_new_module)												// Only if it is a new module
				iziplus_modules[module_idx].helper.requests_init |= (1 << IZIPLUS_REQ_CHANNELMODE);		// Mark as failed on init, so current config can not be trusted
		}

		if(IziPlus_Request_Config(&iziplus_modules[module_idx], true, &payload_len))
		{
			if(IziPlus_Response_Config(&iziplus_modules[module_idx], &iziplus_nwdata_rx[sizeof(iziplus_network_data_t)], payload_len))
			{
				if(!is_new_module)
				{
					IZIPLUS_TRACE_INFO("Write Config2: %d\r\n", module_idx);							// Only if it is not a new module, and the value is not the same as our content
					if(iziplus_modules[module_idx].base.config_amount == 0)							// Possibly not requested yet from IZI-Access
						iziplus_modules[module_idx].base.config_amount = iziplus_modules[module_idx].base.config_rec_amount;
					IziPlus_Request_WriteConfig(&iziplus_modules[module_idx], module_idx);				// Incorrect config, try to recover by a write
				}
				IziPlus_ReportConfigFlag(&iziplus_modules[module_idx]);
			}
		}
		else
		{
			iziplus_modules[module_idx].helper.requests |= (1 << IZIPLUS_REQ_CONFIG);					// On fail, try later
			if(is_new_module)																			// Only if it is a new module
				iziplus_modules[module_idx].helper.requests_init |= (1 << IZIPLUS_REQ_CONFIG);			// Mark as failed on init, so current config can not be trusted
		}

		if(IziPlus_Request_Text(&iziplus_modules[module_idx], true, &payload_len))
		{
			if(IziPlus_Response_Text(&iziplus_modules[module_idx], &iziplus_nwdata_rx[sizeof(iziplus_network_data_t)], payload_len))
			{
				if(!is_new_module)																		// Only if it is not a new module, and the value is not the same as our content
					IziPlus_Request_WriteText(&iziplus_modules[module_idx], module_idx);				// Incorrect text, try to recover by a write
				IziPlus_ReportConfigFlag(&iziplus_modules[module_idx]);
			}
		}
		else
		{
			iziplus_modules[module_idx].helper.requests |= (1 << IZIPLUS_REQ_TEXT);						// On fail, try later
			if(is_new_module)																			// Only if it is a new module
				iziplus_modules[module_idx].helper.requests_init |= (1 << IZIPLUS_REQ_TEXT);			// Mark as failed on init, so current config can not be trusted
		}

		if(IziPlus_Request_Version(&iziplus_modules[module_idx], true))
		{
			if(IziPlus_Response_Version(&iziplus_modules[module_idx], &iziplus_nwdata_rx[sizeof(iziplus_network_data_t)]))
				IziPlus_ReportConfigFlag(&iziplus_modules[module_idx]);
		}
		else
			iziplus_modules[module_idx].helper.requests |= (1 << IZIPLUS_REQ_VERSION);				// On fail, try later
	}
	else
	{
		iziplus_modules[module_idx].helper.requests |= (1 << IZIPLUS_REQ_VERSION)|(1 << IZIPLUS_REQ_CONFIG)|(1 << IZIPLUS_REQ_CHANNELMODE);
		iziplus_modules[module_idx].helper.requests_init |= (1 << IZIPLUS_REQ_VERSION) | (1 << IZIPLUS_REQ_CONFIG) | (1 << IZIPLUS_REQ_CHANNELMODE);
		return false;
	}
		
	// Todo: module is still in the list, when not responding
	return true;
}

void IziPlus_ClearIndexes(uint8_t i)
{
	iziplus_modules[i].base.monitor_status_idx = 255;
	iziplus_modules[i].base.monitor_input_idx = 255;
	
	for(int e = 0; e < IZI_MODULE_MAX_ENCODERMAP; e++)
		iziplus_modules[i].base.monitor_encoder_idx[e] = 255;
}


bool IziPlus_Discover()
{
	bool res = true, replace_ok = false;
	
	sprintf(text, "Discover start: %s", (iziplus_discover_option < DISCOVER_OPTION_DEFINED ? IziPlus_DiscoverOptionText[iziplus_discover_option] : "??"));
	LOGWRITE_INFO(ERRCODE_IZI_DISCOVER_START, text, log_src_task_postpone);
	if(iziplus_discover_option == IZIPLUS_OPTION_OFF)			// Complete off for other discover?
	{
		IziPlus_Powerdown();
		return res;
	}
	else if(iziplus_discover_option == IZIPLUS_OPTION_ON)
	{
		res = IziPlus_Powerup();
		State_ClearAttentionInfo();
		return res;
	}
	IziPlus_Discover_Operation();				// Switch to discover frequency

	iziplus_module_extra = 0;
	if((iziplus_discover_option == IZIPLUS_OPTION_CLEAN))
	{
		iziplus_module_amount = 0;
		memset(iziplus_modules, 0, sizeof(iziplus_modules));		// Clear all vars
	}
	else if(iziplus_discover_option == IZIPLUS_OPTION_ADD || iziplus_discover_option == IZIPLUS_OPTION_SWITCH || iziplus_discover_option == IZIPLUS_OPTION_REPLACE)
	{
		memset(iziplus_modules, 0, sizeof(iziplus_modules));		// Clear all vars
		IziPlus_ModuleLoad();										// Load content from EEPROM
	}

	if(++iziplus_discover_session == 0)			// session 0 may not be used
		iziplus_discover_session = 1;
	iziplus_discover_newcount = 0;
	
	IziPlus_ReportLinkState(LINK_STATE_DISCOVER, iziplus_module_amount);
	uint16_t iziplus_module_amount_start = iziplus_module_amount;
	
	for(int d = 0; d < IZIPLUS_DISCOVER_ATTEMPTS; d++)
	{
		uint16_t nw_length = iziplus_networkframe_discover(iziplus_nwdata, iziplus_discover_session);
		iziplus_discover_phase = 1;
		iziplus_dataframe_sendspecial(0x00000000, IZIPLUS_DEVTYPE_BROADCAST, iziplus_nwdata, nw_length);

		vTaskDelay(500);
		IZI_TRACE_INFO("Discovered[%d]: %d modules\r\n", d, iziplus_module_amount);

		iziplus_discover_phase = 2;
		for(int i = 0; i < iziplus_module_amount; i++)
		{
			if(iziplus_modules[i].var.flags & FLAG_ASSIGN_INCOMPLETE)
			{
				uint8_t idx = i;
				bool is_new_module = i >= iziplus_module_amount_start;
				IZI_TRACE_INFO("Assign[%d]: new:%d (%d) repl_idx: %d\r\n", i, is_new_module, iziplus_modules[i].helper.discover_new, iziplus_offline_idx);
				if(iziplus_discover_option == IZIPLUS_OPTION_REPLACE && iziplus_modules[i].helper.discover_new > 0 && iziplus_offline_idx >= 0 && iziplus_offline_idx < iziplus_module_amount)
				{
					if(iziplus_modules[i].base.device_type == iziplus_modules[iziplus_offline_idx].base.device_type)
					{
						iziplus_modules[iziplus_offline_idx].base.device_id = iziplus_modules[i].base.device_id;
						is_new_module = false;			// Force update
						iziplus_module_amount--;		// Assume only one module is added (rest is ignored on discover receive).
						idx = iziplus_offline_idx;
						replace_ok = true;
						IZI_TRACE_INFO("Assign[%d]: replace ok (%d, %d)\r\n", i, idx, iziplus_modules[idx].base.config_amount);
					}
					else
					{
						 IZI_TRACE_INFO("Assign[%d]: replace fail\r\n", i);
						 iziplus_module_amount--;		// If the type was wrong, just remove it
						 continue;
					}
				}
				
				for(int r = 0; r < 3; r++)
				{
					if(!IziPlus_AssignNetwork(idx, is_new_module))					// Assign to this network and assign a short ID
					{
						vTaskDelay(100);											// If it fails wait some time and try again.
					}
					else
					{
						iziplus_modules[i].var.flags &= ~FLAG_ASSIGN_INCOMPLETE;	// Assigned OK			
						IziPlus_ClearIndexes(i);
						break;
					}

				}
				// Todo: what if assign fails?
			}
		}
	}

	sprintf(text, "Discovered %d modules (new: %d)", iziplus_module_amount, iziplus_module_amount - iziplus_module_amount_start);
	LOGWRITE_INFO(ERRCODE_IZI_DISCOVER_READY, text, log_src_task_postpone);

	if(iziplus_module_extra > 0)
	{
		sprintf(text, "Too many modules discovered (%d)", iziplus_module_amount + iziplus_module_extra);
		LOGWRITE_ERROR(ERRCODE_IZI_MODULE_MAX, text, log_src_task_postpone);
	}

	for(uint8_t i = 0; i < iziplus_module_amount; i++)
	{
		IziPlus_ReportConfigFlag(&iziplus_modules[i]);
		IziPlus_ReportMonitorFlag(&iziplus_modules[i]);	// At least report state

		// Write to EEPROM
		Eeprom_Write(EEPROM_MODULES + (i * IZI_MODULE_STORE_SIZE), (uint8_t *)&iziplus_modules[i], IZI_MODULE_STORE_SIZE);
	}
	appconfig_t *cfgram = AppConfig_Get();
	cfgram->app_modules = iziplus_module_amount;		// Set new amount
	AppConfig_Set();

	IziPlus_LightDataCreate(true);						// Must be done after AppConfig_Set

	for(int i = 0; i < iziplus_module_amount; i++)
	{
		uint16_t nw_length = iziplus_networkframe_operationmode(iziplus_nwdata, IZIPLUS_OPERATIONMODE_NORMAL, false);
		iziplus_data_request(&iziplus_modules[i], iziplus_nwdata, nw_length);			// Switch to normal frequency, force per module with retries
	}
	vTaskDelay(100);

	IziPlus_Powerup();					// Goto own normal frequency
	
	iziplus_lightdata_tokenoverrule = 0;
	if(iziplus_discover_scan)
	{
		memset(iziplus_scan_result, 0, sizeof(iziplus_scan_result));
		if(iziplus_module_amount > 0 && iziplus_module_amount <= IZI_MAX_MODULES)
		{
			iziplus_lightdata_tokenoverrule = 1;
			iziplus_scan_token = 0;
			iziplus_scan_total = 0;
			iziplus_scan_cnt = 0;
			iziplus_scan_attempts = iziplus_module_amount > 10 ? 20 : 40;
		}
	}
	
	if(iziplus_discover_option == IZIPLUS_OPTION_REPLACE && !replace_ok)
		res = false;
		
	return res;
}

bool IziPlus_Acks()
{
	if(iziplus_contacttrigger_acks_count > 0)
	{
		uint32_t device_id = 0;
		uint16_t device_type = 0;
		bool multi_module = false, multi_group = false;
		for(int c = 0; c < iziplus_contacttrigger_acks_count; c++)
		{
			for(int16_t i = 0; i < iziplus_module_amount; i++)
			{
				if(iziplus_contacttrigger_acks[c].short_id != iziplus_module_sort[i]->short_id)
					continue;
					
				if(device_id > 0)
					multi_module = true;
				if(device_type > 0 && device_type != iziplus_module_sort[i]->device_type)
					multi_group = true;
				device_id = iziplus_module_sort[i]->device_id;
				device_type = iziplus_module_sort[i]->device_type;
				
				break;
			}
		}
		if(multi_module)
			device_id = 0;
		
		uint16_t nw_length = iziplus_networkframe_contacttrigger_ack(iziplus_nwdata_notification, (uint8_t *)&iziplus_contacttrigger_acks[0], iziplus_contacttrigger_acks_count * sizeof(contacttriggerack_t));
		iziplus_data_notification(device_id, multi_module ? (multi_group ? IZIPLUS_DEVTYPE_BROADCAST : device_type | IZIPLUS_DEVTYPE_GROUPCAST) : device_type, iziplus_nwdata_notification, nw_length);			// Do not respond any more (only possible to use notification from here)
		IZIPLUS_TRACE_INFO("Send Contact trigger Ack: %d\r\n", iziplus_contacttrigger_acks_count);
		iziplus_contacttrigger_acks_count = 0;
		return true;
	}
	return false;
}

/*
 * Handle pending actions
 */
bool IziPlus_Actions()
{
	bool action_exe = false;
	iziplus_fifo_config_t iziplus_fifo_address_item;
	iziplus_fifo_identify_t iziplus_fifo_identify_item;
	iziplus_fifo_join_t iziplus_fifo_join_item;
	
	if(fifo_get(iziplus_fifo_config, &iziplus_fifo_address_item) && iziplus_fifo_address_item.index >= 0 && iziplus_fifo_address_item.index < iziplus_module_amount)
	{
		uint16_t idx = iziplus_fifo_address_item.index;
		izi_module_t *izi_module = &iziplus_modules[idx];

		// Write config (if any)
		bool config_write_attempt = true;
		bool retry = false;
		if(iziplus_fifo_address_item.config_change)
		{
			config_write_attempt = IziPlus_Request_WriteConfig(izi_module, idx);
			if(config_write_attempt)
				iziplus_fifo_address_item.config_change = 0;
			else if(iziplus_fifo_address_item.config_change > 0)
			{
				iziplus_fifo_address_item.config_change--;
				retry = true;
			}
		}
		if(iziplus_fifo_address_item.text_change && IziPlus_Request_WriteText(izi_module, idx))
		{
			if(config_write_attempt)
			{
				izi_module->var.flags &= ~(FLAG_CONFIG_ERROR);			// If set OK remove flag
				iziplus_fifo_address_item.text_change = 0;
			}
			else if(iziplus_fifo_address_item.text_change > 0)
			{
				iziplus_fifo_address_item.text_change--;
				retry = true;
			}				
			IziPlus_ReportConfigFlag(izi_module);
			izican_slave_notifymodule(iziplus_fifo_address_item.index, iziplus_module_amount, &izi_module->base);				// Send notify of change
		}
		if(retry && izi_module->var.flags & FLAG_ONLINE)					// Retry needed and module still online?
		{
			fifo_add(iziplus_fifo_config, &iziplus_fifo_address_item);		// Put same item with less retries back
		}
		action_exe = true;
	}
	else if(fifo_get(iziplus_fifo_identify, &iziplus_fifo_identify_item) && iziplus_fifo_identify_item.index >= 0 && iziplus_fifo_identify_item.index < iziplus_module_amount)
	{
		uint16_t idx = iziplus_fifo_identify_item.index;

		uint16_t nw_length = iziplus_networkframe_identify(iziplus_nwdata, iziplus_fifo_identify_item.time, (uint8_t)iziplus_fifo_identify_item.mode, false);
		if(iziplus_data_request(&iziplus_modules[idx], iziplus_nwdata, nw_length) >=
				(int16_t)(sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_identify_rsp_t)))
		{
			IZI_TRACE_INFO("Identify requested OK for m[%d] for %d min (mode: %d)\r\n", idx, iziplus_fifo_identify_item.time, iziplus_fifo_identify_item.mode);
			if(iziplus_fifo_identify_item.time == 0)
				iziplus_modules[idx].var.flags &= ~FLAG_IDENTIFY_BUTTON;			// Clear it directly if set off
		}
		else
		{
			IZI_TRACE_INFO("Identify fail for m[%d]\r\n", idx);
		}
		action_exe = true;
	}
	else if(fifo_get(iziplus_fifo_join_items, &iziplus_fifo_join_item))
	{
		uint8_t searchModule = iziplus_module_amount;
		for(uint16_t i = 0; i < iziplus_module_amount; i++)
		{
			if(iziplus_modules[i].base.device_id == iziplus_fifo_join_item.device_id)
			{
				searchModule = i;				// Check if already in list
				break;
			}
		}
		
		uint8_t iziplus_module_amount_start = iziplus_module_amount;
		if(searchModule >= iziplus_module_amount)
		{
			if(iziplus_module_amount >= IZI_MAX_MODULES)
			{
				State_SetError(STATE_ERROR_MODULE_MAX);
				return false;
			}
			iziplus_module_amount++;
		}
		
		iziplus_modules[iziplus_module_amount_start].base.prot_version = iziplus_fifo_join_item.prot_version;
		iziplus_modules[iziplus_module_amount_start].base.device_type = iziplus_fifo_join_item.device_type;
		iziplus_modules[iziplus_module_amount_start].base.device_id = iziplus_fifo_join_item.device_id;
		
		action_exe = true;
		if(!IziPlus_AssignNetwork(searchModule, iziplus_module_amount_start < iziplus_module_amount))
		{
			IZIPLUS_TRACE_INFO("Assign network fail: %d %d\r\n", iziplus_module_amount_start, iziplus_module_amount);
			if(iziplus_module_amount_start != iziplus_module_amount)
			{
				iziplus_module_amount = iziplus_module_amount_start;
			}
			return true;
		}
		IZIPLUS_TRACE_INFO("Assign network join: %d %d\r\n", iziplus_module_amount_start, iziplus_module_amount);
		
		for(uint8_t i = iziplus_module_amount_start; i < iziplus_module_amount; i++)
		{
			IziPlus_ReportConfigFlag(&iziplus_modules[i]);
			IziPlus_ReportMonitorFlag(&iziplus_modules[i]);	// At least report state

			// Write to EEPROM
			Eeprom_Write(EEPROM_MODULES + (i * IZI_MODULE_STORE_SIZE), (uint8_t *)&iziplus_modules[i], IZI_MODULE_STORE_SIZE);
		}
		appconfig_t *cfgram = AppConfig_Get();
		if(cfgram->app_modules != iziplus_module_amount)
		{
			cfgram->app_modules = iziplus_module_amount;		// Set new amount
			AppConfig_Set();
			iziplus_addressmode_set_delay = ADDRESS_MODE_SET_DELAY;
		}
	}
	
	if(iziplus_addressmode_set)
	{
		bool reprogramming_active = false;
		for(uint16_t i = 0; i < iziplus_module_amount; i++)
		{
			if(iziplus_modules[i].var.flags & FLAG_REPROGRAMMING)			// Check if reprogramming is active, if so wait until ready
			{
				reprogramming_active = true;
				break;
			}
		}
		if(!reprogramming_active)
			IziPlus_LightDataCreate(true);
	}

	return action_exe;
}

void IziPlus_LightDataCreate(bool assign)
{
	IziPlus_ModuleSort();
	iziplus_module_lightdata_amount = 0;
	memset(iziplus_module_lightdata, 0, sizeof(iziplus_module_lightdata));
	bool written = false;
	uint16_t offset = 0, offset_next = 0;
	izi_module_base_t *changedModule;

	iziplus_state_t iziplus_state_prev = iziplus_state;
	iziplus_state = IZIPLUS_STATE_ASSIGN_CHAN;

	for(int16_t i = 0; i < iziplus_module_amount; i++)
	{
		changedModule = iziplus_module_sort[i];

		if(iziplus_module_lightdata[iziplus_module_lightdata_amount].amount == 0)	// Still empty?
		{
			offset = offset_next;

			iziplus_module_lightdata[iziplus_module_lightdata_amount].channel = iziplus_module_sort[i]->address;
			iziplus_module_lightdata[iziplus_module_lightdata_amount].amount = iziplus_module_sort[i]->channels;

			changedModule->offset = offset;
			offset_next += iziplus_module_sort[i]->channels;
			if(Eeprom_Write(EEPROM_MODULES + ((changedModule->short_id - 1) * IZI_MODULE_STORE_SIZE), (uint8_t *)changedModule, IZI_MODULE_STORE_SIZE))
				written = true;

			IZI_TRACE_INFO("Module[%x] offset: %d\r\n", changedModule->device_id, changedModule->offset);
		}
		else if(iziplus_module_sort[i]->address >= iziplus_module_lightdata[iziplus_module_lightdata_amount].channel &&
				iziplus_module_sort[i]->address < (iziplus_module_lightdata[iziplus_module_lightdata_amount].channel + iziplus_module_lightdata[iziplus_module_lightdata_amount].amount))
		{
			// Should amount be extended?
			if((iziplus_module_sort[i]->address + iziplus_module_sort[i]->channels) >
				(iziplus_module_lightdata[iziplus_module_lightdata_amount].channel + iziplus_module_lightdata[iziplus_module_lightdata_amount].amount))
			{
				uint16_t amount_old = iziplus_module_lightdata[iziplus_module_lightdata_amount].amount;
				iziplus_module_lightdata[iziplus_module_lightdata_amount].amount =
						(iziplus_module_sort[i]->address + iziplus_module_sort[i]->channels) - iziplus_module_lightdata[iziplus_module_lightdata_amount].channel;

				offset_next += (iziplus_module_lightdata[iziplus_module_lightdata_amount].amount - amount_old);

				changedModule->offset = offset + (iziplus_module_sort[i]->address - iziplus_module_lightdata[iziplus_module_lightdata_amount].channel);

				if(Eeprom_Write(EEPROM_MODULES + ((changedModule->short_id - 1) * IZI_MODULE_STORE_SIZE), (uint8_t *)changedModule, IZI_MODULE_STORE_SIZE))
					written = true;

				IZI_TRACE_INFO("Module[%x] offset: %d\r\n", changedModule->device_id, changedModule->offset);
			}
			else		// It fits in an existing part
			{
				changedModule->offset = offset + (iziplus_module_sort[i]->address - iziplus_module_lightdata[iziplus_module_lightdata_amount].channel);

				if(Eeprom_Write(EEPROM_MODULES + ((changedModule->short_id - 1) * IZI_MODULE_STORE_SIZE), (uint8_t *)changedModule, IZI_MODULE_STORE_SIZE))
					written = true;

				IZI_TRACE_INFO("Module[%x] offset: %d\r\n", changedModule->device_id, changedModule->offset);
			}
		}
		else if(i > 0)
		{
			i--;
			iziplus_module_lightdata_amount++;		// Do it again for this index, adding a new entry in iziplus_module_lightdata
		}
	}
	if(iziplus_module_amount > 0)
		iziplus_module_lightdata_amount++;			// First is was used as index, now it is used as amount

	uint16_t size = 0;
	for(uint16_t i = 0; i <	iziplus_module_lightdata_amount; i++)
	{
		IZI_TRACE_INFO("Light data part[%d] => channel: %d, amount: %d\r\n", i, iziplus_module_lightdata[i].channel, iziplus_module_lightdata[i].amount);
		size += iziplus_module_lightdata[i].amount;
	}

	iziplus_addressmode_set = false;			// Could be, IziPlus_Request_WriteChannelMode sets it to true again, because amount of channels so not match

	IZI_TRACE_INFO("Light data create with %d parts, total of %d (%d) channels\r\n", iziplus_module_lightdata_amount, size, offset_next);
	if(assign)
	{
		for(int16_t i = 0; i < iziplus_module_amount; i++)
		{
			IziPlus_Request_WriteChannelMode(&iziplus_modules[i], i);
			IziPlus_ReportConfigFlag(&iziplus_modules[i]);
		}
		if(iziplus_addressmode_set)		// Shall only be set again if channel amount differs reorted by module compared to IZI-Access info
		{
			sprintf(text, "Channel mode difference error");
			LOGWRITE_WARNING(ERRCODE_IZI_SET_MODECHANNELS_ERR, text, log_src_task_postpone);
		}
	}
	iziplus_state = iziplus_state_prev;
}

/************************************************************************/
/* Create hash module table sorted on address					        */
/************************************************************************/
void IziPlus_ModuleSort()
{
	int i, j;

	for (i = 0; i < iziplus_module_amount; ++i)
		iziplus_module_sort[i] = &iziplus_modules[i].base;			// Sort by EEPROM (contains the values that has just been set or what it should get)

	for (i = 0; i < iziplus_module_amount; ++i)
	{
		for (j = i + 1; j < iziplus_module_amount; ++j)
		{
			if (iziplus_module_sort[i]->address > iziplus_module_sort[j]->address)		// Last 2 lines only for order in displaying
			{
				izi_module_base_t* m = iziplus_module_sort[i];
				iziplus_module_sort[i] = iziplus_module_sort[j];
				iziplus_module_sort[j] = m;
			}
		}
	}
}

/*
 * Handle pending update
 */
bool IziPlus_Updates()
{
	if((iziplus_substate == IZIPLUS_SUBSTATE_UPDATE) && (iziplus_update_module != NULL) && (iziplus_update_cnt > 0))
	{
		if(iziplus_update_allow_start)											// Must modules set allow timer for update via groupcast?
		{
			IZI_TRACE_INFO("Firmware Allow State: %d %d\r\n", iziplus_update_allow, iziplus_update_cnt);
			if(iziplus_update_allow < iziplus_update_cnt)
			{
				int match = 0;
				for(int i = 0; i < iziplus_module_amount; i++)
				{
					if(iziplus_update_flags & (1 << i))
					{
						if(match == iziplus_update_allow)						// Check if already handled
						{
							if(!IziPLus_FirmwareAllow(&iziplus_modules[i]))		// If version equal, do nothing (also if not responding)
							{
								iziplus_update_flags &= ~(1 << i);
								iziplus_update_cnt--;
								if(&iziplus_modules[i] == iziplus_update_module)		// Removed module is module chosen for base update
									iziplus_update_module_removed = true;				// Mark for replace
								break;
							}
							else
							{
								iziplus_update_allow++;
								iziplus_update_module_backup = &iziplus_modules[i];
								iziplus_modules[i].var.flags &= ~FLAG_UPDATE_FAIL;				// Clear for new attempt (in case it is a retry)
								iziplus_modules[i].helper.flag_clear_req &= ~FLAG_UPDATE_FAIL;
							}
							break;
						}
						match++;
					}
				}
				if(iziplus_update_allow >= iziplus_update_cnt)					// All modules allowed?
				{
					iziplus_update_allow_start = false;
					if(iziplus_update_flags == 0)								// Anything to update?
					{
						iziplus_substate = IZIPLUS_SUBSTATE_IDLE;
						sprintf(text, "Firmware update not needed");
						LOGWRITE_INFO_S(ERRCODE_UPDATE_IZI, text, log_src_task_postpone, iziplus_update_module->base.device_id);
						iziplus_update_module = NULL;
						iziplus_update_cnt = 0;
						IziPlus_ReportLinkState(LINK_STATE_IDLE, iziplus_module_amount);
						return false;
					}
					else if(iziplus_update_module_removed && iziplus_update_module_backup != NULL)
					{
						iziplus_update_module = iziplus_update_module_backup;	// Take other module that must be updated
					}
					IZI_TRACE_INFO("Firmware Write State: %d %d\r\n", iziplus_update_apply, iziplus_update_cnt);
				}
			}
		}
		else if(!iziplus_update_reboot)
		{
#if IZI_TIMING > 0
			TimingStart("Fw1", 0);
			TimingStart("Fw2", 1);
			TimingStart("Fw3", 2);
			TimingStart("Fw4", 3);
			TimingStart("Fw5", 4);
#endif
			uint32_t flash_address = (uint32_t)(FLASH_APP_MIRROR_BASE + iziplus_update_address);		//FLASH_APP_MIRROR_SHIFT
			uint16_t nw_length = iziplus_networkframe_fw_write(iziplus_nwdata, iziplus_update_address, flash_address, iziplus_update_size, (iziplus_update_cnt > 1));
			if(iziplus_update_cnt == 1)
			{
				if(iziplus_data_request(iziplus_update_module, iziplus_nwdata, nw_length) >=
						(int16_t)(sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_fw_write_wrsp_t)))
				{
					if(!(iziplus_update_module->var.flags & FLAG_UPDATING))
					{
						iziplus_update_module->var.flags |= FLAG_UPDATING;							// Report on first data send
						IziPlus_ReportMonitorFlag(iziplus_update_module);
					}
					iziplus_update_module->helper.xtra_retry = FIRMWARE_XTRA_RETRY;					// Give extra retries when responded ok
				}
				else
				{
					if(iziplus_update_module->helper.xtra_retry > 0)
					{
						IZI_TRACE_INFO("Xtra retry used\r\n");
						iziplus_update_module->helper.xtra_retry--;
						return true;					// Same address again
					}				
					iziplus_update_module->var.flags &= ~FLAG_UPDATING;
					iziplus_update_module->var.flags |= FLAG_UPDATE_FAIL;
					iziplus_update_module->helper.flag_clear_req |= FLAG_UPDATE_FAIL;
					iziplus_update_module->helper.flag_clear_timer = UPDATE_FAIL_TIMEOUT;
					IziPlus_ReportMonitorFlag(iziplus_update_module);
					iziplus_substate = IZIPLUS_SUBSTATE_IDLE;
					sprintf(text, "Firmware update failed (address: %d)", iziplus_update_address);
					LOGWRITE_INFO_S(ERRCODE_IZI_UPDATE_FAIL, text, log_src_task_postpone, iziplus_update_module->base.device_id);
					iziplus_update_module = NULL;
					iziplus_update_cnt = 0;
					IziPlus_ReportLinkState(LINK_STATE_IDLE, iziplus_module_amount);
					return false;
				}
			}
			else
			{
				//IZI_TRACE_ERROR("BC start: %d\r\n", iziplus_update_type);
				if(iziplus_data_request_multi(iziplus_update_module, iziplus_nwdata, nw_length, true) >=
					(int16_t)(sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_fw_write_wrsp_t)))
				{
					for(int i = 0; i < iziplus_module_amount; i++)
					{
						if((iziplus_update_flags & (1 << i)) && (!(iziplus_modules[i].var.flags & FLAG_UPDATING)))
						{
							iziplus_modules[i].var.flags |= FLAG_UPDATING;				// Report on first data send
							IziPlus_ReportMonitorFlag(&iziplus_modules[i]);
						}
					}
					iziplus_update_module->helper.xtra_retry = FIRMWARE_XTRA_RETRY;					// Give extra retries when responded ok
				}
				else
				{
					if(iziplus_update_module->helper.xtra_retry > 0)
					{
						IZI_TRACE_INFO("Xtra retry used\r\n");
						iziplus_update_module->helper.xtra_retry--;
						return true;					// Same address again
					}
					for(int i = 0; i < iziplus_module_amount; i++)
					{
						iziplus_modules[i].var.flags &= ~FLAG_UPDATING;
						iziplus_modules[i].var.flags |= FLAG_UPDATE_FAIL;
						iziplus_modules[i].helper.flag_clear_req |= FLAG_UPDATE_FAIL;
						iziplus_modules[i].helper.flag_clear_timer = UPDATE_FAIL_TIMEOUT;
						IziPlus_ReportMonitorFlag(&iziplus_modules[i]);
					}
					iziplus_substate = IZIPLUS_SUBSTATE_IDLE;
					iziplus_update_cnt = 0;
					iziplus_update_module = NULL;
					sprintf(text, "Firmware bc update fail (addr: %d)", iziplus_update_address);
					LOGWRITE_INFO(ERRCODE_IZI_UPDATE_FAIL, text, log_src_task_postpone);
					IziPlus_ReportLinkState(LINK_STATE_IDLE, iziplus_module_amount);
				}
			}
			iziplus_update_address += iziplus_update_size;
			if(iziplus_update_address >= iziplus_update_length)
			{
				if(iziplus_update_address == iziplus_update_image_size)
				{
					iziplus_update_reboot = true;
					IziPlus_ReportLinkState(LINK_STATE_UPDATEREBOOT, iziplus_module_amount);
				}
				else if(iziplus_update_address < (iziplus_update_image_size - sizeof(firmware_t)))
					iziplus_update_address = iziplus_update_image_size - sizeof(firmware_t);
			}
		}
		else
		{
			if(iziplus_update_apply < iziplus_update_cnt && iziplus_update_allow > 1)
			{
				int match = 0;
				for(int i = 0; i < iziplus_module_amount; i++)
				{
					if(iziplus_update_flags & (1 << i))
					{
						if(match == iziplus_update_apply)				// Check if already handled
						{
							//IZI_TRACE_INFO("Fw apply: %d 0x%x\r\n", i, iziplus_update_flags);
							if(IziPLus_FirmwareApply(&iziplus_modules[i]))
							{
								iziplus_update_flags &= ~(1 << i);
								iziplus_update_cnt--;
							}
							else
								iziplus_update_apply++;
							IziPlus_ReportMonitorFlag(&iziplus_modules[i]);
							break;
						}
						match++;
					}
				}
				if(iziplus_update_apply >= iziplus_update_cnt)
				{
					if(iziplus_update_flags > 0)						// Not all succeeded?
					{
						if(!(iziplus_update_module != NULL && iziplus_update_module->var.flags & FLAG_UPDATE_FAIL))		// If the addressed module failed. Stop
						{
							iziplus_update_apply = 0;
							iziplus_update_allow = 0;
							iziplus_update_address = 0;
							iziplus_update_reboot = false;
							iziplus_update_module = NULL;
							iziplus_update_cnt = 0;
							for(int i = 0; i < iziplus_module_amount; i++)
							{
								if(iziplus_update_flags & (1 << i))
								{
									if(iziplus_update_module == NULL)
										iziplus_update_module = &iziplus_modules[i];
									iziplus_update_cnt++;
								}
							}
							iziplus_update_allow_start = iziplus_update_cnt > 1;
							return true;
						}
					}
					
					iziplus_substate = IZIPLUS_SUBSTATE_IDLE;
					iziplus_update_module = NULL;
					iziplus_update_cnt = 0;
					IziPlus_ReportLinkState(LINK_STATE_IDLE, iziplus_module_amount);
				}
			}
			else
			{
				IziPLus_FirmwareApply(iziplus_update_module);
				IziPlus_ReportMonitorFlag(iziplus_update_module);
				iziplus_update_module = NULL;
				iziplus_substate = IZIPLUS_SUBSTATE_IDLE;
				iziplus_update_cnt = 0;
				IziPlus_ReportLinkState(LINK_STATE_IDLE, iziplus_module_amount);
			}
		}
		return true;
	}
	return false;
}

bool IziPLus_FirmwareAllow(izi_module_t *module)
{
	uint16_t nw_length = iziplus_networkframe_fw_allow(iziplus_nwdata, &iziplus_image_version, 120);		// Allow 120 sec firmware update
	int16_t res = iziplus_data_request(module, iziplus_nwdata, nw_length);
	bool update_needed = (((int8_t)((iziplus_network_data_t *)iziplus_nwdata_rx)->tokenres) == IZIPLUS_TOKERES_OK);
	if(res >= 4 && update_needed)						// Module reported OK (so versions differs)
		module->var.flags |= FLAG_UPDATING;				// Mark firmware update is started
	else
		module->var.flags &= ~FLAG_UPDATING;
		
	IziPlus_ReportMonitorFlag(module);
	
	IZI_TRACE_INFO("Firmware Allow: %d %d\r\n", res, ((int8_t)((iziplus_network_data_t *)iziplus_nwdata_rx)->tokenres));
	
	return module->var.flags & FLAG_UPDATING;
}

bool IziPLus_FirmwareApply(izi_module_t *module)
{
	bool result = true;
	
	module->var.flags &= ~FLAG_UPDATING;
	uint16_t nw_length = iziplus_networkframe_fw_apply(iziplus_nwdata);
	int16_t res = iziplus_data_request(module, iziplus_nwdata, nw_length);
	if(res >= (int16_t)0 || res <= (int16_t)-6)						// Delayed response OK or not received (if delay was reported but real response was not received, it could be lost but reprogramming is still started)
	{
		module->var.flags |= FLAG_REPROGRAMMING;		// Mark reprogramming (request config/version/text after reboot and report log)
	}
	else
	{
		module->var.flags |= FLAG_UPDATE_FAIL;
		module->helper.flag_clear_req |= FLAG_UPDATE_FAIL;
		module->helper.flag_clear_timer = UPDATE_FAIL_TIMEOUT;
		LOGWRITE_INFO_S(ERRCODE_IZI_UPDATE_FAIL, "Firmware apply fail", log_src_task_postpone, module->base.device_id);
		result = false;
	}

	IziPlus_ReportMonitorFlag(module);
	
	IZI_TRACE_INFO("Firmware Apply: %d %d\r\n", res, ((int8_t)((iziplus_network_data_t *)iziplus_nwdata_rx)->tokenres));
	
	return result;
}

/*
 * Handle request of versions
 */
bool IziPlus_Request_Version(izi_module_t *module, bool add_retries)
{
	uint16_t nw_length = iziplus_networkframe_versions(iziplus_nwdata);
	if(!add_retries)
		iziplus_data_no_retry();				// No retries
	if(!(iziplus_data_request(module, iziplus_nwdata, nw_length) >=
		(int16_t)((sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_versions_rrsp_t)))))
		return false;
	return true;
}

/*
 * Handle response on version command
 */
bool IziPlus_Response_Version(izi_module_t *module, uint8_t *payload)
{
	bool any_change = false;

	iziplus_cmd_versions_rrsp_t *versions_rsp = (iziplus_cmd_versions_rrsp_t *)payload;
	if(module->base.app_version.d != versions_rsp->app_version.d)		
	{
		module->base.app_version.d = versions_rsp->app_version.d;
		any_change = true;
	}
	if(module->base.boot_version.w != versions_rsp->boot_version.w[1])		// Only check major minor for now
	{
		module->base.boot_version.w = versions_rsp->boot_version.w[1];
		any_change = true;
	}
	if(module->base.prot_version.w != versions_rsp->protocol_version.w)
	{
		module->base.prot_version.w = versions_rsp->protocol_version.w;
		any_change = true;
	}
	if(module->base.ledtable_version.w != versions_rsp->ledtable_version.w)
	{
		module->base.ledtable_version.w = versions_rsp->ledtable_version.w;
		any_change = true;
	}
	if(module->base.typedef_version.w != versions_rsp->typedef_version.w)
	{
		module->base.typedef_version.w = versions_rsp->typedef_version.w;
		any_change = true;
	}
	if(module->base.mem_version != versions_rsp->mem_version)
	{
		module->base.mem_version = versions_rsp->mem_version;
		any_change = true;
	}
	if(module->base.hw_ref != versions_rsp->hw_ref)
	{
		module->base.hw_ref = versions_rsp->hw_ref;
		any_change = true;
	}
	module->base.variant = versions_rsp->variant;
	module->helper.requests &= ~(1 << IZIPLUS_REQ_VERSION);
	module->helper.requests_init &= ~(1 << IZIPLUS_REQ_VERSION);

	if(module->var.flags & FLAG_UPDATE_VERSION)				// Log new version
	{
		module->var.flags &= ~FLAG_UPDATE_VERSION;
		sprintf(text, "Firmware update to: %d.%d.%d", module->base.app_version.v.major, module->base.app_version.v.minor, module->base.app_version.v.build);
		LOGWRITE_INFO_S(ERRCODE_IZI_UPDATED, text, log_src_task_postpone, module->base.device_id);
	}
	return any_change;
}

/*
 * Handle request of channel mode
 */
bool IziPlus_Request_ChannelMode(izi_module_t *module, bool add_retries)
{
	uint16_t nw_length = iziplus_networkframe_assign_channelmoderead(iziplus_nwdata);
	if(!add_retries)
		iziplus_data_no_retry();				// No retries
	if(!(iziplus_data_request(module, iziplus_nwdata, nw_length) >=
		(int16_t)((sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_assign_chanmode_rrsp_t)))))
		return false;
	return true;
}

/*
 * Handle response on channel mode command
 */
bool IziPlus_Response_ChannelMode(izi_module_t *module, uint8_t *payload)
{
	bool any_change = false;

	iziplus_cmd_assign_chanmode_rrsp_t *chanmode_rsp = (iziplus_cmd_assign_chanmode_rrsp_t *)payload;
	if(module->base.address != chanmode_rsp->channel)
	{
		module->base.address = chanmode_rsp->channel;
		any_change = true;
	}
	if(module->base.mode != chanmode_rsp->mode)
	{
		module->base.mode = chanmode_rsp->mode;
		any_change = true;
	}
	if(module->base.dmxfail != chanmode_rsp->dmxfail)
	{
		module->base.dmxfail = chanmode_rsp->dmxfail;
		any_change = true;
	}
	if(module->base.channels != chanmode_rsp->amount)
	{
		module->base.channels = chanmode_rsp->amount;
		any_change = true;
	}
	if(module->base.offset != chanmode_rsp->offset)
	{
		module->base.offset = chanmode_rsp->offset;
		any_change = true;
	}
	if(module->base.channels != chanmode_rsp->amount)
	{
		module->base.channels = chanmode_rsp->amount;
		//any_change = true;
		// Todo: Take action?
	}

	module->helper.requests &= ~(1 << IZIPLUS_REQ_CHANNELMODE);
	module->helper.requests_init &= ~(1 << IZIPLUS_REQ_CHANNELMODE);

	return any_change;
}

bool IziPlus_Request_WriteChannelMode(izi_module_t *module, uint16_t idx)
{
	izi_module_base_t ee_module;
	Eeprom_Read(EEPROM_MODULES + (idx * IZI_MODULE_STORE_SIZE), &ee_module, IZI_MODULE_STORE_SIZE);
	
	// Copy new values from EEPROM
	module->base.address = ee_module.address;
	module->base.mode = ee_module.mode;
	module->base.dmxfail = ee_module.dmxfail;
	module->base.offset = ee_module.offset;

	uint16_t nw_length = iziplus_networkframe_assign_channelmodewrite(iziplus_nwdata, module->base.address, module->base.mode, module->base.dmxfail, module->base.offset);
	if(iziplus_data_request(module, iziplus_nwdata, nw_length) >=
			(int16_t)(sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_assign_chanmode_wrsp_t)))
	{
		iziplus_cmd_assign_chanmode_wrsp_t *chanmode_rsp = (iziplus_cmd_assign_chanmode_wrsp_t *)&iziplus_nwdata_rx[sizeof(iziplus_network_data_t)];

		module->var.flags &= ~(FLAG_ADDRESS_ERROR);			// If set OK remove flag
		IZI_TRACE_INFO("Set address requested for %x -> a: %d, m: %d, c: %d o: %d\r\n", module->base.device_id, module->base.address, module->base.mode, chanmode_rsp->amount, module->base.offset);

		sprintf(text, "Write OK address: %c.%d, mode: %d", module->base.address / 512 == 0 ? 'A' : 'B', (module->base.address & 0x1FF) + 1, module->base.mode);
		LOGWRITE_INFO_S(ERRCODE_IZI_SET_ADDRESSMODE, text, log_src_task_postpone, module->base.device_id);

		module->base.channels = chanmode_rsp->amount;
		if(chanmode_rsp->amount != ee_module.channels)
		{
			IZI_TRACE_INFO("Set address amount differs: %d != %d\r\n", chanmode_rsp->amount, ee_module.channels);
			Eeprom_Write(EEPROM_MODULES + (idx * IZI_MODULE_STORE_SIZE), (uint8_t *)&module->base, IZI_MODULE_STORE_SIZE);
			iziplus_addressmode_set = true;			// Recalculate light data
		}

		return true;
	}
	else
	{
		module->var.flags |= FLAG_ADDRESS_ERROR;
		IZIPLUS_TRACE_INFO("Write address fail for %x\r\n", module->base.device_id);

		sprintf(text, "Write address/mode failed");
		LOGWRITE_ERROR_S(ERRCODE_IZI_SET_ADDRESSMODE_ERR, text, log_src_task_postpone, module->base.device_id);
	}

	return false;
}

/*
 * Handle request of config
 */
bool IziPlus_Request_Config(izi_module_t *module, bool add_retries, uint16_t *length)
{
	uint16_t nw_length = iziplus_networkframe_configread(iziplus_nwdata);
	if(!add_retries)
		iziplus_data_no_retry();				// No retries

	int16_t rsp_len = iziplus_data_request(module, iziplus_nwdata, nw_length);
	if(!(rsp_len >= (int16_t)(sizeof(iziplus_network_data_t))))			// Response OK?
		return false;

	*length = rsp_len - sizeof(iziplus_network_data_t);
	return true;
}

/*
 * Handle response on config command
 */
bool IziPlus_Response_Config(izi_module_t *module, uint8_t *payload, uint16_t length)
{
	bool any_change = false;

	if(length > 0)		// Config parameters received?
	{
		iziplus_cmd_config_rrsp_t *config_rsp = (iziplus_cmd_config_rrsp_t *)payload;
		module->base.config_rec_amount = length;
		uint16_t cfg_len = module->base.config_rec_amount > IZI_MAX_CONFIG ? IZI_MAX_CONFIG : module->base.config_rec_amount;
		if(memcmp(module->base.config, config_rsp->config, cfg_len) != 0)
		{
			memset(module->base.config, 0, IZI_MAX_CONFIG);		// Clear all not used bytes
			memcpy(module->base.config, config_rsp->config, cfg_len);
			any_change = true;
			IZIPLUS_TRACE_INFO("Rsp Config diff: %d %d\r\n", cfg_len, config_rsp->config[0]);
		}
		else
			IZIPLUS_TRACE_INFO("Rsp Config no diff: %d %d %d\r\n", cfg_len, config_rsp->config[0], module->base.config);
	}
	else
		module->base.config_rec_amount = 0;
	module->helper.requests &= ~(1 << IZIPLUS_REQ_CONFIG);
	module->helper.requests_init &= ~(1 << IZIPLUS_REQ_CONFIG);

	return any_change;
}

bool IziPlus_Request_WriteConfig(izi_module_t *module, uint16_t idx)
{
	izi_module_base_t ee_module;
	Eeprom_Read(EEPROM_MODULES + (idx * IZI_MODULE_STORE_SIZE), &ee_module, IZI_MODULE_STORE_SIZE);
	memcpy(module->base.config, &ee_module.config[0], IZI_MAX_CONFIG);			// Real value is found in EEPROM (to be able to detect changes)
	if(module->base.config_amount > 0)
	{
		uint16_t nw_length = iziplus_networkframe_configwrite(iziplus_nwdata, module->base.config, module->base.config_amount);
		if(iziplus_data_request(module, iziplus_nwdata, nw_length) >=
				(int16_t)(sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_config_wrp_t)))
		{
			module->var.flags &= ~(FLAG_CONFIG_ERROR);			// If set OK remove flag
			IZI_TRACE_INFO("Set config requested for %x\r\n", module->base.device_id);

			char txt[20] = { 0 };
			for(uint8_t i = 0; i < module->base.config_amount; i++)
			{
				sprintf(&txt[i * 3], "%02X ",  module->base.config[i]);
				if((i + 1) * 3 >= sizeof(txt))
					break;
			}

			sprintf(text, "Write config OK -> %s", txt);
			LOGWRITE_INFO_S(ERRCODE_IZI_SET_CONFIG, text, log_src_task_postpone, module->base.device_id);

			return true;
		}
		else
		{
			module->var.flags |= FLAG_CONFIG_ERROR;
			IZIPLUS_TRACE_INFO("Write config fail for %x\r\n", module->base.device_id);

			sprintf(text, "Write config failed");
			LOGWRITE_ERROR_S(ERRCODE_IZI_SET_CONFIG, text, log_src_task_postpone, module->base.device_id);
		}
	}
	else
		IZI_TRACE_INFO("Module[%x] has no config\r\n", module->base.device_id);

	return false;
}

/*
 * Handle request of text
 */
bool IziPlus_Request_Text(izi_module_t *module, bool add_retries, uint16_t *length)
{
	uint16_t nw_length = iziplus_networkframe_textread(iziplus_nwdata);
	if(!add_retries)
		iziplus_data_no_retry();				// No retries

	int16_t rsp_len = iziplus_data_request(module, iziplus_nwdata, nw_length);
	if(!(rsp_len >= (int16_t)(sizeof(iziplus_network_data_t))))			// Response OK?
		return false;

	*length = rsp_len - sizeof(iziplus_network_data_t);
	return true;
}

/*
 * Handle response on text command
 */
bool IziPlus_Response_Text(izi_module_t *module, uint8_t *payload, uint16_t length)
{
	bool any_change = false;

	if(length > 0)		// Config parameters received?
	{
		iziplus_cmd_text_rrsp_t *text_rrsp = (iziplus_cmd_text_rrsp_t *)payload;
		if(strncmp(module->base.txt, (char *)text_rrsp->text, IZI_MAX_TXT) != 0)
		{
			memset(module->base.txt, 0, IZI_MAX_TXT);		// Clear all not used bytes
			if(length > IZI_MAX_TXT)
				length = IZI_MAX_TXT;
			memcpy(module->base.txt, text_rrsp->text, length);
			any_change = true;
		}
	}
	else
		module->base.txt[0] = 0;
	module->helper.requests &= ~(1 << IZIPLUS_REQ_TEXT);
	module->helper.requests_init &= ~(1 << IZIPLUS_REQ_TEXT);

	return any_change;
}

bool IziPlus_Request_WriteText(izi_module_t *module, uint16_t idx)
{
	izi_module_base_t ee_module;
	Eeprom_Read(EEPROM_MODULES + (idx * IZI_MODULE_STORE_SIZE), &ee_module, IZI_MODULE_STORE_SIZE);
	memcpy(module->base.txt, &ee_module.txt[0], IZI_MAX_TXT);			// Get real value from EEPROM

	uint16_t nw_length = iziplus_networkframe_textwrite(iziplus_nwdata, (uint8_t *)module->base.txt, strlen(module->base.txt));
	if(iziplus_data_request(module, iziplus_nwdata, nw_length) >=
			(int16_t)(sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_text_wrsp_t)))
	{
		IZIPLUS_TRACE_INFO("Set text ok for %x: %s\r\n", module->base.device_id, module->base.txt);

		sprintf(text, "Write text OK -> %.22s", module->base.txt);
		LOGWRITE_INFO_S(ERRCODE_IZI_SET_TEXT, text, log_src_task_postpone, module->base.device_id);

		return true;
	}
	else
	{
		module->var.flags |= FLAG_CONFIG_ERROR;
		IZIPLUS_TRACE_INFO("Set text fail for %x: %s\r\n", module->base.device_id, module->base.txt);

		sprintf(text, "Write text fail -> %.20s", module->base.txt);
		LOGWRITE_INFO_S(ERRCODE_IZI_SET_TEXT_FAIL, text, log_src_task_postpone, module->base.device_id);
	}
	return false;
}

/*
 * Handle pending requests
 */
void IziPlus_Requests()
{
	static uint16_t last_req_idx = 0;								// Keep looping
	for(int i = 0; i < iziplus_module_amount; i++)					// Check all modules for pending requests
	{
		if(!(iziplus_modules[last_req_idx].var.flags & FLAG_ONLINE))		// If module not online (by state messages), wait with request
		{
			if(++last_req_idx >= iziplus_module_amount)
				last_req_idx = 0;
			continue;
		}

		if(iziplus_modules[last_req_idx].helper.requests & (1 << IZIPLUS_REQ_VERSION))
		{
			if(IziPlus_Request_Version(&iziplus_modules[last_req_idx], false))
			{
				if(IziPlus_Response_Version(&iziplus_modules[last_req_idx], &iziplus_nwdata_rx[sizeof(iziplus_network_data_t)]))
					IziPlus_ReportConfigFlag(&iziplus_modules[last_req_idx]);
			}
			break;		// Next request, next loop
		}
		else if(iziplus_modules[last_req_idx].helper.requests & (1 << IZIPLUS_REQ_CONFIG))
		{
			uint16_t payload_len = 0;
			if(IziPlus_Request_Config(&iziplus_modules[last_req_idx], false, &payload_len))
			{
				bool init_cfg_ok = !(iziplus_modules[last_req_idx].helper.requests_init & (1 << IZIPLUS_REQ_CONFIG));		// Check here (it is cleared in the response)
				if(IziPlus_Response_Config(&iziplus_modules[last_req_idx], &iziplus_nwdata_rx[sizeof(iziplus_network_data_t)], payload_len))
				{
					if(init_cfg_ok)			// No correction when first received from module
					{
						IZIPLUS_TRACE_INFO("Write Config: %d %d\r\n", last_req_idx, iziplus_modules[last_req_idx].base.config[0]);
						IziPlus_Request_WriteConfig(&iziplus_modules[last_req_idx], last_req_idx);			// Incorrect config, try to recover by a write
					}
					IziPlus_ReportConfigFlag(&iziplus_modules[last_req_idx]);
				}
			}
			break;		// Next request, next loop
		}
		else if(iziplus_modules[last_req_idx].helper.requests & (1 << IZIPLUS_REQ_TEXT))
		{
			uint16_t payload_len = 0;
			if(IziPlus_Request_Text(&iziplus_modules[last_req_idx], false, &payload_len))
			{
				bool init_text_ok = !(iziplus_modules[last_req_idx].helper.requests_init & (1 << IZIPLUS_REQ_TEXT));		// Check here (it is cleared in the response)
				if(IziPlus_Response_Text(&iziplus_modules[last_req_idx], &iziplus_nwdata_rx[sizeof(iziplus_network_data_t)], payload_len))
				{
					if(init_text_ok)		// No correction when first received from module
					{
						IziPlus_Request_WriteText(&iziplus_modules[last_req_idx], last_req_idx);				// Incorrect text, try to recover by a write
					}
					IziPlus_ReportConfigFlag(&iziplus_modules[last_req_idx]);
				}
			}
			break;		// Next request, next loop
		}
		else if(iziplus_modules[last_req_idx].helper.requests & (1 << IZIPLUS_REQ_CHANNELMODE))
		{
			if(IziPlus_Request_ChannelMode(&iziplus_modules[last_req_idx], false))
			{
				bool init_cm_ok = !(iziplus_modules[last_req_idx].helper.requests_init & (1 << IZIPLUS_REQ_CHANNELMODE));		// Check here (it is cleared in the response)
				if(IziPlus_Response_ChannelMode(&iziplus_modules[last_req_idx], &iziplus_nwdata_rx[sizeof(iziplus_network_data_t)]))
				{
					if(init_cm_ok)			// No correction when first received from module
					{
						IziPlus_Request_WriteChannelMode(&iziplus_modules[last_req_idx], last_req_idx);
					}
					IziPlus_ReportConfigFlag(&iziplus_modules[last_req_idx]);
				}
			}
			break;		// Next request, next loop
		}
		else if(iziplus_modules[last_req_idx].helper.requests & (1 << IZIPLUS_REQ_PRODUCTION))
		{
			uint8_t prod_data[30];
			uint32_t serial_fake = last_req_idx + RtcTime_GetSeconds();
			memcpy(prod_data, &serial_fake, 4);
			strcpy((char *)&prod_data[4], "Top batch!");
			uint16_t nw_length = iziplus_networkframe_production_data_write(iziplus_nwdata, prod_data, 30);
			//iziplus_data_no_retry();				// No retries
			if(iziplus_data_request(&iziplus_modules[last_req_idx], iziplus_nwdata, nw_length) >=
				(int16_t)((sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_production_data_wrsp_t))))
			{
				IZI_TRACE_INFO("Production write OK\r\n");
			}
			iziplus_modules[last_req_idx].helper.requests &= ~(1 << IZIPLUS_REQ_PRODUCTION);
		}
		else if(iziplus_modules[last_req_idx].helper.requests & (1 << IZIPLUS_REQ_PRODUCTION_R))
		{
			uint16_t nw_length = iziplus_networkframe_production_data_read(iziplus_nwdata);
			//iziplus_data_no_retry();				// No retries
			if(iziplus_data_request(&iziplus_modules[last_req_idx], iziplus_nwdata, nw_length) >=
				(int16_t)((sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_production_data_rrsp_t))))
			{
				//iziplus_cmd_production_data_rrsp_t *prod_read_rsp = (iziplus_cmd_production_data_rrsp_t *)&iziplus_nwdata_rx[sizeof(iziplus_network_data_t)];
				//uint8_t txt[12];
				//strncpy(txt, &prod_read_rsp->data[4], 12);
				//IZI_TRACE_INFO("Production read OK: %s\r\n", txt);
			}
			iziplus_modules[last_req_idx].helper.requests &= ~(1 << IZIPLUS_REQ_PRODUCTION_R);
		}
		else if(iziplus_modules[last_req_idx].helper.requests & (1 << IZIPLUS_REQ_FACTORY))
		{
			uint16_t nw_length = iziplus_networkframe_factory_default(iziplus_nwdata);
			//iziplus_data_no_retry();				// No retries
			if(iziplus_data_request(&iziplus_modules[last_req_idx], iziplus_nwdata, nw_length) >=
				(int16_t)((sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_factory_arsp_t))))
			{
				IZI_TRACE_INFO("Factory default OK\r\n");
			}
			iziplus_modules[last_req_idx].helper.requests &= ~(1 << IZIPLUS_REQ_FACTORY);
		}
		if(++last_req_idx >= iziplus_module_amount)
			last_req_idx = 0;
	}
}

void IziPlus_ReportConfig(void)
{
	if (iziplus_state == IZIPLUS_STATE_DMX || iziplus_state == IZIPLUS_STATE_SCAN)
	{
		for(uint16_t i = 0; i < iziplus_module_amount; i++)
		{
			//if(iziplus_modules[i] == NULL)
			//	continue;

			bool written = false;
			if(iziplus_modules[i].var.changes.report_config)
			{
				izi_module_base_t ee_module;
				Eeprom_Read(EEPROM_MODULES + (i * IZI_MODULE_STORE_SIZE), &ee_module, IZI_MODULE_STORE_SIZE);
				
				uint8_t channels_now = ee_module.channels;
				uint8_t config_amount_now = ee_module.config_amount;
				uint8_t monitor_amount_now = ee_module.monitor_amount;
				
				if(!izican_slave_reportmodule(i, iziplus_module_amount, &iziplus_modules[i].base, &iziplus_modules[i].base.channels, &iziplus_modules[i].base.config_amount, 
				&iziplus_modules[i].base.monitor_amount, &iziplus_modules[i].base.monitor_status_idx, &iziplus_modules[i].base.monitor_input_idx, iziplus_modules[i].base.monitor_encoder_idx))
				{
					iziplus_modules[i].base.channels = 8;				// On fail, just send probably too much channels
					if(++iziplus_modules[i].var.changes.report_config_retry >= 3)
						iziplus_modules[i].var.changes.report_config = 0;		// Didn't work after several retries
					IziPlus_ClearIndexes(i);
					
					IZI_TRACE_INFO("Report config fail: %d\r\n", i);
				}
				else
					iziplus_modules[i].var.changes.report_config = 0;

				if(iziplus_modules[i].var.changes.report_config == 0 && (channels_now != iziplus_modules[i].base.channels || config_amount_now != iziplus_modules[i].base.config_amount || monitor_amount_now != iziplus_modules[i].base.monitor_amount))
				{
					izi_module_base_t *changedModule = &iziplus_modules[i].base;
					changedModule->channels = iziplus_modules[i].base.channels;			// Only overwrite channel data, rest could not be wanted
					if(Eeprom_Write(EEPROM_MODULES + (i * IZI_MODULE_STORE_SIZE), (uint8_t *)changedModule, IZI_MODULE_STORE_SIZE))
						written = true;
				}

				vTaskDelay(2);
			}
			// Todo: if(written)
			// Todo: 	Eeprom_finish();
		}
	}
}

/**
 * Set changed flag so slave task will send update to master
 */
void IziPlus_ReportMonitorFlag(izi_module_t *module)
{
	module->var.changes.report_monitor_retry = 0;
	module->var.changes.report_monitor = 1;
	//IZI_TRACE_INFO("IZI report %d\r\n", module->base.device_id);
}

/**
 * Set changed flag so slave task will send update to master
 */
void IziPlus_ReportConfigFlag(izi_module_t *module)
{
	module->var.changes.report_config_retry = 0;
	module->var.changes.report_config = 1;
}

void IziPlus_FastReport()
{
	OS_TRACE_INFO("%d Fast report\r\n", xTaskGetTickCount())
	fast_report = true;
}

bool IziPlus_FastReportPending()
{
	bool res = fast_report;
	fast_report = false;
	return res;
}

void IziPlus_ReportMonitor(void)
{
	if (iziplus_state == IZIPLUS_STATE_DMX || iziplus_state == IZIPLUS_STATE_PROTECT || iziplus_state == IZIPLUS_STATE_PROTECT2)
	{
		for(uint16_t i = 0; i < iziplus_module_amount; i++)
		{
			//if(iziplus_modules[i] == NULL)
			//	continue;

			if(iziplus_modules[i].var.changes.report_monitor && !iziplus_modules[i].var.changes.report_config)		// First send config
			{
				bool ok = izican_slave_reportmonitor(i, &iziplus_modules[i]);
				iziplus_modules[i].var.changes.report_monitor = 0;
				IZI_TRACE_INFO("%d Report monitor: %d %d -> %d\r\n", xTaskGetTickCount(), i, ok, iziplus_modules[i].var.contact_state);
				vTaskDelay(2);
			}
			else if(iziplus_modules[i].var.changes.report_monitor)
			{
				//IZI_TRACE_INFO("Report monitor**: %d %d\r\n", i, iziplus_modules[i].var.changes.report_config);
				if(++(iziplus_modules[i].var.changes.report_monitor_retry) >= 3)
					iziplus_modules[i].var.changes.report_monitor = 0;		// Didn't work after several retries
			}
		}
	}
	/*else
	{
		IZI_TRACE_INFO("Report state: %d\r\n", iziplus_state);
	}*/
}

/**
 * Load modules from EEPROM
 */
void IziPlus_ModuleLoad()
{
	iziplus_module_amount = 0;
	if(appConfig->app_modules > 0 && appConfig->app_modules <= APPMODULES_MAX)
	{
		uint16_t i;
		for(i = 0; i < appConfig->app_modules; i++)
		{
			if(i >= IZI_MAX_MODULES)
				break;
			izi_module_base_t ee_module;
			memset(&iziplus_modules[i], 0, sizeof(izi_module_base_t));
			Eeprom_Read(EEPROM_MODULES + (i * IZI_MODULE_STORE_SIZE), &ee_module, IZI_MODULE_STORE_SIZE);
			
			memcpy(&iziplus_modules[i], &ee_module, IZI_MODULE_STORE_SIZE);

			IziPlus_ReportConfigFlag(&iziplus_modules[i]);
			IziPlus_ReportMonitorFlag(&iziplus_modules[i]);	// At least report state

			iziplus_module_amount++;
		}

		IZI_TRACE_INFO("IZI Load ready, loaded %d modules\r\n", iziplus_module_amount);
	}
}

uint16_t IziPlus_ModuleAmount()
{
	return iziplus_module_amount;
}

izi_module_t *IziPlus_GetModule(int index)
{
	if(index < iziplus_module_amount)
		return &iziplus_modules[index];
	return NULL;
}

int8_t IziPlus_Identify(uint32_t serial, uint16_t time, uint16_t mode)
{
	uint16_t id = 0;

	if(serial == 0)				// Identify/Action of CAN module itself
	{
		if(mode == IDENTIFY_ACTION_CLEARMAX)
			Analog_OutputCurrentMaxCLear();
		else if(mode == IDENTIFY_ACTION_CANCEL)
		{
			if(iziplus_substate == IZIPLUS_SUBSTATE_UPDATE)
			{
				iziplus_substate = IZIPLUS_SUBSTATE_IDLE;
				sprintf(text, "Firmware update cancelled");
				LOGWRITE_WARNING(ERRCODE_UPDATE_IZI, text, log_src_task_postpone);
				for(int i = 0; i < iziplus_module_amount; i++)
					iziplus_modules[i].var.flags &= ~FLAG_UPDATING;
				iziplus_update_module = NULL;
				iziplus_update_flags = 0;
				iziplus_update_cnt = 0;
				IziPlus_ReportLinkState(LINK_STATE_IDLE, iziplus_module_amount);
			}
		}
		else if(time > 0)
		{
			State_SetAttentionInfo(COLOR_MAGENTA, COLOR_BLUE, time * 60, mode + 1);			// Local identify
			iziplus_local_identify_time = time * 60;
		}
		else
		{
			State_ClearAttentionInfo();
			iziplus_local_identify_time = 0;
		}
		
		izican_slave_update_state(true, false);
		IZI_TRACE_INFO("Identify req local: %d %d %d\r\n", id, time, mode);
		return 0;
	}

	for(id = 0; id < iziplus_module_amount; id++)
	{
		if(iziplus_modules[id].base.device_id == serial)
		{
			break;
		}
	}

	if(id >= iziplus_module_amount)
		return -1;

	iziplus_fifo_identify_t iziplus_fifo_identify_item;
	iziplus_fifo_identify_item.index = id;
	iziplus_fifo_identify_item.time = time;
	iziplus_fifo_identify_item.mode = mode;

	bool added = fifo_add(iziplus_fifo_identify, &iziplus_fifo_identify_item);
	IZI_TRACE_INFO("Identify req add: %d %d %d (%d)\r\n", id, time, mode, added);
	return added ? 0 : -2;
}

bool IziPlus_SetChannelMode(uint32_t serial, uint16_t address, uint8_t mode, uint8_t dmxfail, uint8_t *cfg, uint8_t cfg_length, uint8_t *txt)
{
	izi_module_base_t *changedModule;
	iziplus_fifo_config_t iziplus_fifo_config_item;
	bool addressmode_change = false, mode_change = false;
	uint16_t id;
	for(id = 0; id < iziplus_module_amount; id++)
	{
		if(iziplus_modules[id].base.device_id == serial)
		{
			break;
		}
	}

	if(id >= iziplus_module_amount)
		return false;

	iziplus_fifo_config_item.index = id;
	changedModule = &iziplus_modules[id].base;		// Just report next time it

	if(changedModule->address != address || changedModule->mode != mode || changedModule->dmxfail != dmxfail)
	{
		if(changedModule->mode != mode)				// Possibly channel amount change?
			mode_change = true;
		iziplus_addressmode_set_delay = ADDRESS_MODE_SET_DELAY;			// Wait for assigning channels/modes for 2 - 3 seconds, in case more configs come in, in short time...
		changedModule->address = address;			// Overwrite with new data
		changedModule->mode = mode;
		changedModule->dmxfail = dmxfail;
		addressmode_change = true;
	}

	iziplus_fifo_config_item.config_change = 0;
	if(cfg != NULL && cfg_length > 0 && cfg_length <= IZI_MAX_CONFIG)
	{
		if(memcmp(changedModule->config, cfg, cfg_length) != 0)
		{
			memcpy(changedModule->config, cfg, cfg_length);
			IZI_TRACE_INFO("Config req add: %d len: %d cfg: %d %d\r\n", id, cfg_length, cfg[0], cfg[1]);
			iziplus_fifo_config_item.config_change = CONFIG_CHANGE_RETRY;
		}
	}

	iziplus_fifo_config_item.text_change = 0;
	if(txt != NULL)
	{
		if(strncmp(changedModule->txt, (char *)txt, IZI_MAX_TXT) != 0)
		{
			strncpy(changedModule->txt, (char *)txt, IZI_MAX_TXT);
			iziplus_fifo_config_item.text_change = TEXT_CHANGE_RETRY;
			IZI_TRACE_INFO("Text req add: %d %s\r\n", id, changedModule->txt);
		}
	}
	if(!addressmode_change && !iziplus_fifo_config_item.text_change && !iziplus_fifo_config_item.config_change)
		return true;				// No changes

	if(!Eeprom_Write(EEPROM_MODULES + (id * IZI_MODULE_STORE_SIZE), (uint8_t *)changedModule, IZI_MODULE_STORE_SIZE))
	 	return false;

	iziplus_modules[id].helper.requests_init = 0;				// Now we now for sure, the value the powercom has is the right one
	if(iziplus_fifo_config_item.text_change || iziplus_fifo_config_item.config_change)
		return fifo_add(iziplus_fifo_config, &iziplus_fifo_config_item);

	if(mode_change)
		IziPlus_ReportConfigFlag(&iziplus_modules[id]);			// Report new mode to get back possible other amount of channels
	return true;
}

// Proceeded with 'I'
void IziPlus_Debug(uint8_t *data, uint8_t length)
{
	if(data[0] == 't' && length >= 2)
	{
		izi_trace_lvl = data[1] - '0';
		IZI_TRACE_ERROR("Trace level: %d\r\n", izi_trace_lvl);
	}
	else if(data[0] == 'd')
	{
		uint8_t clear;
		IziPlus_DiscoverStart(data[1] != 'a' ? IZIPLUS_OPTION_CLEAN : IZIPLUS_OPTION_ADD, 0xFF, 0xFF, &clear);//1FE7FCF
	}
	else if(data[0] == 'm')
	{
		uint8_t i;
		for(i = 0; i < iziplus_module_amount; i++)
		{
			IZI_TRACE_ERROR("[%02d] Type: %02d: Address: %03d, ID: %08x, Mode: %d, Short:%d, Cfg[0]: %d, Cfg[1]: %d Txt: %s -> %s\r\n", i, iziplus_modules[i].base.device_type, iziplus_modules[i].base.address, iziplus_modules[i].base.device_id, iziplus_modules[i].base.mode,
					iziplus_modules[i].base.short_id, iziplus_modules[i].base.config[0], iziplus_modules[i].base.config[1], iziplus_modules[i].base.txt, iziplus_modules[i].var.flags & FLAG_ONLINE ? "Online" : "Offline");
		}
	}
	else if(data[0] == 'i' && length >= 2)
	{
		int16_t izi_identify_reqid, izi_identify_reqtime;

		izi_identify_reqid = data[1] - '0';
		if(length >= 3)
			izi_identify_reqtime = data[2] - '0';
		else
			izi_identify_reqtime = 0;

		if(izi_identify_reqid >= iziplus_module_amount)
			return;

		IziPlus_Identify(iziplus_modules[izi_identify_reqid].base.device_id, izi_identify_reqtime, 0);
		IZI_TRACE_ERROR("Identify[%d]: %d\r\n", izi_identify_reqid, izi_identify_reqtime);
	}
	else if(data[0] == 'p' && length >= 2)
	{
		int16_t izi_prod_reqid;

		izi_prod_reqid = data[2] - '0';
		if(izi_prod_reqid >= iziplus_module_amount)
			return;

		if(data[1] == 'w')
			iziplus_modules[izi_prod_reqid].helper.requests |= (1 << IZIPLUS_REQ_PRODUCTION);
		else if(data[1] == 'r')
			iziplus_modules[izi_prod_reqid].helper.requests |= (1 << IZIPLUS_REQ_PRODUCTION_R);
		IZI_TRACE_ERROR("Production write/read[%d]\r\n", izi_prod_reqid);
	}
	else if(data[0] == 'f' && data[1] == 'w' && length >= 2)
	{
		int16_t izi_prod_reqid;

		izi_prod_reqid = data[2] - '0';
		if(izi_prod_reqid >= iziplus_module_amount)
			return;

		iziplus_modules[izi_prod_reqid].helper.requests |= (1 << IZIPLUS_REQ_FACTORY);
		IZI_TRACE_ERROR("Production write[%d]\r\n", izi_prod_reqid);
	}
	else if(data[0] == 'f' && data[1] == 'w' && length >= 2)
	{

	}
	else if(data[0] == 'T')
	{
		IZI_OUTPUT_TRACE_ERROR("Interval in us overview\r\n");
#if IZI_TIMING >= 1
		for(int i = 0; i < 6; i++)
		{
			IZI_OUTPUT_TRACE_ERROR("%s\r\n", TimingPrint(i));
		}
		if(data[1] == 'c')
		{
			Timing_Init();
		}
#endif
	}
	//iziplus_module_amount iziplus_modules[last_req_idx];
}
