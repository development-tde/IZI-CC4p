/*
 * Code generated from Atmel Start.
 *
 * This file will be overwritten when reconfiguring your Atmel Start project.
 * Please copy examples or other code you want to keep to a separate file
 * to avoid losing it when reconfiguring.
 */
#ifndef ATMEL_START_PINS_H_INCLUDED
#define ATMEL_START_PINS_H_INCLUDED

#include <hal_gpio.h>

// SAME51 has 14 pin functions

#define GPIO_PIN_FUNCTION_A 0
#define GPIO_PIN_FUNCTION_B 1
#define GPIO_PIN_FUNCTION_C 2
#define GPIO_PIN_FUNCTION_D 3
#define GPIO_PIN_FUNCTION_E 4
#define GPIO_PIN_FUNCTION_F 5
#define GPIO_PIN_FUNCTION_G 6
#define GPIO_PIN_FUNCTION_H 7
#define GPIO_PIN_FUNCTION_I 8
#define GPIO_PIN_FUNCTION_J 9
#define GPIO_PIN_FUNCTION_K 10
#define GPIO_PIN_FUNCTION_L 11
#define GPIO_PIN_FUNCTION_M 12
#define GPIO_PIN_FUNCTION_N 13

#define PA08 GPIO(GPIO_PORTA, 8)
#define PA09 GPIO(GPIO_PORTA, 9)
#define PA10 GPIO(GPIO_PORTA, 10)
#define PA11 GPIO(GPIO_PORTA, 11)
#define PA12 GPIO(GPIO_PORTA, 12)
#define PA13 GPIO(GPIO_PORTA, 13)

#define PA22 GPIO(GPIO_PORTA, 22)
#define PA23 GPIO(GPIO_PORTA, 23)

#define PA04 GPIO(GPIO_PORTA, 4)
#define PA05 GPIO(GPIO_PORTA, 5)

#define PA16 GPIO(GPIO_PORTA, 16)
#define PA17 GPIO(GPIO_PORTA, 17)

#define PA20 GPIO(GPIO_PORTA, 20)

#define PA24 GPIO(GPIO_PORTA, 24)
#define PA25 GPIO(GPIO_PORTA, 25)

#define PB04 GPIO(GPIO_PORTB, 4)
#define PB06 GPIO(GPIO_PORTB, 6)

#define PB08 GPIO(GPIO_PORTB, 8)
#define PB09 GPIO(GPIO_PORTB, 9)

#define PB12 GPIO(GPIO_PORTB, 12)
#define PB13 GPIO(GPIO_PORTB, 13)
#define PB15 GPIO(GPIO_PORTB, 15)


#define HW_ID0 GPIO(GPIO_PORTA, 0)
#define HW_ID1 GPIO(GPIO_PORTA, 1)
#define HW_ID2 GPIO(GPIO_PORTA, 2)
#define HW_ID3 GPIO(GPIO_PORTA, 3)
#define DEV_ID0 GPIO(GPIO_PORTA, 4)
#define DEV_ID1 GPIO(GPIO_PORTA, 5)
#define DEV_ID2 GPIO(GPIO_PORTA, 6)
#define DEV_ID3 GPIO(GPIO_PORTA, 7)
#define DEV_ID4 GPIO(GPIO_PORTA, 24)
#define DEV_ID5 GPIO(GPIO_PORTA, 25)
#define EXT_TXD GPIO(GPIO_PORTA, 12)
#define EXT_RXD GPIO(GPIO_PORTA, 13)
#define PLC_RST GPIO(GPIO_PORTA, 15)
#define PLC_HDC GPIO(GPIO_PORTA, 18)
//#define PLC_RTR GPIO(GPIO_PORTA, 19)
#define PLC_TXON GPIO(GPIO_PORTA, 20)
//#define CAN_STB GPIO(GPIO_PORTA, 21)
#define PA22 GPIO(GPIO_PORTA, 22)
#define PA23 GPIO(GPIO_PORTA, 23)
#define CAN_SNS GPIO(GPIO_PORTB, 0)
#define CAN_CHK GPIO(GPIO_PORTB, 1)
#define CAN_END GPIO(GPIO_PORTB, 2)
#define ADC_TIN GPIO(GPIO_PORTB, 6)
#define ADC_TIN_AD PINMUX_PB06B_ADC1_AIN8
#define ADC_VIN GPIO(GPIO_PORTB, 4)
#define ADC_VIN_AD PINMUX_PB04B_ADC1_AIN6
#define ADC_OUT10 GPIO(GPIO_PORTA, 9)
#define ADC_OUT10_AD PINMUX_PA09B_ADC1_AIN3
#define AD_GND_REF GPIO(GPIO_PORTB, 8)
#define AD_GND_REF_AD PINMUX_PB08B_ADC1_AIN0
#ifdef PCB_REV6
#define REV_ID0 GPIO(GPIO_PORTB, 2)
#define REV_ID1 GPIO(GPIO_PORTB, 3)
#define ADC_OUT20 GPIO(GPIO_PORTB, 5)
#define ADC_OUT20_AD PINMUX_PB05B_ADC1_AIN7
#define ADC_VOUT GPIO(GPIO_PORTB, 9)
#define ADC_VOUT_AD PINMUX_PB09B_ADC1_AIN1
#define ADC_REF		GPIO(GPIO_PORTB, 7)
#define ADC_REF_AD	PINMUX_PB07B_ADC1_AIN9
#define OUT_5V_OFF GPIO(GPIO_PORTB, 30)
#else
#define CAN_TERM GPIO(GPIO_PORTB, 3)
#define REV_ID0 GPIO(GPIO_PORTB, 5)
#define REV_ID1 GPIO(GPIO_PORTB, 7)
#define REV_ID2 GPIO(GPIO_PORTB, 8)
#define REV_ID2_AD PINMUX_PB08B_ADC1_AIN0
#define REV_ID3 GPIO(GPIO_PORTB, 9)
#endif
#define OUT_EN GPIO(GPIO_PORTB, 10)
#define SWITCH GPIO(GPIO_PORTB, 11)
#define OUT_OC GPIO(GPIO_PORTB, 14)
#define PLC_CSEL1 GPIO(GPIO_PORTB, 16)
#define PLC_CSEL0 GPIO(GPIO_PORTB, 17)
#define BOOST GPIO(GPIO_PORTB, 31)
#define PB24 GPIO(GPIO_PORTB, 24)
#define PB25 GPIO(GPIO_PORTB, 25)

#define AC_EXT_IN1					GPIO(GPIO_PORTA, 0)			// Schema says TRG1
#define AC_EXT_IN1_FUNC				PINMUX_PA00A_EIC_EXTINT0
#define AC_EXT_IN1_EVENT_BIT		0
#define AC_EXT_IN1_EVENT_SENSE		EIC_CONFIG_SENSE0_FALL
#define AC_EXT_IN1_EVENT_CFG		0							// Config register 8 and above is reg 1
#define AC_EXT_IN1_EVENT_ID_GEN		EVSYS_ID_GEN_EIC_EXTINT_0

#define AC_EXT_IN2					GPIO(GPIO_PORTA, 2)			// Schema says TRG2
#define AC_EXT_IN2_FUNC				PINMUX_PB02A_EIC_EXTINT2
#define AC_EXT_IN2_EVENT_BIT		2
#define AC_EXT_IN2_EVENT_SENSE		EIC_CONFIG_SENSE2_FALL
#define AC_EXT_IN2_EVENT_CFG		0							// Config register 8 and above is reg 1
#define AC_EXT_IN2_EVENT_ID_GEN		EVSYS_ID_GEN_EIC_EXTINT_2

#define AC_EXT_IN3					GPIO(GPIO_PORTA, 4)			// Schema says TRG2
#define AC_EXT_IN3_FUNC				PINMUX_PB04A_EIC_EXTINT4
#define AC_EXT_IN3_EVENT_BIT		4
#define AC_EXT_IN3_EVENT_SENSE		EIC_CONFIG_SENSE4_FALL
#define AC_EXT_IN3_EVENT_CFG		0							// Config register 8 and above is reg 1
#define AC_EXT_IN3_EVENT_ID_GEN		EVSYS_ID_GEN_EIC_EXTINT_4

#define SW1_PORT					GPIO_PORTA				// !!!! ALSO USED for AD calibration!!
#define SW1_PIN						1
#define SW1							GPIO(SW1_PORT, SW1_PIN)

#define SW2_PORT					GPIO_PORTA				// Check Port to event system PORT_EVCTRL_PORTEI0 when changed
#define SW2_PIN						3
#define SW2							GPIO(SW2_PORT, SW2_PIN)

#define SW3_PORT					GPIO_PORTA				// Check Port to event system PORT_EVCTRL_PORTEI0 when changed
#define SW3_PIN						7
#define SW3							GPIO(SW2_PORT, SW2_PIN)

#define DIM1_PORT					GPIO_PORTA
#define DIM1_PIN					21
#define DIM1						GPIO(DIM1_PORT, DIM1_PIN)
#define DIM1_FUNC					PINMUX_PA21G_TCC0_WO1
#define DIM1_WO						1						// & 0x03??	check TCCX_IRQ_MCMP_EN_CH1 + TCCX_INTC_HANDLER_EN_CH1 + TCCX_INTC_INTENSET_CH1 when changed!!

#define DIM2_PORT					GPIO_PORTA
#define DIM2_PIN					19
#define DIM2						GPIO(DIM2_PORT, DIM2_PIN)
#define DIM2_FUNC					PINMUX_PA19F_TCC1_WO3
#define DIM2_WO						3						// & 0x03??	check TCCX_IRQ_MCMP_EN_CH2 + TCCX_INTC_HANDLER_EN_CH2 + TCCX_INTC_INTENSET_CH2 when changed!!

#define DIM3_PORT					GPIO_PORTA
#define DIM3_PIN					24
#define DIM3						GPIO(DIM2_PORT, DIM2_PIN)
#define DIM3_FUNC					PINMUX_PA24F_TCC2_WO2
#define DIM3_WO						2						// & 0x03??	check TCCX_IRQ_MCMP_EN_CH2 + TCCX_INTC_HANDLER_EN_CH2 + TCCX_INTC_INTENSET_CH2 when changed!!

#define DAC_EXT_OUT					GPIO(GPIO_PORTA, 5)
#define DAC_EXT_OUT_FUNC			PINMUX_PA05B_DAC_VOUT1

#define DAC2_EXT_OUT				GPIO(GPIO_PORTA, 2)
#define DAC2_EXT_OUT_FUNC			PINMUX_PA02B_DAC_VOUT0


#endif // ATMEL_START_PINS_H_INCLUDED
