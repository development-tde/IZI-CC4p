/*
 * usartx.h
 *
 * Created: 17-5-2022 08:59:52
 *  Author: Milo
 */ 


#ifndef DMAC_H_
#define DMAC_H_

typedef void (*dma_cb_func_txptr)(void);
typedef void (*dma_cb_func_errptr)(void);

void DMA_Init();
bool DMA_Send(uint8_t channel, uint8_t *bfr, uint16_t length);
void DMA_ChannelInit(uint8_t channel, uint32_t dst, uint8_t trigsrc, dma_cb_func_txptr dma_tx, dma_cb_func_errptr dma_err);

#endif /* DMAC_H_ */