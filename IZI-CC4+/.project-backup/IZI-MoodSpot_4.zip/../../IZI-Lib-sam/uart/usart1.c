/*
 * usart1.c
 *
 * Created: 8-3-2022 08:42:33
 *  Author: Milo
 */ 

#include "includes.h"
#include "usart1.h"

// Defines
#define USART1_CLK_APBXMASK			((Mclk *)MCLK)->APBAMASK.bit.SERCOM1_
#define USART1_CLK_GCLK_ID			8				// Check PCHCTRL in datasheet for index of peripheral
#ifndef USART1_CLK_FREQ
#define USART1_CLK_FREQ				96000000.0
#endif
#ifndef USART1_CLK_PCHCTRL
#define USART1_CLK_PCHCTRL			GCLK_PCHCTRL_GEN_GCLK0_Val
#endif

#define USART1_HW					SERCOM1->USART
#ifndef USART1_TX_PAD
#define USART1_TX_PAD				0
#endif
#ifndef USART1_TX_PIN
#define USART1_TX_PIN				PA16, PINMUX_PA16C_SERCOM1_PAD0
#endif
#ifndef USART1_RX_PAD
#define USART1_RX_PAD				1
#endif
#ifndef USART1_RX_PIN
#define USART1_RX_PIN				PA17, PINMUX_PA17C_SERCOM1_PAD1
#endif
#ifndef USART1_BAUD	
#define USART1_BAUD					460800	//921600
#endif

#define USART1_INT0					SERCOM1_0_Handler			// DRE
#define USART1_INT1					SERCOM1_1_Handler			// TX
#define USART1_INT2					SERCOM1_2_Handler			// RX
#define USART1_INT3					SERCOM1_3_Handler			// ERR and others

#define USART1_INT0_NR				SERCOM1_0_IRQn			// DRE
#define USART1_INT1_NR				SERCOM1_1_IRQn			// TX
#define USART1_INT2_NR				SERCOM1_2_IRQn			// RX
#define USART1_INT3_NR				SERCOM1_3_IRQn			// ERR and others

#ifndef USART1_INT_PRIO
#define USART1_INT_PRIO				configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY
#endif

#ifndef USART1_TX_BFR_SIZE
#define USART1_TX_BFR_SIZE			1024						// Max data in transmit buffer
#endif

// Globals
volatile uint8_t Usart1_TxBuffer[USART1_TX_BFR_SIZE];
volatile uint16_t Usart1_TxInWriteIdx, Usart1_TxOutWriteIdx;

static usartx_cb_func_txptr  Usart1_TxCb = NULL;
static usartx_cb_func_rxptr  Usart1_RxCb = NULL;
static usartx_cb_func_errptr  Usart1_ErrCb = NULL;

void Usart1_Init(usartx_cb_func_txptr tx_cb, usartx_cb_func_rxptr rx_cb, usartx_cb_func_errptr err_cb)
{
	Usart1_TxCb = tx_cb;
	Usart1_RxCb = rx_cb;
	Usart1_ErrCb = err_cb;
	
	MCLK_CRITICAL_SECTION_ENTER();
	USART1_CLK_APBXMASK = 1;
	MCLK_CRITICAL_SECTION_LEAVE();
	
	hri_gclk_write_PCHCTRL_reg(GCLK, USART1_CLK_GCLK_ID, USART1_CLK_PCHCTRL | (1 << GCLK_PCHCTRL_CHEN_Pos));		// Set to Main clock (Generic clock generator 0) = CONF_CPU_FREQUENCY = 96MHz
	//hri_gclk_write_PCHCTRL_reg(GCLK, SERCOM1_GCLK_ID_SLOW, CONF_GCLK_SERCOM1_SLOW_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
	
	USART1_HW.CTRLA.bit.SWRST = SERCOM_USART_CTRLA_SWRST;
	while ((USART1_HW.SYNCBUSY.reg) & SERCOM_USART_SYNCBUSY_SWRST) {
	};
	
	USART1_HW.CTRLA.reg = SERCOM_USART_CTRLA_MODE(1) | SERCOM_USART_CTRLA_TXPO(USART1_TX_PAD) | SERCOM_USART_CTRLA_RXPO(USART1_RX_PAD) | SERCOM_USART_CTRLA_DORD;
	USART1_HW.CTRLB.reg = SERCOM_USART_CTRLB_TXEN | SERCOM_USART_CTRLB_RXEN;
	//USART1_HW.CTRLC.reg = SERCOM_USART_CTRLC_MAXITER(7) | SERCOM_USART_CTRLC_GTIME(2);
	USART1_HW.BAUD.reg = (uint16_t)(65536.0 * (1.0 - (16.0 * ((double)USART1_BAUD / USART1_CLK_FREQ))));
	USART1_HW.INTENSET.reg = SERCOM_USART_INTENSET_RXC | SERCOM_USART_INTENSET_ERROR;
	
	NVIC_DisableIRQ(USART1_INT0_NR);
	NVIC_ClearPendingIRQ(USART1_INT0_NR);
	NVIC_SetPriority(USART1_INT0_NR, USART1_INT_PRIO);					// Prio 0 is highest, 7 is lowest
	NVIC_EnableIRQ(USART1_INT0_NR);
	
#ifdef USART1_DMA
	DMA_ChannelInit(USART1_DMA_CHANNEL, (uint32_t)&SERCOM1->USART.DATA.reg, SERCOM1_DMAC_ID_TX, Usart1_TxCb, Usart1_ErrCb);
#else	
	if(Usart1_TxCb != NULL)
	{
		NVIC_DisableIRQ(USART1_INT1_NR);
		NVIC_ClearPendingIRQ(USART1_INT1_NR);
		NVIC_SetPriority(USART1_INT1_NR, USART1_INT_PRIO);				// Prio 0 is highest, 7 is lowest
		NVIC_EnableIRQ(USART1_INT1_NR);
	}
#endif	
	if(Usart1_RxCb != NULL)
	{
		NVIC_DisableIRQ(USART1_INT2_NR);
		NVIC_ClearPendingIRQ(USART1_INT2_NR);
		NVIC_SetPriority(USART1_INT2_NR, USART1_INT_PRIO);					// Prio 0 is highest, 7 is lowest
		NVIC_EnableIRQ(USART1_INT2_NR);
	}
	
	if(Usart1_ErrCb != NULL)
	{
		NVIC_DisableIRQ(USART1_INT3_NR);
		NVIC_ClearPendingIRQ(USART1_INT3_NR);
		NVIC_SetPriority(USART1_INT3_NR, USART1_INT_PRIO);					// Prio 0 is highest, 7 is lowest
		NVIC_EnableIRQ(USART1_INT3_NR);
	}
	
	USART1_HW.CTRLA.reg |= SERCOM_USART_CTRLA_ENABLE;

	Usart1_TxInWriteIdx = Usart1_TxOutWriteIdx = 0;
	
	gpio_set_pin_function(USART1_TX_PIN);
	gpio_set_pin_function(USART1_RX_PIN);
}

/**
 * \internal Sercom interrupt handler DRE -> Data register empty
 */
void USART1_INT0(void)
{
	if(++Usart1_TxOutWriteIdx >= USART1_TX_BFR_SIZE)
		Usart1_TxOutWriteIdx = 0;
	if(Usart1_TxInWriteIdx != Usart1_TxOutWriteIdx)						// Buffer not empty?
		USART1_HW.DATA.reg = Usart1_TxBuffer[Usart1_TxOutWriteIdx];
	else
		USART1_HW.INTENCLR.reg = SERCOM_USART_INTENCLR_DRE;
	USART1_HW.INTFLAG.reg = SERCOM_USART_INTFLAG_DRE;
}
/**
 * \internal Sercom interrupt handler TXC -> Transmit complete
 */
void USART1_INT1(void)
{
	if(Usart1_TxCb != NULL && (Usart1_TxInWriteIdx == Usart1_TxOutWriteIdx))
	{
		Usart1_TxCb();
		USART1_HW.INTENCLR.reg = SERCOM_USART_INTENCLR_TXC;				// Disable interrupt until new data
	}
	USART1_HW.INTFLAG.reg = SERCOM_USART_INTFLAG_TXC;
}
/**
 * \internal Sercom interrupt handler RXC -> Receive complete
 */
void USART1_INT2(void)
{
	if(Usart1_RxCb != NULL)
		Usart1_RxCb(USART1_HW.DATA.reg);
	USART1_HW.INTFLAG.reg = SERCOM_USART_INTFLAG_RXC;
}
/**
 * \internal Sercom interrupt handler ERROR -> Error is detected
 */
void USART1_INT3(void)
{
	if(Usart1_ErrCb != NULL)
		Usart1_ErrCb();
	USART1_HW.STATUS.reg = SERCOM_USART_STATUS_BUFOVF | SERCOM_USART_STATUS_FERR;
	USART1_HW.INTFLAG.reg = SERCOM_USART_INTFLAG_ERROR;
	//USART1_HW.RXERRCNT
}

void Usart1_SendStart()
{
	if(!(USART1_HW.INTENSET.reg & SERCOM_USART_INTENSET_DRE))
	{
		while(!USART1_HW.INTFLAG.bit.DRE);
		
		USART1_HW.DATA.reg = Usart1_TxBuffer[Usart1_TxOutWriteIdx];
		if(Usart1_TxCb != NULL)
			USART1_HW.INTENSET.reg = SERCOM_USART_INTENSET_TXC | SERCOM_USART_INTENSET_DRE;			// Enable data register empty interrupt and transmit ready
		else
			USART1_HW.INTENSET.reg = SERCOM_USART_INTENSET_DRE;			// Enable data register empty interrupt
	}
}

void Usart1_Putx(uint8_t data)
{
	uint16_t idx = Usart1_TxInWriteIdx;
	if(++idx >= USART1_TX_BFR_SIZE)
		idx = 0;
	
	if(idx == Usart1_TxOutWriteIdx)					// Overrun, buffer still full?
		vTaskDelay(2);								// Wait ff
	
	Usart1_TxBuffer[Usart1_TxInWriteIdx] = data;
	Usart1_TxInWriteIdx = idx;
}

void Usart1_Putc(uint8_t data)
{
	Usart1_Putx(data);
	Usart1_SendStart();
}

void Usart1_PutBfr(uint8_t *data, uint16_t length)
{
#ifdef USART1_DMA
	DMA_Send(USART1_DMA_CHANNEL, data, length);
#else	
	for(uint16_t i = 0; i < length; i++)
		Usart1_Putx(data[i]);
	Usart1_SendStart();
#endif
}