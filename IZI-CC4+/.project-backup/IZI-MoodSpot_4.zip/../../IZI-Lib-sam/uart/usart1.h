/*
 * usartx.h
 *
 * Created: 8-3-2022 08:42:52
 *  Author: Milo
 */ 


#ifndef USART1_H_
#define USART1_H_

#include "usartx.h"

void Usart1_Init(usartx_cb_func_txptr tx_cb, usartx_cb_func_rxptr rx_cb,  usartx_cb_func_errptr err_cb);
void Usart1_Putc(uint8_t data);
void Usart1_PutBfr(uint8_t *data, uint16_t length);

#endif /* USART1_H_ */