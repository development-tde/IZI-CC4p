/*
 * iziplus_networkframe.c
 *
 *  Created on: 23 apr. 2021
 *      Author: Milo
 */

#include "includes.h"
#include "iziplus_networkframe.h"
#include "iziplus_frames.h"

uint16_t iziplus_networkframe_error(uint8_t *data, uint8_t seq_id, uint8_t cmd, uint8_t cmdtype, int8_t result)
{
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->cmd = cmd;
	nw_data->seqid = seq_id;
	nw_data->msgtype.u.cmd_type = cmdtype;
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_RSP;
	nw_data->msgtype.u.sync = 0;
	nw_data->tokenres = result;
	//iziplus_cmd_assign_network_wrsp_t *payload =((iziplus_cmd_assign_network_wrsp_t *)(data + 4));
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_assign_network_wrsp_t);
}

uint16_t iziplus_networkframe_discover(uint8_t *data, uint8_t seq_id, izi_version_u protocol_version)
{
	iziplus_networkframe_error(data, seq_id, IZIPLUS_CMD_DISCOVER, IZIPLUS_CMDTYPE_DISCOVER, IZIPLUS_TOKERES_OK);
	iziplus_cmd_discover_rsp_t *payload =((iziplus_cmd_discover_rsp_t *)(data + 4));
	payload->protocol_version.v.major = protocol_version.v.major;
	payload->protocol_version.v.minor = protocol_version.v.minor;
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_discover_rsp_t);
}

uint16_t iziplus_networkframe_assign_network(uint8_t *data, uint8_t seq_id)
{
	iziplus_networkframe_error(data, seq_id, IZIPLUS_CMD_ASSIGN_NETWORK, IZIPLUS_CMDTYPE_WRITE, IZIPLUS_TOKERES_OK);
	//iziplus_cmd_assign_network_wrsp_t *payload =((iziplus_cmd_assign_network_wrsp_t *)(data + 4));
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_assign_network_wrsp_t); 
}

uint16_t iziplus_networkframe_assign_channelmodewritedelay(uint8_t *data, uint8_t seq_id, uint8_t channels)
{
	iziplus_networkframe_error(data, seq_id, IZIPLUS_CMD_ASSIGN_CHANMODE, IZIPLUS_CMDTYPE_WRITE, IZIPLUS_TOKERES_OK);
	iziplus_cmd_assign_chanmode_wrsp_t *payload =((iziplus_cmd_assign_chanmode_wrsp_t *)(data + 4));
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_DLY;
	payload->amount = channels;
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_assign_chanmode_wrsp_t);
}

uint16_t iziplus_networkframe_assign_channelmodewrite(uint8_t *data, uint8_t seq_id, uint8_t channels)
{
	iziplus_networkframe_error(data, seq_id, IZIPLUS_CMD_ASSIGN_CHANMODE, IZIPLUS_CMDTYPE_WRITE, IZIPLUS_TOKERES_OK);
	iziplus_cmd_assign_chanmode_wrsp_t *payload =((iziplus_cmd_assign_chanmode_wrsp_t *)(data + 4));
	payload->amount = channels;
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_assign_chanmode_wrsp_t);
}

uint16_t iziplus_networkframe_assign_channelmoderead(uint8_t *data, uint8_t seq_id, uint16_t channel, uint8_t mode, uint8_t dmxfail, uint8_t offset, uint8_t channels)
{
	iziplus_networkframe_error(data, seq_id, IZIPLUS_CMD_ASSIGN_CHANMODE, IZIPLUS_CMDTYPE_READ, IZIPLUS_TOKERES_OK);
	iziplus_cmd_assign_chanmode_rrsp_t *payload =((iziplus_cmd_assign_chanmode_rrsp_t *)(data + 4));
	payload->channel = channel;
	payload->mode = mode;
	payload->dmxfail = dmxfail;
	payload->offset = offset;
	payload->amount = channels;
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_assign_chanmode_rrsp_t);
}

uint16_t iziplus_networkframe_assign_configwrite(uint8_t *data, uint8_t seq_id)
{
	return iziplus_networkframe_error(data, seq_id, IZIPLUS_CMD_CONFIG, IZIPLUS_CMDTYPE_WRITE, IZIPLUS_TOKERES_OK);
}

uint16_t iziplus_networkframe_assign_configwritedly(uint8_t *data, uint8_t seq_id)
{
	iziplus_networkframe_error(data, seq_id, IZIPLUS_CMD_CONFIG, IZIPLUS_CMDTYPE_WRITE, IZIPLUS_TOKERES_OK);
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_DLY;
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_config_wrp_t);
}

uint16_t iziplus_networkframe_assign_configread(uint8_t *data, uint8_t seq_id, uint8_t *cfg, uint8_t amount)
{
	iziplus_networkframe_error(data, seq_id, IZIPLUS_CMD_CONFIG, IZIPLUS_CMDTYPE_READ, IZIPLUS_TOKERES_OK);
	iziplus_cmd_config_rrsp_t *payload =((iziplus_cmd_config_rrsp_t *)(data + 4));
	memcpy(payload->config, cfg, amount);
	return sizeof(iziplus_network_data_t) + amount;
}


uint16_t iziplus_networkframe_textwrite(uint8_t *data, uint8_t seq_id)
{
	return iziplus_networkframe_error(data, seq_id, IZIPLUS_CMD_TEXT, IZIPLUS_CMDTYPE_WRITE, IZIPLUS_TOKERES_OK);
}

uint16_t iziplus_networkframe_textwritedly(uint8_t *data, uint8_t seq_id)
{
	iziplus_networkframe_error(data, seq_id, IZIPLUS_CMD_TEXT, IZIPLUS_CMDTYPE_WRITE, IZIPLUS_TOKERES_OK);
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_DLY;
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_text_wrsp_t);
}

uint16_t iziplus_networkframe_textread(uint8_t *data, uint8_t seq_id, uint8_t *text, uint8_t amount)
{
	iziplus_networkframe_error(data, seq_id, IZIPLUS_CMD_TEXT, IZIPLUS_CMDTYPE_READ, IZIPLUS_TOKERES_OK);
	iziplus_cmd_config_rrsp_t *payload =((iziplus_cmd_config_rrsp_t *)(data + 4));
	memcpy(payload->config, text, amount);
	return sizeof(iziplus_network_data_t) + amount;
}

uint16_t iziplus_networkframe_versionread(uint8_t *data, uint8_t seq_id, izi_versionplus_u appversion, izi_versionplus_u bootversion, izi_version_u protversion, izi_version_u typedefversion, izi_versionplus_u imageversion, izi_version_u ledversion, uint8_t memversion, uint8_t hwref, uint8_t variant, bool isnotification)
{
	iziplus_networkframe_error(data, seq_id, IZIPLUS_CMD_VERSIONS, IZIPLUS_CMDTYPE_READ, IZIPLUS_TOKERES_OK);
	if(isnotification)
	{
		iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
		nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_NOT;
	}
	iziplus_cmd_versions_rrsp_t *payload =((iziplus_cmd_versions_rrsp_t *)(data + 4));
	payload->app_version.d = appversion.d;
	payload->boot_version.d = bootversion.d;
	payload->protocol_version.w = protversion.w;
	payload->image_version.d = imageversion.d;
	payload->ledtable_version.w = ledversion.w;
	payload->mem_version = memversion;
	payload->hw_ref = hwref;
	payload->variant = variant;
	payload->typedef_version.w = typedefversion.w;
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_versions_rrsp_t);
}

uint16_t iziplus_networkframe_operationmodewrite(uint8_t *data, uint8_t seq_id, uint8_t pl_freq, uint8_t pl_rate, uint8_t shortid)
{
	iziplus_networkframe_error(data, seq_id, IZIPLUS_CMD_OPERATION_MODE, IZIPLUS_CMDTYPE_WRITE, IZIPLUS_TOKERES_OK);
	iziplus_cmd_operation_mode_rsp_t *payload =((iziplus_cmd_operation_mode_rsp_t *)(data + 4));
	payload->freq = pl_freq;
	payload->rate = pl_rate;
	payload->shortid = shortid;
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_operation_mode_req_t);
}

uint16_t iziplus_networkframe_stateread(uint8_t *data, uint8_t seq_id, uint8_t frame_type, uint16_t cpu_state, uint8_t *monitor, uint8_t amount)
{
	iziplus_networkframe_error(data, seq_id, IZIPLUS_CMD_STATE, IZIPLUS_CMDTYPE_READ, IZIPLUS_TOKERES_OK);
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->msgtype.u.frame_type = frame_type;
	
	iziplus_cmd_state_rsp_t *payload =((iziplus_cmd_state_rsp_t *)(data + 4));
	payload->cpu_state = cpu_state;
	memcpy(payload->data, monitor, amount);
	return sizeof(iziplus_network_data_t) + amount + 2;
}

uint16_t iziplus_networkframe_contactaction(uint8_t *data, uint8_t seq_id, uint8_t event_id, uint8_t contacts)
{
	iziplus_networkframe_error(data, seq_id, IZIPLUS_CMD_CONTACTTRIGGER, IZIPLUS_CMDTYPE_ACTION, IZIPLUS_TOKERES_OK);
	iziplus_cmd_contacttrigger_not_t *payload =((iziplus_cmd_contacttrigger_not_t *)(data + 4));
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_NOT;
	payload->contacts = contacts;
	payload->event_id = event_id;
	payload->option.w = 0;
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_contacttrigger_not_t) - 1;
}

uint16_t iziplus_networkframe_contactanalogaction(uint8_t *data, uint8_t seq_id, uint8_t event_id, uint8_t contacts, uint16_t value)
{
	iziplus_networkframe_error(data, seq_id, IZIPLUS_CMD_CONTACTTRIGGER, IZIPLUS_CMDTYPE_ACTION, IZIPLUS_TOKERES_OK);
	iziplus_cmd_contacttrigger_not_t *payload =((iziplus_cmd_contacttrigger_not_t *)(data + 4));
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_NOT;
	payload->contacts = contacts;
	payload->event_id = event_id;
	payload->option.analog.value = value;
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_contacttrigger_not_t);
}

uint16_t iziplus_networkframe_contactencaction(uint8_t *data, uint8_t seq_id, uint8_t event_id, uint8_t contacts, int8_t encoder, uint8_t encoder_press)
{
	iziplus_networkframe_error(data, seq_id, IZIPLUS_CMD_CONTACTTRIGGER, IZIPLUS_CMDTYPE_ACTION, IZIPLUS_TOKERES_OK);
	iziplus_cmd_contacttrigger_not_t *payload =((iziplus_cmd_contacttrigger_not_t *)(data + 4));
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_NOT;
	payload->contacts = contacts;
	payload->event_id = event_id;
	payload->option.encoder.press = encoder_press;
	payload->option.encoder.delta = encoder;
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_contacttrigger_not_t);
}

uint16_t iziplus_networkframe_joinnetworkaction(uint8_t *data, uint8_t seq_id, uint32_t pan_id, izi_version_u protocol_version)
{
	iziplus_networkframe_error(data, seq_id, IZIPLUS_CMD_JOINNETWORK, IZIPLUS_CMDTYPE_ACTION, IZIPLUS_TOKERES_OK);
	iziplus_cmd_joinnetwork_not_t *payload =((iziplus_cmd_joinnetwork_not_t *)(data + 4));
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_NOT;
	payload->pan_id = pan_id;
	payload->protocol_version.v.major = protocol_version.v.major;
	payload->protocol_version.v.minor = protocol_version.v.minor;
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_joinnetwork_not_t);
}


uint16_t iziplus_networkframe_identifyaction(uint8_t *data, uint8_t seq_id)
{
	iziplus_networkframe_error(data, seq_id, IZIPLUS_CMD_IDENTIFY, IZIPLUS_CMDTYPE_ACTION, IZIPLUS_TOKERES_OK);
	//iziplus_cmd_identify_rsp_t *payload =((iziplus_cmd_identify_rsp_t *)(data + 4));
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_identify_rsp_t);
}

uint16_t iziplus_networkframe_identifyaction_not(uint8_t *data, uint8_t seq_id)
{
	iziplus_networkframe_error(data, seq_id, IZIPLUS_CMD_IDENTIFY, IZIPLUS_CMDTYPE_ACTION, IZIPLUS_TOKERES_OK);
	iziplus_cmd_identify_not_t *payload =((iziplus_cmd_identify_not_t *)(data + 4));
	payload->time = 0;
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_NOT;
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_identify_not_t);
}

uint16_t iziplus_networkframe_identifytimeaction_not(uint8_t *data, uint8_t seq_id, uint8_t time)
{
	iziplus_networkframe_error(data, seq_id, IZIPLUS_CMD_IDENTIFY, IZIPLUS_CMDTYPE_ACTION, IZIPLUS_TOKERES_OK);
	iziplus_cmd_identify_not_t *payload =((iziplus_cmd_identify_not_t *)(data + 4));
	payload->time = time;
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_NOT;
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_identify_not_t);
}

uint16_t iziplus_networkframe_firmwarewrite(uint8_t *data, uint8_t seq_id)
{
	iziplus_networkframe_error(data, seq_id, IZIPLUS_CMD_FW_WRITE, IZIPLUS_CMDTYPE_WRITE, IZIPLUS_TOKERES_OK);
	//iziplus_cmd_fw_write_wrsp_t *payload =((iziplus_cmd_fw_write_wrsp_t *)(data + 4));
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_fw_write_wrsp_t);
}

uint16_t iziplus_networkframe_firmwarewritedly(uint8_t *data, uint8_t seq_id)
{
	iziplus_networkframe_error(data, seq_id, IZIPLUS_CMD_FW_WRITE, IZIPLUS_CMDTYPE_WRITE, IZIPLUS_TOKERES_OK);
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_DLY;
	//iziplus_cmd_fw_write_wrsp_t *payload =((iziplus_cmd_fw_write_wrsp_t *)(data + 4));
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_fw_write_wrsp_t);
}

uint16_t iziplus_networkframe_firmwareapply(uint8_t *data, uint8_t seq_id)
{
	iziplus_networkframe_error(data, seq_id, IZIPLUS_CMD_FW_APPLY, IZIPLUS_CMDTYPE_WRITE, IZIPLUS_TOKERES_OK);
	//iziplus_cmd_fw_apply_wrp_t *payload =((iziplus_cmd_fw_apply_wrp_t *)(data + 4));
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_fw_apply_wrp_t);
}

uint16_t iziplus_networkframe_firmwareapplydly(uint8_t *data, uint8_t seq_id)
{
	iziplus_networkframe_error(data, seq_id, IZIPLUS_CMD_FW_APPLY, IZIPLUS_CMDTYPE_WRITE, IZIPLUS_TOKERES_OK);
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_DLY;
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_fw_apply_wrp_t);
}

uint16_t iziplus_networkframe_firmwareallow(uint8_t *data, uint8_t seq_id, izi_versionplus_u appversion)
{
	iziplus_networkframe_error(data, seq_id, IZIPLUS_CMD_FW_ALLOW, IZIPLUS_CMDTYPE_ACTION, IZIPLUS_TOKERES_OK);
	iziplus_cmd_fw_allow_wrp_t *payload = ((iziplus_cmd_fw_allow_wrp_t *)(data + 4));
	payload->app_version.d = appversion.d;
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_fw_allow_wrp_t);
}

uint16_t iziplus_networkframe_production_data_write(uint8_t *data, uint8_t seq_id)
{
	return iziplus_networkframe_error(data, seq_id, IZIPLUS_CMDTYPE_PRODUCTION_DATA, IZIPLUS_CMDTYPE_WRITE, IZIPLUS_TOKERES_OK);
}

uint16_t iziplus_networkframe_production_data_read(uint8_t *data, uint8_t seq_id, uint8_t *proddata, uint8_t length)
{
	iziplus_networkframe_error(data, seq_id, IZIPLUS_CMDTYPE_PRODUCTION_DATA, IZIPLUS_CMDTYPE_READ, IZIPLUS_TOKERES_OK);
	iziplus_cmd_production_data_rrsp_t *payload =((iziplus_cmd_production_data_rrsp_t *)(data + 4));
	uint8_t amount = length > IZIPLUS_CMD_PRODUCTION_DATA_SIZE ? IZIPLUS_CMD_PRODUCTION_DATA_SIZE : length;
	memcpy(payload->data, proddata, amount);
	return sizeof(iziplus_network_data_t) + amount;
}