/*
 * smart_eeprom.c
 *
 * Created: 10-9-2021 10:47:43
 *  Author: Milo
 */ 

#include "includes.h"
#include "smart_eeprom.h"
#include "hpl_user_area.h"

#ifdef ATSAMC21
#include "nv.h"
#include "nv_storage.h"

bool Eeprom_init()
{
	nv_init(&FLASH_0);
	nv_storage_init();
	
	return true;
} 

bool Eeprom_Read(uint16_t offset, void *buff, size_t bufflen)
{
	if(offset + bufflen > EEPROM_SIZE)
		return false;
		
	return nv_storage_read(1, 0, buff, bufflen) == ERR_NONE;
}

bool Eeprom_Write(uint16_t offset, const void *buff, size_t bufflen)
{
	if(offset + bufflen > EEPROM_SIZE)
		return false;
	
	return nv_storage_write(1, 0, buff, bufflen) == ERR_NONE;
}

bool Eeprom_ReadProd(void *buff, size_t bufflen)
{
	return nv_storage_read(2, 0, buff, bufflen) == ERR_NONE;
}

bool Eeprom_WriteProd(const void *buff, size_t bufflen)
{
	return nv_storage_write(2, 0, buff, bufflen) == ERR_NONE;
}

#else

bool Eeprom_init()
{
	uint8_t user[20];
	_user_area_read((void *)0x804000, 0, user, sizeof(user));
	
	if(user[4] != 0xB1)			// Check if smartEEPROM is reserved
	{
	/* 35:32 SEESBLK Number of NVM Blocks composing a SmartEEPROM sector NVMCTRL 0x0
	   38:36 SEEPSZ SmartEEPROM Page Size NVMCTRL 0x0*/
		user[4] = 0xB1;		// Virtual size: 4K, allocated size: 16K
		_user_area_write((void *)0x804000, 4, (const uint8_t *)&user[4], 1);
		return true;
	}	
	return false;
} 

static void Eeprom_wait_busy(void)
{
	while ((NVMCTRL->SEESTAT.reg & NVMCTRL_SEESTAT_BUSY) != 0)
	;
}

bool Eeprom_Read(uint16_t offset, void *buff, size_t bufflen)
{
	if(offset + bufflen > EEPROM_SIZE)
		return false;
		
	Eeprom_wait_busy();
	memcpy(buff, (const void *)(SEEPROM_ADDR + offset), bufflen);
	
	return true;
}

bool Eeprom_Write(uint16_t offset, const void *buff, size_t bufflen)
{
	if(offset + bufflen > EEPROM_SIZE)
		return false;
	
	/* XXX: Should probably assert bufflen <= SmartEEPROM size */
	Eeprom_wait_busy();
	memcpy((void *)(SEEPROM_ADDR + offset), buff, bufflen);
	Eeprom_wait_busy();
	if ((NVMCTRL->SEESTAT.reg & NVMCTRL_SEESTAT_LOAD) != 0) {
		NVMCTRL->CTRLB.reg = NVMCTRL_CTRLB_CMDEX_KEY | NVMCTRL_CTRLB_CMD_SEEFLUSH;
		//Eeprom_wait_busy();
	}
	return true;
}

#endif
