/*
 * rtc_time.h
 *
 * Created: 2-9-2021 16:08:04
 *  Author: Milo
 */ 


#ifndef RTC_TIME_H_
#define RTC_TIME_H_


uint32_t RtcTime_GetSeconds();
void RtcTime_SetTime(uint32_t time);
void RtcTime_Tick();


#endif /* RTC_TIME_H_ */