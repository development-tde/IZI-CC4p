/*
 * rtc_time.c
 *
 * Created: 2-9-2021 16:07:47
 *  Author: Milo
 */ 

#include "includes.h"
#include "rtctime.h"

static uint32_t rtc_time = 0;

uint32_t RtcTime_GetSeconds()
{
	return rtc_time;
}

void RtcTime_SetTime(uint32_t time)
{
	rtc_time = time;
}

void RtcTime_Tick()
{
	rtc_time++;
}