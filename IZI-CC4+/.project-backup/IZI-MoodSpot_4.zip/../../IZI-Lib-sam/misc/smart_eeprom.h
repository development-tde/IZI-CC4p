/*
 * smart_eeprom.h
 *
 * Created: 10-9-2021 10:48:10
 *  Author: Milo
 */ 


#ifndef SMART_EEPROM_H_
#define SMART_EEPROM_H_

#define EEPROM_SIZE			4096			// 4k, but 16k is needed

#define EEPROM_APPCFG		0				// Only 512 bytes

// PowerCom -> Todo: move to own project
#define EEPROM_MODULES		0x0400			// 3k for modules
#define EEPROM_MODULES_END	0x1000			// 4k total

// CC2+ -> Todo: move to own project
// 1k free
#define EEPROM_CALIBRATE	0x0800			// 128b for calibration data

#define EEPROM_LOG			0x0C00			// 128b for log data

// 2k - 128b free
#define EEPROM_END			0x1000			// 4k total

bool Eeprom_init(); 
bool Eeprom_Read(uint16_t offset, void *buff, size_t bufflen);
bool Eeprom_Write(uint16_t offset, const void *buff, size_t bufflen);
#ifdef ATSAMC21
bool Eeprom_ReadProd(void *buff, size_t bufflen);
bool Eeprom_WriteProd(const void *buff, size_t bufflen);
#endif

#endif /* SMART_EEPROM_H_ */