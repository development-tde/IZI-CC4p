/*
 * izi_can_driver.h
 *
 *  Created on: 29 jun. 2020
 *      Author: Milo
 */

#ifndef IZI_CAN_DRIVER_H_
#define IZI_CAN_DRIVER_H_

#include "izi_can_frame.h"

extern trace_level_t izi_can_trace_lvl;

#define IZI_CAN_PREFIX	"[can]\t"

#ifndef IZI_CAN_TRACE_BUILD_LVL
#define IZI_CAN_TRACE_BUILD_LVL	-1
#endif

#if IZI_CAN_TRACE_BUILD_LVL >= 0
#define IZI_CAN_TRACE_ERROR(...)		{ if(izi_can_trace_lvl >= TRACE_LEVEL_ERROR)		{ esp_printf(Debug_Putc, IZI_CAN_PREFIX, __VA_ARGS__); } }
#else
#define IZI_CAN_TRACE_ERROR(...)
#endif
#if IZI_CAN_TRACE_BUILD_LVL >= 1
#define IZI_CAN_TRACE_WARNING(...)		{ if(izi_can_trace_lvl >= TRACE_LEVEL_WARNING)	{ esp_printf(Debug_Putc, IZI_CAN_PREFIX, __VA_ARGS__); } }
#else
#define IZI_CAN_TRACE_WARNING(...)
#endif
#if IZI_CAN_TRACE_BUILD_LVL >= 2
#define IZI_CAN_TRACE_INFO(...)			{ if(izi_can_trace_lvl >= TRACE_LEVEL_INFO)		{ esp_printf(Debug_Putc, IZI_CAN_PREFIX, __VA_ARGS__); } }
#else
#define IZI_CAN_TRACE_INFO(...)
#endif
#if IZI_CAN_TRACE_BUILD_LVL >= 3
#define IZI_CAN_TRACE_DEBUG(...)		{ if(izi_can_trace_lvl >= TRACE_LEVEL_DEBUG)		{ esp_printf(Debug_Putc, IZI_CAN_PREFIX, __VA_ARGS__); } }
#else
#define IZI_CAN_TRACE_DEBUG(...)
#endif
#if IZI_CAN_TRACE_BUILD_LVL >= 4
#define IZI_CAN_TRACE_VERBOSE(...)		{ if(izi_can_trace_lvl >= TRACE_LEVEL_DEBUG)		{ esp_printf(Debug_Putc, IZI_CAN_PREFIX, __VA_ARGS__); } }
#else
#define IZI_CAN_TRACE_VERBOSE(...)
#endif

typedef struct izi_can_rxflags_s
{
	uint16_t xtd : 1;			// std = 0, ext = 1
}izi_can_rxflags_t;

#define STDID_OFFSET (18U)

#define IZI_CAN_MULTISTATE_IDLE		0

#define IZI_CAN_MULTI_TIMEOUT		100

#define IZI_CAN_MAX_REQ_RETRY		3				// = number of attempts

#define IZI_CAN_SEQ_AUTO			0xFF

typedef struct izi_can_rxmultiframe_s
{
	uint32_t id;
	uint16_t time;					// From can driver
	uint16_t length;
	izi_can_rxflags_t flags;
	uint16_t state;
	TickType_t ticks;				// Used for multiframe timing
	uint8_t data[MAX_LENGTH_MULTI];
}izi_can_rxmultiframe_t;

typedef struct izi_can_rxframe_s
{
	uint32_t id;
	uint16_t time;					// From can driver
	uint16_t length;
	izi_can_rxflags_t flags;
	uint16_t state;
	TickType_t ticks;				// Used for multiframe timing
	uint8_t data[MAX_LENGTH_SINGLE];
}izi_can_rxframe_t;


typedef struct izi_can_errflags_s
{
	uint32_t fifo_full : 1; 		/*!< Fifo overflow. */
	uint32_t fifo_lost : 1; 	/*!< CAN Frame Type(STD or EXT). */
	uint32_t bus_err : 1; 		/*!< MCAN Module Error and Status */
	uint32_t unhandled_int : 1; /*!< Unhandled Interrupt asserted. */
}izi_can_errflags_t;

typedef union
{
	izi_can_errflags_t flags;
	uint32_t all;
}izi_can_errflags_u;

#define IZI_CAN_OK				0			// All handled ok
#define IZI_CAN_ERR_TX_ERR		-1			// Error sending message
#define IZI_CAN_ERR_NO_TXBFR	-2			// No tx buffer free
#define IZI_CAN_ERR_DATA		-3			// Invalid data
#define IZI_CAN_ERR_LENGTH		-4			// Incorrect or unsupported length
#define IZI_CAN_ERR_NOINIT		-5			// Can not initialised or resetting
#define IZI_CAN_ERR_NORSP		-6			// No response to request

typedef void (*izi_can_receive_callback_t)(izi_can_rxframe_t *);
typedef bool (*izi_can_receive_int_callback_t)(struct can_message *);

// Proto
void izican_driver_init(uint8_t address);
void izican_debug(uint8_t *data, uint8_t length);
#if	IZI_CAN_MASTER > 0
int8_t izican_senddmx(uint8_t universe, uint8_t *data, uint16_t length);
#endif
int8_t izican_sendcommand(uint8_t address, uint8_t devtype_group, uint8_t cmd, uint8_t msg_type, uint8_t *data, uint16_t length, uint8_t seq_id);
void izican_extended_timeout(uint32_t to);
int8_t izican_sendcommand_req(uint8_t address, uint8_t devtype_group, uint8_t cmd, uint8_t *data, uint16_t length, izican_response_data_t *rsp);
void izican_set_callback(izi_can_receive_callback_t cb);
void izican_set_int_callback(izi_can_receive_int_callback_t cb);
void izican_set_slave_address(uint8_t address);
bool izican_bus_ok();

extern const uint8_t fd_len[16];

#endif /* IZI_CAN_DRIVER_H_ */
