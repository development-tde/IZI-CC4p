/*
 * production.h
 *
 * Created: 9-9-2021 17:14:26
 *  Author: Milo
 */ 


#ifndef PRODUCTION_H_
#define PRODUCTION_H_

typedef struct proddata_s {
	uint32_t serial;
	char batch[11];
	char plant;
	uint32_t time;
	char info[12];
} proddata_t;

typedef union {
	proddata_t v;
	uint8_t data[16];
} proddata_u;

#ifdef ATSAMC21
extern proddata_t production_data;

#define PRODUCTION_DATA ((proddata_t *)&production_data)
#define PRODUCTION_SERIAL (production_data.serial)
#define PRODUCTION_BATCH  (production_data.batch)
#define PRODUCTION_PLANT  (production_data.plant)
#else
#define PRODUCTION_DATA ((proddata_t *)0x804020)
#define PRODUCTION_SERIAL ((proddata_t *)0x804020)->serial
#define PRODUCTION_BATCH  ((proddata_t *)0x804020)->batch
#define PRODUCTION_PLANT  ((proddata_t *)0x804020)->plant
#endif

// Proto
int32_t Production_Write(uint32_t serial, char *batch, char plant, uint32_t time, char* info);
int32_t Production_WriteStruct(proddata_t *data);
int32_t Production_Read(proddata_t *data);

#endif /* PRODUCTION_H_ */