/*
 * production.c
 *
 * Created: 9-9-2021 17:14:13
 *  Author: Milo
 */ 

#include "includes.h"
#include "production.h"
#include "hpl_user_area.h"
#include "smart_eeprom.h"

int32_t Production_Write(uint32_t serial, char *batch, char plant, uint32_t time, char* info)
{
	proddata_t data;
	data.serial = serial;
	strncpy(data.batch, batch, sizeof(data.batch));
	data.plant = plant;
	data.time = time;
	strncpy(data.info, info, sizeof(data.info));
	
#ifdef ATSAMC21
	return _rww_flash_write(&FLASH_0.dev, NVMCTRL_RWW_EEPROM_ADDR + 0xFC0, (uint8_t *)&data, sizeof(proddata_t));//Eeprom_WriteProd( (const uint8_t *)&data, sizeof(data));
#else	
	return _user_area_write((void *)0x804000, 32, (const uint8_t *)&data, sizeof(data));
#endif	
}

int32_t Production_WriteStruct(proddata_t *data)
{
#ifdef ATSAMC21
	return _rww_flash_write(&FLASH_0.dev, NVMCTRL_RWW_EEPROM_ADDR + 0xFC0, (uint8_t *)data, sizeof(proddata_t));//Eeprom_WriteProd( (const uint8_t *)&data, sizeof(data));//Eeprom_WriteProd( (const uint8_t *)&data, sizeof(data));
#else
	return _user_area_write((void *)0x804000, 32, (const uint8_t *)&data, sizeof(data));
#endif	
}

#ifdef ATSAMC21
int32_t Production_Read(proddata_t *data)
{
	return _rww_flash_read(&FLASH_0.dev, NVMCTRL_RWW_EEPROM_ADDR + 0xFC0, (uint8_t *)data, sizeof(proddata_t));
}
#endif
