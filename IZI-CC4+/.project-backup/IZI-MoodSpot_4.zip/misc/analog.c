/*
 * analog.c
 *
 *  Created on: 9 dec. 2020
 *      Author: Milo
 */

#include "includes.h"
#include "analog.h"
#include "timers.h"
#include <hpl_adc_base.h>
#include <hal_adc_async.h>
//#include "izican/izi_can_slave.h"
#include "izilink/iziplus_driver.h"
#include "peripheral_clk_config.h"
#include "hpl_tcc_config.h"

#define ADC_CLK_APBXMASK			((Mclk *)MCLK)->APBDMASK.bit.ADC1_
#define ADC_CLK_GCLK_ID				41 //(40 = ADC0)			// Check PCHCTRL in datasheet for index of peripheral
#define ADC_INT0					ADC1_0_Handler
#define ADC_INT1					ADC1_1_Handler

#define ADC_INT0_NR					ADC1_0_IRQn			// Overrun/Window
#define ADC_INT1_NR					ADC1_1_IRQn			// Result ready
#define ADC_INT_PRIO				configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 2

#define ADC_REG						ADC1

#ifndef _NVM_SW_CALIB_AREA_BASE
#define _NVM_SW_CALIB_AREA_BASE 0x00800080
#endif

#ifndef ADC_CLK_PCHCTRL
#define ADC_CLK_PCHCTRL				GCLK_PCHCTRL_GEN_GCLK1_Val
#endif

#define ANALOG_TIMEROS_TICKS		125

#ifdef PCB_REV6
#define ANALOG_REF_VOLTAGE			250000UL		// 2500.0mV, problem ref is power supply which can be +/-1.5% off
#define	ANALOG_SUPPLY_VOLT_RATIO	4123UL			// 41.23mV is one volt (* 100 just like ANALOG_REF_VOLTAGE)
#else
#define ANALOG_REF_VOLTAGE			100000UL		// 1000.0mV, problem ref is power supply which can be +/-1.5% off
#define	ANALOG_SUPPLY_VOLT_RATIO	1449UL			// 14.45mV is one volt (* 100 just like ANALOG_REF_VOLTAGE)
#endif
#ifdef PCB_REV6
#define ANALOG_SUPPLY_VOLT_OFFSET	0				// Offset in mV over diode and fuse
#else
#define ANALOG_SUPPLY_VOLT_OFFSET	435				// Offset in mV over diode and fuse
#endif
#define ANALOG_SECOND_PRS			(1000/ANALOG_TIMEROS_TICKS)				// Second prescaler in timer
#ifdef PCB_REV6
#define	ANALOG_OUT1_CURRENT_RATIO	250000UL		// (* 100 just like ANALOG_REF_VOLTAGE)
#define ANALOG_OUT1_CURRENT_OFFSET	0				// Offset ??
#define	ANALOG_OUT2_CURRENT_RATIO	125000UL		// (* 100 just like ANALOG_REF_VOLTAGE)
#define ANALOG_OUT2_CURRENT_OFFSET	0				// Offset ??
#else
#define	ANALOG_OUT1_CURRENT_RATIO	75343UL			// (* 100 just like ANALOG_REF_VOLTAGE)
#define ANALOG_OUT1_CURRENT_OFFSET	0				// Offset ??
#endif

#define ANALOG_SUPPLY_VOLT_HIGH		52500			// 53.3V - 1.5% fout marge,  max supply voltage
#define ANALOG_SUPPLY_VOLT_LOW		44000			// 44V and lower is not ok
#define ANALOG_SUPPLY_VOLT_HYST		1000			// 1 V hysteresis
#define ANALOG_TEMPERATURE_HIGH		85				// 85 degrees processor temp is too high
#define ANALOG_TEMPERATURE_WARN		65				// 65 degrees processor temp is worth a warning
#define ANALOG_TEMPERATURE_HYST		2				// 2 degrees hysteresis
#define ANALOG_TEMPERATURE_DELTA	5				// If temp is more or equal than previous logged value log again
#define ANALOG_CURRENT_HIGH			11000			// 11.0A
#define ANALOG_CURRENT_WARN			10300			// 10.3A is worth a warning (must differ at least ANALOG_CURRENT_HYST with ANALOG_CURRENT_HIGH!!)
#define ANALOG_CURRENT_HYST			300				// 0.3A hysteresis
#define ANALOG_CURRENT_SWITCH		9800			// Switch to 20A measure at 9.8 A

#define ANALOG_CALIBRATE_VOLTAGE	122500UL		// 1.225V voltage ref
#define ANALOG_VBOOST_SUPPLY_DIFF	10000			// in mV what is the minimum diff between supply_voltage and vboost

#define ANALOG_MAX_ENERGY_BFR		20				// 3 * 20 = 1 hour

#define ADC_CHANNELS_MAX			6				// 6 values measured

typedef struct energy_log_s
{
	uint32_t power;
	uint32_t energy;
	uint32_t energy_total;
	uint16_t samples;
	uint16_t energy_bfr_idx; 
	uint16_t energy_bfr[ANALOG_MAX_ENERGY_BFR];
	uint16_t loops;
	uint16_t crc;
}energy_log_t;

// Globals
		volatile uint32_t analog_avg_supply_voltage, analog_avg_out_current, analog_avg_out_current20, analog_avg_out_current_max, analog_avg_output_voltage;
		volatile uint32_t analog_avg_out_current_offset = 0, analog_avg_out_current20_offset;
		int16_t analog_avg_temperature;
		uint16_t analog_avg_temperature_logged;
		
static volatile bool adc_calc_busy = false;
static volatile uint8_t adc_calibrate = 0;
static volatile uint32_t adc_calibrate_val = 0;
static volatile bool adc_calibrate_busy = false;
static volatile uint32_t adc_calibrate_offset = 0;
static volatile uint32_t adc_calibrate_gain = 1000UL;

	   volatile uint16_t adc_channel_val[ADC_CHANNELS_MAX];
	   volatile uint16_t adc_channel_sel = 0;
static volatile uint32_t adc_current_avg_total;
static volatile uint16_t adc_current_avg_cnt;
		
//static energy_log_t __attribute__ ((section (".energy_ram"))) energy_log;

static char text[LOG_TEXT_SIZE + 8];
static uint32_t analog_log_prs = 0;
static uint8_t analog_init = 2 * ANALOG_SECOND_PRS;		// Extend first log and check for 0 sec (2 - 1)

const uint32_t g_Adc_12bitFullRange = 4096U;

TimerHandle_t  xAnalog_Timer = NULL;

//static int conversions = 0;

static volatile int channel_index = 0, res; 
static uint8_t hw_ref;

#define BOOST_PERIOD_HZ				3600
#define BOOST_FREQ					((CONF_GCLK_TCC4_FREQUENCY / (1 << CONF_TCC4_PRESCALER)) / BOOST_PERIOD_HZ)
#define BOOST_DUTY_PERCENT(p)		(p * BOOST_FREQ)/100

const uint8_t adc_channels[ADC_CHANNELS_MAX] = { ADC_INPUTCTRL_MUXPOS_AIN3, ADC_INPUTCTRL_MUXPOS_AIN1, ADC_INPUTCTRL_MUXPOS_AIN6, ADC_INPUTCTRL_MUXPOS_AIN8, ADC_INPUTCTRL_MUXPOS_AIN7, ADC_INPUTCTRL_MUXPOS_AIN9 };

#define AD_CHAN_CURRENT		0
#define AD_CHAN_VOUT		1
#define AD_CHAN_VSUPPLY		2
#define AD_CHAN_TIN			3
#define AD_CHAN_CURRENT_20A	4
#define AD_CHAN_REFERENCE	5

// Proto
void Analog_125ms(TimerHandle_t xTimer);
#ifdef PCB_REV6	
extern const int8_t ntc_table[512];
#else
extern const uint8_t ntc_table[512];
#endif
void Analog_Boot_Init();

//void analog_pint_intr_callback(const struct adc_async_descriptor *const descr, const uint8_t channel)
void EIC_14_Handler(void)
{
#ifdef PCB_REV6		
	//IziPlus_PowerProtectShutdown();
#endif
	EIC->INTFLAG.reg = EIC_INTFLAG_EXTINT(1 << 14);
}

void Analog_OverCurrent_Init()
{
	// See system_init in Driver_init.c
}

/**
 *
 */
void Analog_Init()
{
	MCLK_CRITICAL_SECTION_ENTER();
	ADC_CLK_APBXMASK = 1;
	MCLK_CRITICAL_SECTION_LEAVE();
	
	hri_gclk_write_PCHCTRL_reg(GCLK, ADC_CLK_GCLK_ID, ADC_CLK_PCHCTRL | (1 << GCLK_PCHCTRL_CHEN_Pos));		// Set to Generic clock generator 1 = 1MHz
	
	ADC_REG->CTRLA.bit.SWRST = ADC_CTRLA_SWRST;
	while ((ADC_REG->SYNCBUSY.reg) & ADC_SYNCBUSY_SWRST) {
	};
	
	ADC_REG->INTENSET.reg = ADC_INTENSET_RESRDY;
	ADC_REG->INPUTCTRL.reg = ADC_INPUTCTRL_MUXPOS_AIN0;// | ADC_INPUTCTRL_MUXNEG_GND;
	ADC_REG->CTRLB.reg = 0;
	ADC_REG->REFCTRL.reg = ADC_REFCTRL_REFCOMP;

#ifdef PCB_REV6	
	SUPC->VREF.reg = SUPC_VREF_SEL_2V5;
#else
	SUPC->VREF.reg = 0;//SUPC_VREF_VREFOE;
#endif	
		
	ADC_REG->CTRLA.reg = ADC_CTRLA_PRESCALER_DIV32;
	ADC_REG->SAMPCTRL.reg = ADC_SAMPCTRL_SAMPLEN(38);		// 38 clock cycles per sample -> 12-bit + 38 = 50 cycles per sample -> (48MHz / 32) = 1.5MHz) / 50 -> 30.0kHz sampling -> avaraging 4 = 7.5kHz / ADC_CHANNELS_MAX = 1.25kHz per channel (measured 7.22kHz iso 7.5kHz caused by interrupt delay -> 1.2kHz per channel)
	ADC_REG->AVGCTRL.reg = ADC_AVGCTRL_SAMPLENUM_4 |  ADC_AVGCTRL_ADJRES(2);
	
	uint16_t calval = ((uint16_t *)_NVM_SW_CALIB_AREA_BASE)[1];
	ADC_REG->CALIB.reg = (calval & 0x07) | ((calval & 0x38) << 5) | ((calval & 0x1C0) >> 3);		// Search for 'NVM Software Calibration Area Mapping' in datasheet
		
	ADC_REG->CTRLA.bit.ENABLE = true;		// INTREF (internal bandgap reference), Reference buffer offset compensation is enabled
	
	NVIC_DisableIRQ(ADC_INT1_NR);
	NVIC_ClearPendingIRQ(ADC_INT1_NR);
	NVIC_SetPriority(ADC_INT1_NR, ADC_INT_PRIO);					// Prio 0 is highest, 7 is lowest
	NVIC_EnableIRQ(ADC_INT1_NR);
	
	// GND offset ref
	gpio_set_pin_direction(AD_GND_REF, GPIO_DIRECTION_OFF);
	gpio_set_pin_function(AD_GND_REF, AD_GND_REF_AD);
	
	// Max 10A measurement
	gpio_set_pin_direction(ADC_OUT10, GPIO_DIRECTION_OFF);
	gpio_set_pin_function(ADC_OUT10, ADC_OUT10_AD);

	// Temp measure
	gpio_set_pin_direction(ADC_TIN, GPIO_DIRECTION_OFF);
	gpio_set_pin_function(ADC_TIN, ADC_TIN_AD);

	// Input voltage
	gpio_set_pin_direction(ADC_VIN, GPIO_DIRECTION_OFF);
	gpio_set_pin_function(ADC_VIN, ADC_VIN_AD);

#ifdef PCB_REV6		
	// Voltage ref
	gpio_set_pin_direction(ADC_REF, GPIO_DIRECTION_OFF);
	gpio_set_pin_function(ADC_REF, ADC_REF_AD);
	
	// Output voltage
	gpio_set_pin_direction(ADC_VOUT, GPIO_DIRECTION_OFF);
	gpio_set_pin_function(ADC_VOUT, ADC_VOUT_AD);
	
	// Max 20A measure
	gpio_set_pin_direction(ADC_OUT20, GPIO_DIRECTION_OFF);
	gpio_set_pin_function(ADC_OUT20, ADC_OUT20_AD);
#endif

#if 0
	vTaskDelay(2);
	
	adc_calibrate_val = 0;
	adc_calibrate = 16;
	ADC_REG->SWTRIG.bit.START = true;
	
	adc_calibrate_busy = true;
	
	while(adc_calibrate > 0) vTaskDelay(2);
	
	adc_calibrate_offset = adc_calibrate_val / 16;

#ifdef PCB_REV6	
	ADC_REG->INPUTCTRL.reg = ADC_INPUTCTRL_MUXPOS_AIN9;			// Voltage ref
	adc_calibrate_val = 0;
	adc_calibrate = 16;
	
	ADC_REG->SWTRIG.bit.START = true;
	
	while(adc_calibrate > 0) vTaskDelay(2);
	
	adc_calibrate_gain = (((g_Adc_12bitFullRange * ANALOG_CALIBRATE_VOLTAGE) / ANALOG_REF_VOLTAGE) * 1000UL) / ((adc_calibrate_val - (16*adc_calibrate_offset)) / 16);		
#endif	
#else
	adc_calibrate_val = 0;
#endif
	adc_calibrate_busy = false;
	ADC_REG->SWTRIG.bit.START = true;			// Start regular
	
	analog_avg_out_current_max = 0;
	adc_current_avg_total = adc_current_avg_cnt = 0;
	
	//if(energy_log.crc != Crc16Fast(&energy_log, sizeof(energy_log) - 2, 0))
	//	memset(&energy_log, 0, sizeof(energy_log));
	
	if(xAnalog_Timer == NULL)
		xAnalog_Timer = xTimerCreate("Analog_Timer", ANALOG_TIMEROS_TICKS, pdTRUE, ( void * ) 0, Analog_125ms);

	if(xAnalog_Timer == NULL)
	{
		GEN_TRACE_INFO("Timer not created analog");				// Todo: what to do
	}
	else if( xTimerStart(xAnalog_Timer, 0) != pdPASS )
	{
		GEN_TRACE_INFO("Timer not started analog");				// Todo: what to do
	}
	Analog_OverCurrent_Init();
	hw_ref = get_hw_id();
	//if(hw_ref >= 2)
	//	Analog_Boot_Init();
}

void ADC_INT1(void)
{
	if(!adc_calibrate_busy)
	{
		uint16_t oldVal = adc_channel_val[adc_channel_sel];
		uint16_t newVal = ADC_REG->RESULT.reg;
		if(newVal >= adc_calibrate_offset)
			newVal -= adc_calibrate_offset;
		else
			newVal = 0;
		
		uint16_t calcVal;
		if(newVal != oldVal)
		{
			if(oldVal < newVal)
			{
				calcVal = (uint16_t)(oldVal + ((newVal - oldVal) >> 4));
				if(oldVal == calcVal)
					calcVal++;
			}
			else
			{
				calcVal = (uint16_t)(oldVal - ((oldVal - newVal) >> 4));
				if(oldVal == calcVal)
					calcVal--;
			}
			adc_channel_val[adc_channel_sel] = calcVal;
		}
		if(adc_channel_sel == AD_CHAN_CURRENT)
		{
			adc_current_avg_total += newVal;
			adc_current_avg_cnt++;
		}
		if(++adc_channel_sel >= ADC_CHANNELS_MAX)
			adc_channel_sel = 0;
		
		ADC_REG->INPUTCTRL.reg = adc_channels[adc_channel_sel];
		ADC_REG->SWTRIG.bit.START = true;
	}
	else if(adc_calibrate > 0)
	{
		adc_calibrate_val += ADC_REG->RESULT.reg;
		if(--adc_calibrate > 0)
			ADC_REG->SWTRIG.bit.START = true;
	}
	
	ADC_REG->INTFLAG.reg = ADC_INTFLAG_RESRDY;
}

/*void Analog_Boot_Init()
{
	hri_mclk_set_APBDMASK_TCC4_bit(MCLK);
	hri_gclk_write_PCHCTRL_reg(GCLK, TCC4_GCLK_ID, CONF_GCLK_TCC4_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
	
	pwm_init(&PWM_4, TCC4, _tcc_get_pwm());
	gpio_set_pin_function(BOOST, PINMUX_PB31F_TCC4_WO1);
	pwm_set_parameters(&PWM_4, BOOST_FREQ, BOOST_DUTY_PERCENT(50));
	pwm_enable(&PWM_4);
}*/

void Analog_125ms(TimerHandle_t xTimer)
{
	//_pwm_setduty(TCC4, CONF_TCC4_SEL_CH, BOOST_DUTY_PERCENT(50));			// Needed after init to resolve bug that the duty cycle is not set??
	
	//if(gAdcConvSeqAIntFlag)
	{
		bool update_log = false;
		if(++analog_log_prs >= (12*60*60*ANALOG_SECOND_PRS))		// Log every 12 hours
		{
			update_log = true;
			analog_log_prs = 0;
		}
		
#ifdef PCB_REV6			
		if(analog_init == 0)
		{
			//adc_calibrate_offset = 0;//adc_channel_val[AD_CHAN_OFFSET];
			adc_calibrate_gain = ((((g_Adc_12bitFullRange * ANALOG_CALIBRATE_VOLTAGE) / ANALOG_REF_VOLTAGE) * 1000UL) / adc_channel_val[AD_CHAN_REFERENCE]);		
		}
#endif
		
		uint32_t supplyVoltage = ((((ANALOG_REF_VOLTAGE * ((uint32_t)adc_channel_val[AD_CHAN_VSUPPLY]))/(ANALOG_SUPPLY_VOLT_RATIO)) * adc_calibrate_gain) / g_Adc_12bitFullRange);
		analog_avg_supply_voltage = supplyVoltage + ANALOG_SUPPLY_VOLT_OFFSET;

#if 0
		uint32_t outputVoltage = ((((ANALOG_REF_VOLTAGE * ((uint32_t)adc_channel_val[AD_CHAN_VOUT]))/(ANALOG_SUPPLY_VOLT_RATIO)) * adc_calibrate_gain) / g_Adc_12bitFullRange);
		analog_avg_output_voltage = outputVoltage;
		
/*		uint32_t adc_current_avg_calc = adc_current_avg_cnt > 0 ? (adc_current_avg_total / adc_current_avg_cnt) : 0;
		uint32_t outputCurrent = ((((ANALOG_REF_VOLTAGE * (adc_current_avg_calc))/((ANALOG_OUT1_CURRENT_RATIO / 10UL))) * adc_calibrate_gain) / g_Adc_12bitFullRange);
		analog_avg_out_current = outputCurrent + ANALOG_OUT1_CURRENT_OFFSET;
#ifdef PCB_REV6		
		uint32_t outputCurrent20 = ((((ANALOG_REF_VOLTAGE * ((uint32_t)adc_channel_val[AD_CHAN_CURRENT_20A]))/(ANALOG_OUT2_CURRENT_RATIO / 10UL)) * adc_calibrate_gain) / g_Adc_12bitFullRange);
		analog_avg_out_current20 = outputCurrent + ANALOG_OUT2_CURRENT_OFFSET;
#endif
		adc_current_avg_total = 0;
		adc_current_avg_cnt = 0;
	*/
		int16_t temperature = ntc_table[((adc_channel_val[AD_CHAN_TIN]) >> 3) & 0x01FF];
		analog_avg_temperature = temperature;
		if(temperature == -128)			// Error?
		{
			if(!State_IsErrorActive(STATE_ERROR_NTC))
			{
				LOGWRITE_ERROR(ERRCODE_HW_FAULT, "NTC defect", log_src_task_postpone);
			}
			State_SetError(STATE_ERROR_NTC);
			analog_avg_temperature = 0;
		}
		else
			State_ClearError(STATE_ERROR_NTC);
			
		if(analog_init <= 1)
		{				
			if(analog_avg_supply_voltage >= ANALOG_SUPPLY_VOLT_HIGH)					// Supply voltage too high
			{
				if(!State_IsErrorActive(STATE_ERROR_OVERVOLTAGE) || update_log)			// Check if error already set or log every 12 hours
				{
					if(!State_IsErrorActive(STATE_ERROR_UNDERVOLTAGE))
					{
						sprintf(text, "Supply voltage too high: %d.%dV", analog_avg_supply_voltage/1000, (analog_avg_supply_voltage % 1000)/100);
						LOGWRITE_CRITICAL(ERRCODE_SUPPLY_VOLTAGE_TOO_HIGH, text, log_src_task_postpone);
					}
					State_SetError(STATE_ERROR_OVERVOLTAGE);			// Set error only
					State_ClearWarning(STATE_ERROR_UNDERVOLTAGE);
				}
				//IziPlus_VoltageProtectShutdown();			// Protect modules from to high voltage
			}
			else if(analog_avg_supply_voltage < ANALOG_SUPPLY_VOLT_LOW ||				 // Supply voltage too low (on start it should even be above min + hysteresis
					((analog_init == 1) && (analog_avg_supply_voltage < (ANALOG_SUPPLY_VOLT_LOW + ANALOG_SUPPLY_VOLT_HYST))))
			{
				if(!State_IsErrorActive(STATE_ERROR_UNDERVOLTAGE) || update_log)	// Check if error already set or log every 12 hours
				{
					State_ClearError(STATE_ERROR_OVERVOLTAGE);		// Set error
					State_SetError(STATE_ERROR_UNDERVOLTAGE);
					sprintf(text, "Supply voltage too low: %d.%dV", analog_avg_supply_voltage/1000, (analog_avg_supply_voltage % 1000)/100);
					LOGWRITE_ERROR(ERRCODE_SUPPLY_VOLTAGE_TOO_LOW, text, log_src_task_postpone);
				}
				//IziPlus_VoltageProtectShutdown();			// Do not start on too low voltage
			}
			else if((analog_avg_supply_voltage > (ANALOG_SUPPLY_VOLT_LOW + ANALOG_SUPPLY_VOLT_HYST)) && (analog_avg_supply_voltage < (ANALOG_SUPPLY_VOLT_HIGH - ANALOG_SUPPLY_VOLT_HYST)))
			{
				if(State_IsErrorActive(STATE_ERROR_OVERVOLTAGE) || State_IsErrorActive(STATE_ERROR_UNDERVOLTAGE) || analog_init)
				{
					State_ClearError(STATE_ERROR_UNDERVOLTAGE);		// All OK
					State_ClearError(STATE_ERROR_OVERVOLTAGE);
					sprintf(text, "Supply voltage OK: %d.%dV", analog_avg_supply_voltage/1000, (analog_avg_supply_voltage % 1000)/100);
					LOGWRITE_INFO(ERRCODE_SUPPLY_VOLTAGE_OK, text, log_src_task_postpone);
				}
			}
			else if(State_IsErrorActive(STATE_ERROR_OVERVOLTAGE) || State_IsErrorActive(STATE_ERROR_UNDERVOLTAGE))
			{
				//IziPlus_VoltageProtectShutdown();				
			}
			//GEN_TRACE_INFO("Power voltage: %dmV\r\n", analog_avg_supply_voltage);

			if(abs((int16_t)analog_avg_temperature - (int16_t)analog_avg_temperature_logged) >= ANALOG_TEMPERATURE_DELTA)		// 5 degree difference log now
				update_log = true;

			if(analog_avg_temperature >= ANALOG_TEMPERATURE_HIGH)
			{
				if(!State_IsErrorActive(STATE_ERROR_TEMP_TOO_HIGH) || update_log)
				{
					State_SetError(STATE_ERROR_TEMP_TOO_HIGH);			// Set error only
					State_ClearWarning(STATE_WARNING_TEMP_HIGH);
					sprintf(text, "Processor temperature is %d degrees", analog_avg_temperature);
					LOGWRITE_CRITICAL(ERRCODE_PROCESSOR_TEMP_TOO_HIGH, text, log_src_task_postpone);
					analog_avg_temperature_logged = analog_avg_temperature;		// Store for delta check
				}
			}
			else if(analog_avg_temperature >= ANALOG_TEMPERATURE_WARN && analog_avg_temperature < (ANALOG_TEMPERATURE_HIGH - ANALOG_TEMPERATURE_HYST))
			{
				if(!State_IsWarningActive(STATE_WARNING_TEMP_HIGH) || update_log)
				{
					State_ClearError(STATE_ERROR_TEMP_TOO_HIGH);		// Set warning only
					State_SetWarning(STATE_WARNING_TEMP_HIGH);
					sprintf(text, "Processor temperature is %d degrees", analog_avg_temperature);
					LOGWRITE_WARNING(ERRCODE_PROCESSOR_TEMP_HIGH, text, log_src_task_postpone);
					analog_avg_temperature_logged = analog_avg_temperature;		// Store for delta check
				}
			}
			else if(analog_avg_temperature < (ANALOG_TEMPERATURE_WARN - ANALOG_TEMPERATURE_HYST))
			{
				if(State_IsWarningActive(STATE_WARNING_TEMP_HIGH) || State_IsErrorActive(STATE_ERROR_TEMP_TOO_HIGH) || update_log || analog_init)
				{
					sprintf(text, "Processor temperature is %d degrees", analog_avg_temperature);
					LOGWRITE_INFO(ERRCODE_PROCESSOR_TEMP_OK, text, log_src_task_postpone);

					State_ClearError(STATE_ERROR_TEMP_TOO_HIGH);		// All OK
					State_ClearWarning(STATE_WARNING_TEMP_HIGH);
					analog_avg_temperature_logged = analog_avg_temperature;		// Store for delta check
				}
			}
/*
			if(analog_avg_out_current > analog_avg_out_current_offset)
				analog_avg_out_current -= analog_avg_out_current_offset;
			else 
				analog_avg_out_current = 0;
#ifdef PCB_REV6			
			if(analog_avg_out_current20 > analog_avg_out_current20_offset)
				analog_avg_out_current20 -= analog_avg_out_current20_offset;
			else
				analog_avg_out_current20 = 0;
#endif
			if(analog_init == 1)
			{
				analog_avg_out_current_offset = analog_avg_out_current;
#ifdef PCB_REV6
				analog_avg_out_current20_offset = analog_avg_out_current20;
#endif				
			}
			else if(analog_init == 0)
			{
#ifdef PCB_REV6				
				if(analog_avg_out_current > ANALOG_CURRENT_SWITCH)
				{
					if(analog_avg_out_current20 > analog_avg_out_current_max)
						analog_avg_out_current_max = analog_avg_out_current20;
				}
				else
#endif				
				{
					if(analog_avg_out_current > analog_avg_out_current_max)
						analog_avg_out_current_max = analog_avg_out_current;	
				}
			}			

			if(analog_avg_out_current >= ANALOG_CURRENT_HIGH)
			{
				if(!State_IsErrorActive(STATE_ERROR_CURRENT_HIGH) || update_log)
				{
					State_SetError(STATE_ERROR_CURRENT_HIGH);			// Set error only
					State_ClearWarning(STATE_WARNING_CURRENT_HIGH);
					sprintf(text, "Output current is too high: %d.%dA", analog_avg_out_current/1000, (analog_avg_out_current % 1000)/100);
					LOGWRITE_CRITICAL(ERRCODE_OUTPUT_CURRENT_TOO_HIGH, text, log_src_task_postpone);
				}
				//IziPlus_DecMaster(16);
			}
			else if(analog_avg_out_current >= ANALOG_CURRENT_WARN && analog_avg_out_current < (ANALOG_CURRENT_HIGH - ANALOG_CURRENT_HYST))
			{
				if(!State_IsWarningActive(STATE_WARNING_CURRENT_HIGH) || update_log)
				{
					State_ClearError(STATE_ERROR_CURRENT_HIGH);		// Set warning only
					State_SetWarning(STATE_WARNING_CURRENT_HIGH);
					sprintf(text, "Output current is high: %d.%dA", analog_avg_out_current/1000, (analog_avg_out_current % 1000)/100);
					LOGWRITE_WARNING(ERRCODE_OUTPUT_CURRENT_HIGH, text, log_src_task_postpone);
				}
				//IziPlus_DecMaster(1);
			}
			else if(analog_avg_out_current < (ANALOG_CURRENT_WARN - ANALOG_CURRENT_HYST))
			{
				if(State_IsWarningActive(STATE_WARNING_CURRENT_HIGH) || State_IsErrorActive(STATE_ERROR_CURRENT_HIGH) || update_log || analog_init)
				{
					sprintf(text, "Output current OK: %d.%dA (%d.%dA)", analog_avg_out_current/1000, (analog_avg_out_current % 1000)/100, analog_avg_out_current_max/1000, (analog_avg_out_current_max % 1000)/100);
					LOGWRITE_INFO(ERRCODE_OUTPUT_CURRENT_OK, text, log_src_task_postpone);

					State_ClearError(STATE_ERROR_CURRENT_HIGH);		// All OK
					State_ClearWarning(STATE_WARNING_CURRENT_HIGH);

					analog_avg_out_current_max = 0;
				}
				//IziPlus_IncMaster(1);
			}
				*/
			//energy_log.power = (analog_avg_out_current * analog_avg_supply_voltage)/1000;		// Calc Mw
			//energy_log.energy += energy_log.power;
			//energy_log.samples++;
			//energy_log.crc = Crc16Fast(&energy_log, sizeof(energy_log) - 2, 0);
				
			analog_init = 0;			// Initial sequence (ignore first samples) is over
		}
		else
			analog_init--;

		/*if(conversions == 0)
			ADC_REG->SWTRIG.bit.START = true;
		else
		{
			//OS_TRACE_ERROR("ADC conv[%d]: %d (val: %d, res: %d, %d)\r\n", channel_index, conversions, adc_channel_val[AD_CHAN_VSUPPLY], res, adc_channel_val[AD_CHAN_CURRENT]); 
			conversions = 0;
		}*/		
#endif
	}
}

/*void Analog_PowerUpdate(uint8_t idx, uint8_t total)
{
	if(energy_log.samples == 0)
		return;
	if(idx == 0 || total == 0)
	{
		energy_log.energy_bfr[energy_log.energy_bfr_idx] = (uint16_t)((energy_log.energy / (uint32_t)energy_log.samples) / 100L);		// Calc per 0.1W over 3 minutes
	}
	else
		energy_log.energy_bfr[energy_log.energy_bfr_idx] = (uint16_t)(((energy_log.energy * (uint32_t)idx) / (uint32_t)energy_log.samples) / (total * 100L));		// Calc per 0.1W over 3 minutes
		
	energy_log.crc = Crc16Fast(&energy_log, sizeof(energy_log) - 2, 0);
}

void Analog_PowerNext(void)
{
	energy_log.energy_total += energy_log.energy_bfr[energy_log.energy_bfr_idx] / 2;			// analog_avg_energy_total in 0.01mWh (/2 is * 10 because not 0.1 but 0.01 and /20 because of every 3 minutes = 20x per hour
	if(++energy_log.energy_bfr_idx >= ANALOG_MAX_ENERGY_BFR)
	{
		energy_log.energy_bfr_idx = 0;
		energy_log.loops++;
	}
	energy_log.energy = 0;
	energy_log.samples = 0;
	energy_log.crc = Crc16Fast(&energy_log, sizeof(energy_log) - 2, 0);
}

uint32_t Analog_GetEnergy(void)
{	
	return energy_log.energy_total / 100;
}

uint8_t Analog_GetPower(uint16_t *data)
{
	uint8_t amount = ANALOG_MAX_ENERGY_BFR;
	if(energy_log.loops == 0)
		amount = energy_log.energy_bfr_idx + 1;
		
	uint8_t read_idx = energy_log.energy_bfr_idx;
	for(int i = 0; i < amount; i++)
	{
		data[i] = energy_log.energy_bfr[read_idx];
		if(read_idx == 0)
			read_idx = ANALOG_MAX_ENERGY_BFR - 1;
		else
			read_idx--;
	}
	return amount;
}
*/
/**
 * Get supply voltage in mV
 */
uint32_t Analog_GetSupplyVoltage()
{
	return 48000;//analog_avg_supply_voltage;
}

uint32_t Analog_GetSupplyVoltageRaw()
{
	return 3500;//adc_channel_val[AD_CHAN_VSUPPLY];
}

/**
 * Get output voltage in mV
 */
uint32_t Analog_GetOutputVoltage()
{
	return analog_avg_output_voltage;
}


/**
 * Get output current in mA
 */
uint32_t Analog_GetOutputCurrent()
{
	return analog_avg_out_current;
}

/**
 * Get output current in mA max since reset
 */
uint32_t Analog_GetOutputCurrentMax()
{
	return analog_avg_out_current_max;
}

void Analog_OutputCurrentMaxCLear()
{
	analog_avg_out_current_max = 0;
}

/**
 * Get supply voltage in mV
 */
uint16_t Analog_GetProcessorTemperature()
{
	return analog_avg_temperature;
}

#ifdef PCB_REV6	
const int8_t ntc_table[512] = 
{
	-128,	-128,	-128,	-128,	-128,	-128,	-128,	-128,	127,	127,	127,	127,	127,	127,	127,	127,
	127,	127,	127,	127,	127,	126,	124,	122,	120,	118,	116,	115,	113,	112,	110,	109,
	107,	106,	105,	104,	102,	101,	100,	99,	98,	97,	96,	95,	94,	93,	92,	92,
	91,	90,	89,	88,	88,	87,	86,	85,	85,	84,	83,	83,	82,	81,	81,	80,
	79,	79,	78,	78,	77,	77,	76,	75,	75,	74,	74,	73,	73,	72,	72,	71,
	71,	70,	70,	70,	69,	69,	68,	68,	67,	67,	67,	66,	66,	65,	65,	65,
	64,	64,	63,	63,	63,	62,	62,	62,	61,	61,	60,	60,	60,	59,	59,	59,
	58,	58,	58,	57,	57,	57,	57,	56,	56,	56,	55,	55,	55,	54,	54,	54,
	54,	53,	53,	53,	52,	52,	52,	52,	51,	51,	51,	50,	50,	50,	50,	49,
	49,	49,	49,	48,	48,	48,	48,	47,	47,	47,	47,	46,	46,	46,	46,	45,
	45,	45,	45,	45,	44,	44,	44,	44,	43,	43,	43,	43,	43,	42,	42,	42,
	42,	41,	41,	41,	41,	41,	40,	40,	40,	40,	40,	39,	39,	39,	39,	39,
	38,	38,	38,	38,	38,	37,	37,	37,	37,	37,	36,	36,	36,	36,	36,	36,
	35,	35,	35,	35,	35,	34,	34,	34,	34,	34,	34,	33,	33,	33,	33,	33,
	32,	32,	32,	32,	32,	32,	31,	31,	31,	31,	31,	31,	30,	30,	30,	30,
	30,	30,	29,	29,	29,	29,	29,	29,	28,	28,	28,	28,	28,	28,	27,	27,
	27,	27,	27,	27,	27,	26,	26,	26,	26,	26,	26,	25,	25,	25,	25,	25,
	25,	25,	24,	24,	24,	24,	24,	24,	23,	23,	23,	23,	23,	23,	23,	22,
	22,	22,	22,	22,	22,	22,	21,	21,	21,	21,	21,	21,	21,	20,	20,	20,
	20,	20,	20,	19,	19,	19,	19,	19,	19,	19,	18,	18,	18,	18,	18,	18,
	18,	18,	17,	17,	17,	17,	17,	17,	17,	16,	16,	16,	16,	16,	16,	16,
	15,	15,	15,	15,	15,	15,	15,	14,	14,	14,	14,	14,	14,	14,	13,	13,
	13,	13,	13,	13,	13,	13,	12,	12,	12,	12,	12,	12,	12,	11,	11,	11,
	11,	11,	11,	11,	11,	10,	10,	10,	10,	10,	10,	10,	9,	9,	9,	9,
	9,	9,	9,	8,	8,	8,	8,	8,	8,	8,	8,	7,	7,	7,	7,	7,
	7,	7,	6,	6,	6,	6,	6,	6,	6,	6,	5,	5,	5,	5,	5,	5,
	5,	4,	4,	4,	4,	4,	4,	4,	3,	3,	3,	3,	3,	3,	3,	3,
	2,	2,	2,	2,	2,	2,	2,	1,	1,	1,	1,	1,	1,	1,	0,	0,
	0,	0,	0,	0,	0,	0,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-2,	-2,	-2,
	-2,	-2,	-2,	-2,	-3,	-3,	-3,	-3,	-3,	-3,	-3,	-4,	-4,	-4,	-4,	-4,
	-4,	-4,	-5,	-5,	-5,	-5,	-5,	-5,	-6,	-6,	-6,	-6,	-6,	-6,	-6,	-7,
	-7,	-7,	-7,	-7,	-7,	-7,	-8,	-8,	-128, 128, -128, -128,-128,-128,-128,-128
};
#else	
const uint8_t ntc_table[512] =
{
	255,	255,	219,	193,	176,	164,	154,	146,	140,	134,	129,	125,	121,	118,	115,	112,
	109,	107,	104,	102,	100,	98,	96,	95,	93,	91,	90,	89,	87,	86,	85,	83,
	82,	81,	80,	79,	78,	77,	76,	75,	74,	74,	73,	72,	71,	70,	70,	69,
	68,	67,	67,	66,	65,	65,	64,	64,	63,	62,	62,	61,	61,	60,	60,	59,
	59,	58,	58,	57,	57,	56,	56,	55,	55,	54,	54,	54,	53,	53,	52,	52,
	52,	51,	51,	50,	50,	50,	49,	49,	49,	48,	48,	48,	47,	47,	47,	46,
	46,	46,	45,	45,	45,	44,	44,	44,	44,	43,	43,	43,	42,	42,	42,	42,
	41,	41,	41,	41,	40,	40,	40,	40,	39,	39,	39,	39,	38,	38,	38,	38,
	37,	37,	37,	37,	37,	36,	36,	36,	36,	35,	35,	35,	35,	35,	34,	34,
	34,	34,	34,	33,	33,	33,	33,	33,	32,	32,	32,	32,	32,	31,	31,	31,
	31,	31,	31,	30,	30,	30,	30,	30,	29,	29,	29,	29,	29,	29,	28,	28,
	28,	28,	28,	28,	28,	27,	27,	27,	27,	27,	27,	26,	26,	26,	26,	26,
	26,	26,	25,	25,	25,	25,	25,	25,	25,	24,	24,	24,	24,	24,	24,	24,
	23,	23,	23,	23,	23,	23,	23,	22,	22,	22,	22,	22,	22,	22,	22,	21,
	21,	21,	21,	21,	21,	21,	21,	20,	20,	20,	20,	20,	20,	20,	20,	19,
	19,	19,	19,	19,	19,	19,	19,	19,	18,	18,	18,	18,	18,	18,	18,	18,
	17,	17,	17,	17,	17,	17,	17,	17,	17,	17,	16,	16,	16,	16,	16,	16,
	16,	16,	16,	15,	15,	15,	15,	15,	15,	15,	15,	15,	15,	14,	14,	14,
	14,	14,	14,	14,	14,	14,	14,	13,	13,	13,	13,	13,	13,	13,	13,	13,
	13,	13,	12,	12,	12,	12,	12,	12,	12,	12,	12,	12,	11,	11,	11,	11,
	11,	11,	11,	11,	11,	11,	11,	11,	10,	10,	10,	10,	10,	10,	10,	10,
	10,	10,	10,	9,	9,	9,	9,	9,	9,	9,	9,	9,	9,	9,	9,	8,
	8,	8,	8,	8,	8,	8,	8,	8,	8,	8,	8,	8,	7,	7,	7,	7,
	7,	7,	7,	7,	7,	7,	7,	7,	7,	6,	6,	6,	6,	6,	6,	6,
	6,	6,	6,	6,	6,	6,	5,	5,	5,	5,	5,	5,	5,	5,	5,	5,
	5,	5,	5,	4,	4,	4,	4,	4,	4,	4,	4,	4,	4,	4,	4,	4,
	4,	3,	3,	3,	3,	3,	3,	3,	3,	3,	3,	3,	3,	3,	3,	3,
	2,	2,	2,	2,	2,	2,	2,	2,	2,	2,	2,	2,	2,	2,	1,	1,
	1,	1,	1,	1,	1,	1,	1,	1,	1,	1,	1,	1,	1,	1,	0,	0,
	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,
	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,
	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,
};	
#endif	