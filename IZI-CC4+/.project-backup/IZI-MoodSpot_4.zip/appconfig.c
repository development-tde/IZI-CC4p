/*
 * appconfig.c
 *
 *  Created on: 15 jun. 2020
 *      Author: Milo
 */

#include "includes.h"
#include "appconfig.h"
#include "crc.h"
#include "smart_eeprom.h"
#include "iziplus_module_def.h"

#define APPCFG_GEN			1
#define APPCFG_NETWORK		8

uint32_t AppConfig_Changes = 0;

//const uint8_t  __attribute__ ((section (".appsettingsection"))) appsettings;
appconfig_t appCfg;
appconfig_t *appConfig;

appcalib_t appCalib;
appcalib_t *appCalibData;

applog_t __attribute__ ((section (".energy_ram"))) appLog;
applog_t *appLogData;

void AppConfig_Init()
{
	appconfig_t *cfg = AppConfig_Get();
	appConfig = cfg;
	
	uint16_t crc = Crc16((uint8_t *)&cfg->ref, (uint16_t)(sizeof(appconfig_t) - sizeof(cfg->crc)), 0xFFFF);
	if(cfg->crc != crc)
	{
		GEN_TRACE_INFO("App settings crc fail\r\n");
		AppConfig_Default();
	}
	else
	{
		GEN_TRACE_INFO("App settings OK\r\n");
		if(cfg->version < CONFIG_VERSION)
		{
			if(cfg->version < 2)
			{
				cfg->location_id = 0;
			}
			else if(cfg->version < 3)
			{
				cfg->pan_id = PRODUCTION_SERIAL;
			}
			else if(cfg->version < 6)
			{
				cfg->pc_config[APPCFG_TXMODE] = APPCFG_TXMODE_DYNAMIC;
			}
			cfg->version = CONFIG_VERSION;
			AppConfig_Set();
		}
	}

	IziPlus_Module_Init();
	
	applog_t *log = AppLog_Get();
	appLogData = log;
	
	crc = Crc16((uint8_t *)&log->ref, (uint16_t)(sizeof(applog_t) - sizeof(log->crc)), 0xFFFF);
	if(log->crc != crc)
	{
		GEN_TRACE_INFO("App log crc fail\r\n");
		AppLog_Default();
	}
	else
	{
		GEN_TRACE_INFO("App log OK\r\n");
		if(log->version < LOG_VERSION)
		{
			log = AppLog_Get();
			log->version = LOG_VERSION;
			AppLog_Set();
		}
	}
	
	appcalib_t *calib = AppCalib_Get();
	appCalibData = calib;
	
	crc = Crc16((uint8_t *)&calib->ref, (uint16_t)(sizeof(appcalib_t) - sizeof(calib->crc)), 0xFFFF);
	if(calib->crc != crc)
	{
		GEN_TRACE_INFO("App calibration crc fail\r\n");
		AppCalib_Default();
	}
	else
	{
		GEN_TRACE_INFO("App calibration OK\r\n");
		if(calib->version < CALIB_VERSION)
		{
			calib = AppCalib_Get();
			calib->version = CALIB_VERSION;
			AppCalib_Set();
		}
	}
}

void AppCalib_Default()
{
	appcalib_t *calib = &appCalib;
	
	// General
	calib->ref = 0;
	calib->version = CALIB_VERSION;
	
	calib->vled1_max_mv = calib->vled2_max_mv = 0;
	calib->pwm1_offset = calib->pwm2_offset = 100;
	
	uint16_t crc = Crc16((uint8_t *)&calib->ref, (uint16_t)(sizeof(appconfig_t) - sizeof(calib->crc)), 0xFFFF);
	calib->crc = crc;
	
	if(Eeprom_Write(EEPROM_CALIBRATE, (uint8_t *)calib, APPCALIB_SECTOR_SIZE))
	{
		GEN_TRACE_INFO("App calib default OK\r\n");
		AppCalib_Get();
	}
	else
	GEN_TRACE_INFO("App calib default error\r\n");
}

void AppConfig_Default()
{
	appconfig_t *cfg = &appCfg;
	
	// General
	cfg->ref = 0;
	cfg->version = CONFIG_VERSION;
	
	strcpy(cfg->name, "IZI-PowerCom-0000");
	strcpy(cfg->project, "TDE");
	
	cfg->can_slave_id = 0xFF;
	cfg->pl_frequency = (9 - 5) * 10;		// Band 2 = 9MHz
	cfg->pl_rate = 0x03;
	cfg->app_modules = 0;
	
	cfg->timing_offset = 0;
	cfg->master_idx = 0;
	cfg->master_total = 0;
	
	cfg->short_id = 0xFF;
	cfg->channel = 0;
	cfg->mode = 2;
	cfg->dmxfail = 0x12;
	cfg->offset = 0;
	cfg->location_id = 0;
	
	cfg->pan_id = PRODUCTION_SERIAL;
	cfg->pc_config[APPCFG_TXMODE] = APPCFG_TXMODE_DYNAMIC;
	
#if DEBUG	
	cfg->dbg_on = 2;
#else
	cfg->dbg_on = 0;
#endif
	
	uint8_t offset = 0;
	memset(cfg->config, 0, 24);
	for(int i = 0; i < CONFIG_AMOUNT; i++)
	{
		memcpy(&cfg->config[i + offset], &module_config[i].dflt, module_config[i].size);
		offset += (module_config[i].size - 1);
	}
	
	uint16_t crc = Crc16((uint8_t *)&cfg->ref, (uint16_t)(sizeof(appconfig_t) - sizeof(cfg->crc)), 0xFFFF);
	cfg->crc = crc;
	
	if(Eeprom_Write(EEPROM_APPCFG, (uint8_t *)cfg, APPSETTING_SECTOR_SIZE))
	{
		GEN_TRACE_INFO("App default OK\r\n");
		AppConfig_Get();
	}
	else
		GEN_TRACE_INFO("App default error\r\n");
}

appconfig_t *AppConfig_Get()
{
	Eeprom_Read(EEPROM_APPCFG, (uint8_t *)&appCfg, APPSETTING_SECTOR_SIZE);
	return &appCfg;
}

appconfig_t *AppConfig_GetPtr()
{
	return &appCfg;
}


bool AppConfig_Set()
{
	TickType_t ticks = xTaskGetTickCount();

	if(appCfg.pc_config[APPCFG_TXMODE] > APPCFG_TXMODE_MAX)				// Valid value?
	{
		appCfg.pc_config[APPCFG_TXMODE] = APPCFG_TXMODE_DYNAMIC;		// If not, set to default
	}

	uint16_t crc = Crc16((uint8_t *)&appCfg.ref, (uint16_t)(sizeof(appconfig_t) - sizeof(appCfg.crc)), 0xFFFF);
	appCfg.crc = crc;
	
	if(Eeprom_Write(EEPROM_APPCFG, (uint8_t *)&appCfg, APPSETTING_SECTOR_SIZE))
	{
		GEN_TRACE_INFO("App write ram settings %d ms\r\n", xTaskGetTickCount() - ticks);
		return true;
	}
	else
		GEN_TRACE_INFO("App write error\r\n");
	return false;
}

void AppConfig_Print()
{
	GEN_TRACE_INFO("General\r\n");
	GEN_TRACE_INFO("Serial    : %08x\r\n", PRODUCTION_SERIAL);
	GEN_TRACE_INFO("Batch     : %s\r\n", PRODUCTION_BATCH);
	GEN_TRACE_INFO("Plant     : %c\r\n", PRODUCTION_PLANT);
	GEN_TRACE_INFO("Version   : %d\r\n", appConfig->version);
	GEN_TRACE_INFO("Name      : %s\r\n", appConfig->name);
	GEN_TRACE_INFO("Project   : %s\r\n", appConfig->project);
	GEN_TRACE_INFO("Modules   : %d\r\n", appConfig->app_modules);
	GEN_TRACE_INFO("PAN ID    : %d\r\n", appConfig->pan_id);
	GEN_TRACE_INFO("CAN\r\n");
	GEN_TRACE_INFO("Network id: %d\r\n", appConfig->can_network_id);
	GEN_TRACE_INFO("Slave id  : %d\r\n", appConfig->can_slave_id);
	GEN_TRACE_INFO("Power line\r\n");
	GEN_TRACE_INFO("Frequency : %d\r\n", appConfig->pl_frequency);
	GEN_TRACE_INFO("Rate      : %d\r\n", appConfig->pl_rate);
	GEN_TRACE_INFO("Timing ms : %d\r\n", appConfig->timing_offset);
	GEN_TRACE_INFO("Master idx: %d\r\n", appConfig->master_idx);
	GEN_TRACE_INFO("Masters nr: %d\r\n", appConfig->master_total);
}

appcalib_t *AppCalib_Get()
{
	Eeprom_Read(EEPROM_CALIBRATE, (uint8_t *)&appCalib, APPCALIB_SECTOR_SIZE);
	return &appCalib;
}

/************************************************************************/
/* Brief: Calculate crc and write into smart eeprom                     */
/************************************************************************/
bool AppCalib_Set()
{
	TickType_t ticks = xTaskGetTickCount();

	uint16_t crc = Crc16((uint8_t *)&appCalib.ref, (uint16_t)(sizeof(appcalib_t) - sizeof(appCalib.crc)), 0xFFFF);
	appCalib.crc = crc;
	
	if(Eeprom_Write(EEPROM_CALIBRATE, (uint8_t *)&appCalib, APPCALIB_SECTOR_SIZE))
	{
		GEN_TRACE_INFO("App calib write ram settings %d ms\r\n", xTaskGetTickCount() - ticks);
		return true;
	}
	else
	GEN_TRACE_INFO("App calib write error\r\n");
	return false;
}

void AppLog_Default()
{
	applog_t *log = &appLog;
	
	// General
	log->ref = 0;
	log->version = LOG_VERSION;
	
	log->operating_sec = log->active_ch1_sec = log->active_ch2_sec = 0;
	log->intern_temp_max = log->ntc1_temp_max =  log->ntc2_temp_max = 0;
	log->change_count = 0;
	
	uint16_t crc = Crc16((uint8_t *)&log->ref, (uint16_t)(sizeof(applog_t) - sizeof(log->crc)), 0xFFFF);
	log->crc = crc;
	
	if(Eeprom_Write(EEPROM_LOG, (uint8_t *)log, APPLOG_SECTOR_SIZE))
	{
		GEN_TRACE_INFO("App log default OK\r\n");
		AppCalib_Get();
	}
	else
	GEN_TRACE_INFO("App log default error\r\n");
}

applog_t *AppLog_Get()
{
	Eeprom_Read(EEPROM_LOG, (uint8_t *)&appLog, APPLOG_SECTOR_SIZE);
	return &appLog;
}

/************************************************************************/
/* Brief: Calculate crc and write into smart eeprom                     */
/************************************************************************/
bool AppLog_Set()
{
	TickType_t ticks = xTaskGetTickCount();

	uint16_t crc = Crc16((uint8_t *)&appLog.ref, (uint16_t)(sizeof(applog_t) - sizeof(appLog.crc)), 0xFFFF);
	appLog.crc = crc;
	
	if(Eeprom_Write(EEPROM_LOG, (uint8_t *)&appLog, APPLOG_SECTOR_SIZE))
	{
		appLog.change_count = 0;
		GEN_TRACE_INFO("Log write ram ok %d ms\r\n", xTaskGetTickCount() - ticks);
		return true;
	}
	else
	GEN_TRACE_INFO("Log write error\r\n");
	
	appLog.change_count = 0;
	return false;
}