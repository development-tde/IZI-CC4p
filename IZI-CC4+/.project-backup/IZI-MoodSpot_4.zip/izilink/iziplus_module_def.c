/*
 * iziplus_module_def.c
 *
 * Created: 26-2-2022 17:28:14
 *  Author: Milo
 */ 

#include "includes.h"
#include "iziplus_module_def.h"
#include "version.h"
#include "appconfig.h"
#include "stepdown.h"
#include "izi_input.h"
#include "izi_output.h"
#include "analog.h"
#include "iziplus_dataframe.h"
#include "iziplus_driver.h"

uint8_t module_channels_amount = 0;			// AMount of channels in current mode
iziplus_cpustate_u module_cpu_state;
uint8_t module_monitor[MONITOR_SIZE];
uint16_t module_identify_time = 0, module_identify_prs = 0, module_identify_mode = 0;
uint16_t module_reset_report;
extern uint8_t reset_cause;

volatile int16_t max_intern_temp_raw = 0, limit_intern_temp_raw;
volatile int16_t max_ntc1_temp_raw = 0, limit_ntc1_temp_raw;
volatile int16_t max_ntc2_temp_raw = 0, limit_ntc2_temp_raw;

volatile uint16_t safety_time_ch1 = 0;						// Time to overrule channel level to 0 for safety
volatile uint16_t safety_time_ch2 = 0;						// Time to overrule channel level to 0 for safety
volatile uint16_t safety_time_ch3 = 0;						// Time to overrule channel level to 0 for safety
volatile uint16_t overrule_time_ch1 = 0;					// Time to overrule channel level
volatile uint8_t overrule_level_ch1 = 0;					// Overrule level, overriding channel level
volatile uint16_t overrule_time_ch2 = 0;					// Time to overrule channel level
volatile uint8_t overrule_level_ch2 = 0;					// Overrule level, overriding channel level
volatile uint16_t overrule_time_ch3 = 0;					// Time to overrule channel level
volatile uint8_t overrule_level_ch3 = 0;					// Overrule level, overriding channel level
volatile uint8_t overrule_prio_ch1 = 0;						// Overrule priority, overriding channel level
volatile uint8_t overrule_prio_ch2 = 0;						// Overrule priority, overriding channel level
volatile uint8_t overrule_prio_ch3 = 0;						// Overrule priority, overriding channel level

static bool iziplus_last_comcheck = false;
static uint8_t iziplus_prs_comcheck = 0;
static uint16_t iziplus_data_wasok = false;					// Has light data ever been received?
static uint16_t iziplus_level_ch1, iziplus_level_ch2;

#define TEMP_MAX_RESOLUTION			2000					// Max calculation for resolution of temp and power reduce, checked per 100ms
#define TEMP_LIMIT_START_OFFSET		5						// 5 degrees before limit the power reduce will start
#define MAX_INTERN_TEMP				105						// Max 90 degrees intern (105 = off, from 105 - TEMP_LIMIT_START_OFFSET reduce will start)

#define POWER_MAX_RESOLUTION		TEMP_MAX_RESOLUTION		// 0.05% per 100ms
#define POWER_MAX					4050					// in 10mW

uint16_t ntc1_temp_master = TEMP_MAX_RESOLUTION;			// NTC1 reduce in promille
uint16_t ntc2_temp_master = TEMP_MAX_RESOLUTION;			// NTC2 reduce in promille
uint16_t intern_temp_master = TEMP_MAX_RESOLUTION;			// Intern temp reduce in promille

uint16_t power_ch1_master = POWER_MAX_RESOLUTION;			// Power reduce channel 1
uint16_t power_ch2_master = POWER_MAX_RESOLUTION;			// Power reduce channel 2

uint8_t timer_prs = 0;

const iziplus_mode_def module_modes[MODE_AMOUNT] =
{
	{ .channels = 1, .name = "1 Channel"},
	{ .channels = 3, .name = "2 Chan Master"},
	{ .channels = 2, .name = "2 Channel"},
	{ .channels = 1, .name = "1 Output"},
	{ .channels = 2, .name = "TunableWhite"},
	{ .channels = 1, .name = "WarmDimming"},
	{ .channels = 2, .name = "Changeover TW"},
	{ .channels = 1, .name = "Changeover WD"},
	{ .channels = 4, .name = "2 Channel 16-bit"}
};

const iziplus_config_def module_config[CONFIG_AMOUNT] =
{
	{ .size = 1, .name = "Current set", .min = 0, .max = 18, .dflt = 0 },
	{ .size = 1, .name = "Filter mode", .min = 0, .max = 3, .dflt = 0},
	{ .size = 1, .name = "NTC1 Temp Prot", .min = 60, .max = 90, .dflt = 70 },
	{ .size = 1, .name = "NTC2 Temp Prot", .min = 60, .max = 90, .dflt = 70 },
	{ .size = 1, .name = "Channel Swap", .min = 0, .max = 1, .dflt = 0 },
	{ .size = 1, .name = "Contact 1 Map", .min = 0, .max = 32, .dflt = 0 },
	{ .size = 1, .name = "Curve", .min = 0, .max = (CONFIG_MAX_CURVES - 1), .dflt = 0 },
	{ .size = 1, .name = "Frequency mode", .min = 0, .max = (CONFIG_MAX_FREQ - 1), .dflt = 0 }
};		// check CONFIG_SIZE if changed

const iziplus_monitor_def module_monitors[MONITOR_AMOUNT] =
{
	{ .size = 1, .name = "Supply Voltage" },		
	{ .size = 2, .name = "Output Power" },
	{ .size = 1, .name = "Output" },
	{ .size = 1, .name = "Internal Temp" },
	{ .size = 1, .name = "NTC1 Temp" },
	{ .size = 1, .name = "NTC2 Temp" },
	{ .size = 1, .name = "Max IntTemp" },
	{ .size = 1, .name = "Max NTC1Temp" },
	{ .size = 1, .name = "Max NTC2Temp" },
	{ .size = 1, .name = "Com Quality" },
	{ .size = 1, .name = "Active Contacts" },
	{ .size = 1, .name = "Status" },
	{ .size = 2, .name = "Fw voltage 1" },
	{ .size = 2, .name = "Fw voltage 2" },
	{ .size = 2, .name = "Operating days" },
	{ .size = 2, .name = "Active days 1" },
	{ .size = 2, .name = "Active days 2" },
	{ .size = 1, .name = "Frequency 1" },
	{ .size = 1, .name = "Frequency 2" }
};		// MONITOR_SIZE

/************************************************************************/
/* Code                                                                 */
/************************************************************************/

// Init current parameters
void IziPlus_Module_Init()
{
	module_reset_report = 30;		// Report reset cause for 3 seconds
	module_cpu_state.w = 0;
	if(reset_cause == RESET_CAUSE_POWER_UP)
		module_cpu_state.u.powerup = true;
	else if(reset_cause == RESET_CAUSE_EXTRST)
		module_cpu_state.u.extreset = true;
	else if(reset_cause == RESET_CAUSE_BOD)
		module_cpu_state.u.brownout = true;
	else if(reset_cause == RESET_CAUSE_SYSRST)
		module_cpu_state.u.sw_reset = true;
	else if(reset_cause == RESET_CAUSE_WATCHDOG)
		module_cpu_state.u.watchdog = true;
	
	IziPlus_Module_Update();
}

/************************************************************************/
/* Call after every config write and after init                         */
/************************************************************************/
void IziPlus_Module_Update()
{
	if(appConfig->mode < MODE_AMOUNT)
		module_channels_amount = module_modes[appConfig->mode].channels;
		
	/*max_intern_temp_raw = Adc_GetTempRaw(MAX_INTERN_TEMP);
	limit_intern_temp_raw = Adc_GetTempRaw(MAX_INTERN_TEMP - TEMP_LIMIT_START_OFFSET);
	max_ntc1_temp_raw = Adc_GetTempRaw(appConfig->config[2]);
	limit_ntc1_temp_raw = Adc_GetTempRaw(appConfig->config[2] - TEMP_LIMIT_START_OFFSET);
	max_ntc2_temp_raw = Adc_GetTempRaw(appConfig->config[3]);
	limit_ntc2_temp_raw = Adc_GetTempRaw(appConfig->config[3] - TEMP_LIMIT_START_OFFSET);*/
}

bool IziPlus_Module_TemperatureCheck(int16_t temp, uint16_t *temp_master, int16_t max_config, int16_t limit_config)
{
	if(temp <= limit_config)			// Temp above limit, reduce level (looks weird because value gets lower on a higher temperature, because the raw ad value is used)
	{
		if(temp > max_config)			// Still under max temp (where it should be 0)
		{
			uint16_t level_limit = (temp - max_config) * (TEMP_MAX_RESOLUTION / (limit_config - max_config));
			if(*temp_master > level_limit)
			{
				if(((*temp_master - level_limit) >= 128) && (*temp_master >= 4))
					*temp_master -= 4;		// -1 is 0.20% per 100ms
				else if(*temp_master > 0)
					*temp_master -= 1;		// -1 is 0.05% per 100ms
			}
			else if((*temp_master < level_limit) && (*temp_master < TEMP_MAX_RESOLUTION))
				*temp_master += 1;
		}
		else if(*temp_master > 10)		// Faster (max 10s) to 0% when on or over limit
			*temp_master -= 10;
		else 
			*temp_master = 0;		
		
		return true;					// Report temp too high, still reducing
	}
	else if(*temp_master < (TEMP_MAX_RESOLUTION - 10))
	{
		*temp_master += 10;
		return true;					// Report temp too high, still reducing
	}
	else	
		*temp_master = TEMP_MAX_RESOLUTION;
		
	return false;					// Report temp too high, still reducing
}

/************************************************************************/
/* Power in 10mW                                                        */
/************************************************************************/
bool IziPlus_Module_PowerCheck(uint16_t power, uint16_t *power_master)
{
	if(power >= POWER_MAX)			// Power too high?
	{
		if((power - 16) >= POWER_MAX)
		{
			uint16_t delta = ((power - POWER_MAX) / 8);
			if(*power_master > delta)
				*power_master -= delta;
		}
		else
			*power_master -= 1;
		return true;					// Report power too high, still reducing
	}
	else if(*power_master < POWER_MAX_RESOLUTION)
	{
		if((power + 16) < POWER_MAX)
		{
			uint16_t delta = ((POWER_MAX - power) / 8);
			if(*power_master + delta <= POWER_MAX_RESOLUTION)
				*power_master += delta;
			else
				*power_master += 1;
		}
		else
			*power_master += 1;
		return true;					// Report power too high, still reducing
	}
	else
		*power_master = POWER_MAX_RESOLUTION;
	
	return false;					// Report power too high, still reducing
}

uint16_t power_current1, power_current2;
/*
 * 100 ms timer timed by OS. Do not call OS routines from here
 */
void IziPlus_Module_Timer100ms()
{
	if(overrule_time_ch1 > 0)
		overrule_time_ch1--;
	if(overrule_time_ch2 > 0)
		overrule_time_ch2--;
	if(overrule_time_ch3 > 0)
		overrule_time_ch3--;
		
	if(safety_time_ch1 > 0)
		safety_time_ch1--;
	if(safety_time_ch2 > 0)
		safety_time_ch2--;
	if(safety_time_ch3 > 0)
		safety_time_ch3--;
		
	/*if(IziPlus_Module_TemperatureCheck(Adc_GetNtc1Raw(), &ntc1_temp_master, max_ntc1_temp_raw, limit_ntc1_temp_raw))
		State_SetWarning(STATE_WARNING_NTC1_HIGH);
	else
		State_ClearWarning(STATE_WARNING_NTC1_HIGH);
		
	if(IziPlus_Module_TemperatureCheck(Adc_GetNtc2Raw(), &ntc2_temp_master, max_ntc2_temp_raw, limit_ntc2_temp_raw))
		State_SetWarning(STATE_WARNING_NTC2_HIGH);
	else
		State_ClearWarning(STATE_WARNING_NTC2_HIGH);
	
	if(IziPlus_Module_TemperatureCheck(Adc_GetTemperatureRaw(), &intern_temp_master, max_intern_temp_raw, limit_intern_temp_raw))
		State_SetWarning(STATE_WARNING_TEMP_HIGH);
	else
		State_ClearWarning(STATE_WARNING_TEMP_HIGH);*/
	
	if(module_identify_time > 0)
	{
		if(--module_identify_time > 0)
		{
			if(module_identify_mode == IZIPLUS_IDENTMODE_BLINK)
			{
				if(module_identify_prs == 0)
					IziPlus_Module_Overrule_Ch1(255, 400, PRIO_OVERRULE_HIGH);
				else if(module_identify_prs == 4)
					IziPlus_Module_Overrule_Ch1(0, 2100, PRIO_OVERRULE_HIGH);
			
				if(module_identify_prs == 9 || module_identify_prs == 15)
					IziPlus_Module_Overrule_Ch2(255, 400, PRIO_OVERRULE_HIGH);
				else if(module_identify_prs == 13 || module_identify_prs == 19)
					IziPlus_Module_Overrule_Ch2(0, 1500, PRIO_OVERRULE_HIGH);			
			}
			else if(module_identify_mode == IZIPLUS_IDENTMODE_SPOTON)
			{
				IziPlus_Module_Overrule_Ch1(255, 1000, PRIO_OVERRULE_HIGH);				// Overrule until timer expires (always on)
				IziPlus_Module_Overrule_Ch2(255, 1000, PRIO_OVERRULE_HIGH);
			}
			else if(module_identify_mode == IZIPLUS_IDENTMODE_QUALITY)
			{
				uint8_t level = (iziplus_data_comquality() * 255) / 100;
				IziPlus_Module_Overrule_Ch1(level, 1000, PRIO_OVERRULE_HIGH);				// Overrule until timer expires (always on)
				IziPlus_Module_Overrule_Ch2(level, 1000, PRIO_OVERRULE_HIGH);
			}
		}
		else
		{
			IziPlus_Module_Overrule_Ch1(0, 0, PRIO_OVERRULE_HIGH);			
			IziPlus_Module_Overrule_Ch2(0, 0, PRIO_OVERRULE_HIGH);			
			module_cpu_state.u.identify = 0;
		}		
	}
	if(++module_identify_prs >= 25)
		module_identify_prs = 0;
		
	if(module_reset_report > 0)
	{
		if(--module_reset_report == 0)
		{
			module_cpu_state.u.powerup = false;		// Clear reset cause
			module_cpu_state.u.extreset = false;
			module_cpu_state.u.brownout = false;
			module_cpu_state.u.sw_reset = false;
			module_cpu_state.u.watchdog = false;
			IziPlus_Module_Update();
		}
	}
	
	if(++timer_prs >= 10)
	{
		appLogData->operating_sec++;
		if(iziplus_level_ch1)
			appLogData->active_ch1_sec++;
		if(iziplus_level_ch2)
			appLogData->active_ch2_sec++;
			
		timer_prs = 0;
	}
}

void IziPlus_Module_IdentifySync()
{
	if(module_identify_prs < 4 || module_identify_prs > 19)
		module_identify_prs = 0;
	else if((module_identify_prs != 9) && (module_identify_prs != 15) && (module_identify_prs != 13) && (module_identify_prs != 19))		// Don't skip upcoming change event
		module_identify_prs++;
}

bool IziPlus_Module_IsOverruled_Ch1()
{
	return overrule_time_ch1 > 0;
}

bool IziPlus_Module_IsOverruled_Ch2()
{
	return overrule_time_ch2 > 0;
}

void IziPlus_Module_Overrule_Ch1(uint8_t level, uint32_t time, uint8_t prio)
{
	if(prio >= overrule_prio_ch1 || overrule_time_ch1 == 0)
	{
		overrule_prio_ch1 = prio;
		overrule_level_ch1 = level;
		overrule_time_ch1 = time / 100;
	}
}

bool IziPlus_Module_IsSafetyOff_Ch1()
{
	return (safety_time_ch1 > 0);
}

void IziPlus_Module_SafetyOff_Ch1(uint16_t time)
{
	safety_time_ch1 = time / 100;
}


void IziPlus_Module_Overrule_Ch2(uint8_t level, uint32_t time, uint8_t prio)
{
	if(prio >= overrule_prio_ch2 || overrule_time_ch2 == 0)
	{
		overrule_prio_ch2 = prio;
		overrule_level_ch2 = level;
		overrule_time_ch2 = time / 100;
	}
}

bool IziPlus_Module_IsSafetyOff_Ch2()
{
	return (safety_time_ch2 > 0);
}

void IziPlus_Module_SafetyOff_Ch2(uint16_t time)
{
	safety_time_ch2 = time / 100;
}

bool IziPlus_Module_IsSafetyOff_Ch3()
{
	return (safety_time_ch3 > 0);
}

void IziPlus_Module_SafetyOff_Ch3(uint16_t time)
{
	safety_time_ch3 = time / 100;
}

bool IziPlus_Module_IsIdentifying()
{
	return (module_identify_time > 0);
}


iziplus_cpustate_u IziPlus_Module_GetCpuState()
{
	return module_cpu_state;
}

uint8_t *IziPlus_Module_GetMonitor()
{
	int8_t warning = State_GetHighestWarning();
	
	// Update vars here
	memset(module_monitor, 0, MONITOR_SIZE);
	module_monitor[0] = (uint8_t)(Analog_GetSupplyVoltage()/1000);
	
	uint16_t power1, power2;
	StepDown_GetPower(&power1, &power2);
	uint32_t power = (warning == STATE_WARNING_OUTPUT1_OPEN ? 0 : power1) + (warning == STATE_WARNING_OUTPUT2_OPEN ? 0 : power2);
	module_monitor[1] = (uint8_t)(power >> 0);
	module_monitor[2] = (uint8_t)(power >> 8);
	module_monitor[3] = intern_temp_master > ntc1_temp_master ? ((ntc1_temp_master > ntc2_temp_master) ?  (ntc2_temp_master/(TEMP_MAX_RESOLUTION/100)) : (ntc1_temp_master/(TEMP_MAX_RESOLUTION/100))) : (intern_temp_master/(TEMP_MAX_RESOLUTION/100));
	//module_monitor[4] = Adc_GetTemperature();
	//module_monitor[5] = Adc_GetNtc1();
	//module_monitor[6] = Adc_GetNtc2();
	//module_monitor[7] = Adc_GetTemperatureMax();
	//module_monitor[8] = Adc_GetNtc1Max();
	//module_monitor[9] = Adc_GetNtc2Max();
	module_monitor[10] = iziplus_data_comquality();
	//module_monitor[11] = IziInput_GetExtInput();
	
	int8_t error = State_GetHighestError();
	uint8_t state = 0;
	if(error >= 0)
	{
		if(error == STATE_ERROR_VIN_LOW)
			state = 132;
		//else if(error == STATE_ERROR_OUTPUT_SHORT)
		//	state = 136;
		else if(error == STATE_ERROR_OUTPUT1_SHORT)
			state = 138;
		else if(error == STATE_ERROR_OUTPUT2_SHORT)
			state = 140;
		//else if(error == STATE_ERROR_VIN_LOW)
		//	state = 132;
	}
	if(warning >= 0 && state == 0)
	{
		if(warning == STATE_WARNING_OUTPUT1_OPEN)
			state = 137;
		else if(warning == STATE_WARNING_OUTPUT2_OPEN)
			state = 139;
		else if(warning == STATE_WARNING_TEMP_HIGH)
			state = 128;
		else if(warning == STATE_WARNING_NTC1_HIGH)
			state = 130;
		else if(warning == STATE_WARNING_NTC2_HIGH)
			state = 131;
		else if(warning == STATE_WARNING_SUPPLY_HIGH)
			state = 133;
		else if(warning == STATE_WARNING_BAD_COMQUAL)
			state = 148;
		else if(warning == STATE_WARNING_POWER1_HIGH || warning == STATE_WARNING_POWER2_HIGH)
			state = 145;
		else if(warning == STATE_WARNING_UART_OVW_WARN)
			state = 151;
	}
	module_monitor[12] = state;
	uint16_t vled1 = Adc_GetVled1();
	if(vled1 < 1000)
		vled1 = 0;
	module_monitor[13] = (uint8_t)(vled1 >> 0);
	module_monitor[14] = (uint8_t)(vled1 >> 8);
	
	uint16_t vled2 = Adc_GetVled2();
	if(vled2 < 1000)
		vled2 = 0;
	module_monitor[15] = (uint8_t)(vled2 >> 0);
	module_monitor[16] = (uint8_t)(vled2 >> 8);
	
	uint16_t operating_days = appLogData->operating_sec / (24*60*60/10);		// Per 10th of day
	module_monitor[17] = (uint8_t)(operating_days >> 0);
	module_monitor[18] = (uint8_t)(operating_days >> 8);
	
	uint16_t active_days_ch1 = appLogData->active_ch1_sec / (24*60*60/10);
	module_monitor[19] = (uint8_t)(active_days_ch1 >> 0);
	module_monitor[20] = (uint8_t)(active_days_ch1 >> 8);
	
	uint16_t active_days_ch2 = appLogData->active_ch2_sec / (24*60*60/10);
	module_monitor[21] = (uint8_t)(active_days_ch2 >> 0);
	module_monitor[22] = (uint8_t)(active_days_ch2 >> 8);
	
	uint16_t f1, f2;
	StepDown_GetFrequency(&f1, &f2);
	module_monitor[23] = (uint8_t)(f1/100);
	module_monitor[24] = (uint8_t)(f2/100);

	return module_monitor;
}

void IziPlus_Module_SetIdentify(uint8_t mode, uint8_t time)
{
	// Todo: Handle all modes
	if(time > 0)
	{
		State_SetAttentionInfo(COLOR_MAGENTA, COLOR_BLUE, ((uint16_t)time * 60), 2);
		module_cpu_state.u.identify = 1;
		module_identify_time = ((uint16_t)time * 600);
		module_identify_mode = mode;
		module_identify_prs = 0;
	}
	else
	{
		State_ClearAttentionInfo();	
		module_cpu_state.u.identify = 0;
		module_identify_time = 1;
	}
}

uint8_t IziPlus_Module_GetChannelAmount()
{
	return module_channels_amount;
}

uint8_t IziPlus_Module_GetChannelAmountTemp()
{
	if(appConfig->mode < MODE_AMOUNT)
		return module_modes[appConfig->mode].channels;
	return module_channels_amount;
}

uint8_t IziPlus_Module_GetHwRevision()
{
	return get_hw_id();			
}

uint8_t IziPlus_Module_GetVariant()
{
	return 0;//get_revision_id();			
}

izi_versionplus_u IziPlus_Module_GetAppVersion()
{
	izi_versionplus_u appversion = { .v.major = firmare_info.version.v.major, .v.minor = firmare_info.version.v.minor, .v.build = firmare_info.version.v.build };
	return appversion;			
}

izi_versionplus_u IziPlus_Module_GetBootVersion()
{
	version_u *boot_version = (version_u *)BOOT_VERSION_ADDRESS;
	izi_versionplus_u bootversion = { .v.major = boot_version->v.major, .v.minor = boot_version->v.minor, .v.build = boot_version->v.build };
	return bootversion;			
}

izi_versionplus_u IziPlus_Module_GetImageVersion()
{
	firmware_t *image_info = (firmware_t *)(FLASH_APP_MIRROR_END - FLASH_APP_FW_INFO_SIZE - FLASH_APP_MIRROR_SHIFT);
	izi_versionplus_u imageversion = { .v.major = image_info->version.v.major, .v.minor = image_info->version.v.minor, .v.build = image_info->version.v.build };
	return imageversion;
}

izi_version_u IziPlus_Module_GetTypedefVersion()
{
	izi_version_u typedefversion = { .v.major = 2, .v.minor = 2 };
	return typedefversion;			// Min version of TDE file
}

izi_version_u IziPlus_Module_GetLedtableVersion()
{
	izi_version_u ledtableversion = { .v.major = 0xFF, .v.minor = 0xFF };
	return ledtableversion;			// Todo: real led table version
}

uint8_t IziPlus_Module_GetMemoryVersion()
{
	return CONFIG_VERSION;		
}

bool IziPlus_Module_HasOutputMaster()
{
	return appConfig->mode == MODE_2_CHANMASTER;
}

bool IziPlus_Module_Is16bit()
{
	return appConfig->mode == MODE_2_CHANNEL_16;
}

int16_t IziPlus_Module_GetOutput1Index()
{
	uint8_t swap = CONFIG_PAR_SWAP(appConfig->config);
	if(appConfig->mode == MODE_SINGLE_CHANNEL && swap)
		return -1;
	if(appConfig->mode == MODE_1_CHANNEL)
		return 0;
	
	int index = (appConfig->mode != MODE_2_CHANMASTER) ? 0 : 1;
	if(swap)
	{
		index++;
		if(IziPlus_Module_Is16bit())
			index++;
	}
		
	return index;
}

int16_t IziPlus_Module_GetOutput2Index()
{
	uint8_t swap = CONFIG_PAR_SWAP(appConfig->config);
	if(appConfig->mode == MODE_SINGLE_CHANNEL && !swap)
		return -1;
	if(appConfig->mode == MODE_1_CHANNEL || appConfig->mode == MODE_WARM_DIM || appConfig->mode == MODE_CHANGEOVER_WD)
		return 0;
	
	int index = ((appConfig->mode != MODE_2_CHANMASTER) && !(IziPlus_Module_Is16bit())) ? 1 : 2;
	if(swap)
	{
		index--;
		if(IziPlus_Module_Is16bit())
			index--;
	}
	return index;
}

const uint8_t Tw_Table[] = 
{
	0,           83,         96,        104,        110,        115,        119,        123,        127,        130,        132,        135,        137,      140,        142,        144,
	146,        147,        149,        151,        152,        154,        155,        157,        158,        159,        161,        162,        163,      164,        165,        166,
	168,        169,        170,        171,        172,        173,        173,        174,        175,        176,        177,        178,        179,      179,        180,        181,
	182,        183,        183,        184,        185,        185,        186,        187,        188,        188,        189,        190,        190,      191,        191,        192,
	193,        193,        194,        194,        195,        196,        196,        197,        197,        198,        198,        199,        199,      200,        200,        201,
	202,        202,        203,        203,        204,        204,        204,        205,        205,        206,        206,        207,        207,      208,        208,        209,
	209,        210,        210,        210,        211,        211,        212,        212,        212,        213,        213,        214,        214,      214,        215,        215,
	216,        216,        216,        217,        217,        218,        218,        218,        219,        219,        219,        220,        220,      220,        221,        221,
	222,        222,        222,        223,        223,        223,        224,        224,        224,        225,        225,        225,        226,      226,        226,        227,
	227,        227,        227,        228,        228,        228,        229,        229,        229,        230,        230,        230,        231,      231,        231,        231,
	232,        232,        232,        233,        233,        233,        233,        234,        234,        234,        235,        235,        235,      235,        236,        236,
	236,        236,        237,        237,        237,        238,        238,        238,        238,        239,        239,        239,        239,      240,        240,        240,
	240,        241,        241,        241,        241,        242,        242,        242,        242,        243,        243,        243,        243,      244,        244,        244,
	244,        245,        245,        245,        245,        245,        246,        246,        246,        246,        247,        247,        247,      247,        248,        248,
	248,        248,        248,        249,        249,        249,        249,        249,        250,        250,        250,        250,        251,      251,        251,        251,
	251,        252,        252,        252,        252,        252,        253,        253,        253,        253,        253,        254,        254,      254,        254,        255
};

uint16_t IziPlus_Module_Chan1()
{
	if(safety_time_ch1 > 0)
		return 0;
	
	uint16_t level_ch1;
	int16_t outchan1_index = IziPlus_Module_GetOutput1Index();
	if(outchan1_index >= 0)	
	{
		uint16_t lvl_ch1 = overrule_time_ch1 == 0 ? Izi_OutputGet(outchan1_index) : overrule_level_ch1;
		if(IziPlus_Module_HasOutputMaster())					// Is there a master i this mode?
		{
			uint16_t lvl_master = overrule_time_ch1 == 0 ? Izi_OutputGet(0) : 0xFF;				// If so, merge them. If overruled, set master to full
			if(lvl_master != 0xFF || lvl_ch1 != 0xFF)
				level_ch1 = lvl_master * lvl_ch1;
			else
				level_ch1 = 0xFFFF;
		}
		else if(overrule_level_ch1 == 0 && IziPlus_Module_Is16bit())
			level_ch1 = Izi_OutputGet(outchan1_index + 1) | (lvl_ch1 << 8);
		else
			level_ch1 = (lvl_ch1 << 8) | lvl_ch1; 
	}
	else
		level_ch1 = 0;
		
	StepDown_GetPower(&power_current1, &power_current2);
	if(IziPlus_Module_PowerCheck(power_current1, &power_ch1_master))
		State_SetWarning(STATE_WARNING_POWER1_HIGH);
	else
		State_ClearWarning(STATE_WARNING_POWER1_HIGH);
	
	iziplus_level_ch1 = level_ch1;
	
	return level_ch1;
}

uint16_t IziPlus_Module_Chan2()
{
	if(safety_time_ch2 > 0)
		return 0;
	
	uint16_t level_ch2;
	int16_t outchan2_index = IziPlus_Module_GetOutput2Index();
	if(outchan2_index >= 0)
	{
		uint16_t lvl_ch2 = overrule_time_ch2 == 0 ? Izi_OutputGet(outchan2_index) : overrule_level_ch2;
		if(IziPlus_Module_HasOutputMaster())					// Is there a master in this mode?
		{
			uint16_t lvl_master = overrule_time_ch2 == 0 ? Izi_OutputGet(0) : 0xFF;				// If so, merge them. If overruled, set master to full
			if(lvl_master != 0xFF || lvl_ch2 != 0xFF)
				level_ch2 = lvl_master * lvl_ch2;
			else
				level_ch2 = 0xFFFF;
		}
		else if(overrule_level_ch1 == 0 && IziPlus_Module_Is16bit())
		{
			level_ch2 = Izi_OutputGet(outchan2_index + 1) | (lvl_ch2 << 8);
		}
		else if(appConfig->mode == MODE_WARM_DIM || appConfig->mode == MODE_CHANGEOVER_WD)
		{
			if(IziPlus_Module_IsIdentifying())
				level_ch2 = (overrule_level_ch1 << 8) | overrule_level_ch1;
			else if(lvl_ch2 >= 63 && lvl_ch2 < 255)
				level_ch2 = ((lvl_ch2 - 63) * 171) * 2;
			else if(lvl_ch2 == 255)	
				level_ch2 = 0xFFFF;
			else
				level_ch2 = 0;			
		}
		else if(appConfig->mode == MODE_TUNABLE_WHITE)
		{
			int16_t outchan1_index = IziPlus_Module_GetOutput1Index();
			if(outchan1_index >= 0)
			{
				uint16_t lvl_ch1 = overrule_time_ch1 == 0 ? Izi_OutputGet(outchan1_index) : overrule_level_ch1;
				if(lvl_ch1 < 0xFF)
					level_ch2 = Tw_Table[lvl_ch2] * lvl_ch1;
				else
					level_ch2 = (Tw_Table[lvl_ch2] << 8) | Tw_Table[lvl_ch2];
			}
			else
				level_ch2 = 0;
		}
		else
			level_ch2 = (lvl_ch2 << 8) | lvl_ch2;
	}
	else
		level_ch2 = 0;
	
	StepDown_GetPower(&power_current1, &power_current2);
	if(IziPlus_Module_PowerCheck(power_current2, &power_ch2_master))
		State_SetWarning(STATE_WARNING_POWER2_HIGH);
	else
		State_ClearWarning(STATE_WARNING_POWER2_HIGH);
	
	iziplus_level_ch2 = level_ch2;
	return level_ch2;
}

uint16_t IziPlus_Module_TempLimit_Chan1(uint16_t pwm)
{
	uint16_t temp_master = intern_temp_master > ntc1_temp_master ? ntc1_temp_master : intern_temp_master;		// Take the lowest level
	if(power_ch1_master < temp_master)
		temp_master = power_ch1_master;
		
	if(temp_master < TEMP_MAX_RESOLUTION)
		pwm = (pwm * temp_master)/TEMP_MAX_RESOLUTION;
		
	return pwm;
}

uint16_t IziPlus_Module_TempLimit_Chan2(uint16_t pwm)
{
	uint16_t temp_master = intern_temp_master > ntc2_temp_master ? ntc2_temp_master : intern_temp_master;		// Take the lowest level
	if(power_ch2_master < temp_master)
		temp_master = power_ch2_master;
		
	if(temp_master < TEMP_MAX_RESOLUTION)
		pwm = (pwm * temp_master)/TEMP_MAX_RESOLUTION;
	
	return pwm;
}

uint16_t IziPlus_Module_TempLimit_Chan3(uint16_t pwm)
{
	uint16_t temp_master = intern_temp_master > ntc2_temp_master ? ntc2_temp_master : intern_temp_master;		// Take the lowest level
	if(power_ch2_master < temp_master)
		temp_master = power_ch2_master;
	
	if(temp_master < TEMP_MAX_RESOLUTION)
		pwm = (pwm * temp_master)/TEMP_MAX_RESOLUTION;
	
	return pwm;
}

void IziPlus_NoComCheck()
{
	bool isok = IziPlus_LightDataOk();
	if(!isok)
	{
		if(xTaskGetTickCount() < 5000)				// Do nothing if shorter than 5 sec after power-up (should not go on during discover)
			return;
		if(isok != iziplus_last_comcheck)
		{
			overrule_level_ch1 = iziplus_level_ch1;
			overrule_level_ch2 = iziplus_level_ch2;
		}
		if((iziplus_data_wasok && (DMXFAIL_OPERATE(appConfig->dmxfail) == DMXFAIL_MAX)) || (!iziplus_data_wasok && (DMXFAIL_PUP(appConfig->dmxfail) == DMXFAIL_MAX)))
		{
			IziPlus_Module_Overrule_Ch1((overrule_level_ch1 < 255 && iziplus_prs_comcheck == 0) ? overrule_level_ch1 + 1 : overrule_level_ch1, 1000, PRIO_OVERRULE_LOWEST);
			IziPlus_Module_Overrule_Ch2((overrule_level_ch2 < 255 && iziplus_prs_comcheck == 0) ? overrule_level_ch2 + 1 : overrule_level_ch2, 1000, PRIO_OVERRULE_LOWEST);
		}
		else if((iziplus_data_wasok && (DMXFAIL_OPERATE(appConfig->dmxfail) == DMXFAIL_OFF)) || (!iziplus_data_wasok && (DMXFAIL_PUP(appConfig->dmxfail) == DMXFAIL_OFF)))
		{
			IziPlus_Module_Overrule_Ch1((overrule_level_ch1 > 0 && iziplus_prs_comcheck == 0) ? overrule_level_ch1 - 1 : overrule_level_ch1, 1000, PRIO_OVERRULE_LOWEST);
			IziPlus_Module_Overrule_Ch2((overrule_level_ch2 > 0 && iziplus_prs_comcheck == 0) ? overrule_level_ch2 - 1 : overrule_level_ch2, 1000, PRIO_OVERRULE_LOWEST);
		}
		
		if(++iziplus_prs_comcheck >= 2)
			iziplus_prs_comcheck = 0;
	}
	else if(isok != iziplus_last_comcheck)
	{
		IziPlus_Module_Overrule_Ch1(0, 0, PRIO_OVERRULE_LOWEST);
		IziPlus_Module_Overrule_Ch2(0, 0, PRIO_OVERRULE_LOWEST);
	}
	else
		iziplus_data_wasok = true;			// Mark it has been ok once since power-up, and so DMXFAIL_OPERATE should be used 
		
	iziplus_last_comcheck = isok;
}