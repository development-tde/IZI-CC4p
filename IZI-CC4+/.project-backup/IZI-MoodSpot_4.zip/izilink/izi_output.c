/*
 * izi_output.c
 *
 *  Created on: 3 jun. 2020
 *      Author: Milo
 */

#include "includes.h"
#include "izi_output.h"
#include "timers.h"

#define IZI_TIMEROS_TICKS	25

uint8_t izi_output_buffer[IZI_OUTPUT_MAX] = {0};
uint8_t izi_output_merge[IZI_OUTPUT_MAX] = {0};

TimerHandle_t  xIziOutput_Timer = NULL;

trace_level_t izi_output_trace_lvl = IZI_OUTPUT_DFLT_TRACE_LVL;

// Proto

void IziOutput_Init()
{
	memset(izi_output_buffer, 0, sizeof(izi_output_buffer));
	memset(izi_output_merge, 0, sizeof(izi_output_merge));
}

void Izi_OutputSet(int channel, uint8_t value)
{
	if(channel >= IZI_OUTPUT_MAX)
		return;

	izi_output_buffer[channel] = value;
}

void Izi_OutputSetBuffer(int channel, uint8_t *values, uint16_t len)
{
	if((channel + len) > IZI_OUTPUT_MAX)
		return;

	memcpy(&izi_output_buffer[channel], values, len);
}

void Izi_OutputSetBufferFixed(int channel, uint8_t value, uint16_t len)
{
	if((channel + len) > IZI_OUTPUT_MAX)
		return;

	memset(&izi_output_buffer[channel], value, len);
}

uint8_t Izi_OutputGet(int channel)
{
	if(channel >= IZI_OUTPUT_MAX)
		return 0;

	return izi_output_buffer[channel];
}

uint8_t *Izi_OutputGetTotal()
{
	return izi_output_buffer;
}

uint8_t *Izi_OutputGetMerge()
{
	for(int i = 0; i < IZI_OUTPUT_MAX; i++)
	{
		izi_output_merge[i] = izi_output_buffer[i];
	}
	return izi_output_merge;
}

void Izi_Output_debug(uint8_t *data, uint8_t length)
{
	if(data[0] == 't' && length >= 2)
	{
		izi_output_trace_lvl = data[1] - '0';
		IZI_OUTPUT_TRACE_ERROR("Trace level: %d\r\n", izi_output_trace_lvl);
	}
	else if(data[0] == 'd' && length >= 1)
	{
		IZI_OUTPUT_TRACE_ERROR("DMX data 1 - 4: %02x %02x %02x %02x\r\n", izi_output_buffer[0], izi_output_buffer[1], izi_output_buffer[2], izi_output_buffer[3]);
	}
}
