/*
 * izi_output.h
 *
 *  Created on: 3 jun. 2020
 *      Author: Milo
 */

#ifndef IZI_OUTPUT_H_
#define IZI_OUTPUT_H_

#include "includes.h"

extern trace_level_t izi_output_trace_lvl;

#define IZI_OUTPUT_MAX		1024

#define IZI_OUPUT_PREFIX	"[izo]\t"

#define IZI_OUTPUT_TRACE_ERROR(...)		//if(izi_output_trace_lvl >= TRACE_LEVEL_ERROR)		{ esp_printf(Debug_Putc, IZI_OUPUT_PREFIX, __VA_ARGS__); }
#define IZI_OUTPUT_TRACE_WARNING(...)	//if(izi_output_trace_lvl >= TRACE_LEVEL_WARNING)		{ esp_printf(Debug_Putc, IZI_OUPUT_PREFIX, __VA_ARGS__); }
#define IZI_OUTPUT_TRACE_INFO(...)		//if(izi_output_trace_lvl >= TRACE_LEVEL_INFO)		{ esp_printf(Debug_Putc, IZI_OUPUT_PREFIX, __VA_ARGS__); }
#define IZI_OUTPUT_TRACE_DEBUG(...)		//if(izi_output_trace_lvl >= TRACE_LEVEL_DEBUG)		{ esp_printf(Debug_Putc, IZI_OUPUT_PREFIX, __VA_ARGS__); }

void IziOutput_Init();
void Izi_OutputSet(int channel, uint8_t value);
void Izi_OutputSetBuffer(int channel, uint8_t *values, uint16_t len);
void Izi_OutputSetBufferFixed(int channel, uint8_t value, uint16_t len);
uint8_t Izi_OutputGet(int channel);
uint8_t *Izi_OutputGetMerge();
uint8_t *Izi_OutputGetTotal();

void Izi_Output_debug(uint8_t *data, uint8_t length);

#endif /* IZI_OUTPUT_H_ */
