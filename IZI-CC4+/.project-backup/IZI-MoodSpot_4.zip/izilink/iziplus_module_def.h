/*
 * iziplus_module_def.h
 *
 * Created: 26-2-2022 17:28:25
 *  Author: Milo
 */ 


#ifndef IZIPLUS_MODULE_DEF_H_
#define IZIPLUS_MODULE_DEF_H_

#include "izi_module.h"
#include "iziplus_frames.h"

#define IZIPLUS_DEVTYPE		0x100		// CC2+

#define MODE_AMOUNT			9

#define MODE_1_CHANNEL		0
#define MODE_2_CHANMASTER	1
#define MODE_2_CHANNEL		2
#define MODE_SINGLE_CHANNEL	3
#define MODE_TUNABLE_WHITE	4
#define MODE_WARM_DIM		5
#define MODE_CHANGEOVER_TW	6
#define MODE_CHANGEOVER_WD	7
#define MODE_2_CHANNEL_16	8

#define DMXFAIL_OFF			0
#define DMXFAIL_HOLD		1
#define DMXFAIL_MAX			2
#define DMXFAIL_PUP(x)		(x & 0x0F)
#define DMXFAIL_OPERATE(x)	((x >> 4) & 0x0F)

#define CONFIG_AMOUNT		8
#define CONFIG_SIZE			8		// If 16-bit is used, calc total bytes

#define CONFIG_PAR_CURRENT	0		// Current setting from 150 to 1050mA
#define CONFIG_CURRENT_MA(v)		(150 + (v[0] * 50))		// Convert setting to mA
#define CONFIG_CURRENT_MA_RAW(v)	(v[0])		// Convert setting to mA
#define CONFIG_CURRENT_MA_REV(c, mA)	c[0] = ((mA - 150) / 50)		// Convert mA to setting
#define CONFIG_PAR_SWAP(v)	v[4]

#define CONFIG_FILTER_NORMAL	0
#define CONFIG_FILTER_FAST		1
#define CONFIG_FILTER_DYNAMIC	2
#define CONFIG_FILTER_SLOW		3
#define CONFIG_PAR_FILTER(v)	v[1]

#define CONFIG_MAX_CURVES	3

#define CONFIG_CURVE_NORMAL		0
#define CONFIG_CURVE_DEEP		1
#define CONFIG_CURVE_DEEPEST	2
#define CONFIG_PAR_CURVE(v)		v[6]

#define CONFIG_VIRTUAL_IN(v)	(v[5])		// Virtual input (0 = none)

#define CONFIG_MAX_FREQ			4

#define CONFIG_FREQ_NORMAL				0
#define CONFIG_FREQ_DYNAMIC				1
#define CONFIG_FREQ_DYNAMIC_LIMIT		2
#define CONFIG_FREQ_LOW					3
#define CONFIG_PAR_FREQ(v)		v[7]

#define MONITOR_AMOUNT		19
#define MONITOR_SIZE		25		// If 16-bit is used, calc total bytes

#define PRIO_OVERRULE_LOWEST	0
#define PRIO_OVERRULE_LOW		2
#define PRIO_OVERRULE_MEDIUM	4
#define PRIO_OVERRULE_HIGH		6
#define PRIO_OVERRULE_HIGHEST	8

typedef struct
{
	uint8_t channels;
	uint8_t res;
	char name[18];
}iziplus_mode_def;

typedef struct
{
	uint8_t size;
	uint8_t res;
	uint16_t dflt;
	uint16_t min;
	uint16_t max;
	char name[16];
}iziplus_config_def;

typedef struct
{
	uint8_t size;
	uint8_t res;
	char name[18];
}iziplus_monitor_def;


extern const iziplus_mode_def module_modes[MODE_AMOUNT];
extern const iziplus_config_def module_config[CONFIG_AMOUNT];

// Proto
void IziPlus_Module_Init();
void IziPlus_Module_Update();
void IziPlus_Module_Timer100ms();
void IziPlus_Module_SetIdentify(uint8_t mode, uint8_t time);
iziplus_cpustate_u IziPlus_Module_GetCpuState();
uint8_t *IziPlus_Module_GetMonitor();
uint8_t IziPlus_Module_GetChannelAmount();
uint8_t IziPlus_Module_GetChannelAmountTemp();
uint8_t IziPlus_Module_GetHwRevision();
uint8_t IziPlus_Module_GetVariant();
izi_versionplus_u IziPlus_Module_GetAppVersion();
izi_versionplus_u IziPlus_Module_GetBootVersion();
izi_versionplus_u IziPlus_Module_GetImageVersion();
izi_version_u IziPlus_Module_GetTypedefVersion();
izi_version_u IziPlus_Module_GetLedtableVersion();
uint8_t IziPlus_Module_GetMemoryVersion();
uint16_t IziPlus_Module_Chan1();
uint16_t IziPlus_Module_Chan2();
void IziPlus_Module_Overrule_Ch1(uint8_t level, uint32_t time, uint8_t prio);
void IziPlus_Module_Overrule_Ch2(uint8_t level, uint32_t time, uint8_t prio);
bool IziPlus_Module_IsSafetyOff_Ch1();
void IziPlus_Module_SafetyOff_Ch1(uint16_t time);
bool IziPlus_Module_Overrule_Off_Ch1();
bool IziPlus_Module_IsSafetyOff_Ch2();
void IziPlus_Module_SafetyOff_Ch2(uint16_t time);
bool IziPlus_Module_Overrule_Off_Ch2();
bool IziPlus_Module_IsSafetyOff_Ch3();
void IziPlus_Module_SafetyOff_Ch3(uint16_t time);
bool IziPlus_Module_Overrule_Off_Ch3();
bool IziPlus_Module_IsIdentifying();
uint16_t IziPlus_Module_TempLimit_Chan1(uint16_t pwm);
uint16_t IziPlus_Module_TempLimit_Chan2(uint16_t pwm);
uint16_t IziPlus_Module_TempLimit_Chan3(uint16_t pwm);
void IziPlus_NoComCheck();
bool IziPlus_Module_IsOverruled_Ch1();
bool IziPlus_Module_IsOverruled_Ch2();
//bool IziPlus_Module_IsOverruled_Ch3();
void IziPlus_Module_IdentifySync();

#endif /* IZIPLUS_MODULE_DEF_H_ */