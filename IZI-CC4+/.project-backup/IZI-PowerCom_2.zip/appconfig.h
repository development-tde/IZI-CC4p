/*
 * appconfig.h
 *
 *  Created on: 15 jun. 2020
 *      Author: Milo
 */

#ifndef SOURCE_APPCONFIG_H_
#define SOURCE_APPCONFIG_H_

#include "izi_module.h"

#define CONFIG_VERSION	5

#define NAME_SIZE		32
#define PROJECT_SIZE	16

#define APPSETTING_SECTOR_SIZE		512
#define APPSETTING_MAX_PC			4

typedef struct appconfig_s {
	// General
	uint32_t crc;
	uint32_t ref;				// time of file (used in code as first after crc, so do not move)
	uint32_t version;
	uint32_t serial;
	char name[NAME_SIZE];
	char project[PROJECT_SIZE];	// Not used
	uint32_t can_network_id;
	uint8_t can_slave_id;
	uint8_t pl_frequency;
	uint16_t app_modules;
	uint8_t pl_rate;
	uint8_t transparent_mode;
	uint8_t timing_offset;
	uint8_t master_idx;
	uint8_t master_total;
	uint8_t dbg_on;
	uint16_t location_id;
	uint32_t pan_id;
	uint8_t pc_config[APPSETTING_MAX_PC];
	char dummy[APPSETTING_SECTOR_SIZE-80];				// Filler (page), check AppConfig_Set if larger than 512 (is page size)
} appconfig_t;

#define APPCFG_TXLEVEL			0
#define APPCFG_TXLEVELRAW		1

extern appconfig_t *appConfig;

#define APPMODULES_MAX		32
typedef struct appmodule_s {
	izi_module_base_t modules[APPMODULES_MAX];
}appmodule_t;

// Proto
void AppConfig_Init();
void AppConfig_Default();
void AppConfig_Print();
appconfig_t *AppConfig_Get();
bool AppConfig_Set();

#endif /* SOURCE_APPCONFIG_H_ */
