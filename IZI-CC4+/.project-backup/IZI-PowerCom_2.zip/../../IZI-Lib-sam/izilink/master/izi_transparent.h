/*
 * izi_transparent.h
 *
 *  Created on: 16 apr. 2021
 *      Author: Milo
 */

#ifndef IZI_TRANSPARENT_H_
#define IZI_TRANSPARENT_H_

#define IZI_TRANSPARENT_MAX_RX_BUFFERS	2
#define IZI_TRANSPARENT_MAX_RX_BUFFER	512

#define IZI_TRANSPARENT_MAX_TX_BUFFERS	2
#define IZI_TRANSPARENT_MAX_TX_BUFFER	1024

void IziTransparent_Init();
void IziTransparent_Send(uint8_t *bfr, uint16_t length, uint8_t cmd);
void IziTransparent_SendStart(uint8_t *bfr, uint16_t length, uint8_t cmd);

#endif /* IZI_TRANSPARENT_H_ */
