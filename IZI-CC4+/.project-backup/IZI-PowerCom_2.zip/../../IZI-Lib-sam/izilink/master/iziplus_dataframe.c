/*
 * iziplus_dataframe.c
 *
 *  Created on: 22 apr. 2021
 *      Author: Milo
 */
#include "includes.h"
#include "iziplus_dataframe.h"
#include "iziplus_networkframe.h"
#include "appconfig.h"
#include "crc.h"
//#include "rtctime.h"
#include "powerline/dcbm1_driver.h"
#include "izi_transparent.h"
//#include "timing.h"

// Defines
#define TASK_PLUS_RX_STACK_SIZE (1024 / sizeof(portSTACK_TYPE))
#define TASK_PLUS_RX_TASK_PRIORITY (tskIDLE_PRIORITY + 5)
#define	IZIPLUS_RX_FRAME_BFR_MAX	4

// Globals
static bool wildcard_enable = false;
trace_level_t iziplus_trace_lvl = IZI_DFLT_TRACE_LVL;

SemaphoreHandle_t xiziplus_data_CmdSemaphore = NULL;
static TaskHandle_t		xiziplus_data_RxTask;
static SemaphoreHandle_t xiziplus_data_RxCmdSemaphore = NULL;
static SemaphoreHandle_t xiziplus_data_TxCmdSemaphore = NULL;

static volatile bool iziplus_req_pending = false, iziplus_not_pending = false;
static uint8_t iziplus_req_cmd;
static uint8_t iziplus_req_seqid;
static uint32_t iziplus_req_destination;

static volatile uint8_t iziplus_next_rx_idx = 0;

static iziplus_data_frame_t iziplus_rx_frame[IZIPLUS_RX_FRAME_BFR_MAX];
static volatile uint8_t iziplus_rx_frame_sel = 0;
static TickType_t iziplus_rx_time[IZIPLUS_RX_FRAME_BFR_MAX];
static uint8_t iziplus_rx_overflow = 0;

static bool iziplus_transparent_mode = false;
static bool iziplus_no_retry = false;

static volatile uint16_t iziplus_rx_frame_idx;
static volatile bool iziplus_rx_start_detect = false;
static volatile bool iziplus_rx_cmd_detect = false;
static volatile uint8_t iziplus_escape_esc = false;

uint8_t iziplus_nwdata_rx[IZIPLUS_MAX_DATA];
uint16_t iziplus_nwdata_rx_length;

uint16_t iziplus_rsp_amount = 0, iziplus_req_amount = 0, iziplus_req_per_sec = 0;
uint8_t iziplus_dataframe[1024];

TickType_t last_send_ticks = 0;

// Proto
static void iziplus_data_RxTask(void *p);
void iziplus_data_Dcbm1Rx(uint8_t data, bool interrupt);
void iziplus_data_Dcbm1TxReady();
void iziplus_data_handle_rx(iziplus_data_frame_t *frame);

void iziplus_dataframe_init()
{
	iziplus_transparent_mode = appConfig->transparent_mode == 0x44;
	if(xiziplus_data_RxCmdSemaphore == NULL)
		xiziplus_data_RxCmdSemaphore = xSemaphoreCreateBinary();
	if(xiziplus_data_TxCmdSemaphore == NULL)
		xiziplus_data_TxCmdSemaphore = xSemaphoreCreateBinary();

	if(xiziplus_data_CmdSemaphore == NULL)
		xiziplus_data_CmdSemaphore = xSemaphoreCreateBinary();

	dcbm1_set_rx_callback(iziplus_data_Dcbm1Rx);
	dcbm1_set_txready_callback(iziplus_data_Dcbm1TxReady);

	if(xiziplus_data_RxTask == NULL)
	{
		if (xTaskCreate(iziplus_data_RxTask, "IziPlusRx", TASK_PLUS_RX_STACK_SIZE, NULL, TASK_PLUS_RX_TASK_PRIORITY, &xiziplus_data_RxTask) != pdPASS) {
			while (1) {
				;
			}
		}
	}
#if IZI_TIMING > 0
	Timing_Init();
#endif
}

static iziplus_cb_func_rxptr iziplus_cb_func_rx = NULL;
void iziplus_dataframe_set_rx_callback(iziplus_cb_func_rxptr ptr)
{
	iziplus_cb_func_rx = ptr;
}

static iziplus_cb_func_onlineptr iziplus_cb_func_online = NULL;
void iziplus_dataframe_set_online_callback(iziplus_cb_func_onlineptr ptr)
{
	iziplus_cb_func_online = ptr;
}

static iziplus_cb_func_tokenptr iziplus_cb_func_token = NULL;
void iziplus_dataframe_set_token_callback(iziplus_cb_func_tokenptr ptr)
{
	iziplus_cb_func_token = ptr;
}

void iziplus_dataframe_wildcard(bool enable)
{
	wildcard_enable = enable;
}

uint16_t iziplus_dataframe_sendreq(uint32_t destination, uint16_t devtype, uint8_t *data, uint16_t length, uint8_t *frame)
{
	if(length > IZIPLUS_MAX_DATAFRAME_DATA)
		return 0;

	uint16_t send_len = IZPLUS_MAX_DATAFRAME_BASE + length;
	iziplus_data_frame_t data_frame;
	data_frame.pan_id = wildcard_enable ? IZIPLUS_PANID_WILDCARD : appConfig->pan_id; 
	data_frame.destination = destination;
	data_frame.device_type = devtype;
	data_frame.lengthdir.u.length = length;
	data_frame.lengthdir.u.direction = dir_masterslave;
	memcpy(data_frame.data, data, length);
	uint16_t crc = Crc16((uint8_t *)&data_frame, send_len - 4, 0x0000) ^ 0xFFFF;			// Crc is without Start word (and crc itself)
	data_frame.data[length] = (uint8_t)(crc >> 8);
	data_frame.data[length + 1] = (uint8_t)crc;

	frame[0] = (uint8_t)(IZIPLUS_START >> 8);
	frame[1] = (uint8_t)(IZIPLUS_START >> 0);

	uint16_t idx = 2;
	bool escape_start = false, escape_esc = false;
	for(int i = 0; i < send_len - 2; i++)
	{
		uint8_t data = ((uint8_t *)&data_frame)[i];
		frame[idx++] = data;
		if(escape_esc && data == 0xDC)
		{
			frame[idx++] = IZIPLUS_ESCAPE_ESC;
			escape_esc = false;
		}
		else if(data == 0xAC)
			escape_esc = true;
		else
			escape_esc = false;

		if(escape_start && data == 0xBA)
		{
			frame[idx-2] = 0xAC;
			frame[idx-1] = 0xDC;
			frame[idx++] = IZIPLUS_ESCAPE_START;
			escape_start = false;
		}
		else if(data == 0xAB)
			escape_start = true;
		else
			escape_start = false;
	}
	return idx;
}

bool iziplus_dataframe_checkcrc(iziplus_data_frame_t *data_frame)
{
	return (Crc16((uint8_t *)data_frame, data_frame->lengthdir.u.length + IZPLUS_MAX_DATAFRAME_NOSTART, 0x0000) ^ 0xFFFF) == 0;

}

bool iziplus_dataframe_sendspecial(uint32_t destination, uint16_t devtype, uint8_t *data, uint16_t length)
{
	uint16_t len = iziplus_dataframe_sendreq(destination, devtype, data, length, iziplus_dataframe);

	uint16_t res = dcbm1_send((uint8_t *)iziplus_dataframe, len);
	if(iziplus_transparent_mode)
		IziTransparent_Send((uint8_t *)iziplus_dataframe, len, 0x80);

	return res == len;
}

/************************************************************************/
/* Rx handler task														        */
/************************************************************************/
static void iziplus_data_RxTask(void *p)
{
	while(true)
	{
		if(xSemaphoreTake(xiziplus_data_RxCmdSemaphore, 1000))
		{
			uint8_t idx = iziplus_next_rx_idx;									// Used to handle in correct order
			for(int i = 0; i < IZIPLUS_RX_FRAME_BFR_MAX; i++)
			{
				if(iziplus_rx_time[idx] > 0)
				{
					iziplus_data_frame_t *frame = &iziplus_rx_frame[idx];
	
					IZIPLUS_TRACE_INFO("Frame rx[%d]: %d %d\r\n", idx, xTaskGetTickCount(), iziplus_rx_time[idx]);
					if(iziplus_transparent_mode)
						IziTransparent_SendStart((uint8_t *)frame, frame->lengthdir.u.length + 16, 0x80);

					if(iziplus_dataframe_checkcrc(frame))
					{
						if(frame->lengthdir.u.length >= sizeof(iziplus_network_data_t) && frame->lengthdir.u.direction == dir_slavemaster)
						{
							iziplus_data_handle_rx(frame);				// Handle command if CRC OK
							IZIPLUS_TRACE_DEBUG("Rec frame[%d]: OK -> Module: %08x, Cmd: %02x\r\n", idx, frame->destination, frame->data[2]);
						}
						else
							IZIPLUS_TRACE_DEBUG("Rec frame[%d]: No data -> Module: %08x, Cmd: %02x\r\n\r\n", idx, frame->destination, frame->data[2]);
					}
					else
						IZIPLUS_TRACE_DEBUG("Rec frame[%d]: Err -> Module: %08x, Cmd: %02x\r\n", idx, frame->destination, frame->data[2]);

					iziplus_rx_time[idx] = 0;			// Set handled
					iziplus_next_rx_idx = idx;
					if(++iziplus_next_rx_idx >= IZIPLUS_RX_FRAME_BFR_MAX)
						iziplus_next_rx_idx = 0;
				}
				if(++idx >= IZIPLUS_RX_FRAME_BFR_MAX)
					idx = 0;
			}
		}
		if(iziplus_rx_overflow > 0)
		{
			IZIPLUS_TRACE_INFO("Rx overflow: %d\r\n", iziplus_rx_overflow);
			iziplus_rx_overflow = 0;
		}
	}
}

/*
 * General handling of commands
 */
void iziplus_data_handle_rx(iziplus_data_frame_t *frame)
{
	bool handled = false;
	iziplus_network_data_t *nw_data = ((iziplus_network_data_t *)frame->data);
	// If awaiting an response, check if this matches the pending request
	if(iziplus_req_pending &&
			(iziplus_req_cmd == nw_data->cmd || nw_data->cmd == IZIPLUS_CMD_POLL) &&		// Same command
			iziplus_req_destination == frame->destination &&								// Correct responder
			nw_data->msgtype.u.frame_type != IZIPLUS_FRAMETYPE_REQ &&						// Marked as response or notification (delayed response) (all but request)
			(frame->pan_id == appConfig->pan_id ||
					(wildcard_enable && frame->pan_id == IZIPLUS_PANID_WILDCARD)) &&		// Addressed to this module
			frame->lengthdir.u.direction == dir_slavemaster)								// Slave to master direction
	{
		iziplus_req_pending = false;
		iziplus_nwdata_rx_length = frame->lengthdir.u.length;
		memcpy(iziplus_nwdata_rx, frame->data, iziplus_nwdata_rx_length);					// Copy for handling
		xSemaphoreGive(xiziplus_data_CmdSemaphore);
		handled = true;
	}
	if(iziplus_cb_func_rx != NULL)
		iziplus_cb_func_rx(frame, handled);
}

/**
 * Disable retries the next request
 */
void iziplus_data_no_retry()
{
	iziplus_no_retry = true;
}

/*
 * Check if other master is sending...
 */
void iziplus_data_collision_check()
{
	uint16_t current_index = 0xFFFF;
	uint8_t i;
	for(i = 0; i < 4; i++)		// Wait for pending incoming command (max 10 ms)
	{
		if(current_index == iziplus_rx_frame_idx)		// Nothing came in (possibly will stay unfinished frame)
			break;

		current_index = iziplus_rx_frame_idx;
		if(iziplus_rx_cmd_detect)
			vTaskDelay(i + 1);
		else
			break;
	}
	if(i >= 3)
	{
		IZIPLUS_TRACE_DEBUG("Max collision delay: %d\r\n", i);
	}
}

/*
 * Check if last send was less than 2ms ago
 */
void iziplus_datacheck_delay(uint16_t send_len)
{
	TickType_t now_ticks = xTaskGetTickCount();
	if(last_send_ticks == now_ticks || (last_send_ticks == now_ticks - 1))		// Last frame was send in the same millisecond?
	{
		if(send_len < 64)														// Sending more than 64 bytes will already take a ms to transfer into fifo, skip if large frame is going to be send
			vTaskDelay(2 - (now_ticks - last_send_ticks));						// Add some time for processing by slave (and extra space on bus)
	}
}

uint16_t iziplus_data_waittime()
{
	int wait_time = IZIPLUS_REQ_TIMEOUT_BASE;
	if(appConfig->master_total > 2)
		wait_time = IZIPLUS_REQ_TIMEOUT_BASE * 2;
	else if(appConfig->master_total > 1)
		wait_time = IZIPLUS_REQ_TIMEOUT_BASE + ((IZIPLUS_REQ_TIMEOUT_BASE * 2)/3) + 1;

	return wait_time;
}

int16_t iziplus_data_request(izi_module_t *module, uint8_t *nw_data, uint16_t nw_length)
{
	iziplus_data_request_multi(module, nw_data, nw_length, false);
}

/*
 * Do a request with retries
 * Returns positive number if response was received then it represents the length
 * negative is an error (fail)
 * The network layer data will always be in iziplus_nwdata_rx
 */
int16_t iziplus_data_request_multi(izi_module_t *module, uint8_t *nw_data, uint16_t nw_length, bool multi)
{
	iziplus_data_collision_check();
	iziplus_req_pending = true;
	iziplus_req_cmd = ((iziplus_network_data_t *)nw_data)->cmd;		// Store parameters to check for in response
	iziplus_req_destination = module->base.device_id;
	int retries = iziplus_no_retry ? 1 : IZIPLUS_MAX_REQ_ATTEMPTS;
	iziplus_no_retry = false;
	bool sendFail = false;
	int wait_time = iziplus_data_waittime();

	iziplus_datacheck_delay(nw_length);

#if IZI_TIMING > 0
	TimingStopIfRunning(0);
#endif

	if(iziplus_not_pending)
	{
		IZIPLUS_TRACE_DEBUG("Notification pending while sending request (our seq: %d, cmd: %d)\r\n", ((iziplus_network_data_t *)nw_data)->seqid, ((iziplus_network_data_t *)nw_data)->cmd);
		vTaskDelay(1);
	}
	IZIPLUS_TRACE_DEBUG("Request start -> cmd: %d dst: %d\r\n", iziplus_req_cmd, iziplus_req_destination);
	
	uint16_t devicetype = multi ? (module->base.device_type|IZIPLUS_DEVTYPE_GROUPCAST) : module->base.device_type;
	for(int r = 0; r < retries; r++)
	{
		uint16_t len = iziplus_dataframe_sendreq(module->base.device_id, devicetype, nw_data, nw_length, iziplus_dataframe);
		iziplus_req_seqid = ((iziplus_network_data_t *)nw_data)->seqid;		// Store seq id that should responded to
		xQueueReset(xiziplus_data_CmdSemaphore);
		xQueueReset(xiziplus_data_TxCmdSemaphore);
		iziplus_req_amount++;
		iziplus_req_pending = true;
		if(dcbm1_send((uint8_t *)iziplus_dataframe, len) != len)
		{
			IZIPLUS_TRACE_INFO("Request error send by dcbm1\r\n");
			iziplus_req_pending = false;
			return -1;
		}
#if IZI_TIMING > 0
		TimingStopIfRunning(4);
#endif

		int tx_wait = wait_time + ((nw_length > 128) ? 5 : 0);
		if(!xSemaphoreTake(xiziplus_data_TxCmdSemaphore, tx_wait))		// Max 15ms wait for the message to be send
		{
			IZIPLUS_TRACE_INFO("Request timeout tx after %d ms\r\n", tx_wait);
			sendFail = true;
			//return -4;
		}
		last_send_ticks = xTaskGetTickCount();

		if(iziplus_transparent_mode)
			IziTransparent_Send((uint8_t *)iziplus_dataframe, len, 0x80);

		if(xSemaphoreTake(xiziplus_data_CmdSemaphore, wait_time))
		{
			if(iziplus_cb_func_online != NULL)
				iziplus_cb_func_online(module, true);
			if(((int8_t)((iziplus_network_data_t *)iziplus_nwdata_rx)->tokenres) >= 0)		// Response is marked OK?
			{
				if(((iziplus_network_data_t *)iziplus_nwdata_rx)->msgtype.u.frame_type == IZIPLUS_FRAMETYPE_DLY)
				{
					for(int r2 = 0; r2 < 4; r2++)		// Poll 4x max
					{
						bool res = false;
						iziplus_req_seqid++;
						iziplus_req_pending = true;
						if(iziplus_cb_func_token != NULL)
							res = iziplus_cb_func_token(module);

						if(res)
						{
							xQueueReset(xiziplus_data_CmdSemaphore);
							if(xSemaphoreTake(xiziplus_data_CmdSemaphore, wait_time))
							{
								iziplus_req_pending = false;
								if(((int8_t)((iziplus_network_data_t *)iziplus_nwdata_rx)->tokenres) >= 0)		// Response is marked OK?
									return (int16_t)iziplus_nwdata_rx_length;
								return -5;
							}
							iziplus_req_pending = false;
						}
						else
						{
							iziplus_req_pending = false;
							return -6;
						}
					}
					IZIPLUS_TRACE_INFO("Request error delay fail: %d, cmd: %d (%d)\r\n", (int8_t)(((iziplus_network_data_t *)iziplus_nwdata_rx)->tokenres), (int8_t)(((iziplus_network_data_t *)iziplus_nwdata_rx)->cmd), sendFail);
					//return -4;
				}
				else
					return (int16_t)iziplus_nwdata_rx_length;
			}
			else
			{
				iziplus_req_pending = false;
				IZIPLUS_TRACE_INFO("Request error returned");//: %d (%d)\r\n", (int8_t)(((iziplus_network_data_t *)iziplus_nwdata_rx)->tokenres), sendFail);
				return -3;
			}
		}
		else if(iziplus_cb_func_online != NULL)
			iziplus_cb_func_online(module, false);

		iziplus_req_pending = false;
		iziplus_networkframe_retry(nw_data);
		IZIPLUS_TRACE_DEBUG("Request retry: %d\r\n", r + 1);
	}
	return -2;
}

/*
 * Do a single notification
 * Returns positive number if send ok
 * negative is an error (fail)
 */
int16_t iziplus_data_notification(uint32_t dest, uint16_t devtype, uint8_t *nw_data, uint16_t nw_length)
{
	iziplus_datacheck_delay(nw_length);

	uint16_t len = iziplus_dataframe_sendreq(dest, devtype, nw_data, nw_length, iziplus_dataframe);
	iziplus_data_collision_check();
	int wait_time = iziplus_data_waittime()  + ((nw_length > 128) ? 5 : 0);

	if(iziplus_req_pending)
	{
		IZIPLUS_TRACE_DEBUG("Request pending while sending notification (seq: %d, our seq: %d, cmd: %d)\r\n", iziplus_req_seqid, ((iziplus_network_data_t *)nw_data)->seqid, ((iziplus_network_data_t *)nw_data)->cmd);		
		vTaskDelay(1);
	}
	
	iziplus_not_pending = true;
	xQueueReset(xiziplus_data_TxCmdSemaphore);
	if(dcbm1_send((uint8_t *)iziplus_dataframe, len) == len)
	{
		if(xSemaphoreTake(xiziplus_data_TxCmdSemaphore, wait_time))		// Max 15ms wait
		{
			last_send_ticks = xTaskGetTickCount();
			if(iziplus_transparent_mode)
				IziTransparent_Send((uint8_t *)iziplus_dataframe, len, 0x80);

			iziplus_not_pending = false;
			return 0;
		}
		if(iziplus_transparent_mode)
			IziTransparent_Send((uint8_t *)iziplus_dataframe, len, 0x80);

		IZIPLUS_TRACE_INFO("Notification error send2 by dcbm1: %d (%d)\r\n", wait_time, len);
		iziplus_not_pending = false;
		return -3;
	}
	else
	{
		IZIPLUS_TRACE_INFO("Notification error send by dcbm1\r\n");
	}
	iziplus_not_pending = false;
	return -2;
}

void iziplus_data_Dcbm1Rx(uint8_t data, bool interrupt)
{
	bool skip = false;
	if(!iziplus_rx_start_detect && data == 0xAB)
		iziplus_rx_start_detect = true;
	else if(iziplus_rx_start_detect)
	{
		if(data == 0xBA)
		{
			if(iziplus_rx_frame_idx > 1)
			{
				iziplus_rx_frame_idx = 2;
			}

			iziplus_rx_frame_idx = 0;
			iziplus_rx_start_detect = false;
			iziplus_rx_cmd_detect = true;
			iziplus_escape_esc = 0;
			skip = true;
		}
		else
			iziplus_rx_start_detect = false;
	}
	if(!skip && iziplus_rx_cmd_detect && iziplus_rx_frame_idx < sizeof(iziplus_data_frame_t))
	{
		uint8_t *bfr = (uint8_t *)&iziplus_rx_frame[iziplus_rx_frame_sel];

		if(iziplus_escape_esc == 2)
		{
			//if(data == IZIPLUS_ESCAPE_ESC)
			//	return;								// Skip handling of this byte, escape means 0xACDC was meant to be
			if(data == IZIPLUS_ESCAPE_START)
			{
				bfr[iziplus_rx_frame_idx - 1] = 0xBA;
				bfr[iziplus_rx_frame_idx - 2] = 0xAB;		// Replace by 0xABBA
			}
			iziplus_escape_esc = 0;
			return;
		}
		else if(iziplus_escape_esc == 1 && data == 0xDC)
			iziplus_escape_esc = 2;
		else if(iziplus_escape_esc == 0 && data == 0xAC)
			iziplus_escape_esc = 1;
		else
			iziplus_escape_esc = 0;

		bfr[iziplus_rx_frame_idx++] = data;
		if(iziplus_rx_frame_idx == IZPLUS_MAX_DATAFRAME_NOSTART)		// Minimum amount for datalayer is received?
		{
			uint16_t length = iziplus_rx_frame[iziplus_rx_frame_sel].lengthdir.u.length;
			if(length > IZIPLUS_MAX_DATAFRAME_DATA)
			{
				iziplus_rx_cmd_detect = false;							// Dump, incorrect length
				return;
			}
		}
		if(iziplus_rx_frame_idx >= IZPLUS_MAX_DATAFRAME_NOSTART)
		{
			uint16_t length = iziplus_rx_frame[iziplus_rx_frame_sel].lengthdir.u.length;
			if((iziplus_rx_frame_idx - IZPLUS_MAX_DATAFRAME_NOSTART) >= length)
			{
				iziplus_rx_start_detect = 0;
				iziplus_rx_frame_idx = 0;
				iziplus_rx_cmd_detect = false;
				if(iziplus_rx_time[iziplus_rx_frame_sel] > 0)
					iziplus_rx_overflow++;
				iziplus_rx_time[iziplus_rx_frame_sel] = interrupt ? xTaskGetTickCountFromISR() : xTaskGetTickCount();
				if(iziplus_rx_time[iziplus_rx_frame_sel] == 0)
					iziplus_rx_time[iziplus_rx_frame_sel] += 1;		// 0 means empty
				if(++iziplus_rx_frame_sel >= IZIPLUS_RX_FRAME_BFR_MAX)
					iziplus_rx_frame_sel = 0;

				if(interrupt)
				{
					xSemaphoreGiveFromISR(xiziplus_data_RxCmdSemaphore, NULL);
					portEND_SWITCHING_ISR(true);			// Make sure the semaphore is directly handled (iso the next tick)
				}
				else
				{
					xSemaphoreGive(xiziplus_data_RxCmdSemaphore);
				}
			}
		}
	}
}

/************************************************************************/
/* Callback when tx is sent                                             */
/************************************************************************/
void iziplus_data_Dcbm1TxReady()
{
	xSemaphoreGiveFromISR(xiziplus_data_TxCmdSemaphore, NULL);
	portEND_SWITCHING_ISR(true);		// Make sure the semaphore is directly handled (iso the next tick)
}


