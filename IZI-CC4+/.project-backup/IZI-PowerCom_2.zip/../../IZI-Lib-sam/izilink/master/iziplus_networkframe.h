/*
 * iziplus_networkframe.h
 *
 *  Created on: 23 apr. 2021
 *      Author: Milo
 */

#ifndef IZIPLUS_NETWORKFRAME_H_
#define IZIPLUS_NETWORKFRAME_H_

#include "izi_module.h"




// Proto
uint16_t iziplus_networkframe_discover(uint8_t *data, uint8_t session_id);
uint16_t iziplus_networkframe_assign_network(uint8_t *data, uint8_t session_id, uint8_t freq, uint8_t rate, uint8_t short_id, uint32_t pan_id, uint8_t txlevel);
uint16_t iziplus_networkframe_operationmode(uint8_t *data, uint8_t mode, bool is_notification);
uint16_t iziplus_networkframe_identify(uint8_t *data, uint8_t minutes, uint8_t mode, bool is_notification);
uint16_t iziplus_networkframe_assign_channelmodewrite(uint8_t *data, uint16_t channel_id, uint8_t mode, uint8_t dmxfail, uint8_t offset);
uint16_t iziplus_networkframe_assign_channelmoderead(uint8_t *data);
uint16_t iziplus_networkframe_textwrite(uint8_t *data, uint8_t *text, uint8_t length);
uint16_t iziplus_networkframe_textread(uint8_t *data);
uint16_t iziplus_networkframe_configwrite(uint8_t *data, uint8_t *config, uint8_t length);
uint16_t iziplus_networkframe_configread(uint8_t *data);
uint16_t iziplus_networkframe_monitorread(uint8_t *data);
uint16_t iziplus_networkframe_lightdata(uint8_t *data, uint8_t *levels, uint16_t length, uint8_t token, bool nodata);
uint16_t iziplus_networkframe_poll(uint8_t *data, uint8_t token);
void iziplus_networkframe_retry(uint8_t *data);
void iziplus_networkframe_setsync();
uint16_t iziplus_networkframe_fw_write(uint8_t *data, uint32_t address, uint8_t *fw_data, uint16_t length, bool req_multi);
uint16_t iziplus_networkframe_fw_apply(uint8_t *data);
uint16_t iziplus_networkframe_fw_allow(uint8_t *data, izi_versionplus_u *version, uint8_t time);
uint16_t iziplus_networkframe_versions(uint8_t *data);
uint16_t iziplus_networkframe_production_data_write(uint8_t *data, uint8_t *prod_data, uint16_t length);
uint16_t iziplus_networkframe_factory_default(uint8_t *data);
uint16_t iziplus_networkframe_production_data_read(uint8_t *data);
uint16_t iziplus_networkframe_contacttrigger_ack(uint8_t *data, uint8_t *acks, uint8_t length);

#endif /* IZIPLUS_NETWORKFRAME_H_ */
