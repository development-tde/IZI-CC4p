/*
 * izi_transparent.c
 *
 *  Created on: 16 apr. 2021
 *      Author: Milo
 */

#include "includes.h"
#include "izi_transparent.h"
//#include "virtual_com.h"
#include "powerline/dcbm1_driver.h"
//#include "izi_driver.h"
#include "iziplus_dataframe.h"
#include "iziplus_driver.h"
//#include "USB_Serial.h"
//#include "uart/usart2.h"

// Defines
#define USBCMD_MSGPOOL_SIZE		1024

/*******************************************************************************
 * Globals
 ******************************************************************************/
static TaskHandle_t		xTransparent_Task;
static SemaphoreHandle_t xTransparent_RxCmdSemaphore = NULL;

static TaskHandle_t		xTransparentUsb_Task;
static MessageBufferHandle_t xTransparentUsb_MsgBfrHandle;

static uint8_t usb_rxcmd_buffer[284];

static volatile uint8_t usb_rx_buffer[IZI_TRANSPARENT_MAX_RX_BUFFER];
static volatile uint8_t usb_tx_buffer[IZI_TRANSPARENT_MAX_TX_BUFFERS][IZI_TRANSPARENT_MAX_TX_BUFFER];
static volatile uint16_t usb_rx_in_idx, usb_tx_in_idx, usb_tx_sel_idx, usb_tx_ready[IZI_TRANSPARENT_MAX_TX_BUFFERS];
static volatile uint8_t usb_rx_cmd;
static volatile uint8_t usb_rx_pattern_start_cnt, usb_rx_pattern_end_cnt;
static volatile iziplus_data_frame_t iziplus_data_frame;
static volatile uint16_t iziplus_data_frame_idx, iziplus_data_frame_extra;
static volatile bool iziplus_data_start_detect = false;
static volatile bool iziplus_data_cmd_detect = false;
static volatile uint8_t iziplus_escape_esc = 0;
static volatile uint8_t iziplus_mode = 0;

#define IZI_CMD_PATTERN_LEN		4
const uint8_t izi_cmd_pattern_start[IZI_CMD_PATTERN_LEN] = { 0x22, 0x33, 0xDD, 0xEE };
const uint8_t izi_cmd_pattern_end[IZI_CMD_PATTERN_LEN] = { 0x11, 0x44, 0xBB, 0xAA };

#define TASK_TRANSPA_STACK_SIZE (512 / sizeof(portSTACK_TYPE))
#define TASK_TRANSPA_TASK_PRIORITY (tskIDLE_PRIORITY + 4)

// Proto
static void IziTransparentUsb_Task(void *p);
void IziTransparent_HandleCmd(uint16_t length);
void IziTransparent_UsbRx(uint8_t data);
void IziTransparent_Dcbm1Rx(uint8_t data);
void IziTransparent_Dcbm1TxReady();
static void IziTransparent_Task(void *p);
extern void Debug_Recv(uint8_t c);
extern void Debug_RecvInt(uint8_t c);
/*******************************************************************************
 * Code
 ******************************************************************************/

void IziTransparent_Init()
{
	Usart2_Init(NULL, IziTransparent_UsbRx, NULL);
	//USBSerial_set_rx_callback(IziTransparent_UsbRx);
	dcbm1_set_rx_callback(IziTransparent_Dcbm1Rx);
	dcbm1_set_txready_callback(IziTransparent_Dcbm1TxReady);

	usb_rx_pattern_start_cnt = 0;
	usb_rx_cmd = false;
	usb_tx_sel_idx = 0;
	usb_tx_in_idx = 0;

	//State_SetAttentionInfo(COLOR_AQUA, COLOR_RED, 5, 1);

	//UsbVcom_EchoOff(true);
	//Debug_Off(true);
	if(xTransparent_RxCmdSemaphore == NULL)
		xTransparent_RxCmdSemaphore = xSemaphoreCreateBinary();

	xTransparentUsb_MsgBfrHandle = xMessageBufferCreate(USBCMD_MSGPOOL_SIZE);

	if(xTransparent_Task == NULL)
	{
		if (xTaskCreate(IziTransparent_Task, "Sniffer", TASK_TRANSPA_STACK_SIZE, NULL, TASK_TRANSPA_TASK_PRIORITY, &xTransparent_Task) != pdPASS) {
			while (1) {
				;
			}
		}
	}
	
	//NVIC_SetPriority(USB_0_IRQn, configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY);
	//NVIC_SetPriority(USB_1_IRQn, configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY);
	//NVIC_SetPriority(USB_2_IRQn, configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY);
	//NVIC_SetPriority(USB_3_IRQn, configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY);
	if(xTransparentUsb_Task == NULL)
	{
		if (xTaskCreate(IziTransparentUsb_Task, "USBcmd", TASK_TRANSPA_STACK_SIZE, NULL, TASK_TRANSPA_TASK_PRIORITY + 1, &xTransparentUsb_Task) != pdPASS) {
			while (1) {
				;
			}
		}
	}
}

/************************************************************************/
/* Rx handler task														        */
/************************************************************************/
static void IziTransparent_Task(void *p)
{
	uint16_t last_idx = 0;

	while(true)
	{
		if(xSemaphoreTake(xTransparent_RxCmdSemaphore, 100))
		{
			uint16_t idx = last_idx;		// Start with the last buffer handled + 1 (so all messages will remain in order of receiving)
			for(int i = 0; i < IZI_TRANSPARENT_MAX_TX_BUFFERS; i++)
			{
				if(usb_tx_ready[idx] > 0)
				{
					IziTransparent_Send((uint8_t *)usb_tx_buffer[idx], usb_tx_ready[idx], 0x80);

					usb_tx_ready[idx] = 0;
					last_idx = idx;
					if(++last_idx >= IZI_TRANSPARENT_MAX_TX_BUFFERS)
						last_idx = 0;
				}
				if(++idx >= IZI_TRANSPARENT_MAX_TX_BUFFERS)
					idx = 0;
			}
		}
	}
}

/************************************************************************/
/* Usb command handler task														        */
/************************************************************************/
static void IziTransparentUsb_Task(void *p)
{
	while(true)
	{
		/* Receive the next message from the message buffer.  Wait in the Blocked
		state (so not using any CPU processing time) for a maximum of 100ms for
		a message to become available. */
		size_t xReceivedBytes = xMessageBufferReceive( xTransparentUsb_MsgBfrHandle,
												( void * ) &usb_rxcmd_buffer,
												sizeof( usb_rxcmd_buffer ),
												pdMS_TO_TICKS(2));
												
		if(xReceivedBytes > 0)
		{
			IziTransparent_HandleCmd(xReceivedBytes);
			usb_rx_cmd = 0;												
		}
		//USBSerialWriteUpdate();
	}
}

void IziTransparent_UsbRx(uint8_t data)
{
	if(izi_cmd_pattern_start[usb_rx_pattern_start_cnt] == data || izi_cmd_pattern_start[0] == data)
	{
		if(izi_cmd_pattern_start[0] == data)
			usb_rx_pattern_start_cnt = 0;				// Restart twice 0x22 for example

		if(++usb_rx_pattern_start_cnt >= IZI_CMD_PATTERN_LEN)
		{
			usb_rx_pattern_start_cnt = 0;
			usb_rx_pattern_end_cnt = 0;
			usb_rx_cmd = 0xFF;
			usb_rx_in_idx = 0;
			return;
		}
	}
	else
		usb_rx_pattern_start_cnt = 0;

	if(izi_cmd_pattern_end[usb_rx_pattern_end_cnt] == data || izi_cmd_pattern_end[0] == data)
	{
		if(izi_cmd_pattern_end[0] == data)
			usb_rx_pattern_end_cnt = 0;					// Restart twice 0x11 for example

		if(++usb_rx_pattern_end_cnt >= IZI_CMD_PATTERN_LEN)
		{
			usb_rx_pattern_end_cnt = 0;
			usb_rx_pattern_start_cnt = 0;
			
			BaseType_t xHigherPriorityTaskWoken = pdTRUE;
			xMessageBufferSendFromISR( xTransparentUsb_MsgBfrHandle,
			(void *) usb_rx_buffer,
			usb_rx_in_idx - (IZI_CMD_PATTERN_LEN - 1),
			&xHigherPriorityTaskWoken);
			portEND_SWITCHING_ISR(true);		// Make sure the semaphore is directly handled (iso the next tick)
		}
	}
	else
		usb_rx_pattern_end_cnt = 0;

	if(usb_rx_cmd > 0)
	{
		if(usb_rx_cmd == 0xFF)
			usb_rx_cmd = data;			// Store the command
		else
			usb_rx_buffer[usb_rx_in_idx++] = data;
	}
}

void IziTransparent_Send(uint8_t *bfr, uint16_t length, uint8_t cmd)
{
	if(iziplus_mode & 0x80)
		return;
	if((iziplus_mode & 0x01) && length > 16 && (((iziplus_data_frame_t *)(bfr + 2))->data[2] == IZIPLUS_CMD_LIGHT_DATA))
		return;
	if((iziplus_mode & 0x02) && length > 16 && (((iziplus_data_frame_t *)(bfr + 2))->data[1] & 0x0F) == 0x02)
		return;
	
	//bool usbIsOpen = USBSerialAttached();

	//if(usbIsOpen)
	//	vTaskSuspendAll();							// Make sure not other debug message becomes in between
	for(int a = 0; a < IZI_CMD_PATTERN_LEN; a++)
		Usart2_Putc(izi_cmd_pattern_start[a]);

	Usart2_Putc(cmd);
	uint32_t time = (uint32_t)xTaskGetTickCount();
	uint8_t *time_ptr = (uint8_t *)&time;
	for(int a = 0; a < 4; a++)
		Usart2_Putc(time_ptr[a]);
	for(int a = 0; a < length; a++)
		Usart2_Putc(bfr[a]);

	for(int a = 0; a < IZI_CMD_PATTERN_LEN; a++)
		Usart2_Putc(izi_cmd_pattern_end[a]);
	
	//USBSerialFlushBfr();
	//if(usbIsOpen)
	//	xTaskResumeAll();
}

void IziTransparent_SendStart(uint8_t *bfr, uint16_t length, uint8_t cmd)
{
	if((iziplus_mode & 0x01) && length > 16 && (((iziplus_data_frame_t *)bfr)->data[2] == IZIPLUS_CMD_LIGHT_DATA))
		return;
	if((iziplus_mode & 0x02) && length > 16 && (((iziplus_data_frame_t *)(bfr))->data[1] & 0x0F) == 0x02)
		return;

	//bool usbIsOpen = USBSerialAttached();

	//if(usbIsOpen)
	//	vTaskSuspendAll();							// Make sure not other debug message becomes in between
	for(int a = 0; a < IZI_CMD_PATTERN_LEN; a++)
		Usart2_Putc(izi_cmd_pattern_start[a]);

	Usart2_Putc(cmd);
	uint32_t time = (uint32_t)xTaskGetTickCount();
	uint8_t *time_ptr = (uint8_t *)&time;
	for(int a = 0; a < 4; a++)
		Usart2_Putc(time_ptr[a]);
	Usart2_Putc(0xAB);
	Usart2_Putc(0xBA);
	for(int a = 0; a < length; a++)
		Usart2_Putc(bfr[a]);

	for(int a = 0; a < IZI_CMD_PATTERN_LEN; a++)
		Usart2_Putc(izi_cmd_pattern_end[a]);
		
	//USBSerialFlushBfr();
	//if(usbIsOpen)
	//	xTaskResumeAll();
}

void IziTransparent_HandleCmd(uint16_t length)
{
	if(usb_rx_cmd == 0x01 && length > 0)
	{
		if(usb_rx_buffer[0] > 0 && length > 2)
		{
			int8_t res = dcbm1_init(usb_rx_buffer[1], usb_rx_buffer[2]);
			IZI_POWER_OUT_ENABLE;
#if IZI_DRIVER > 0
			izi_driver_reportlinkstate(LINK_STATE_STARTUP, 0);
#endif
			IziTransparent_Send((uint8_t *)&res, 1, usb_rx_cmd);
		}
		else
		{
			int8_t res = 1;
			IZI_POWER_OUT_DISABLE;
#if IZI_DRIVER > 0
			izi_driver_reportlinkstate(LINK_STATE_POWER_OFF, 0);
#endif
			IziTransparent_Send((uint8_t *)&res, 1, usb_rx_cmd);
		}
	}
	else if(usb_rx_cmd == 0x02)
	{
		uint8_t bfr[2];
		uint16_t len = dcbm1_send(usb_rx_buffer, length);
		bfr[0] = (uint8_t)(len >> 8);
		bfr[1] = (uint8_t)len;
		IziTransparent_Send(bfr, 2, usb_rx_cmd);
	}
	else if(usb_rx_cmd == 0x10 && length > 1)
	{
		uint8_t bfr[1];
		bfr[0] = dcbm1_writereg(usb_rx_buffer[0], usb_rx_buffer[1]);
		IziTransparent_Send(bfr, 1, usb_rx_cmd);
	}
	else if(usb_rx_cmd == 0x20 && length > 0)
	{
		iziplus_mode = usb_rx_buffer[0];
	}
	else if(usb_rx_cmd == 0x40)
	{
		for(int i = 0; i < length; i++)
			iziplus_data_Dcbm1Rx(usb_rx_buffer[i], false);
		//OS_TRACE_INFO("hoe %d\r\n", usb_rx_buffer[14]);
	}
	else if(usb_rx_cmd == 0x80 && length > 0)
	{
		for(uint16_t i = 0; i < length; i++)
			Debug_RecvInt(usb_rx_buffer[i]);
	}
}

void IziTransparent_Dcbm1Rx(uint8_t data)
{
	bool skip = false;
	bool dump = false;
	if(!iziplus_data_start_detect && data == 0xAB)
		iziplus_data_start_detect = true;
	else if(iziplus_data_start_detect)
	{
		if(data == 0xBA)
		{
			iziplus_data_frame_idx = 0;
			iziplus_data_frame_extra = 0;
			iziplus_data_start_detect = false;
			iziplus_data_cmd_detect = true;
			iziplus_escape_esc = 0;
			skip = true;
			if(usb_tx_in_idx > 1)
				dump = true;
		}
		else
			iziplus_data_start_detect = false;
	}

	bool sendme = false;
	if(!skip && iziplus_data_cmd_detect && iziplus_data_frame_idx < sizeof(iziplus_data_frame_t))
	{
		bool escaped = false;
		if(iziplus_escape_esc == 2)
		{
			iziplus_data_frame_extra++;						// Calculate with extra stuff bytes
			escaped = true;
			iziplus_escape_esc = 0;
			if(data == 0x00)
			{
				((uint8_t *)&iziplus_data_frame)[iziplus_data_frame_idx - 2] = 0xAB;		// In case it is part of length byte
				((uint8_t *)&iziplus_data_frame)[iziplus_data_frame_idx - 1] = 0xBA;
			}
		}
		if(iziplus_escape_esc == 1 && data == 0xDC)
		{
			iziplus_escape_esc = 2;
		}
		else if(iziplus_escape_esc == 0 && data == 0xAC)
			iziplus_escape_esc = 1;
		else
			iziplus_escape_esc = 0;

		if(!escaped)
			((uint8_t *)&iziplus_data_frame)[iziplus_data_frame_idx++] = data;

		if(iziplus_data_frame_idx >= IZPLUS_MAX_DATAFRAME_NOSTART)
		{
			if((iziplus_data_frame_idx - IZPLUS_MAX_DATAFRAME_NOSTART) >= (iziplus_data_frame.lengthdir.u.length + iziplus_data_frame_extra) ||
					iziplus_data_frame.lengthdir.u.length > IZIPLUS_MAX_DATAFRAME_DATA)
			{
				sendme = true;
				iziplus_data_start_detect = 0;
				iziplus_data_frame_extra = 0;
				iziplus_data_frame_idx = 0;
				iziplus_data_cmd_detect = false;
			}
		}
	}

	usb_tx_buffer[usb_tx_sel_idx][usb_tx_in_idx++] = data;
	if(usb_tx_in_idx >= IZI_TRANSPARENT_MAX_TX_BUFFER || sendme || dump)
	{
		usb_tx_ready[usb_tx_sel_idx] = dump ? usb_tx_in_idx - 2 : usb_tx_in_idx;
		// New
		usb_tx_sel_idx = (usb_tx_sel_idx + 1) % IZI_TRANSPARENT_MAX_TX_BUFFERS;
		usb_tx_in_idx = 0;

		// Force handling
		xSemaphoreGiveFromISR(xTransparent_RxCmdSemaphore, NULL);

		if(dump)
		{
			usb_tx_buffer[usb_tx_sel_idx][usb_tx_in_idx++] = 0xAB;			// Recover start in new buffer
			usb_tx_buffer[usb_tx_sel_idx][usb_tx_in_idx++] = 0xBA;
		}
	}
}

/************************************************************************/
/* Callback when tx is sent                                             */
/************************************************************************/
void IziTransparent_Dcbm1TxReady()
{

}
