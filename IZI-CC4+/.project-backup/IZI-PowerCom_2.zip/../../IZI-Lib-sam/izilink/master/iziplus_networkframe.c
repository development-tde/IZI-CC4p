/*
 * iziplus_networkframe.c
 *
 *  Created on: 23 apr. 2021
 *      Author: Milo
 */

#include "includes.h"
#include "iziplus_networkframe.h"
#include "iziplus_frames.h"

static uint8_t seq_id = 0;
static bool iziplus_networkframe_sync = false;

void iziplus_networkframe_setsync()
{
	iziplus_networkframe_sync = true;
}

void iziplus_networkframe_retry(uint8_t *data)
{
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->seqid = seq_id++;
	nw_data->tokenres++;			// increase retry
}

uint16_t iziplus_networkframe_discover(uint8_t *data, uint8_t session_id)
{
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->cmd = IZIPLUS_CMD_DISCOVER;
	nw_data->seqid = seq_id++;
	nw_data->msgtype.u.cmd_type = IZIPLUS_CMDTYPE_DISCOVER;
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_REQ;
	nw_data->msgtype.u.sync = iziplus_networkframe_sync;
	nw_data->tokenres = 0;
	iziplus_networkframe_sync = false;
	iziplus_cmd_discover_req_t *payload =((iziplus_cmd_discover_req_t *)(data + 4));
	payload->session_id = session_id;
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_discover_req_t);
}

uint16_t iziplus_networkframe_assign_network(uint8_t *data, uint8_t session_id, uint8_t freq, uint8_t rate, uint8_t short_id, uint32_t pan_id, uint8_t txlevel)
{
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->cmd = IZIPLUS_CMD_ASSIGN_NETWORK;
	nw_data->seqid = seq_id++;
	nw_data->msgtype.u.cmd_type = IZIPLUS_CMDTYPE_ASSIGN_NETWORK;
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_REQ;
	nw_data->msgtype.u.sync = iziplus_networkframe_sync;
	iziplus_networkframe_sync = false;
	nw_data->tokenres = 0;
	iziplus_cmd_assign_network_wreq_t *payload =((iziplus_cmd_assign_network_wreq_t *)(data + 4));
	payload->session_id = session_id;
	payload->freq = freq;
	payload->rate = rate;
	payload->shortid = short_id;
	payload->pan_id = pan_id;
	payload->txlevel = txlevel;
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_assign_network_wreq_t);
}

uint16_t iziplus_networkframe_operationmode(uint8_t *data, uint8_t mode, bool is_notification)
{
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->cmd = IZIPLUS_CMD_OPERATION_MODE;
	nw_data->seqid = seq_id++;
	nw_data->msgtype.u.cmd_type = IZIPLUS_CMDTYPE_OPERATION_MODE;
	nw_data->msgtype.u.frame_type = is_notification ? IZIPLUS_FRAMETYPE_NOT : IZIPLUS_FRAMETYPE_REQ;
	nw_data->msgtype.u.sync = iziplus_networkframe_sync;
	iziplus_networkframe_sync = false;
	nw_data->tokenres = 0;
	iziplus_cmd_operation_mode_req_t *payload =((iziplus_cmd_operation_mode_req_t *)(data + 4));
	payload->mode = mode;
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_operation_mode_req_t);
}

uint16_t iziplus_networkframe_shutdown(uint8_t *data, uint16_t time)
{
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->cmd = IZIPLUS_CMD_SHUTDOWN;
	nw_data->seqid = seq_id++;
	nw_data->msgtype.u.cmd_type = IZIPLUS_CMDTYPE_SHUTDOWN;
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_NOT;
	nw_data->msgtype.u.sync = iziplus_networkframe_sync;
	iziplus_networkframe_sync = false;
	nw_data->tokenres = 0;
	iziplus_cmd_shutdown_not_t *payload =((iziplus_cmd_shutdown_not_t *)(data + 4));
	payload->time = time;
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_shutdown_not_t);
}

uint16_t iziplus_networkframe_identify(uint8_t *data, uint8_t minutes, uint8_t mode, bool is_notification)
{
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->cmd = IZIPLUS_CMD_IDENTIFY;
	nw_data->seqid = seq_id++;
	nw_data->msgtype.u.cmd_type = IZIPLUS_CMDTYPE_IDENTIFY;
	nw_data->msgtype.u.frame_type = is_notification ? IZIPLUS_FRAMETYPE_NOT : IZIPLUS_FRAMETYPE_REQ;
	nw_data->msgtype.u.sync = iziplus_networkframe_sync;
	iziplus_networkframe_sync = false;
	nw_data->tokenres = 0;
	iziplus_cmd_identify_req_t *payload =((iziplus_cmd_identify_req_t *)(data + 4));
	payload->time = minutes;
	payload->mode = mode;
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_identify_req_t);
}

uint16_t iziplus_networkframe_assign_channelmodewrite(uint8_t *data, uint16_t channel_id, uint8_t mode, uint8_t dmxfail, uint8_t offset)
{
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->cmd = IZIPLUS_CMD_ASSIGN_CHANMODE;
	nw_data->seqid = seq_id++;
	nw_data->msgtype.u.cmd_type = IZIPLUS_CMDTYPE_ASSIGN_CHANMODE;
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_REQ;
	nw_data->msgtype.u.sync = iziplus_networkframe_sync;
	iziplus_networkframe_sync = false;
	nw_data->tokenres = 0;
	iziplus_cmd_assign_chanmode_wreq_t *payload =((iziplus_cmd_assign_chanmode_wreq_t *)(data + 4));
	payload->channel_id = channel_id;
	payload->mode = mode;
	payload->dmxfail = dmxfail;
	payload->offset = offset;
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_assign_chanmode_wreq_t);
}

uint16_t iziplus_networkframe_assign_channelmoderead(uint8_t *data)
{
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->cmd = IZIPLUS_CMD_ASSIGN_CHANMODE;
	nw_data->seqid = seq_id++;
	nw_data->msgtype.u.cmd_type = IZIPLUS_CMDTYPE_READ;
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_REQ;
	nw_data->msgtype.u.sync = iziplus_networkframe_sync;
	iziplus_networkframe_sync = false;
	nw_data->tokenres = 0;
	//iziplus_cmd_assign_chanmode_rreq_t *payload =((iziplus_cmd_assign_chanmode_rreq_t *)(data + 4));
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_assign_chanmode_rreq_t);
}

uint16_t iziplus_networkframe_textwrite(uint8_t *data, uint8_t *text, uint8_t length)
{
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->cmd = IZIPLUS_CMD_TEXT;
	nw_data->seqid = seq_id++;
	nw_data->msgtype.u.cmd_type = IZIPLUS_CMDTYPE_TEXT;
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_REQ;
	nw_data->msgtype.u.sync = iziplus_networkframe_sync;
	nw_data->tokenres = 0;
	iziplus_networkframe_sync = false;
	iziplus_cmd_text_wreq_t *payload =((iziplus_cmd_text_wreq_t *)(data + 4));
	uint16_t p_len = length + 1 > IZIPLUS_TEXT_SIZE ? IZIPLUS_TEXT_SIZE : length + 1;		// string + 0 char
	memset(payload->text, 0, IZIPLUS_TEXT_SIZE);
	memcpy(payload->text, text, p_len);
	return sizeof(iziplus_network_data_t) + p_len;
}

uint16_t iziplus_networkframe_textread(uint8_t *data)
{
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->cmd = IZIPLUS_CMD_TEXT;
	nw_data->seqid = seq_id++;
	nw_data->msgtype.u.cmd_type = IZIPLUS_CMDTYPE_READ;
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_REQ;
	nw_data->msgtype.u.sync = iziplus_networkframe_sync;
	nw_data->tokenres = 0;
	iziplus_networkframe_sync = false;
	//iziplus_cmd_text_rreq_t *payload =((iziplus_cmd_text_rreq_t *)(data + 4));
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_text_rreq_t);
}

uint16_t iziplus_networkframe_configwrite(uint8_t *data, uint8_t *config, uint8_t length)
{
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->cmd = IZIPLUS_CMD_CONFIG;
	nw_data->seqid = seq_id++;
	nw_data->msgtype.u.cmd_type = IZIPLUS_CMDTYPE_CONFIG;
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_REQ;
	nw_data->msgtype.u.sync = iziplus_networkframe_sync;
	nw_data->tokenres = 0;
	iziplus_networkframe_sync = false;
	iziplus_cmd_config_wreq_t *payload =((iziplus_cmd_config_wreq_t *)(data + 4));
	uint16_t p_len = length > IZIPLUS_CONFIG_SIZE ? IZIPLUS_CONFIG_SIZE : length;
	memcpy(payload->config, config, p_len);
	return sizeof(iziplus_network_data_t) + p_len;
}

uint16_t iziplus_networkframe_configread(uint8_t *data)
{
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->cmd = IZIPLUS_CMD_CONFIG;
	nw_data->seqid = seq_id++;
	nw_data->msgtype.u.cmd_type = IZIPLUS_CMDTYPE_READ;
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_REQ;
	nw_data->msgtype.u.sync = iziplus_networkframe_sync;
	nw_data->tokenres = 0;
	iziplus_networkframe_sync = false;
	//iziplus_cmd_config_rreq_t *payload =((iziplus_cmd_config_rreq_t *)(data + 4));
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_config_rreq_t);
}

uint16_t iziplus_networkframe_monitorread(uint8_t *data)
{
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->cmd = IZIPLUS_CMD_MONITOR;
	nw_data->seqid = seq_id++;
	nw_data->msgtype.u.cmd_type = IZIPLUS_CMDTYPE_READ;
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_REQ;
	nw_data->msgtype.u.sync = iziplus_networkframe_sync;
	nw_data->tokenres = 0;
	iziplus_networkframe_sync = false;
	//iziplus_cmd_monitor_rreq_t *payload =((iziplus_cmd_monitor_rreq_t *)(data + 4));
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_monitor_rreq_t);
}

uint16_t iziplus_networkframe_lightdata(uint8_t *data, uint8_t *levels, uint16_t length, uint8_t token, bool nodata)
{
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->cmd = nodata ? IZIPLUS_CMD_LIGHT_DATA_NOINPUT : IZIPLUS_CMD_LIGHT_DATA;
	nw_data->seqid = seq_id++;
	nw_data->msgtype.u.cmd_type = IZIPLUS_CMDTYPE_LIGHT_DATA;
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_NOT;
	nw_data->msgtype.u.sync = iziplus_networkframe_sync;
	nw_data->tokenres = token;
	iziplus_networkframe_sync = false;
	iziplus_cmd_light_data_req_t *payload =((iziplus_cmd_light_data_req_t *)(data + 4));
	uint16_t p_len = length > IZIPLUS_LIGHT_DATA_SIZE ? IZIPLUS_LIGHT_DATA_SIZE : length;
	memcpy(payload->levels, levels, p_len);
	return sizeof(iziplus_network_data_t) + p_len;
}

uint16_t iziplus_networkframe_poll(uint8_t *data, uint8_t token)
{
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->cmd = IZIPLUS_CMD_POLL;
	nw_data->seqid = seq_id++;
	nw_data->msgtype.u.cmd_type = IZIPLUS_CMDTYPE_POLL;
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_NOT;
	nw_data->msgtype.u.sync = iziplus_networkframe_sync;
	nw_data->tokenres = token;
	iziplus_networkframe_sync = false;
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_poll_rreq_t);
}

uint16_t iziplus_networkframe_contacttrigger_ack(uint8_t *data, uint8_t *acks, uint8_t length)
{
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->cmd = IZIPLUS_CMD_CONTACTTRIGGER_ACK;
	nw_data->seqid = seq_id++;
	nw_data->msgtype.u.cmd_type = IZIPLUS_CMDTYPE_CONTACTTRIGGER_ACK;
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_NOT;
	nw_data->msgtype.u.sync = iziplus_networkframe_sync;
	iziplus_networkframe_sync = false;
	nw_data->tokenres = 0;
	iziplus_cmd_contacttriggerack_not_t *payload =((iziplus_cmd_contacttriggerack_not_t *)(data + 4));
	memcpy(payload->ack, acks, length);
	return sizeof(iziplus_network_data_t) + length;
}


uint16_t iziplus_networkframe_fw_write(uint8_t *data, uint32_t address, uint8_t *fw_data, uint16_t length, bool req_multi)
{
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->cmd = IZIPLUS_CMD_FW_WRITE;
	nw_data->seqid = seq_id++;
	nw_data->msgtype.u.cmd_type = IZIPLUS_CMDTYPE_FW_WRITE;
	nw_data->msgtype.u.frame_type = req_multi ? IZIPLUS_FRAMETYPE_REQ_MULTI : IZIPLUS_FRAMETYPE_REQ;
	nw_data->msgtype.u.sync = iziplus_networkframe_sync;
	nw_data->tokenres = 0;
	iziplus_networkframe_sync = false;
	iziplus_cmd_fw_write_wreq_t *payload =((iziplus_cmd_fw_write_wreq_t *)(data + 4));
	payload->address = address;
	uint16_t p_len = (length > IZIPLUS_FW_SIZE ? IZIPLUS_FW_SIZE : length);
	memcpy(payload->data, fw_data, p_len);
	return sizeof(iziplus_network_data_t) + p_len + 4;
}

uint16_t iziplus_networkframe_fw_apply(uint8_t *data)
{
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->cmd = IZIPLUS_CMD_FW_APPLY;
	nw_data->seqid = seq_id++;
	nw_data->msgtype.u.cmd_type = IZIPLUS_CMDTYPE_FW_APPLY;
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_REQ;
	nw_data->msgtype.u.sync = iziplus_networkframe_sync;
	nw_data->tokenres = 0;
	iziplus_networkframe_sync = false;
	//iziplus_cmd_fw_apply_wreq_t *payload =((iziplus_cmd_fw_apply_wreq_t *)(data + 4));
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_fw_apply_wreq_t);
}

uint16_t iziplus_networkframe_fw_allow(uint8_t *data, izi_versionplus_u *version, uint8_t time)
{
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->cmd = IZIPLUS_CMD_FW_ALLOW;
	nw_data->seqid = seq_id++;
	nw_data->msgtype.u.cmd_type = IZIPLUS_CMDTYPE_FW_ALLOW;
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_REQ;
	nw_data->msgtype.u.sync = iziplus_networkframe_sync;
	nw_data->tokenres = 0;
	iziplus_networkframe_sync = false;
	iziplus_cmd_fw_allow_wreq_t *payload =((iziplus_cmd_fw_allow_wreq_t *)(data + 4));
	payload->app_version.d = version->d;
	payload->time = time;
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_fw_allow_wreq_t);
}

uint16_t iziplus_networkframe_versions(uint8_t *data)
{
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->cmd = IZIPLUS_CMD_VERSIONS;
	nw_data->seqid = seq_id++;
	nw_data->msgtype.u.cmd_type = IZIPLUS_CMDTYPE_VERSIONS;
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_REQ;
	nw_data->msgtype.u.sync = iziplus_networkframe_sync;
	nw_data->tokenres = 0;
	iziplus_networkframe_sync = false;
	//iziplus_cmd_assign_network_wreq_t *payload =((iziplus_cmd_versions_rreq_t *)(data + 4));
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_versions_rreq_t);
}

uint16_t iziplus_networkframe_production_data_write(uint8_t *data, uint8_t *prod_data, uint16_t length)
{
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->cmd = IZIPLUS_CMD_PRODUCTION_DATA;
	nw_data->seqid = seq_id++;
	nw_data->msgtype.u.cmd_type = IZIPLUS_CMDTYPE_PRODUCTION_DATA;
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_REQ;
	nw_data->msgtype.u.sync = iziplus_networkframe_sync;
	nw_data->tokenres = 0;
	iziplus_networkframe_sync = false;
	iziplus_cmd_production_data_wreq_t *payload =((iziplus_cmd_production_data_wreq_t *)(data + 4));
	memcpy(payload->data, prod_data, length > IZIPLUS_CMD_PRODUCTION_DATA_SIZE ? IZIPLUS_CMD_PRODUCTION_DATA_SIZE : length);
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_production_data_wreq_t);
}

uint16_t iziplus_networkframe_production_data_read(uint8_t *data)
{
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->cmd = IZIPLUS_CMD_PRODUCTION_DATA;
	nw_data->seqid = seq_id++;
	nw_data->msgtype.u.cmd_type = IZIPLUS_CMDTYPE_READ;
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_REQ;
	nw_data->msgtype.u.sync = iziplus_networkframe_sync;
	nw_data->tokenres = 0;
	iziplus_networkframe_sync = false;
	//iziplus_cmd_production_data_rreq_t *payload =((iziplus_cmd_production_data_rreq_t *)(data + 4));
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_production_data_rreq_t);
}

uint16_t iziplus_networkframe_factory_default(uint8_t *data)
{
	iziplus_network_data_t *nw_data =((iziplus_network_data_t *)data);
	nw_data->cmd = IZIPLUS_CMD_FACTORY_DEFAULT;
	nw_data->seqid = seq_id++;
	nw_data->msgtype.u.cmd_type = IZIPLUS_CMDTYPE_FACTORY_DEFAULT;
	nw_data->msgtype.u.frame_type = IZIPLUS_FRAMETYPE_REQ;
	nw_data->msgtype.u.sync = iziplus_networkframe_sync;
	nw_data->tokenres = 0;
	iziplus_networkframe_sync = false;
	iziplus_cmd_factory_areq_t *payload =((iziplus_cmd_factory_areq_t *)(data + 4));
	payload->check = IZIPLUS_FACTORY_DEFAULT_UNLOCK;
	return sizeof(iziplus_network_data_t) + sizeof(iziplus_cmd_factory_areq_t);
}
