/*
 * iziplus_dataframe.h
 *
 *  Created on: 22 apr. 2021
 *      Author: Milo
 */

#ifndef IZIPLUS_DATAFRAME_H_
#define IZIPLUS_DATAFRAME_H_

#include "iziplus_networkframe.h"
#include "iziplus_frames.h"

#define IZIPLUS_MAX_MASTER			8
#define IZIPLUS_MAX_MASTER_WARN		3
typedef struct iziplus_multimaster_s {
	uint32_t serial;
	uint32_t time;
} iziplus_multimaster_t;

typedef void (*iziplus_cb_func_rxptr)(iziplus_data_frame_t *frame, bool handled);
typedef void (*iziplus_cb_func_onlineptr)(izi_module_t *module, bool online);
typedef bool (*iziplus_cb_func_tokenptr)(izi_module_t *module);

extern trace_level_t iziplus_trace_lvl;

#define IZIPLUS_PREFIX	"[izp]\t"

#define IZIPLUS_TRACE_ERROR(...)	if(iziplus_trace_lvl >= TRACE_LEVEL_ERROR)		{ esp_printf(Debug_Putc, IZIPLUS_PREFIX, __VA_ARGS__); }
#define IZIPLUS_TRACE_WARNING(...)	if(iziplus_trace_lvl >= TRACE_LEVEL_WARNING)	{ esp_printf(Debug_Putc, IZIPLUS_PREFIX, __VA_ARGS__); }
#define IZIPLUS_TRACE_INFO(...)		if(iziplus_trace_lvl >= TRACE_LEVEL_INFO)		{ esp_printf(Debug_Putc, IZIPLUS_PREFIX, __VA_ARGS__); }
#define IZIPLUS_TRACE_DEBUG(...)	if(iziplus_trace_lvl >= TRACE_LEVEL_DEBUG)		{ esp_printf(Debug_Putc, IZIPLUS_PREFIX, __VA_ARGS__); }

// Proto
uint16_t iziplus_dataframe_sendreq(uint32_t destination, uint16_t devtype, uint8_t *data, uint16_t length, uint8_t *frame);
int16_t iziplus_data_request(izi_module_t *module, uint8_t *nw_data, uint16_t nw_length);
int16_t iziplus_data_request_multi(izi_module_t *module, uint8_t *nw_data, uint16_t nw_length, bool multi);
void iziplus_data_no_retry();
bool iziplus_dataframe_checkcrc(iziplus_data_frame_t *data_frame);
void iziplus_dataframe_wildcard(bool enable);
void iziplus_dataframe_init();
void iziplus_dataframe_set_rx_callback(iziplus_cb_func_rxptr ptr);
void iziplus_dataframe_set_online_callback(iziplus_cb_func_onlineptr ptr);
void iziplus_dataframe_set_token_callback(iziplus_cb_func_tokenptr ptr);
bool iziplus_dataframe_sendspecial(uint32_t destination, uint16_t devtype, uint8_t *data, uint16_t length);
int16_t iziplus_data_notification(uint32_t dest, uint16_t devtype, uint8_t *nw_data, uint16_t nw_length);

extern SemaphoreHandle_t xIziPlus_CmdSemaphore;
extern uint16_t iziplus_nwdata_rx_length;
extern uint16_t iziplus_rsp_amount, iziplus_req_amount, iziplus_req_per_sec;
extern uint8_t iziplus_nwdata_rx[IZIPLUS_MAX_DATA];
#endif /* IZIPLUS_DATAFRAME_H_ */
