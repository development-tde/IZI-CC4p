/*
 * state.h
 *
 *  Created on: 13 feb. 2021
 *      Author: Milo
 */

#ifndef STATE_H_
#define STATE_H_

#define STATE_ERROR_MAX				32
#define STATE_ERROR_DEFINED			9

#define STATE_ERROR_HW_ERR			0			// Hardware error 1 (Ext RAM not OK)
#define STATE_ERROR_CURRENT_PEAK	1			// Current peak detected
#define STATE_ERROR_OVERVOLTAGE		2			// Supply voltage above 52V
#define STATE_ERROR_TEMP_TOO_HIGH	3			// Processor temperature above 85 degrees celsius
#define STATE_ERROR_UNDERVOLTAGE	4			// Supply voltage under 18V
#define STATE_ERROR_OS_ASSERT		5			// OS asserted (WD reset should occur)
#define STATE_ERROR_CURRENT_HIGH	6			// Output current too high (> 10.xA)
#define STATE_ERROR_MODULE_MAX		7			// Too many modules detected
#define STATE_ERROR_NTC				8			// NTC error
// Increase STATE_ERROR_DEFINED when error added

#define STATE_WARNING_MAX			32
#define STATE_WARNING_DEFINED		9

#define STATE_WARNING_CURRENT_HIGH	0		// Output current high (> 9.5A)
#define STATE_WARNING_TEMP_HIGH		1		// Temperature of processor above 65 degrees
#define STATE_WARNING_MODULES_MISSING	2	// One or more modules are missing
#define STATE_WARNING_BAD_COMQUAL	3		// Bad Com quality (less than 25% response)
#define STATE_WARNING_NO_MASTER		4		// No CAN master detected
#define STATE_WARNING_STACK_HIGH	5		// Task stack high detected
#define STATE_WARNING_MASTER_HIGH	6		// Too many masters on same frequency (more than 3)
#define STATE_WARNING_PL_SEND		7		// Many errors sending data via powerline modem occurred
#define STATE_WARNING_UART_OVW_WARN	8		// Uart overflow
// Increase STATE_WARNING_DEFINED when error added

#define STATE_STARTINFO_MAX		32
#define STATE_STARTINFO_DEFINED	3

#define STATE_START_CANBUS		0
#define STATE_START_IZILINK		1
#define STATE_START_MAIN		2

#define STATE_RUNINFO_MAX		32
#define STATE_RUN_DISCOVER		0
#define STATE_RUN_CONFIG_SET	1

// CAN state
#define CANSTATE_INIT			0
#define CANSTATE_READY			1
#define CANSTATE_BUSOFF			2
#define CANSTATE_NOMASTER		3

#ifdef trace_level_t
extern trace_level_t state_trace_lvl;
#endif

#define STATE_PREFIX	"[sta]\t"

typedef enum state_led_e { led_toggle = 0, led_on, led_off } state_led_t;

#ifndef STATE_TRACE_BUILD_LVL
#define STATE_TRACE_BUILD_LVL	3
#endif

#if STATE_TRACE_BUILD_LVL >= 0
#define STATE_TRACE_ERROR(...)		{ if(state_trace_lvl >= TRACE_LEVEL_ERROR)		{ esp_printf(Debug_Putc, STATE_PREFIX, __VA_ARGS__); } }
#else
#define STATE_TRACE_ERROR(...)
#endif
#if STATE_TRACE_BUILD_LVL >= 1
#define STATE_TRACE_WARNING(...)	{ if(state_trace_lvl >= TRACE_LEVEL_WARNING)	{ esp_printf(Debug_Putc, STATE_PREFIX, __VA_ARGS__); } }
#else
#define STATE_TRACE_WARNING(...)
#endif
#if STATE_TRACE_BUILD_LVL >= 2
#define STATE_TRACE_INFO(...)		{ if(state_trace_lvl >= TRACE_LEVEL_INFO)		{ esp_printf(Debug_Putc, STATE_PREFIX, __VA_ARGS__); } }
#else
#define STATE_TRACE_INFO(...)
#endif
#if STATE_TRACE_BUILD_LVL >= 3
#define STATE_TRACE_DEBUG(...)		{ if(state_trace_lvl >= TRACE_LEVEL_DEBUG)		{ esp_printf(Debug_Putc, STATE_PREFIX, __VA_ARGS__); } }
#else
#define STATE_TRACE_DEBUG(...)
#endif
#if STATE_TRACE_BUILD_LVL >= 4
#define STATE_TRACE_VERBOSE(...)	{ if(state_trace_lvl >= TRACE_LEVEL_DEBUG)		{ esp_printf(Debug_Putc, STATE_PREFIX, __VA_ARGS__); } }
#else
#define STATE_TRACE_VERBOSE(...)
#endif

#define COLOR_RED			0
#define COLOR_GREEN			1
#define COLOR_BLUE			2
#define COLOR_YELLOW		3
#define COLOR_MAGENTA		4
#define COLOR_AQUA			5
#define COLOR_WHITE			6
#define COLOR_ORANGE		7
#define COLOR_PINK			8
#define COLOR_OFF			9
#define COLOR_YELLOW_LOW	10
#define COLOR_BLUE_LOW		11
#define COLOR_GREEN_LOW		12
#define COLOR_RED_LOW		13
#define COLOR_WHITE_LOW		14
#define COLOR_LIGHT_BLUE	15
#define COLOR_AQUA_MEDIUM	16

// Proto
void State_SetError(uint8_t error);
void State_ClearError(uint8_t error);
bool State_IsErrorActive(uint8_t error);
uint32_t State_GetErrors();
int8_t State_GetHighestError();
char* State_GetHighestErrorText();
void State_SetWarning(uint8_t warning);
void State_ClearWarning(uint8_t warning);
bool State_IsWarningActive(uint8_t warning);
uint32_t State_GetWarnings();
int8_t State_GetHighestWarning();
char* State_GetHighestWarningText();
void State_SetStartInfo(uint8_t startinfo);
void State_ClearStartInfo(uint8_t startinfo);
uint32_t State_GetStartInfo();
uint8_t State_GetHighestStartInfo();
char* State_GetHighestStartInfoText();
void State_SetRunInfo(uint8_t startinfo);
void State_ClearRunInfo(uint8_t startinfo);
void State_SetRunInfo(uint8_t runinfo);
void State_ClearStartInfo(uint8_t runinfo);
uint32_t State_GetRunInfo();

void State_SetCan(uint8_t state);

void State_debug(uint8_t *data, uint8_t length);
void State_Init();
void State_TimerSync();

void State_LedDmxIn(state_led_t state);
void State_LedDmxOut(state_led_t state);
void State_LedArtnet(state_led_t state);
void State_LedContact(state_led_t state);
void State_LedDali(state_led_t state);
void State_LedInitStart();
void State_LedInitReady();
bool State_IsLedInitReady();
void State_SetAttentionInfo(uint8_t color_idx1, uint8_t color_idx2, uint16_t time, uint8_t speed);
void State_ClearAttentionInfo();

#endif /* STATE_H_ */
