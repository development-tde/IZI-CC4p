/*
 * analog.h
 *
 *  Created on: 9 dec. 2020
 *      Author: Milo
 */

#ifndef ANALOG_H_
#define ANALOG_H_

void Analog_Init();
void Analog_Handler();
uint32_t Analog_GetSupplyVoltage();
uint32_t Analog_GetOutputVoltage();
uint16_t Analog_GetProcessorTemperature();
uint32_t Analog_GetOutputCurrent();
uint32_t Analog_GetOutputCurrentMax();
void Analog_PowerUpdate(uint8_t idx, uint8_t total);
void Analog_PowerNext(void);
uint8_t Analog_GetPower(uint16_t *data);
uint32_t Analog_GetEnergy(void);
#endif /* ANALOG_H_ */
