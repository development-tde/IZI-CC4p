/*
 * analog.h
 *
 *  Created on: 9 dec. 2020
 *      Author: Milo
 */

#ifndef ANALOG_H_
#define ANALOG_H_

#define ADC_VIN_MAX				56561UL				// Max to be measured in mV (ref 1.0V, 17.68mV/V)

#define ADC_RAW_MV(r)			((uint16_t)((r * ADC_VIN_MAX)/4095UL))
#define ADC_MV_RAW(m)			((uint16_t)((m * 4095UL)/ADC_VIN_MAX))

void Analog_Init();
void Analog_Handler();
uint32_t Analog_GetSupplyVoltage();
uint32_t Analog_GetSupplyVoltageRaw();
uint32_t Analog_GetOutputVoltage();
uint16_t Analog_GetProcessorTemperature();
uint32_t Analog_GetTint1Raw();
uint32_t Analog_GetTint2Raw();
uint8_t Analog_GetTint1();
uint8_t Analog_GetTint2();
uint8_t Adc_GetTemperature();
uint8_t Adc_GetTemperatureMax();
uint16_t Adc_GetVled1Raw();
uint16_t Adc_GetVled1();
int16_t Adc_GetVled2Raw();
uint16_t Adc_GetVled2();
int16_t Adc_GetVled3Raw();
uint16_t Adc_GetVled3();
int16_t Adc_GetVled4Raw();
uint16_t Adc_GetVled4();

#endif /* ANALOG_H_ */
