/*
 * iziplus_module_def.c
 *
 * Created: 26-2-2022 17:28:14
 *  Author: Milo
 */ 

#include "includes.h"
#include "iziplus_module_def.h"
#include "version.h"
#include "appconfig.h"
#include "iziplus_dataframe.h"
#include "iziplus_driver.h"
#include "stepdown.h"
#include "analog.h"
#include "izi_output.h"
#include "at30tse.h"
#include "crc.h"

#define TEMP_MAX_RESOLUTION			2000					// Max calculation for resolution of temp and power reduce, checked per 100ms
#define TEMP_LIMIT_START_OFFSET		5						// 5 degrees before limit the power reduce will start
#define MAX_INTERN_TEMP				110						// Max 110 degrees intern (110 = off, from 110 - TEMP_LIMIT_START_OFFSET reduce will start)
#define MAX_NTC_TEMP				95						// Max 95 degrees intern (95 = off, from 95 - TEMP_LIMIT_START_OFFSET reduce will start)
#define POWER_MAX_RESOLUTION		TEMP_MAX_RESOLUTION		// 0.05% per 100ms
#define POWER_MAX					10050					// in 10mW

#define MODE_CTRL_UNKNOWN		0
#define MODE_CTRL_RGBW			1
#define MODE_CTRL_TW			2
#define MODE_CTRL_WD			3
#define MODE_CTRL_DIRECT		4			// No RGBW/Tunable/WD just dim

uint8_t module_channels_amount = 0;			// AMount of channels in current mode
iziplus_cpustate_u module_cpu_state;
uint8_t module_monitor[IZI_MAX_MONITOR];
uint16_t module_identify_time = 0, module_identify_prs = 0, module_identify_mode = 0;
uint16_t module_pup_time  = 0;
uint16_t module_reset_report;
uint8_t module_mode_switch, module_mode = MODE_CTRL_UNKNOWN;
extern uint8_t reset_cause;

static bool iziplus_last_comcheck = false;
static uint8_t iziplus_prs_comcheck = 0;
static uint16_t iziplus_data_wasok = false;					// Has light data ever been received?

volatile uint8_t overrule_level_chx[MAX_DIM_CHANNELS];					// Overrule level, overriding channel level
volatile uint16_t overrule_time_chx = 0;								// Time to overrule channel level
volatile uint8_t overrule_prio_chx = 0;
static uint16_t iziplus_level_chx[MAX_DIM_CHANNELS];
static uint16_t iziplus_master_zero_time = 0;
uint16_t iziplus_devtype;
static int16_t iziplus_emitter_state = 0;

uint16_t ntc_temp_master = TEMP_MAX_RESOLUTION;				// NTC reduce in promille
uint16_t intern_temp_master = TEMP_MAX_RESOLUTION;			// Intern temp reduce in promille

volatile int16_t max_intern_temp_raw = 0, limit_intern_temp_raw;
volatile int16_t max_ntc_temp_raw = 0, limit_ntc_temp_raw;

uint8_t timer_prs = 0;
/*const iziplus_emitter_def emitter_data = 
{
	.dim_outputs = 4,
	.test_lvls = {0x00000020, 0x00002000, 0x00200000, 0x20000000 }
};*/

#if 0
const iziplus_mode_def module_modes[MODE_AMOUNT] =
{
	{ .channels = 5, /*.name = "Master RGBW", */ .rgbw_chan = 1, .master_chan = 0, .tw_chan = -1, .control_chan = -1, .flags = 0, .indicate_lvl = 0xF0000000 },
	{ .channels = 4, /*.name = "RGBW", */		.rgbw_chan = 0, .master_chan = -1, .tw_chan = -1, .control_chan = -1, .flags = 0, .indicate_lvl = 0xF0000000 },
	{ .channels = 2, /*.name = "TrueTW", */		.rgbw_chan = -1, .master_chan = 0, .tw_chan = 1, .control_chan = -1, .flags = 0, .indicate_lvl = 0xF0000000 },			// MODE_TRUE_TW
	{ .channels = 1, /*.name = "TrueWD", */		.rgbw_chan = -1, .master_chan = 0, .tw_chan = 0, .control_chan = -1, .flags = MODE_FLASH_WD_SINGLE, .indicate_lvl = 0xF0003813 },			// MODE_TRUE_WD
	{ .channels = 6, /*.name = "Dynamic Auto 6Ch", */ .rgbw_chan = 2, .master_chan = 0, .tw_chan = 1, .control_chan = -2, .flags = MODE_FLASH_AUTO, .indicate_lvl = 0xF0003813 },
	{ .channels = 6, /*.name = "Dynamic Select 6Ch", */ .rgbw_chan = 1, .master_chan = 0, .tw_chan = 4, .control_chan = 5, .flags = 0, .indicate_lvl = 0xF0000000 },
	{ .channels = 7, /*.name = "Dynamic Select 7Ch", */ .rgbw_chan = 2, .master_chan = 0, .tw_chan = 1, .control_chan = 6, .flags = 0, .indicate_lvl = 0xF0000000 },
};

const iziplus_config_def module_config[CONFIG_AMOUNT] =
{
	{ .size = 1, /*.name = "Maximum Output", */ .min = 0, .max = 100, .dflt = 100 },
	{ .size = 1, /*.name = "TTW CCT Color R", */ .min = 0, .max = 1, .dflt = 0},
	{ .size = 1, /*.name = "Filter mode", */ .min = 0, .max = 3, .dflt = 0 },
};		// check CONFIG_SIZE if changed

const iziplus_monitor_def module_monitors[MONITOR_AMOUNT] =
{
	{ .size = 1, /*.name = "Supply Voltage" */ },		
	{ .size = 1, /*.name = "Com Quality" */ },		
	{ .size = 1, /*.name = "Power" */ },		
	{ .size = 1, /*.name = "Output" */ },		
	{ .size = 1, /*.name = "Internal Temp" */ },	
	{ .size = 1, /*.name = "LED Temp" */ },
	{ .size = 1, /*.name = "Max IntTemp" */ },
	{ .size = 1, /*.name = "Max LEDTemp" */ },
	{ .size = 2, /*.name = "Up Time" */ },
	{ .size = 2, /*.name = "On time" */ },	
	{ .size = 1, /*.name = "Status" */ },	
};		// MONITOR_SIZE
#endif

//const uint8_t channel_patch[MAX_DIM_CHANNELS] = { 1, 2, 3, 0 };		// WRGB


/*Scaling
Red	0,69
Green	1,00
Blue	1,20
White	1,06
*/
/*
const uint8_t ColorRed[MAX_COLOR_ITEMS] = { 125, 125, 125, 100, 45, 26, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
const uint8_t ColorGreen[MAX_COLOR_ITEMS] = { 56, 61, 61, 49, 18, 23, 32, 49, 79, 108, 135, 157, 175, 193, 209, 223, 239 };
const uint8_t ColorBlue[MAX_COLOR_ITEMS] = { 0, 0, 0, 0, 0, 3, 10, 20, 35, 54, 69, 88, 110, 127, 147, 166, 188 };
const uint8_t ColorWhite[MAX_COLOR_ITEMS] = { 0, 15, 49, 98, 168, 199, 227, 247, 255, 255, 245, 229, 217, 205, 195, 185, 176 };
*/
/*
const uint8_t ColorRed[MAX_COLOR_ITEMS] = { 147, 147, 147, 118, 53, 31, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
const uint8_t ColorGreen[MAX_COLOR_ITEMS] = { 46, 50, 50, 40, 15, 19, 26, 40, 65, 88, 111, 129, 143, 157, 170, 182, 195 };
const uint8_t ColorBlue[MAX_COLOR_ITEMS] = { 0, 0, 0, 0, 0, 2, 7, 13, 24, 37, 47, 60, 75, 87, 100, 113, 128 };
const uint8_t ColorWhite[MAX_COLOR_ITEMS] = { 0, 15, 49, 98, 168, 199, 227, 247, 255, 255, 245, 229, 217, 205, 195, 185, 176 };
*/

//const uint8_t Tw3000K = 122;		// 3000K Point 
//const uint8_t Tw4000K = 170;        // 4000K Point

/*const uint16_t FwVoltageTables[MAX_DIM_CHANNELS] =
{											// Use the Order of the DIM channels
	15000,									// Forward Voltage of the LEDs on DIM1 channel
	8800,
	6000,
	6000
};*/

uint8_t* ColorTables[MAX_DIM_CHANNELS] = 
{
	/*ColorWhite,					// Use the Order of the DIM channels
	ColorRed,
	ColorGreen,
	ColorBlue*/
};
/*
const int16_t CorrTempTables[MAX_DIM_CHANNELS] =
{											// Use the Order of the DIM channels
	0,										// Color correction factor (0 = no correction)
	201,
	36,
	-27
};

const uint16_t CorrTjcTables[MAX_DIM_CHANNELS] =
{											// Use the Order of the DIM channels
	0,										// Constant for Dtjc calculation
	112,
	0,
	0
};*/


//const uint16_t MaxCurrent = 700;
//const uint16_t MaxPower = 10050;

//const uint16_t TwGain = 67;					// 70% in TW mode, so the 10W is not reached over the complete range
//const uint16_t WdGain = 82;					// 86% in WD mode, so the 10W is not reached over the complete range

//const uint8_t RgbwSensitivity[MAX_DIM_CHANNELS] = { 255, 142, 196, 78 }; //{ 255, 184, 255, 102 };                  // RGBW Sensitivity (in patched order!)

iziplus_fixture_def	iziplus_fixdef;
bool iziplus_fixdef_ok = false;
uint16_t  iziplus_config_size;
uint16_t  iziplus_monitor_size;

// Proto
void print_resetcause();
void IziPlus_Module_WriteEmitter(bool load_only);
void IziPlus_Module_CreateVariant(uint8_t variant);
bool IziPlus_Module_CreateRgbw();

// Temp
uint8_t Adc_GetTint()
{
	return Adc_GetTemperature();
}

uint8_t Adc_GetNtc()
{
	return 24;
}

uint16_t Adc_GetNtcRaw()
{
	return Adc_GetNtc() * AT30TSE_MUL;
}

uint8_t Adc_GetTintMax()
{
	return Adc_GetTemperatureMax();
}

uint8_t Adc_GetNtcMax() 
{
	return 31;
}

uint16_t Adc_GetVout()
{
	return 30000;
}

extern const uint8_t ntc_table[512];

int16_t Adc_GetTempRaw(uint8_t degrees)
{
	for(uint16_t i = 0; i < 512; i++)
	{
		if(ntc_table[i] == degrees)
		{
			return (int16_t)(i << 3);				// Give back raw value of AD (convert 8 to 12 bit)
		}
	}
	return -1;
}

uint16_t Adc_GetTintRaw()
{
	return 3000;
}

/************************************************************************/
/* Code                                                                 */
/************************************************************************/
bool IziPlus_GetDevType()
{
	iziplus_devtype = IZIPLUS_DEVTYPE_BASE + iziplus_fixdef.id;
	
	if(iziplus_fixdef.max_channels > MAX_DIM_CHANNELS)
		return false;
	
	for(int i = 0; i < iziplus_fixdef.max_channels; i++)
	{
		if(iziplus_fixdef.patch[i] > MAX_DIM_CHANNELS)
			return false;
	}
	
	// Todo: check if patch is within limits
	ColorTables[iziplus_fixdef.patch[3]] = iziplus_fixdef.bbc_white;
	ColorTables[iziplus_fixdef.patch[0]] = iziplus_fixdef.bbc_red;
	ColorTables[iziplus_fixdef.patch[1]] = iziplus_fixdef.bbc_green;
	ColorTables[iziplus_fixdef.patch[2]] = iziplus_fixdef.bbc_blue;
	
	return true;
}

// Init current parameters
bool IziPlus_Module_Init()
{
	bool res = true;
	//print_resetcause();
	
	module_reset_report = 30;		// Report reset cause for 3 seconds
	module_cpu_state.w = 0;
	if(reset_cause == RESET_CAUSE_POWER_UP)
		module_cpu_state.u.powerup = true;
	else if(reset_cause == RESET_CAUSE_EXTRST)
		module_cpu_state.u.extreset = true;
	else if(reset_cause == RESET_CAUSE_BOD)
		module_cpu_state.u.brownout = true;
	else if(reset_cause == RESET_CAUSE_SYSRST)
		module_cpu_state.u.sw_reset = true;
	else if(reset_cause == RESET_CAUSE_WATCHDOG)
		module_cpu_state.u.watchdog = true;
	
	uint8_t variant = IziPlus_Module_GetVariant();
	if(variant > VARIANT_EMITTER)
		IziPlus_Module_CreateVariant(variant);
	else
		res = IziPlus_Module_CreateRgbw();
	
	iziplus_fixdef_ok = res;
	
	if(iziplus_fixdef_ok)
	{
		if(appConfig->default_ok != APPCFG_DFLT_OK || appConfig->variant != variant || appConfig->typeid != iziplus_fixdef.id)		// Different emitter, different variant, default incomplete (when emitter was not known yet)
			AppConfig_Default();				// Do a default
		else
			AppConfig_CheckConfig();			// Check if all config is within limits
	}
	IziPlus_GetDevType();
	IziPlus_Module_Update();
	
	return res;
}

void IziPlus_Module_CheckDefinitions()
{
	uint16_t crc = Crc16((uint8_t *)&iziplus_fixdef, sizeof(iziplus_fixdef) - 2, 0);
	if(crc != iziplus_fixdef.crc)
	{
		State_SetError(STATE_ERROR_EMITTER_DATA);
		uint8_t variant = IziPlus_Module_GetVariant();
		if(variant > VARIANT_EMITTER)
			IziPlus_Module_CreateVariant(variant);
		else
			iziplus_fixdef_ok = IziPlus_Module_CreateRgbw();		// Todo: What todo if it fails
	}
	else
		State_ClearError(STATE_ERROR_EMITTER_DATA);
}

bool IziPlus_Module_CreateRgbw()
{
#if !(defined(MS_MEASURE) || defined(MS_TEMPCORR_OFF) || defined(MS_TEST_NO_EMITTER))
	if(At30tse_ReadEeprom((uint8_t *)&iziplus_fixdef, 0, sizeof(iziplus_fixdef)) != 0)
	{
		State_SetError(STATE_ERROR_NO_EMITTER);
		iziplus_emitter_state = -1;
	}
	else
	{
#else		
		IziPlus_Module_WriteEmitter(true);
#endif		
		//IziPlus_Module_WriteEmitterTw(false);
		uint16_t crc = Crc16((uint8_t *)&iziplus_fixdef, sizeof(iziplus_fixdef) - 2, 0);
		
		//At30tse_ReadEeprom((uint8_t *)&iziplus_fixdef, 0, sizeof(iziplus_fixdef));
		
		if(crc != iziplus_fixdef.crc)
		{
			State_SetError(STATE_ERROR_NO_EMITTER);
			iziplus_emitter_state = -2;
			
			//IziPlus_Module_WriteEmitter(false);
		}
		else
		{
			iziplus_config_size = 0;
			for(int i = 0; i < iziplus_fixdef.max_configs; i++)
				iziplus_config_size += iziplus_fixdef.configs[i].size;
			
			iziplus_monitor_size = 0;
			for(int i = 0; i < iziplus_fixdef.max_monitors; i++)
				iziplus_monitor_size += iziplus_fixdef.monitors[i].size;
				
			iziplus_emitter_state = 0;
#if !(defined(MS_MEASURE) || defined(MS_TEMPCORR_OFF) || defined(MS_TEST_NO_EMITTER))
		}	
#endif
	}
	
	return iziplus_emitter_state >= 0;
}

void IziPlus_Module_WriteEmitter(bool load_only)
{
#ifdef MS_MEASURE		
	iziplus_fixdef.version = 99;
#else
	iziplus_fixdef.version = 0x21;			// V1.0
#endif
	iziplus_fixdef.id = 0;
	iziplus_fixdef.max_channels = 4;
	iziplus_fixdef.max_current = 700;		// Max current = 0.7A
	iziplus_fixdef.max_power = 10050;		// Max power = 10.05W (0.05 is offset for component deviations)
	iziplus_fixdef.tw3000K = 122;			// 3000K level
	iziplus_fixdef.tw4000K = 170;			// 4000K level
	iziplus_fixdef.tw_gain = 100;			// 100% in TW mode, so the 10W is not reached over the complete range
	iziplus_fixdef.wd_gain = 100;			// 100% in WD mode, so the 10W is not reached over the complete range
	
	const uint32_t test_lvls[MAX_DIM_CHANNELS] = {0x00000020, 0x00002000, 0x00200000, 0x20000000 };
	memcpy(iziplus_fixdef.test_lvls, test_lvls, MAX_DIM_CHANNELS * 4);								// Button test levels
	
#ifdef MS_MEASURE	
	const uint8_t rgbw_sensitivity[MAX_DIM_CHANNELS] = { 255, 255, 255, 255 };
#else		
	const uint8_t rgbw_sensitivity[MAX_DIM_CHANNELS] = { 255, 152, 235, 168 };
#endif		
	memcpy(iziplus_fixdef.rgbw_sensitivity, rgbw_sensitivity, MAX_DIM_CHANNELS);					// RGBW Sensitivity (in patched order!)
	
#if defined(MS_MEASURE) || defined(MS_TEMPCORR_OFF)
	const uint16_t corr_tjc_tables[MAX_DIM_CHANNELS] = { 0, 0, 0, 0 };
#else
	const uint16_t corr_tjc_tables[MAX_DIM_CHANNELS] = { 0, 120, 22, 22 };
#endif
	memcpy(iziplus_fixdef.corr_tjc_tables, corr_tjc_tables, MAX_DIM_CHANNELS * 2);                  // Constant for Dtjc calculation
	
#if defined(MS_MEASURE) || defined(MS_TEMPCORR_OFF)
	const int16_t corr_temp_tables[MAX_DIM_CHANNELS] = { 0, 0, 0, 0 };
#else
	const int16_t corr_temp_tables[MAX_DIM_CHANNELS] = { 0, 201, 36, -27 };
#endif
	memcpy(iziplus_fixdef.corr_temp_tables, corr_temp_tables, MAX_DIM_CHANNELS * 2);                // Color correction factor (0 = no correction)
	
	const uint16_t fw_voltage_tables[MAX_DIM_CHANNELS] = { 14000, 8600, 5700, 5700 };
	memcpy(iziplus_fixdef.fw_voltage_tables, fw_voltage_tables, MAX_DIM_CHANNELS * 2);				// Forward Voltage of the LEDs on DIM1 channel (in patched order!)
	
	const uint8_t bbc_red[MAX_COLOR_ITEMS] = { 179,	179,	179,	157,	103,	51,	23,	11,	0,	0,	0,	0,	0,	0,	0,	0,	0 };
	memcpy(iziplus_fixdef.bbc_red, bbc_red, MAX_COLOR_ITEMS);
	const uint8_t bbc_green[MAX_COLOR_ITEMS] = { 90,	98,	109,	106,	70,	52,	54,	70,	85,	100,	113,	119,	128,	130,	131,	137,	140 };
	memcpy(iziplus_fixdef.bbc_green, bbc_green, MAX_COLOR_ITEMS);
	const uint8_t bbc_blue[MAX_COLOR_ITEMS] = { 0,	0,	0,	0,	0,	5,	19,	30,	47,	67,	83,	103,	117,	132,	145,	154,	164 };
	memcpy(iziplus_fixdef.bbc_blue, bbc_blue, MAX_COLOR_ITEMS);
	const uint8_t bbc_white[MAX_COLOR_ITEMS] = { 7,	36,	70,	111,	156,	189,	198,	193,	186,	172,	161,	150,	142,	134,	129,	123,	117 };
	memcpy(iziplus_fixdef.bbc_white, bbc_white, MAX_COLOR_ITEMS);
	
	const uint8_t patch[MAX_DIM_CHANNELS] = { 1, 2, 3, 0 };		// WRGB
	memcpy(iziplus_fixdef.patch, patch, MAX_DIM_CHANNELS);
	
	iziplus_fixdef.max_modes = 7;
	const iziplus_mode_def modes[7] =
	{
		{ .channels = 5, /*.name = "Master RGBW", */ .rgbw_chan = 1, .master_chan = 0, .tw_chan = -1, .control_chan = -1, .flags = 0, .indicate_lvl = 0xF0000000 },
		{ .channels = 4, /*.name = "RGBW", */		.rgbw_chan = 0, .master_chan = -1, .tw_chan = -1, .control_chan = -1, .flags = 0, .indicate_lvl = 0xF0000000 },
		{ .channels = 2, /*.name = "TrueTW", */		.rgbw_chan = -1, .master_chan = 0, .tw_chan = 1, .control_chan = -1, .flags = 0, .indicate_lvl = 0xF0000000 },			// MODE_TRUE_TW
		{ .channels = 1, /*.name = "TrueWD", */		.rgbw_chan = -1, .master_chan = 0, .tw_chan = 0, .control_chan = -1, .flags = MODE_FLASH_WD_SINGLE, .indicate_lvl = 0xF0003813 },			// MODE_TRUE_WD
		{ .channels = 6, /*.name = "Dynamic Auto 6Ch", */ .rgbw_chan = 2, .master_chan = 0, .tw_chan = 1, .control_chan = -2, .flags = MODE_FLASH_AUTO, .indicate_lvl = 0xF0003813 },
		{ .channels = 6, /*.name = "Dynamic Select 6Ch", */ .rgbw_chan = 1, .master_chan = 0, .tw_chan = 4, .control_chan = 5, .flags = 0, .indicate_lvl = 0xF0000000 },
		{ .channels = 7, /*.name = "Dynamic Select 7Ch", */ .rgbw_chan = 2, .master_chan = 0, .tw_chan = 1, .control_chan = 6, .flags = 0, .indicate_lvl = 0xF0000000 },
	};
	memcpy(iziplus_fixdef.modes, modes, sizeof(modes));
	
	iziplus_fixdef.max_configs = 3;
	const iziplus_config_def configs[3] =
	{
		{ .size = 1, .ref = 0,/*.name = "Maximum Output", */ .min = 0, .max = 100, .dflt = 100 },
		{ .size = 1, .ref = 1,/*.name = "TTW CCT Color R", */ .min = 0, .max = 1, .dflt = 0},
		{ .size = 1, .ref = 2,/*.name = "Filter mode", */ .min = 0, .max = 3, .dflt = 0 },
	};		// check CONFIG_SIZE if changed
	memcpy(iziplus_fixdef.configs, configs, sizeof(configs));
	
	iziplus_config_size = 0;
	for(int i = 0; i < iziplus_fixdef.max_configs; i++)
	iziplus_config_size += iziplus_fixdef.configs[i].size;
	
	iziplus_fixdef.max_monitors = 12;
	const iziplus_monitor_def monitors[12] =
	{
		{ .size = 1, .ref = 0,  /*.name = "Supply Voltage" */ },
		{ .size = 1, .ref = 1,  /*.name = "Com Quality" */ },
		{ .size = 1, .ref = 2,  /*.name = "Power" */ },
		{ .size = 1, .ref = 3,  /*.name = "Output" */ },
		{ .size = 1, .ref = 4,  /*.name = "Internal Temp" */ },
		{ .size = 1, .ref = 5,  /*.name = "LED Temp" */ },
		{ .size = 1, .ref = 6,  /*.name = "Max IntTemp" */ },
		{ .size = 1, .ref = 7,  /*.name = "Max LEDTemp" */ },
		{ .size = 2, .ref = 8,  /*.name = "Up Time" */ },
		{ .size = 2, .ref = 10, /*.name = "On time" */ },
		{ .size = 1, .ref = 12, /*.name = "Status" */ },
		{ .size = 2, .ref = 13, /*.name = "Forward voltage" */ },
	};		// MONITOR_SIZE
	memcpy(iziplus_fixdef.monitors, monitors, sizeof(monitors));
	iziplus_monitor_size = 0;
	for(int i = 0; i < iziplus_fixdef.max_monitors; i++)
	iziplus_monitor_size += iziplus_fixdef.monitors[i].size;
	
	iziplus_fixdef.crc = Crc16((uint8_t *)&iziplus_fixdef, sizeof(iziplus_fixdef) - 2, 0);
	if(!load_only)
	{
		if(At30tse_WriteEeprom((uint8_t *)&iziplus_fixdef, 0, sizeof(iziplus_fixdef)) != 0)
			State_SetError(1);
	}
}

void IziPlus_Module_WriteEmitterTw(bool load_only)
{
	iziplus_fixdef.version = 1;
	iziplus_fixdef.id = 16;
	iziplus_fixdef.max_channels = 4;		// Bit weird, because it has only 3 channels
	iziplus_fixdef.max_current = 700;		// Max current = 0.7A
	iziplus_fixdef.max_power = 10050;		// Max power = 10.05W (0.05 is offset for component deviations)
	iziplus_fixdef.tw3000K = 122;			// 3000K level
	iziplus_fixdef.tw4000K = 170;			// 4000K level
	iziplus_fixdef.tw_gain = 100;			// 100% in TW mode, so the 10W is not reached over the complete range
	iziplus_fixdef.wd_gain = 100;			// 100% in WD mode, so the 10W is not reached over the complete range
	
	const uint32_t test_lvls[MAX_DIM_CHANNELS] = {0x00000020, 0x00002000, 0x00200000, 0x20000000 };
	memcpy(iziplus_fixdef.test_lvls, test_lvls, MAX_DIM_CHANNELS * 4);								// Button test levels
	
	const uint8_t rgbw_sensitivity[MAX_DIM_CHANNELS] = { 255, 255, 255, 255 };
	memcpy(iziplus_fixdef.rgbw_sensitivity, rgbw_sensitivity, MAX_DIM_CHANNELS);					// RGBW Sensitivity (in patched order!)
	
	const uint16_t corr_tjc_tables[MAX_DIM_CHANNELS] = { 0, 0, 0, 0 };
	memcpy(iziplus_fixdef.corr_tjc_tables, corr_tjc_tables, MAX_DIM_CHANNELS * 2);                  // Constant for Dtjc calculation
	
	const int16_t corr_temp_tables[MAX_DIM_CHANNELS] = { 0, 0, 0, 0 };
	memcpy(iziplus_fixdef.corr_temp_tables, corr_temp_tables, MAX_DIM_CHANNELS * 2);                // Color correction factor (0 = no correction)
	
	const uint16_t fw_voltage_tables[MAX_DIM_CHANNELS] = { 15000, 9000, 9000, 6000 };
	memcpy(iziplus_fixdef.fw_voltage_tables, fw_voltage_tables, MAX_DIM_CHANNELS * 2);				// Forward Voltage of the LEDs on DIM1 channel (in patched order!)
	
	const uint8_t bbc_red[MAX_COLOR_ITEMS] = { 255,	255,	255,	255,	255,	237,	219,	200,	184,	168,	150,	135,	120,	100,	74,	40,	0 };
	memcpy(iziplus_fixdef.bbc_red, bbc_red, MAX_COLOR_ITEMS);
	const uint8_t bbc_green[MAX_COLOR_ITEMS] = { 56,	70,	82,	98,	113,	122,	127,	126,	127,	121,	113,	102,	86,	67,	29,	16,	0 };
	memcpy(iziplus_fixdef.bbc_green, bbc_green, MAX_COLOR_ITEMS);
	const uint8_t bbc_blue[MAX_COLOR_ITEMS] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
	memcpy(iziplus_fixdef.bbc_blue, bbc_blue, MAX_COLOR_ITEMS);
	const uint8_t bbc_white[MAX_COLOR_ITEMS] = { 5,	5,	7,	10,	18,	24,	32,	43,	53,	66,	80,	97,	116,	140,	179,	205,	240 };
	memcpy(iziplus_fixdef.bbc_white, bbc_white, MAX_COLOR_ITEMS);
	
	const uint8_t patch[MAX_DIM_CHANNELS] = { 1, 2, 3, 0 };		// RG(B)W -> WRG(B)
	memcpy(iziplus_fixdef.patch, patch, MAX_DIM_CHANNELS);
	
	iziplus_fixdef.max_modes = 4;
	const iziplus_mode_def modes[4] =
	{
		{ .channels = 2, /*.name = "TrueTW", */		.rgbw_chan = -1, .master_chan = 0, .tw_chan = 1, .control_chan = -1, .flags = 0, .indicate_lvl = 0xF0003813 },			
		{ .channels = 1, /*.name = "TrueWD", */		.rgbw_chan = -1, .master_chan = 0, .tw_chan = 0, .control_chan = -1, .flags = MODE_FLASH_WD_SINGLE, .indicate_lvl = 0xF0003813 },			
		{ .channels = 3, /*.name = "TrueTW 16-bit", */		.rgbw_chan = -1, .master_chan = 0, .tw_chan = 2, .control_chan = -1, .flags = MODE_FIRST_16B, .indicate_lvl = 0xF0003813 },			
		{ .channels = 2, /*.name = "TrueWD 16-bit", */		.rgbw_chan = -1, .master_chan = 0, .tw_chan = 0, .control_chan = -1, .flags = MODE_FLASH_WD_SINGLE|MODE_FIRST_16B, .indicate_lvl = 0xF0003813 },			
	};
	memcpy(iziplus_fixdef.modes, modes, sizeof(modes));
	
	iziplus_fixdef.max_configs = 3;
	const iziplus_config_def configs[3] =
	{
		{ .size = 1, .ref = 0,/*.name = "Maximum Output", */ .min = 0, .max = 100, .dflt = 100 },
		{ .size = 1, .ref = 1,/*.name = "TTW CCT Color R", */ .min = 0, .max = 1, .dflt = 0},
		{ .size = 1, .ref = 2,/*.name = "Filter mode", */ .min = 0, .max = 3, .dflt = 0 },
	};		// check CONFIG_SIZE if changed
	memcpy(iziplus_fixdef.configs, configs, sizeof(configs));
	
	iziplus_config_size = 0;
	for(int i = 0; i < iziplus_fixdef.max_configs; i++)
	iziplus_config_size += iziplus_fixdef.configs[i].size;
	
	iziplus_fixdef.max_monitors = 12;
	const iziplus_monitor_def monitors[12] =
	{
		{ .size = 1, .ref = 0,  /*.name = "Supply Voltage" */ },
		{ .size = 1, .ref = 1,  /*.name = "Com Quality" */ },
		{ .size = 1, .ref = 2,  /*.name = "Power" */ },
		{ .size = 1, .ref = 3,  /*.name = "Output" */ },
		{ .size = 1, .ref = 4,  /*.name = "Internal Temp" */ },
		{ .size = 1, .ref = 5,  /*.name = "LED Temp" */ },
		{ .size = 1, .ref = 6,  /*.name = "Max IntTemp" */ },
		{ .size = 1, .ref = 7,  /*.name = "Max LEDTemp" */ },
		{ .size = 2, .ref = 8,  /*.name = "Up Time" */ },
		{ .size = 2, .ref = 10, /*.name = "On time" */ },
		{ .size = 1, .ref = 12, /*.name = "Status" */ },
		{ .size = 2, .ref = 13, /*.name = "Forward voltage" */ },
	};		// MONITOR_SIZE
	memcpy(iziplus_fixdef.monitors, monitors, sizeof(monitors));
	iziplus_monitor_size = 0;
	for(int i = 0; i < iziplus_fixdef.max_monitors; i++)
	iziplus_monitor_size += iziplus_fixdef.monitors[i].size;
	
	iziplus_fixdef.crc = Crc16((uint8_t *)&iziplus_fixdef, sizeof(iziplus_fixdef) - 2, 0);
	if(!load_only)
	{
		if(At30tse_WriteEeprom((uint8_t *)&iziplus_fixdef, 0, sizeof(iziplus_fixdef)) != 0)
		State_SetError(1);
	}
}

void IziPlus_Module_CreateVariant(uint8_t variant)
{
	iziplus_fixdef.version = 1;
	iziplus_fixdef.id = variant == VARIANT_CC1 ? 24 : 8;
	iziplus_fixdef.max_channels = 1;
	iziplus_fixdef.max_current = 300;		// Max current = 0.3A
	iziplus_fixdef.max_power = 10050;		// Max power = 10.05W (0.05 is offset for component deviations)
	iziplus_fixdef.tw3000K = 122;			// 3000K level
	iziplus_fixdef.tw4000K = 170;			// 4000K level
	iziplus_fixdef.tw_gain = 67;			// 67% in TW mode, so the 10W is not reached over the complete range
	iziplus_fixdef.wd_gain = 82;			// 82% in WD mode, so the 10W is not reached over the complete range
	
	const uint32_t test_lvls[MAX_DIM_CHANNELS] = {0x00000020, 0x00002000, 0x00200000, 0x20000000 };
	memcpy(iziplus_fixdef.test_lvls, test_lvls, MAX_DIM_CHANNELS * 4);								// Button test levels
	
	const uint8_t rgbw_sensitivity[MAX_DIM_CHANNELS] = { 255, 255, 255, 255 };
	memcpy(iziplus_fixdef.rgbw_sensitivity, rgbw_sensitivity, MAX_DIM_CHANNELS);					// RGBW Sensitivity (in patched order!)
	
	const uint16_t corr_tjc_tables[MAX_DIM_CHANNELS] = { 0, 0, 0, 0 };
	memcpy(iziplus_fixdef.corr_tjc_tables, corr_tjc_tables, MAX_DIM_CHANNELS * 2);                  // Constant for Dtjc calculation
	
	const int16_t corr_temp_tables[MAX_DIM_CHANNELS] = { 0, 0, 0, 0 };
	memcpy(iziplus_fixdef.corr_temp_tables, corr_temp_tables, MAX_DIM_CHANNELS * 2);                // Color correction factor (0 = no correction)
	
	const uint16_t fw_voltage_tables[MAX_DIM_CHANNELS] = { 15000, 8800, 6000, 6000 };
	memcpy(iziplus_fixdef.fw_voltage_tables, fw_voltage_tables, MAX_DIM_CHANNELS * 2);				// Forward Voltage of the LEDs on DIM1 channel (in patched order!)
	
	const uint8_t bbc_red[MAX_COLOR_ITEMS] = { 125, 125, 125, 100, 45, 26, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
	memcpy(iziplus_fixdef.bbc_red, bbc_red, MAX_COLOR_ITEMS);
	const uint8_t bbc_green[MAX_COLOR_ITEMS] = { 56, 61, 61, 49, 18, 23, 32, 49, 79, 108, 135, 157, 175, 193, 209, 223, 239 };
	memcpy(iziplus_fixdef.bbc_green, bbc_green, MAX_COLOR_ITEMS);
	const uint8_t bbc_blue[MAX_COLOR_ITEMS] = { 0, 0, 0, 0, 0, 3, 10, 20, 35, 54, 69, 88, 110, 127, 147, 166, 188 };
	memcpy(iziplus_fixdef.bbc_blue, bbc_blue, MAX_COLOR_ITEMS);
	const uint8_t bbc_white[MAX_COLOR_ITEMS] = { 0, 15, 49, 98, 168, 199, 227, 247, 255, 255, 245, 229, 217, 205, 195, 185, 176 };
	memcpy(iziplus_fixdef.bbc_white, bbc_white, MAX_COLOR_ITEMS);
	
	const uint8_t patch[MAX_DIM_CHANNELS] = { 0, 1, 2, 3 };		// RGBW
	memcpy(iziplus_fixdef.patch, patch, MAX_DIM_CHANNELS);
	
	iziplus_fixdef.max_modes = 2;
	const iziplus_mode_def modes[2] =
	{
		{ .channels = 1, /*.name = "1 channel 8-bit", */		.rgbw_chan = -1, .master_chan = -1, .tw_chan = -1, .control_chan = -1, .flags = MODE_FLASH_DIRECT, .indicate_lvl = 0xFFFFFFFF },			// MODE_TRUE_WD
		{ .channels = 2, /*.name = "2 channel 16-bit", */		.rgbw_chan = -1, .master_chan = -1, .tw_chan = -1, .control_chan = -1, .flags = MODE_FLASH_DIRECT|MODE_FIRST_16B, .indicate_lvl = 0xFFFFFFFF },			// MODE_TRUE_WD
	};
	memcpy(iziplus_fixdef.modes, modes, sizeof(modes));
	
	if(variant == VARIANT_WD800)
	{
		iziplus_fixdef.max_configs = 2;
		const iziplus_config_def configs[2] =
		{
			{ .size = 1, .ref = 0,  /*.name = "Maximum Output", */ .min = 0, .max = 100, .dflt = 100 },
			{ .size = 1, .ref = 2,/*.name = "Filter mode", */ .min = 0, .max = 3, .dflt = 0 },
		};		// check CONFIG_SIZE if changed
		memcpy(iziplus_fixdef.configs, configs, sizeof(configs));
	}
	else
	{
		iziplus_fixdef.max_configs = 3;
		const iziplus_config_def configs[3] =
		{
			{ .size = 1, .ref = 0,  /*.name = "Maximum Output", */ .min = 0, .max = 100, .dflt = 100 },
			{ .size = 1, .ref = 2,/*.name = "Filter mode", */ .min = 0, .max = 3, .dflt = 0 },
			{ .size = 1, .ref = 3,/*.name = "Maximum Current Selection", */ .min = 0, .max = 11, .dflt = 0 },
		};		// check CONFIG_SIZE if changed
		memcpy(iziplus_fixdef.configs, configs, sizeof(configs));
	}
	
	iziplus_config_size = 0;
	for(int i = 0; i < iziplus_fixdef.max_configs; i++)
		iziplus_config_size += iziplus_fixdef.configs[i].size;
	
	iziplus_fixdef.max_monitors = 10;
	const iziplus_monitor_def monitors[10] =
	{
		{ .size = 1, .ref = 0,  /*.name = "Supply Voltage" */ },
		{ .size = 1, .ref = 1,  /*.name = "Com Quality" */ },
		{ .size = 1, .ref = 2,  /*.name = "Power" */ },
		{ .size = 1, .ref = 3,  /*.name = "Output" */ },
		{ .size = 1, .ref = 4,  /*.name = "Internal Temp" */ },
		//{ .size = 1, .ref = 5,  /*.name = "LED Temp" */ },
		{ .size = 1, .ref = 6,  /*.name = "Max IntTemp" */ },
		//{ .size = 1, .ref = 7,  /*.name = "Max LEDTemp" */ },
		{ .size = 2, .ref = 8,  /*.name = "Up Time" */ },
		{ .size = 2, .ref = 10, /*.name = "On time" */ },
		{ .size = 1, .ref = 12, /*.name = "Status" */ },
		{ .size = 2, .ref = 13, /*.name = "Forward voltage" */ },
	};		// MONITOR_SIZE
	memcpy(iziplus_fixdef.monitors, monitors, sizeof(monitors));
	iziplus_monitor_size = 0;
	for(int i = 0; i < iziplus_fixdef.max_monitors; i++)
		iziplus_monitor_size += iziplus_fixdef.monitors[i].size;
	
	iziplus_fixdef.crc = Crc16((uint8_t *)&iziplus_fixdef, sizeof(iziplus_fixdef) - 2, 0);
}


/************************************************************************/
/* Call after every config write and after init                         */
/************************************************************************/
void IziPlus_Module_Update()
{
	if(appConfig->mode < MODE_AMOUNT)
		module_channels_amount = iziplus_fixdef.modes[appConfig->mode].channels;
	
	max_intern_temp_raw = Adc_GetTempRaw(MAX_INTERN_TEMP);
	limit_intern_temp_raw = Adc_GetTempRaw(MAX_INTERN_TEMP - TEMP_LIMIT_START_OFFSET);
	max_ntc_temp_raw = MAX_NTC_TEMP * AT30TSE_MUL;
	limit_ntc_temp_raw = (MAX_NTC_TEMP - TEMP_LIMIT_START_OFFSET) * AT30TSE_MUL;
	
	module_mode_switch = 0;					// Indicate to go off (while switching)
}

bool IziPlus_Module_TemperatureCheck(int16_t temp, uint16_t *temp_master, int16_t max_config, int16_t limit_config)
{
	if(temp <= limit_config)			// Temp above limit, reduce level (looks weird because value gets lower on a higher temperature, because the raw ad value is used)
	{
		if(temp > max_config)			// Still under max temp (where it should be 0)
		{
			uint16_t level_limit = (temp - max_config) * (TEMP_MAX_RESOLUTION / (limit_config - max_config));
			if(*temp_master > level_limit)
			{
				if(((*temp_master - level_limit) >= 128) && (*temp_master >= 4))
					*temp_master -= 4;		// -1 is 0.20% per 100ms
				else if(*temp_master > 0)
					*temp_master -= 1;		// -1 is 0.05% per 100ms
			}
			else if((*temp_master < level_limit) && (*temp_master < TEMP_MAX_RESOLUTION))
				*temp_master += 1;
		}
		else if(*temp_master > 10)		// Faster (max 10s) to 0% when on or over limit
			*temp_master -= 10;
		else
			*temp_master = 0;
		
		return true;					// Report temp too high, still reducing
	}
	else if(*temp_master < (TEMP_MAX_RESOLUTION - 10))
	{
		*temp_master += 10;
		return true;					// Report temp too high, still reducing
	}
	else
		*temp_master = TEMP_MAX_RESOLUTION;
	
	return false;					// Report temp too high, still reducing
}

bool IziPlus_Module_TemperatureCelciusCheck(int16_t temp, uint16_t *temp_master, int16_t max_config, int16_t limit_config)
{
	if(temp >= limit_config)			// Temp above limit, reduce level (looks weird because value gets lower on a higher temperature, because the raw ad value is used)
	{
		if(temp < max_config)			// Still under max temp (where it should be 0)
		{
			uint16_t level_limit = (max_config - temp) * (TEMP_MAX_RESOLUTION / (max_config - limit_config));
			if(*temp_master > level_limit)
			{
				if(((*temp_master - level_limit) >= 128) && (*temp_master >= 4))
					*temp_master -= 4;		// -1 is 0.20% per 100ms
				else if(*temp_master > 0)
					*temp_master -= 1;		// -1 is 0.05% per 100ms
			}
			else if((*temp_master < level_limit) && (*temp_master < TEMP_MAX_RESOLUTION))
				*temp_master += 1;
		}
		else if(*temp_master > 10)		// Faster (max 10s) to 0% when on or over limit
			*temp_master -= 10;
		else
			*temp_master = 0;
		
		return true;					// Report temp too high, still reducing
	}
	else if(*temp_master < (TEMP_MAX_RESOLUTION - 10))
	{
		*temp_master += 10;
		return true;					// Report temp too high, still reducing
	}
	else
		*temp_master = TEMP_MAX_RESOLUTION;
	
	return false;					// Report temp too high, still reducing
}

uint16_t IziPlus_Module_TempLimit(uint16_t level)
{
	uint16_t temp_master = intern_temp_master > ntc_temp_master ? ntc_temp_master : intern_temp_master;		// Take the lowest level
	//if(power_ch_master < temp_master)
	//	temp_master = power_ch_master;
	
	if(temp_master < TEMP_MAX_RESOLUTION)
		level = (level * temp_master)/TEMP_MAX_RESOLUTION;
	
	return level;
}

/*
 * 100 ms timer timed by OS. Do not call OS routines from here
 */
void IziPlus_Module_Timer100ms()
{
	if(++module_identify_prs >= 10)
		module_identify_prs = 0;
	if(overrule_time_chx > 0)
		overrule_time_chx--;
		
	if(module_reset_report > 0)
	{
		if(--module_reset_report == 0)
		{
			module_cpu_state.u.powerup = false;		// Clear reset cause
			module_cpu_state.u.extreset = false;
			module_cpu_state.u.brownout = false;
			module_cpu_state.u.sw_reset = false;
			module_cpu_state.u.watchdog = false;
			IziPlus_Module_Update();
		}
	}
	
	if(IziPlus_Module_TemperatureCelciusCheck(Adc_GetNtcRaw(), &ntc_temp_master,  max_ntc_temp_raw,  limit_ntc_temp_raw))
		State_SetWarning(STATE_WARNING_NTC1_HIGH);
	else
		State_ClearWarning(STATE_WARNING_NTC1_HIGH);
	
	if(IziPlus_Module_TemperatureCheck(Adc_GetTintRaw(), &intern_temp_master, max_intern_temp_raw, limit_intern_temp_raw))
		State_SetWarning(STATE_WARNING_TEMP_HIGH);
	else
		State_ClearWarning(STATE_WARNING_TEMP_HIGH);
	
	if(module_identify_time > 0)
	{
		if(--module_identify_time > 0)
		{
			if(module_identify_mode == IZIPLUS_IDENTMODE_BLINK)
			{
				if(module_identify_prs == 1)
					IziPlus_Module_Overrule_Ch1234(iziplus_fixdef.modes[appConfig->mode].indicate_lvl, 500, PRIO_OVERRULE_HIGH);
				else if(module_identify_prs == 6)
					IziPlus_Module_Overrule_Ch1234(0, 500, PRIO_OVERRULE_HIGH);
			}
			else if(module_identify_mode == IZIPLUS_IDENTMODE_SPOTON)
			{
				IziPlus_Module_Overrule_Ch1234(iziplus_fixdef.modes[appConfig->mode].indicate_lvl, 1000, PRIO_OVERRULE_HIGH);
			}
			else if(module_identify_mode == IZIPLUS_IDENTMODE_QUALITY)
			{
				for(int i = 0; i < iziplus_fixdef.max_channels; i++)
				{
					uint8_t level = (iziplus_data_comquality() * (uint8_t)(iziplus_fixdef.modes[appConfig->mode].indicate_lvl >> (i * 8))) / 100;
					IziPlus_Module_Overrule_Chx(i, level, 1000, PRIO_OVERRULE_HIGH);
				}
			}
		}
		else
		{
			IziPlus_Module_Overrule_Ch1234(0, 0, PRIO_OVERRULE_HIGH);
			module_cpu_state.u.identify = 0;
		}
	}
	if(++timer_prs >= 10)
	{
		appLogData->operating_sec++;
		for(int i = 0; i < iziplus_fixdef.max_channels; i++)
		{
			if(iziplus_level_chx[i])
			{
				appLogData->active_sec++;
				break;
			}
		}
		
		if(module_pup_time < (60 * 60))				// Keep the timer after power-up, clip at one hour
			module_pup_time++;
		timer_prs = 0;
	}
}

void IziPlus_Module_IdentifySync()
{
	module_identify_prs = 0;
}

bool IziPlus_Module_IsIdentifying()
{
	return (module_identify_time > 0);
}

bool IziPlus_Module_IsModeSwitching()
{
	return (module_mode_switch > 0);
}

iziplus_cpustate_u IziPlus_Module_GetCpuState()
{
	return module_cpu_state;
}

bool IziPlus_EmitterOk()
{
	return iziplus_emitter_state >= 0;
}


uint8_t *IziPlus_Module_GetMonitor()
{
	int8_t warning = State_GetHighestWarning();
	
	// Update vars here
	memset(module_monitor, 0, IZI_MAX_MONITOR);
	
	module_monitor[0] = (uint8_t)(Analog_GetSupplyVoltage()/1000);
	module_monitor[1] = iziplus_data_comquality();
	
	/*uint vout = 0;
	if(stepdown_ctrl_shared.per[0] > 0 && stepdown_ctrl_shared.per[0] > stepdown_ctrl_chx[0].ccx[0])
		vout = ((uint)stepdown_ctrl_shared.per[0] * Adc_GetVout()) / (uint)(stepdown_ctrl_shared.per[0] - stepdown_ctrl_chx[0].ccx[0]);
	*/
	module_monitor[2] = (2345*20)/1000;//(uint8_t)((stepdown_ctrl_shared.power * 20)/1000);
	//uint8_t temp_limit = intern_temp_master > ntc_temp_master ? (ntc_temp_master/(TEMP_MAX_RESOLUTION/100)) : (intern_temp_master/(TEMP_MAX_RESOLUTION/100));
	//uint8_t power_limit = State_IsWarningActive(STATE_WARNING_POWER1_HIGH) ? (100 * stepdown_ctrl_shared.dac_data_now) / stepdown_ctrl_shared.dac_data_now_org : 100;
	
	module_monitor[3] = 100;//power_limit < temp_limit ? power_limit : temp_limit;
	
	module_monitor[4] = Adc_GetTint();
	module_monitor[5] = Adc_GetNtc();
	module_monitor[6] = Adc_GetTintMax();
	module_monitor[7] = Adc_GetNtcMax();
	
	uint16_t operating_days = appLogData->operating_sec / (24*60*60/10);		// Per 10th of day
	module_monitor[8] = (uint8_t)(operating_days >> 0);
	module_monitor[9] = (uint8_t)(operating_days >> 8);
	
	uint16_t active_days_ch1 = appLogData->active_sec / (24*60*60/10);
	module_monitor[10] = (uint8_t)(active_days_ch1 >> 0);
	module_monitor[11] = (uint8_t)(active_days_ch1 >> 8);
	
	int8_t error = State_GetHighestError();
	uint8_t state = 0;
	if(error >= 0)
	{
		if(error == STATE_ERROR_VIN_LOW)
			state = 132;
		else if(error == STATE_ERROR_OUTPUT_SHORT)
			state = 136;
		else if(error == STATE_ERROR_VIN_LOW)
			state = 132;
		else if(error == STATE_ERROR_NO_EMITTER)
			state = iziplus_emitter_state == -2 ? 147 : 152;
		else if(error == STATE_ERROR_EMITTER_DATA)
			state = 153;
	}
	if(warning >= 0 && state == 0)
	{
		if(warning == STATE_WARNING_OUTPUT1_OPEN)
			state = 137;
		else if(warning == STATE_WARNING_TEMP_HIGH)
			state = 128;
		else if(warning == STATE_WARNING_NTC1_HIGH)
			state = 130;
		else if(warning == STATE_WARNING_SUPPLY_HIGH)
			state = 133;
		else if(warning == STATE_WARNING_BAD_COMQUAL)
			state = 148;
		else if(warning == STATE_WARNING_POWER1_HIGH)
			state = 145;
		else if(warning == STATE_WARNING_UART_OVW_WARN)
			state = 151;
	}
	module_monitor[12] = state;
	uint16_t vled = Adc_GetVout();
	module_monitor[13] = (uint8_t)(vled >> 0);
	module_monitor[14] = (uint8_t)(vled >> 8);
	return module_monitor;
}

void IziPlus_Module_SetIdentify(uint8_t mode, uint8_t time)
{
	// Todo: Handle all modes
	if(time > 0)
	{
		State_SetAttentionInfo(COLOR_MAGENTA, COLOR_BLUE, ((uint16_t)time * 60), 2);
		module_cpu_state.u.identify = 1;
		module_identify_time = ((uint16_t)time * 600);
		module_identify_mode = mode;
		module_identify_prs = 0;
	}
	else
	{
		State_ClearAttentionInfo();	
		module_cpu_state.u.identify = 0;
		module_identify_time = 1;
	}
}


__inline uint8_t IziPlus_Module_HasOutputMaster()
{
	return iziplus_fixdef.modes[appConfig->mode].master_chan >= 0;
	
}

__inline int8_t IziPlus_Module_OutputMasterChannel()
{
	return iziplus_fixdef.modes[appConfig->mode].master_chan;
	
}

__inline uint8_t IziPlus_Module_HasControl()
{
	return iziplus_fixdef.modes[appConfig->mode].control_chan >= 0 || (iziplus_fixdef.modes[appConfig->mode].flags & (MODE_FLASH_AUTO));
	
}

__inline int8_t IziPlus_Module_ControlChannel()
{
	return iziplus_fixdef.modes[appConfig->mode].control_chan;	
}

__inline uint8_t IziPlus_Module_HasTwChannel()
{
	return iziplus_fixdef.modes[appConfig->mode].tw_chan >= 0;
	
}

__inline int8_t IziPlus_Module_TwChannel()
{
	return iziplus_fixdef.modes[appConfig->mode].tw_chan;
}

__inline uint8_t IziPlus_Mode_IsRGBW()
{
	return module_mode == MODE_CTRL_RGBW;
}

__inline int8_t IziPlus_Module_OutputRgbwStartChannel()
{
	return iziplus_fixdef.modes[appConfig->mode].rgbw_chan;
}

__inline uint8_t IziPlus_Mode_UsesTable()
{
	return module_mode == MODE_CTRL_WD || module_mode == MODE_CTRL_TW;
}

__inline bool IziPlus_Mode_IsDirect()
{
	return module_mode == MODE_CTRL_DIRECT;
}

__inline uint8_t IziPlus_Module_IsWdSingle()
{
	return (iziplus_fixdef.modes[appConfig->mode].flags & (MODE_FLASH_WD_SINGLE)) ? 1 : 0;
}

__inline uint8_t IziPlus_Module_IsDirect()
{
	return (iziplus_fixdef.modes[appConfig->mode].flags & (MODE_FLASH_DIRECT)) ? 1 : 0;
}

__inline uint8_t IziPlus_Module_IsFirst16b()
{
	return (iziplus_fixdef.modes[appConfig->mode].flags & (MODE_FIRST_16B)) ? 1 : 0;
}

__inline uint8_t IziPlus_Module_IsAutoControl()
{
	return (iziplus_fixdef.modes[appConfig->mode].flags & (MODE_FLASH_AUTO)) ? 1 : 0;
}

__inline uint8_t IziPlus_Mode_IsWdSingle()
{
	return module_mode == MODE_CTRL_WD;
}

#define MODE_SWITCH_STABLE_TIME		180			// Per 10ms = 2.0 sec
#define MODE_SWITCH_SWITCH_TIME		(MODE_SWITCH_STABLE_TIME + 20)

static uint8_t mode_ctrl_prev;
static uint16_t mode_ctrl_stable;
static uint8_t mode_cct_last = 0;			// Some value it mostly not set to

uint8_t IzIPlus_GetModeFromLevel(uint8_t level)
{
	uint8_t mode = MODE_CTRL_UNKNOWN;
	if(level < 80)
		mode = MODE_CTRL_WD;
	else if(level >= 90 && level <= 160)
		mode = MODE_CTRL_TW;
	else if(level >= 170)
		mode = MODE_CTRL_RGBW;
		
	return mode;
}

uint8_t IziPlus_CheckMode()
{
	if(IziPlus_Module_HasControl())
	{
		uint8_t ctrl = 0;
		if(IziPlus_Module_IsAutoControl())
		{
			bool rgbw_on = false;
			for(int i = 0; i < 4; i++)	
			{
				if(Izi_OutputGet(IziPlus_Module_OutputRgbwStartChannel() + i) > 0)
				{
					rgbw_on = true;
					mode_cct_last = Izi_OutputGet(IziPlus_Module_TwChannel());
					break;
				}
			}
			if(!rgbw_on && module_mode == MODE_CTRL_RGBW && module_mode_switch == 0 && mode_cct_last == Izi_OutputGet(IziPlus_Module_TwChannel()))
				rgbw_on = true;												// Do not change until CCT is changed
			ctrl = rgbw_on ? 200 : 100;			// Set value of RGBW or TW
			if(rgbw_on && module_mode != MODE_CTRL_RGBW && module_mode_switch == 0)
				mode_ctrl_stable = MODE_SWITCH_STABLE_TIME - 1;
			else if(!rgbw_on && module_mode != MODE_CTRL_TW && module_mode_switch == 0)
				mode_ctrl_stable = MODE_SWITCH_STABLE_TIME - 1;
		}
		else
		{
			ctrl = Izi_OutputGet(IziPlus_Module_ControlChannel());
			if(iziplus_master_zero_time >= 100)								// At least one sec idle?
			{
				uint8_t mode = IzIPlus_GetModeFromLevel(ctrl);
				if(mode != MODE_CTRL_UNKNOWN && mode != module_mode)		// Mode changed?
				{
					mode_ctrl_prev = ctrl;									// Force direct switch of mode
					mode_ctrl_stable = MODE_SWITCH_SWITCH_TIME - 1;
				}
			}
		}
			
		if(ctrl == mode_ctrl_prev)
		{
			if(++mode_ctrl_stable == MODE_SWITCH_STABLE_TIME)				// Called every 10ms, so 2 second stable
			{
				uint8_t mode = IzIPlus_GetModeFromLevel(ctrl);
				if(mode != MODE_CTRL_UNKNOWN && mode != module_mode)
					module_mode_switch = 1;									// Indicate to go off (while switching)			
			}
			else if(mode_ctrl_stable == MODE_SWITCH_SWITCH_TIME)			// Called every 10ms, so 2.2 second stable
			{
				module_mode_switch = 0;
				uint8_t mode = IzIPlus_GetModeFromLevel(ctrl);
				if(mode != MODE_CTRL_UNKNOWN)
					module_mode = mode;
					
				mode_ctrl_stable--;						// Clip here
			}
		}
		else
			mode_ctrl_stable = 0;
			
		mode_ctrl_prev = ctrl;
	}
	else if(iziplus_fixdef.modes[appConfig->mode].rgbw_chan >= 0)
		module_mode = MODE_CTRL_RGBW;
	else if(IziPlus_Module_IsDirect())
		module_mode = MODE_CTRL_DIRECT;
	else if(IziPlus_Module_IsWdSingle())
		module_mode = MODE_CTRL_WD;
	else
		module_mode = MODE_CTRL_TW;
		
	return module_mode;
}

// chan_idx, indicates the index of the non patched dim channel, in case of an rgbw emitter: r = 0, g = 1, b = 2, w = 3
uint16_t IziPlus_Module_GetDim(uint8_t chan_idx)
{
	uint16_t level_chx;
	bool first = chan_idx == 0;
	uint8_t chan_idx_org = chan_idx;
	bool tunable_wd = true;
	uint8_t master = IziPlus_Module_HasOutputMaster();
	if(first)				// Only do it once per loop
		IziPlus_CheckMode();
	
	if(module_mode_switch || (module_pup_time < 3 && IziPlus_Module_HasControl()))		// If switching modes or if mode has control channel and it is less than 3 sec after power-up
	{
		return 0;
	}

	if(master)
	{
		if(IziPlus_Mode_IsRGBW())
		{
			chan_idx += IziPlus_Module_OutputRgbwStartChannel();
			tunable_wd = false;
		}
		else
		{
			chan_idx = IziPlus_Module_OutputMasterChannel();
		}
	}
	
	uint16_t lvl_ch_in = overrule_time_chx == 0 ? Izi_OutputGet(chan_idx) : overrule_level_chx[chan_idx_org];
	uint8_t master_level = 0;
	if(master)
	{
		master_level = Izi_OutputGet(IziPlus_Module_OutputMasterChannel());
		if(first)
		{
			if(master_level == 0)
			{
				if(iziplus_master_zero_time < 60000)
					iziplus_master_zero_time++;
			}
			else
				iziplus_master_zero_time = 0;
		}
	}

	if(master && !tunable_wd)					// Is there a master in this mode? If tunable/warm dimming don't use master
	{
		uint16_t lvl_master = overrule_time_chx == 0 ? master_level : 0xFF;				// If so, merge them. If overruled, set master to full
		if(lvl_master != 0xFF || lvl_ch_in != 0xFF)
			level_chx = lvl_master * lvl_ch_in;
		else
			level_chx = 0xFFFF;
	}
	else if(chan_idx == 0 && IziPlus_Module_IsFirst16b())
	{
		level_chx = (lvl_ch_in << 8) | Izi_OutputGet(chan_idx + 1);
	}
	else
		level_chx = (lvl_ch_in << 8) | lvl_ch_in;
	
	iziplus_level_chx[chan_idx_org] = level_chx;
	
	//if(chan_idx_org == 1)
	//	stepdown_ctrl_shared.test = level_chx;
	
	return level_chx;
}

uint16_t tw_channel_virtual = 0;
uint16_t dtj_store[MAX_EMITTER_MODES];
int8_t corrtemp_ovw_chan_idx = -1;
uint32_t corrtemp_ovw_val;

#define CONST_T		262UL

extern volatile stepdown_control_t stepdown_ctrl_chx[MAX_DIM_CHANNELS];

uint16_t IziPlus_Module_GetTable(uint8_t chan_idx, uint16_t val)
{
	if(IziPlus_Mode_UsesTable() && overrule_time_chx == 0)				// Check if table is used in current mode
	{
		uint16_t tw_chan;
		if(chan_idx == 0)
		{
			if(IziPlus_Mode_IsWdSingle())
			{
				tw_chan = ((uint32_t)val * (uint32_t)iziplus_fixdef.tw3000K) >> 8;
			}
			else
			{
				uint8_t data = CONFIG_CCT_COLOR_RANGE(appConfig->config) == 0 ? (Izi_OutputGet((IziPlus_Module_TwChannel())) * iziplus_fixdef.tw4000K)/256 : Izi_OutputGet(IziPlus_Module_TwChannel());
			
				int32_t tw_chan_goal = (data << 8) + data;
				tw_chan = Filter_LowPass(tw_channel_virtual, tw_chan_goal, stepdown_ctrl_chx[0].filter_shift);
				
				/*tw_chan = ((tw_chan_goal - (int32_t)tw_channel_virtual) / (int32_t)stepdown_ctrl_chx[0].filter_shift) + (int32_t)tw_channel_virtual;		// TODO: if in dynamic, and only Tunable is changed fast it won't be fast (when level fast is also changed it will be ok)
				if(tw_chan == tw_channel_virtual && tw_chan_goal != tw_chan)		// Make sure if last delta is divided to 0, that the real level is still reached in steps of 1
				{
					if(tw_chan_goal > tw_chan)
						tw_chan++;
					else
						tw_chan--;
				}
				tw_channel_virtual = tw_chan;*/
			}
			tw_channel_virtual = tw_chan;
		}
		else
			tw_chan = tw_channel_virtual;
			
		uint16_t tw = tw_chan / 4096;
		uint16_t tw_offset = tw_chan - (tw * 4096);
		
		uint8_t tw_val = ColorTables[chan_idx][tw];
		uint8_t tw_val_next = ColorTables[chan_idx][tw + 1];
		if(tw_val <= tw_val_next)
			val = (((tw_val << 8) + (((tw_val_next - tw_val) * (tw_offset >> 4)))) * val) >> 16;// * (val))/256L;
		else
			val = (((tw_val << 8) - (((tw_val - tw_val_next) * (tw_offset >> 4)))) * val) >> 16;// * (val))/256L;
					
		if(!IziPlus_Mode_IsWdSingle())
			val = (val * iziplus_fixdef.tw_gain)/100;			// Limit so 10W is never reached
		else
			val = (val * iziplus_fixdef.wd_gain)/100;
	}	
	else if(!IziPlus_Mode_IsDirect())
	{
		val = ((uint32_t)val * (uint32_t)iziplus_fixdef.rgbw_sensitivity[chan_idx]) / 256;
	}
	//if(chan_idx == 0)
	//	stepdown_ctrl_shared.test = val;
		
	stepdown_ctrl_chx[chan_idx].level_curve_raw = stepdown_ctrl_chx[chan_idx].level_curve;			// Store here without limitations
	
	uint8_t max_output = CONFIG_MAX_OUTPUT(appConfig->config);		// Check if max output is configured reduced
	if(max_output < 100)
		val = (val * max_output)/100;								// Less than 100%, scale it
	
	// TODO
	/*uint16_t temp = Adc_GetNtcRaw();
	if(temp >= (25 * AT30TSE_MUL))				// Temperature corrections
	{
		int16_t corr_temp = iziplus_fixdef.corr_temp_tables[chan_idx];
		if(corr_temp != 0)				// Any correction on this channel?
		{
			uint16_t corr_tjc = iziplus_fixdef.corr_tjc_tables[chan_idx];
			uint16_t dtj = corr_tjc > 0 ? (temp + ((((((stepdown_ctrl_shared.imax_avg * stepdown_ctrl_chx[chan_idx].dac_data_now * CONST_T) >> 16) * stepdown_ctrl_chx[chan_idx].level_curve_correct_prev) >> 16) * corr_tjc) >> 17)) - (25 * AT30TSE_MUL) : (temp - (25 * AT30TSE_MUL) );
			dtj = Filter_LowPass(dtj_store[chan_idx], dtj, 3);
			
			uint32_t calc = corr_temp > 0 ? (val + ((uint64_t)(((uint64_t)dtj * (uint64_t)corr_temp) * (uint64_t)val) >> 17)) :  (val - ((uint64_t)(((uint64_t)dtj * (uint64_t)abs(corr_temp)) * (uint64_t)val) >> 17));
			if(calc > 0xFFFF)							// Check for overflow
			{
				corrtemp_ovw_val = calc;				// Store overflow calculation, to reduce other channels
				corrtemp_ovw_chan_idx = chan_idx;		// Set chan idx that causes overflow
				calc = 0xFFFF;							// Clip at 65535
			}
			else if(corrtemp_ovw_chan_idx == chan_idx)	// Overflowing channels ok now?
				chan_idx = -1;							// Stop reducing other channels
			val = calc;									// Store calculated value
			
			dtj_store[chan_idx] = dtj;					// Store value for filter
		}
		if(corrtemp_ovw_chan_idx >= 0 && corrtemp_ovw_chan_idx != chan_idx && corrtemp_ovw_val > 0)
		{
			val = ((uint32_t)val << 16) / corrtemp_ovw_val;
		}
	}*/
	return val;
}

uint8_t IziPlus_Module_GetChannelAmount()
{
	return module_channels_amount;
}

uint8_t IziPlus_Module_GetChannelAmountTemp()
{
	if(appConfig->mode < MODE_AMOUNT)
		return iziplus_fixdef.modes[appConfig->mode].channels;
	return module_channels_amount;
}

uint8_t IziPlus_Module_GetHwRevision()
{
	return get_hw_id();			
}

uint8_t IziPlus_Module_GetVariant()
{
	return get_device_id();			
}

izi_versionplus_u IziPlus_Module_GetAppVersion()
{
	izi_versionplus_u appversion = { .v.major = firmare_info.version.v.major, .v.minor = firmare_info.version.v.minor, .v.build = firmare_info.version.v.build };
	return appversion;			
}

izi_versionplus_u IziPlus_Module_GetBootVersion()
{
	version_u *boot_version = (version_u *)BOOT_VERSION_ADDRESS;
	izi_versionplus_u bootversion = { .v.major = boot_version->v.major, .v.minor = boot_version->v.minor, .v.build = boot_version->v.build };
	return bootversion;			
}

izi_versionplus_u IziPlus_Module_GetImageVersion()
{
	firmware_t *image_info = (firmware_t *)(FLASH_APP_MIRROR_END - FLASH_APP_FW_INFO_SIZE - FLASH_APP_MIRROR_SHIFT);
	izi_versionplus_u imageversion = { .v.major = image_info->version.v.major, .v.minor = image_info->version.v.minor, .v.build = image_info->version.v.build };
	return imageversion;
}

izi_version_u IziPlus_Module_GetTypedefVersion()
{
	izi_version_u typedefversion = { .v.major = 2, .v.minor = 2 };
	return typedefversion;			// Min version of TDE file
}

izi_version_u IziPlus_Module_GetLedtableVersion()
{
	izi_version_u ledtableversion = { .v.major = iziplus_fixdef.version >> 5, .v.minor = iziplus_fixdef.version & 0x1F };
	return ledtableversion;			// Todo: real led table version
}

uint8_t IziPlus_Module_GetMemoryVersion()
{
	return CONFIG_VERSION;		
}

bool IziPlus_Module_IsOverruled()
{
	return overrule_time_chx > 0;
}

bool IziPlus_Module_Test(uint8_t idx, uint32_t time, uint8_t prio)
{
	IziPlus_Module_Overrule_Ch1234(iziplus_fixdef.test_lvls[idx], time, prio);
	idx++;
	if(idx >= iziplus_fixdef.max_channels || iziplus_fixdef.test_lvls[idx] == 0)
		return true;
	return false;
}

void IziPlus_Module_Overrule_Chx(uint8_t chan_idx, uint8_t level, uint32_t time, uint8_t prio)
{
	if(prio >= overrule_prio_chx || overrule_time_chx == 0)
	{
		overrule_prio_chx = prio;
		overrule_level_chx[chan_idx] = level;
		overrule_time_chx = time / 100;
		
		//OS_TRACE_ERROR("Overrule channel[%d]: l:%d p:%d t:%d\r\n", chan_idx, level, prio, time);
	}
}

void IziPlus_Module_Overrule_Ch1234(uint32_t dim1234, uint32_t time, uint8_t prio)
{
	if(prio >= overrule_prio_chx || overrule_time_chx == 0)
	{
		overrule_prio_chx = prio;
		for(int i = 0; i < iziplus_fixdef.max_channels; i++)
			overrule_level_chx[i] = (uint8_t)(dim1234 >> (i * 8));
		overrule_time_chx = time / 100;
		//OS_TRACE_ERROR("Overrule channel1234: l:%d p:%d t:%d\r\n", dim1234, prio, time);
	}
}

void IziPlus_NoComCheck()
{
	bool isok = IziPlus_LightDataOk();
	if(!isok)
	{
		if(xTaskGetTickCount() < 5000)				// Do nothing if shorter than 5 sec after power-up (should not go on during discover)
			return;
		if(isok != iziplus_last_comcheck)
		{
			for(int i = 0; i < iziplus_fixdef.max_channels; i++)
				overrule_level_chx[i] = iziplus_level_chx[i];
		}
		if((iziplus_data_wasok && (DMXFAIL_OPERATE(appConfig->dmxfail) == DMXFAIL_MAX)) || (!iziplus_data_wasok && (DMXFAIL_PUP(appConfig->dmxfail) == DMXFAIL_MAX)))
		{
			for(int i = 0; i < iziplus_fixdef.max_channels; i++)
			{
				uint8_t level = (uint8_t)(iziplus_fixdef.modes[appConfig->mode].indicate_lvl >> (i * 8));
				if(iziplus_prs_comcheck == 0)
					IziPlus_Module_Overrule_Chx(i, overrule_level_chx[i] < level ? overrule_level_chx[i] + 1 : overrule_level_chx[i], 1000, PRIO_OVERRULE_LOWEST);
			}
		}
		else if((iziplus_data_wasok && (DMXFAIL_OPERATE(appConfig->dmxfail) == DMXFAIL_OFF)) || (!iziplus_data_wasok && (DMXFAIL_PUP(appConfig->dmxfail) == DMXFAIL_OFF)))
		{
			for(int i = 0; i < iziplus_fixdef.max_channels; i++)
			{
				if(iziplus_prs_comcheck == 0)
					IziPlus_Module_Overrule_Chx(i, overrule_level_chx[i] > 0 ? overrule_level_chx[i] - 1 : 0, 1000, PRIO_OVERRULE_LOWEST);
			}
		}
		
		if(++iziplus_prs_comcheck >= 2)
			iziplus_prs_comcheck = 0;
	}
	else if(isok != iziplus_last_comcheck)
	{
		IziPlus_Module_Overrule_Ch1234(0, 0, PRIO_OVERRULE_LOWEST);
	}
	else
		iziplus_data_wasok = true;			// Mark it has been ok once since power-up, and so DMXFAIL_OPERATE should be used
	
	iziplus_last_comcheck = isok;
}