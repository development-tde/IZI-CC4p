/*
 * izi_input.c
 *
 *  Created on: 8 apr. 2021
 *      Author: Milo
 */

#include "includes.h"
#include "izi_input.h"
#include "appconfig.h"
//#include "izican/izi_can_slave.h"
#include "iziplus_driver.h"

// Defines
#define TIME_SEC					40
#define TIME_START_DISCOVER_RP		2			// In seconds
#define TIME_WINDOW_DISCOVER_RP		2
#define TIME_START_DISCOVER_CL		8			// In seconds
#define TIME_WINDOW_DISCOVER_CL		2
#define TIME_START_FACTORY_DFLT		20
#define TIME_WINDOW_FACTORY_DFLT	2
#define TIME_CLICK					(TIME_SEC/2)
#define TIME_CLIP_DEBOUNCE			2400		// 40 * 60 = 1 minute
#define TIME_HANDLED_DEBOUNCE		(TIME_CLIP_DEBOUNCE + 1)

// Globals
trace_level_t izi_input_trace_lvl = IZI_INPUT_DFLT_TRACE_LVL;

static uint16_t iziinput_switchdbc = 0;
static uint16_t iziinput_switchoffdbc = 0;
static uint16_t iziinput_switchclicks = 0;
static bool iziinput_switchactive = false;
static char text[LOG_TEXT_SIZE + 8];

TimerHandle_t  xIziInput_Timer = NULL;

// Proto
void IziInput_25ms(TimerHandle_t xTimer);

// Code

void IziInput_Init()
{
	if(xIziInput_Timer == NULL)
		xIziInput_Timer = xTimerCreate("Izi_InputTmr", IZI_TIMEROS_TICKS, pdTRUE, ( void * ) 0, IziInput_25ms);

	if(xIziInput_Timer == NULL)
	{
		IZI_INPUT_TRACE_INFO("Timer not created Izi preset");	// Todo: what to do
	}
	else if( xTimerStart(xIziInput_Timer, 0) != pdPASS )
	{
		IZI_INPUT_TRACE_INFO("Timer not started Izi preset\r\n");				// Todo: what to do
	}
}

void IziInput_25ms(TimerHandle_t xTimer)
{
	if(gpio_get_pin_level(SWITCH) == 0) 
	{
		if(iziinput_switchdbc < TIME_CLIP_DEBOUNCE)	// Clip at on minute
			iziinput_switchdbc++;
		if(iziinput_switchdbc == TIME_SEC/10)		// 100ms active
		{
			iziinput_switchactive = true;
			IZI_INPUT_TRACE_INFO("Switch active\r\n");
		}
		else if(iziinput_switchdbc == TIME_START_DISCOVER_RP*TIME_SEC)		// All active off option
			State_SetAttentionInfo(COLOR_AQUA, COLOR_YELLOW, TIME_WINDOW_DISCOVER_RP, 2);
		else if(iziinput_switchdbc == TIME_START_DISCOVER_CL*TIME_SEC)		// All active off option
			State_SetAttentionInfo(COLOR_WHITE, COLOR_YELLOW, TIME_WINDOW_DISCOVER_RP, 2);
		else if(iziinput_switchdbc == TIME_START_FACTORY_DFLT*TIME_SEC)	// Factory default
			State_SetAttentionInfo(COLOR_WHITE, COLOR_RED, TIME_WINDOW_FACTORY_DFLT, 2);

		iziinput_switchoffdbc = 0;
	}
	else if(++iziinput_switchoffdbc >= 2 && iziinput_switchactive)		// Accept one low before resetting debounce, and handle switch functions
	{
		if(iziinput_switchdbc > TIME_CLICK)
		{
			if(iziinput_switchdbc < TIME_HANDLED_DEBOUNCE)
			{
				sprintf(text, "Switch active (press time %d ms)", iziinput_switchdbc * (1000/TIME_SEC));
			}
			else
				sprintf(text, "Switch active and reported handled");
			LOGWRITE_INFO(ERRCODE_SWITCH_ACTIVE, text, log_src_task_postpone);
		}
		else
			iziinput_switchclicks++;

		if((iziinput_switchdbc >= (TIME_START_DISCOVER_RP*TIME_SEC)) && (iziinput_switchdbc <= ((TIME_START_DISCOVER_RP + TIME_WINDOW_DISCOVER_RP)*TIME_SEC)))
		{
			uint8_t clear;
			//if(IziPlus_DiscoverStart(IZIPLUS_OPTION_REPLACE, 0xFF, 0xFF, &clear) < 0)
				State_SetAttentionInfo(COLOR_RED, COLOR_RED, 2, 1);
		}
		else if((iziinput_switchdbc >= (TIME_START_DISCOVER_CL*TIME_SEC)) && (iziinput_switchdbc <= ((TIME_START_DISCOVER_CL + TIME_WINDOW_DISCOVER_RP)*TIME_SEC)))
		{
			uint8_t clear;
			//if(IziPlus_DiscoverStart(IZIPLUS_OPTION_CLEAN, 0xFF, 0xFF, &clear) < 0)
				State_SetAttentionInfo(COLOR_RED, COLOR_RED, 2, 1);
		}
		else if((iziinput_switchdbc >= (TIME_START_FACTORY_DFLT*TIME_SEC)) && (iziinput_switchdbc <= ((TIME_START_FACTORY_DFLT + TIME_WINDOW_FACTORY_DFLT)*TIME_SEC)))
		{
			AppConfig_Default();
			LOGWRITE_WARNING(ERRCODE_FACTORY_DEFAULT, "Factory default", log_src_task);
			vTaskDelay(500);				// Give some time to respond
			NVIC_SystemReset();
		}
		iziinput_switchactive = false;
		iziinput_switchdbc = 0;
	}
	else if(!iziinput_switchactive)
	{
		iziinput_switchdbc = 0;
		if(iziinput_switchoffdbc < (TIME_SEC*60))
			iziinput_switchoffdbc++;

		if(iziinput_switchoffdbc > (TIME_SEC/2))
		{
			if(iziinput_switchclicks > 0)
			{
				/*if(iziinput_switchclicks == 3)
				{
					//Do things on 3 clicks
					appconfig_t *cfgram = AppConfig_Get();
					if(cfgram->transparent_mode != 0xAA)
					{
						cfgram->transparent_mode = 0xAA;
						State_SetAttentionInfo(COLOR_AQUA, COLOR_RED, 5, 1);
					}
					else
					{
						cfgram->transparent_mode = 0;
						State_SetAttentionInfo(COLOR_AQUA, COLOR_YELLOW, 5, 1);
					}
					AppConfig_Set();
				}
				else if(iziinput_switchclicks == 2)
				{
					//Do things on 2 clicks
					appconfig_t *cfgram = AppConfig_Get();
					if(cfgram->transparent_mode != 0x55)
					{
						cfgram->transparent_mode = 0x55;
						State_SetAttentionInfo(COLOR_AQUA, COLOR_AQUA, 5, 1);
					}
					else
					{
						cfgram->transparent_mode = 0;
						State_SetAttentionInfo(COLOR_AQUA, COLOR_YELLOW, 5, 1);
					}
					AppConfig_Set();
				}
				if(iziinput_switchclicks == 4)
				{
					//Do things on 4 clicks
					appconfig_t *cfgram = AppConfig_Get();
					if(cfgram->transparent_mode != 0x44)
					{
						cfgram->transparent_mode = 0x44;
						State_SetAttentionInfo(COLOR_ORANGE, COLOR_RED, 5, 1);
					}
					else
					{
						cfgram->transparent_mode = 0;
						State_SetAttentionInfo(COLOR_AQUA, COLOR_ORANGE, 5, 1);
					}
					AppConfig_Set();
				}
				else */
				{
					//Do things on 1 click
					
				}
				sprintf(text, "Switch active %d clicks", iziinput_switchclicks);
				LOGWRITE_INFO(ERRCODE_SWITCH_ACTIVE, text, log_src_task_postpone);
				iziinput_switchclicks = 0;
			}
		}
	}
}

