#include <atmel_start.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	FREERTOS_V1000_0_example();
	/* Replace with your application code */
	while (1) {
		if(gpio_get_pin_level(USER_BUTTON) == 0)
		{
			gpio_set_pin_level(USER_LED, false);		
		}
		else
		{
			gpio_set_pin_level(USER_LED, true);
			continue;
		}
		CAN_0_example();
	}
}
