/*
 * izi_can_driver.c
 *
 *  Created on: 29 jun. 2020
 *      Author: Milo
 */

#include "includes.h"
#include "izi_can_driver.h"
#include "izi_can_frame.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define TASK_IZICAN_STACK_SIZE (384)
#define TASK_IZICAN_MASTER_STACK_SIZE (1536)			// It is 6k, because the master can call the file system and that can add more than 4k to the stack

#define TASK_IZICAN_TASK_PRIORITY (tskIDLE_PRIORITY + 4)

#ifndef SLAVE_DEVTYPE_GROUP
#define SLAVE_DEVTYPE_GROUP 	DEVTYPE_GROUP_POWERLINE
#endif

#define USE_CANFD (1U)
/*
 *    CAN_DATASIZE   DLC    BYTES_IN_MB
 *    8              8      kMCAN_8ByteDatafield
 *    12             9      kMCAN_12ByteDatafield
 *    16             10     kMCAN_16ByteDatafield
 *    20             11     kMCAN_20ByteDatafield
 *    24             12     kMCAN_24ByteDatafield
 *    32             13     kMCAN_32ByteDatafield
 *    48             14     kMCAN_48ByteDatafield
 *    64             15     kMCAN_64ByteDatafield
 *
 *  CAN data size (pay load size), DLC and Bytes in Message buffer must align.
 *
 */
#define DLC (15)
#define BYTES_IN_MB kMCAN_64ByteDatafield

/* If user need to auto execute the improved timing configuration. */
#define USE_IMPROVED_TIMING_CONFIG (1U)
#if USE_CAN == 1
#define IZI_CAN_MCAN_IRQHandler CAN1_IRQ0_IRQHandler
#define IZI_CAN_MCAN_IRQn 		CAN1_IRQ0_IRQn
#define IZI_CAN_MCAN 			CAN1
#define IZI_CAN_PRIO 			CAN1_IRQ0_IRQn
#define IZI_CAN_CLOCK 			kCLOCK_DivCan1Clk
#if IZI_CAN_MASTER == 1
#define IZI_CAN_CLOCK_DIV		11U		// 220/11=20
#elif IZI_CAN_SLAVE_MHZ == 220
#define IZI_CAN_CLOCK_DIV		11U		// 220/11=20
#else
#define IZI_CAN_CLOCK_DIV		9U		// 180/9=20
#endif
#define MCAN_CLK_FREQ 			CLOCK_GetMCanClkFreq(1U)
#else
#define IZI_CAN_MCAN_IRQHandler CAN0_IRQ0_IRQHandler
#define IZI_CAN_MCAN_IRQn 		CAN0_IRQ0_IRQn
#define IZI_CAN_MCAN 			CAN0
#define IZI_CAN_PRIO 			CAN0_IRQ0_IRQn
#define IZI_CAN_CLOCK 			kCLOCK_DivCan0Clk
#if IZI_CAN_MASTER == 1
#define IZI_CAN_CLOCK_DIV		11U		// 220/11=20
#else
#define IZI_CAN_CLOCK_DIV		9U		// 180/9=20
#endif
#define MCAN_CLK_FREQ 			CLOCK_GetMCanClkFreq(0U)
#endif

#define MSG_RAM_BASE (uint32_t)izi_can_msgram

// STD filter element = 4 bytes
// EXT filter element = 8 bytes

// Size of single buffer is '64 (MAX_LENGTH_SINGLE) + 8 (id+len etc)' = 72 bytes
// When set this is /4 -> 0x12

#define STD_FILTER_OFS 		0x00
#define STD_FILTER_AMOUNT 	0x00U		// Not all used, reserved space
#define STD_FILTER_SIZE		0x04

#define EXT_FILTER_OFS 		(STD_FILTER_OFS + (STD_FILTER_AMOUNT * STD_FILTER_SIZE))
#define EXT_FILTER_AMOUNT 	0x04U		// Not all used, reserved space
#define EXT_FILTER_SIZE 	0x08

#define RX_FIFO0_OFS 		(EXT_FILTER_OFS + (EXT_FILTER_AMOUNT * EXT_FILTER_SIZE))
#define RX_FIFO0_AMOUNT 	0x20U		// Max 64
#define RX_FIFO0_SIZE 		0x48

#define RX_FIFO1_OFS 		(RX_FIFO0_OFS + (RX_FIFO0_AMOUNT * RX_FIFO0_SIZE))
#define RX_FIFO1_AMOUNT 	0x00U			// Tried to use it, but did not work out of the box
#define RX_FIFO1_SIZE 		0x48

// RX buffers
// Tx event fifo

#define TX_BUFFER_OFS 		(RX_FIFO1_OFS + (RX_FIFO1_AMOUNT * RX_FIFO1_SIZE))
#define TX_BUFFER_AMOUNT	0x10U
#define TX_BUFFER_SIZE 		0x48

#define END_DATARAM			(TX_BUFFER_OFS + (TX_BUFFER_AMOUNT * TX_BUFFER_SIZE))

#if	IZI_CAN_MASTER > 0
#define FIRST_STD_TX_BUFFER	0			// DMX has higher prio (so get buffers from 0)
#define MAX_STD_TX_BUFFER	8
#define FIRST_EXT_TX_BUFFER	8
#define MAX_EXT_TX_BUFFER	TX_BUFFER_AMOUNT
#else
#define FIRST_EXT_TX_BUFFER	0
#define MAX_EXT_TX_BUFFER	TX_BUFFER_AMOUNT
#endif

#define IZICAN_REQ_TO	150
/*******************************************************************************
 * Variables
 ******************************************************************************/
static uint32_t izican_req_timeout = IZICAN_REQ_TO;
static TaskHandle_t		xIziCan_Task;
static SemaphoreHandle_t xIziCan_Semaphore = NULL;

volatile bool txComplete = false;
volatile izi_can_errflags_u izi_can_err = {0};
volatile bool rxComplete = false;
mcan_rx_buffer_frame_t rxFrame;
mcan_handle_t mcanHandle;
mcan_fifo_transfer_t rxXfer;

__DATA(SRAMX_CAN) uint8_t izi_can_msgram[END_DATARAM];		// Set to the last used tx buffer used (according to datasheet max 4352 * 4)

#ifdef IZI_CAN_DFLT_TRACE_LVL
trace_level_t izi_can_trace_lvl = IZI_CAN_DFLT_TRACE_LVL;
#else
trace_level_t izi_can_trace_lvl = TRACE_LEVEL_INFO;
#endif

mcan_config_t mcanConfig;
mcan_frame_filter_config_t rxFilter;
mcan_frame_filter_config_t rxExtFilter;
mcan_std_filter_element_config_t stdFilter;
mcan_ext_filter_element_config_t extFilter;
mcan_rx_fifo_config_t rxFifo0;
mcan_rx_fifo_config_t rxFifo1;
mcan_tx_buffer_config_t txBuffer;
uint8_t numMessage = 0;

static bool izi_can_init = false;
static uint8_t izi_can_address, izi_can_seqid;
#if IZI_CAN_MASTER == 1
static uint8_t izi_can_chan_seqid;
#endif
static izi_can_receive_callback_t izi_can_receive_callback;
static izi_can_receive_int_callback_t izi_can_receive_int_callback;

izi_can_rxframe_t volatile izi_can_rxframe;
izi_can_rxframe_t izi_can_receive_process;
#define IZICAN_MSGPOOL_SIZE (sizeof(izi_can_rxframe_t) * (RX_FIFO0_AMOUNT + RX_FIFO1_AMOUNT))
#define IZICAN_MULTI_BUFFERS	4

/* Defines the memory that will actually hold the messages within the message
buffer.  Should be one more than the value passed in the xBufferSizeBytes
parameter. */
#if IZI_CAN_STATICPOOL == 1
__NOINIT(BOARD_SDRAM) 	static uint8_t izi_can_msgpool[IZICAN_MSGPOOL_SIZE];
__NOINIT(BOARD_SDRAM) 	static StaticMessageBuffer_t izi_can_msgbuffer;
__NOINIT(BOARD_SDRAM) 	static MessageBufferHandle_t izi_can_msgbfrhandle;
__NOINIT(BOARD_SDRAM)  izi_can_rxframe_t izi_can_rxframe_multi[IZICAN_MULTI_BUFFERS];
#else
static 	MessageBufferHandle_t izi_can_msgbfrhandle;
		izi_can_rxframe_t izi_can_rxframe_multi[IZICAN_MULTI_BUFFERS];
#endif

static izi_can_extid_u req_extid, rsp_extid;
static izican_response_data_t *rsp_data;
static volatile uint8_t izican_busoff_retry = 0;
static bool izican_busoff = false;

// Proto
void izican_process_rx(izi_can_rxframe_t *frame);

/*******************************************************************************
 * Code
 ******************************************************************************/

void CAN_tx_callback(struct can_async_descriptor *const descr)
{
	(void)descr;
	
	//if(MCAN_TransferUpdate(IZI_CAN_MCAN, &mcanHandle) == kStatus_MCAN_TxIdle)
	txComplete = true;
	izican_busoff_retry = 0;
}

void CAN_err_callback(struct can_async_descriptor *const descr, enum can_async_interrupt_type type)
{
	if(type == CAN_IRQ_BO)
		izi_can_err.flags.bus_err = 1;
	else if(type == CAN_IRQ_DO)
		izi_can_err.flags.fifo_full = 1;
	// izi_can_err.flags.fifo_lost = 1;
	// izi_can_err.flags.unhandled_int = 1;
}

void CAN_rx_callback(struct can_async_descriptor *const descr)
{
	struct can_message msg;
	uint8_t            data[64];
	msg.data = data;
	can_async_read(descr, &msg);
	
	if(izi_can_receive_int_callback == NULL || !izi_can_receive_int_callback(msg))
	{
		izi_can_rxframe.length = msg.len;
		izi_can_rxframe.id = msg.id;
		izi_can_rxframe.flags.xtd = msg.fmt == CAN_FMT_EXTID;		// 11 or 29
		memcpy((void *)izi_can_rxframe.data, (void *)msg.data, izi_can_rxframe.length);

		TickType_t ticks = xTaskGetTickCountFromISR();
		izi_can_rxframe.ticks = ticks;

		BaseType_t xHigherPriorityTaskWoken = pdTRUE;
		size_t xBytesSent = xMessageBufferSendFromISR( izi_can_msgbfrhandle,
		(void *) &izi_can_rxframe,
		sizeof(izi_can_rxframe),
		&xHigherPriorityTaskWoken);

		if(xBytesSent != sizeof(izi_can_rxframe))
		{
			;				// Buffer full
		}
	}
}

struct can_async_descriptor CAN_BUS;

// Set izi_can_master and izi_can_address before calling function
void izican_driver_reset(void)
{
	izi_can_init = false;

	can_async_deinit(&CAN_BUS);

	hri_mclk_set_AHBMASK_CAN0_bit(MCLK);
	hri_gclk_write_PCHCTRL_reg(GCLK, CAN0_GCLK_ID, CONF_GCLK_CAN0_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
	can_async_init(&CAN_BUS, CAN0);
	
	gpio_set_pin_function(PA23, PINMUX_PA23I_CAN0_RX);

	gpio_set_pin_function(PA22, PINMUX_PA22I_CAN0_TX);

	can_async_register_callback(&CAN_BUS, CAN_ASYNC_IRQ_CB, (FUNC_PTR)CAN_err_callback);
	can_async_register_callback(&CAN_BUS, CAN_ASYNC_TX_CB, (FUNC_PTR)CAN_tx_callback);
	can_async_register_callback(&CAN_BUS, CAN_ASYNC_RX_CB, (FUNC_PTR)CAN_rx_callback);
	
	can_async_enable(&CAN_BUS);

	filter.id   = 0x469;
	filter.mask = 0;
	can_async_set_filter(&CAN_BUS, 0, CAN_FMT_STDID, &filter);

	filter.id   = 0x10000096;
	filter.mask = 0;
	can_async_set_filter(&CAN_BUS, 1, CAN_FMT_EXTID, &filter);

	NVIC_SetPriority(IZI_CAN_PRIO, 6);

#if STD_FILTER_AMOUNT > 0
	/* STD filter config. */
	rxFilter.address  = STD_FILTER_OFS;
	rxFilter.idFormat = kMCAN_FrameIDStandard;
	rxFilter.listSize = STD_FILTER_AMOUNT;
	rxFilter.nmFrame  = kMCAN_reject0;
	rxFilter.remFrame = kMCAN_rejectFrame;
	MCAN_SetFilterConfig(IZI_CAN_MCAN, &rxFilter);

	stdFilter.sfec = kMCAN_storeinFifo0;
	/* Classic filter mode, only filter matching ID. */
	stdFilter.sft   = kMCAN_classic;
	stdFilter.sfid1 = rxIdentifier;
	stdFilter.sfid2 = 0x7FFU;
	MCAN_SetSTDFilterElement(IZI_CAN_MCAN, &rxFilter, &stdFilter, 0);
#endif

	/* RX fifo0 config. */
	rxFifo0.address       = RX_FIFO0_OFS;
	rxFifo0.elementSize   = RX_FIFO0_AMOUNT;
	rxFifo0.watermark     = 0;
	rxFifo0.opmode        = kMCAN_FifoBlocking;
	rxFifo0.datafieldSize = kMCAN_8ByteDatafield;
#if (defined(USE_CANFD) && USE_CANFD)
	rxFifo0.datafieldSize = BYTES_IN_MB;
#endif
	MCAN_SetRxFifo0Config(IZI_CAN_MCAN, &rxFifo0);

	/* Ext filter config. */
	rxExtFilter.address  = EXT_FILTER_OFS;
	rxExtFilter.idFormat = kMCAN_FrameIDExtend;
	rxExtFilter.listSize = EXT_FILTER_AMOUNT;
	rxExtFilter.nmFrame  = kMCAN_reject0;
	rxExtFilter.remFrame = kMCAN_rejectFrame;
	MCAN_SetFilterConfig(IZI_CAN_MCAN, &rxExtFilter);

#if IZI_CAN_MASTER == 1
	const izi_can_extid_u master_mask = { .bit.dir = 1, .bit.master_id = 1 };		// Only filter on to master and our master id
	izi_can_extid_u master_id =   { .bit.dir = 1, .bit.master_id = izi_can_address > 0 ? 1 : 0 };

// First filter configuration
	extFilter.efid1 = master_id.all;
	extFilter.efec = kMCAN_storeinFifo0;
	extFilter.efid2 = master_mask.all;
	extFilter.eft = kMCAN_classic;
	MCAN_SetEXTFilterElement(IZI_CAN_MCAN, &rxExtFilter, &extFilter, 0);
#else
	const izi_can_extid_u slave_mask = { .bit.dir = 1, .bit.address = 0x3F, .bit.devtype_group = 0x0F };		// Filter on address, group and direction to slave

	// Unicast
	izi_can_extid_u slave_id =   { .bit.dir = 0, .bit.address = izi_can_address, .bit.devtype_group = SLAVE_DEVTYPE_GROUP };	// Filter on own address

	// First filter configuration
	extFilter.efid1 = slave_id.all;
	extFilter.efec = kMCAN_storeinFifo0;
	extFilter.efid2 = slave_mask.all;
	extFilter.eft = kMCAN_classic;
	MCAN_SetEXTFilterElement(IZI_CAN_MCAN, &rxExtFilter, &extFilter, 0);

	// Groupcast
	izi_can_extid_u slave_id_gc =   { .bit.dir = 0, .bit.address = ADDRESS_GROUPCAST, .bit.devtype_group = SLAVE_DEVTYPE_GROUP };	// Filter on groupcast address

	//Second filter configuration
	extFilter.efid1 = slave_id_gc.all;
	extFilter.efec = kMCAN_storeinFifo0;
	extFilter.efid2 = slave_mask.all;
	extFilter.eft = kMCAN_classic;
	MCAN_SetEXTFilterElement(IZI_CAN_MCAN, &rxExtFilter, &extFilter, 1);

	// Broadcast
	izi_can_extid_u slave_id_bc =   { .bit.dir = 0, .bit.address = ADDRESS_BROADCAST, .bit.devtype_group = DEVTYPE_BROADCAST };	// Filter on groupcast address

	//Third filter configuration
	extFilter.efid1 = slave_id_bc.all;
	extFilter.efec = kMCAN_storeinFifo0;
	extFilter.efid2 = slave_mask.all;
	extFilter.eft = kMCAN_classic;
	MCAN_SetEXTFilterElement(IZI_CAN_MCAN, &rxExtFilter, &extFilter, 2);
#endif
#if RX_FIFO1_AMOUNT > 0
	/* RX fifo1 config. */
	rxFifo1.address       = RX_FIFO1_OFS;
	rxFifo1.elementSize   = RX_FIFO1_AMOUNT;
	rxFifo1.watermark     = 0;
	rxFifo1.opmode        = kMCAN_FifoBlocking;
	rxFifo1.datafieldSize = kMCAN_8ByteDatafield;
#if (defined(USE_CANFD) && USE_CANFD)
	rxFifo1.datafieldSize = BYTES_IN_MB;
#endif
	MCAN_SetRxFifo1Config(IZI_CAN_MCAN, &rxFifo1);
#endif

	/* TX buffer config. */
	memset(&txBuffer, 0, sizeof(txBuffer));
	txBuffer.address       = TX_BUFFER_OFS;
	txBuffer.dedicatedSize = TX_BUFFER_AMOUNT;
	txBuffer.fqSize        = 0;
	txBuffer.datafieldSize = kMCAN_8ByteDatafield;
#if (defined(USE_CANFD) && USE_CANFD)
	txBuffer.datafieldSize = BYTES_IN_MB;
#endif
	MCAN_SetTxBufferConfig(IZI_CAN_MCAN, &txBuffer);

	izi_can_err.all = 0;

	rxFrame.size = MAX_LENGTH_SINGLE;
	rxXfer.frame = &rxFrame;
	MCAN_TransferReceiveFifoNonBlocking(IZI_CAN_MCAN, 0, &mcanHandle, &rxXfer);			// Start receiving via fifo

	/* Finish software initialization and enter normal mode, synchronizes to
	   CAN bus, ready for communication */
	MCAN_EnterNormalMode(IZI_CAN_MCAN);
	izi_can_init = true;
	izican_req_timeout = IZICAN_REQ_TO;
}

/**
 * Check for multiframe timouts and free buffers
 */
void izican_multi_cleanup()
{
	uint8_t i;
	TickType_t ticks = xTaskGetTickCount();

	for(i = 0; i < IZICAN_MULTI_BUFFERS; i++)			// Cleanup unfinished multiframes
	{
		if(izi_can_rxframe_multi[i].state > 0)
		{
			if(ticks - izi_can_rxframe_multi[i].ticks > pdMS_TO_TICKS(IZI_CAN_MULTI_TIMEOUT))
			{
				izi_can_extid_u extid;
				extid.all = izi_can_rxframe_multi[i].id;
				IZI_CAN_TRACE_ERROR("Multi message timeout %d, cmd: %d\r\n", i, extid.bit.command);
				izi_can_rxframe_multi[i].state = IZI_CAN_MULTISTATE_IDLE;
			}
		}
	}
}

/************************************************************************/
/* IZI task														        */
/************************************************************************/
static void izican_task(void *p)
{
	(void)p;

	izican_driver_reset();

	while(1)
	{
		if(izi_can_err.flags.bus_err || izi_can_err.flags.unhandled_int)
		{
			izi_can_init = false;								// Don't sent any more, will make the driver crash
			izican_busoff = true;
			if(izican_busoff_retry < 5)							// Max 5 seconds back off
				izican_busoff_retry++;
			//MCAN_Deinit(IZI_CAN_MCAN);
			vTaskDelay(1000 * (uint32_t)izican_busoff_retry);
			izican_driver_reset();
			if(izican_busoff_retry == 1)
			{
				IZI_CAN_TRACE_ERROR("Re-init IZI can\r\n");				// First bus off
#if IZI_CAN_MASTER == 1
				LOGWRITE_WARNING(ERRCODE_CAN_BUS_OFF, "CAN bus error (bus off)", log_src_task_postpone);
#endif
			}
			else
			{
				IZI_CAN_TRACE_DEBUG("Re-init IZI can retry %d\r\n", izican_busoff_retry);				// Second or later (only log when debug is on)
			}
			izi_can_err.flags.bus_err = 0;
			izi_can_err.flags.unhandled_int = 0;
		}
		if(izi_can_err.flags.fifo_full)
		{
			IZI_CAN_TRACE_ERROR("Fifo overflow\r\n");				// Todo: what to do
			izi_can_err.flags.fifo_full = 0;
		}
		if(izi_can_err.flags.fifo_lost)
		{
			IZI_CAN_TRACE_ERROR("Fifo lost\r\n");				// Todo: what to do
			izi_can_err.flags.fifo_lost = 0;
		}

		/* Receive the next message from the message buffer.  Wait in the Blocked
		state (so not using any CPU processing time) for a maximum of 100ms for
		a message to become available. */
		size_t xReceivedBytes = xMessageBufferReceive( izi_can_msgbfrhandle,
												( void * ) &izi_can_receive_process,
												sizeof( izi_can_receive_process ),
												pdMS_TO_TICKS(100));

		izican_multi_cleanup();				// Check for timeouts
		if(xReceivedBytes > 0)
		{
			bool report_message = true;
			if(izi_can_receive_process.flags.xtd)			// command frame = 29-bit
			{
				izi_can_extid_u extid;
				extid.all = izi_can_receive_process.id;

				if(extid.bit.total > 0)							// Multiframe message
				{
					uint8_t i;

					report_message = false;						// Only report when complete
					if(extid.bit.index == 0)
					{
						// Search a free buffer
						for(i = 0; i < IZICAN_MULTI_BUFFERS; i++)
						{
							if(izi_can_rxframe_multi[i].state == IZI_CAN_MULTISTATE_IDLE)
								break;					// Free buffer found
						}
						if(izi_can_receive_process.length != MAX_LENGTH_SINGLE)	// First frame should always have 64 bytes
						{
							IZI_CAN_TRACE_WARNING("Message multi incorrect length for first frame: %d\r\n", izi_can_receive_process.length);
						}
						else if(i < IZICAN_MULTI_BUFFERS)
						{
							memcpy(&izi_can_rxframe_multi[i], &izi_can_receive_process, sizeof(izi_can_receive_process) - (3 * MAX_LENGTH_SINGLE));		// Copy first part
							izi_can_rxframe_multi[i].ticks = izi_can_receive_process.ticks;
							izi_can_rxframe_multi[i].state |= 0x01;			// First is in
						}
						else
						{
							IZI_CAN_TRACE_ERROR("Multi message overflow\r\n");
						}
					}
					else
					{
						for(i = 0; i < IZICAN_MULTI_BUFFERS; i++)
						{
							if(izi_can_rxframe_multi[i].state > 0)
							{
								izi_can_extid_u cmp_extid;
								cmp_extid.all = izi_can_rxframe_multi[i].id;

								izi_can_extid_u mask_extid;
								mask_extid.all = 0x1FFFFFFF;
								mask_extid.bit.index = 0;

								if((extid.all & mask_extid.all) == cmp_extid.all)
								{
									if(extid.bit.index != extid.bit.total && izi_can_receive_process.length != MAX_LENGTH_SINGLE)	// When not last frame, messages should always have 64 bytes
									{
										IZI_CAN_TRACE_WARNING("Message multi incorrect length for non end frame: %d\r\n", izi_can_receive_process.length);
									}

									memcpy(izi_can_rxframe_multi[i].data + (extid.bit.index * MAX_LENGTH_SINGLE), izi_can_receive_process.data, MAX_LENGTH_SINGLE);		// Copy data
									izi_can_rxframe_multi[i].state |= (0x01 << extid.bit.index);			// Set flag for received part
									izi_can_rxframe_multi[i].length += izi_can_receive_process.length;

									const uint8_t total[4] = { 1, 3, 7, 15 };
									if(izi_can_rxframe_multi[i].state == total[extid.bit.total])
									{
										IZI_CAN_TRACE_DEBUG("Message multi complete with length: %d, cmd: %d\r\n", izi_can_rxframe_multi[i].length, extid.bit.command);
										izican_process_rx(&izi_can_rxframe_multi[i]);

										izi_can_rxframe_multi[i].state = IZI_CAN_MULTISTATE_IDLE;
									}

									break;
								}
							}
						}
						if(i >= IZICAN_MULTI_BUFFERS)
						{
							IZI_CAN_TRACE_WARNING("Message multi index %d before index 0\r\n", extid.bit.index);
						}
					}
				}
			}

			if(report_message)
			{
				//TickType_t ticks = xTaskGetTickCount();
				//IZI_CAN_TRACE_WARNING("Can handling speed: %d ms\r\n",ticks - izi_can_receive_process.ticks);

				izican_process_rx(&izi_can_receive_process);
			}

			if(izi_can_receive_process.flags.xtd)
			{
				if(report_message)
				{
					IZI_CAN_TRACE_DEBUG("Message received ext r: 0x%x len: %d, data[0]: %d, ticks: %d %d\r\n", izi_can_receive_process.id, izi_can_receive_process.length, izi_can_receive_process.data[0], izi_can_receive_process.ticks, xTaskGetTickCount());
				}
				else
				{
					IZI_CAN_TRACE_DEBUG("Message received ext n: 0x%x len: %d, data[0]: %d, ticks: %d\r\n", izi_can_receive_process.id, izi_can_receive_process.length, izi_can_receive_process.data[0], izi_can_receive_process.ticks, xTaskGetTickCount());
				}
			}
			else
			{
				IZI_CAN_TRACE_DEBUG("Message received std: 0x%x len: %d, data[0]: %d\r\n", izi_can_receive_process.id >> STDID_OFFSET, izi_can_receive_process.length, izi_can_receive_process.data[0]);
			}

			if(izican_busoff && izican_busoff_retry == 0)
			{
				IZI_CAN_TRACE_INFO("IZI-Can bus OK\r\n");
				izican_busoff = false;

#if IZI_CAN_MASTER == 1
				LOGWRITE_INFO(ERRCODE_CAN_BUS_OK, "CAN bus OK", log_src_task_postpone);
#endif
			}
		}
#if IZI_CAN_MASTER == 1
		REPORT_STACK(TASK_IZICAN_MASTER_STACK_SIZE, TASK_CANDRIVER);
#endif
	}
}

bool izican_bus_ok()
{
	return !izican_busoff;
}

void izican_process_rx(izi_can_rxframe_t *frame)
{
	izi_can_extid_u extid;
	extid.all = frame->id;
	if(rsp_data != NULL)
	{
		izi_can_extid_u extid_mask = { .bit.master_id = 1, .bit.devtype_group = 0x0F, .bit.seq_id = 0x07, .bit.command = 0xFF };
		if(extid.bit.msg_type == IZI_CAN_MSGTYPE_RSP)
		{
			if(((extid.all & extid_mask.all) == (rsp_extid.all & extid_mask.all)) && ((rsp_extid.bit.address == ADDRESS_WILDCARD) || (extid.bit.address == rsp_extid.bit.address)))		// Also accept wildcard for assign command
			{
				uint16_t length = frame->length > sizeof(izican_response_data_t) ? sizeof(izican_response_data_t) : frame->length;
				memcpy(rsp_data, frame->data, length);
				if(xIziCan_Semaphore != NULL)
				{
					IZI_CAN_TRACE_DEBUG("IZI can post %d\r\n", xTaskGetTickCount());
					xSemaphoreGive(xIziCan_Semaphore);
				}
			}
			else
			{
				IZI_CAN_TRACE_INFO("IZI can process no match, ticks: %d\r\n", xTaskGetTickCount());
			}
			//rsp_data = NULL;
			return;			// Even if not expected, ignore response (no callback)
		}
	}
	else if(extid.bit.msg_type == IZI_CAN_MSGTYPE_RSP)
	{
		IZI_CAN_TRACE_DEBUG("IZI can process no rsp, ticks: %d\r\n", xTaskGetTickCount());
	}

	if(izi_can_receive_callback != NULL)
		izi_can_receive_callback(frame);
}

void izican_set_slave_address(uint8_t address)
{
	if(address != izi_can_address)
	{
		izi_can_address = address;
		izi_can_init = false;								// Don't sent any more, will make the driver crash
		MCAN_Deinit(IZI_CAN_MCAN);
		izican_driver_reset();
	}
}

/**
 * Set receive callback, called from task, not from interrupt
 */
void izican_set_callback(izi_can_receive_callback_t cb)
{
	izi_can_receive_callback = cb;
}

/**
 * Set receive callback, called from interrupt, if function returns true, the message will not be handled further
 */
void izican_set_int_callback(izi_can_receive_int_callback_t cb)
{
	izi_can_receive_int_callback = cb;
}



/************************************************************************/
/* Start the IZI task and init uart								        */
/************************************************************************/
void izican_driver_init(uint8_t address)
{
	/* Set MCAN clock Make 20MHz. */
	CLOCK_SetClkDiv(IZI_CAN_CLOCK, IZI_CAN_CLOCK_DIV, true);

	izi_can_receive_callback = NULL;
	izi_can_receive_int_callback = NULL;
	rsp_data = NULL;

	uint8_t i;
	for(i = 0; i < IZICAN_MULTI_BUFFERS; i++)
		izi_can_rxframe_multi[i].state = IZI_CAN_MULTISTATE_IDLE;

#if IZI_CAN_MASTER > 0
	izi_can_address = address;		// Todo: support master id 1
#else
	izi_can_address = address;
#endif

#if IZI_CAN_STATICPOOL == 1
	izi_can_msgbfrhandle = xMessageBufferCreateStatic( IZICAN_MSGPOOL_SIZE,
		izi_can_msgpool,
		&izi_can_msgbuffer );
#else
	izi_can_msgbfrhandle = xMessageBufferCreate(IZICAN_MSGPOOL_SIZE);
#endif

	xIziCan_Semaphore = xSemaphoreCreateBinary();

#if IZI_CAN_MASTER > 0
	if (xTaskCreate(izican_task, "IziCan", TASK_IZICAN_MASTER_STACK_SIZE, NULL, TASK_IZICAN_TASK_PRIORITY, &xIziCan_Task) != pdPASS) {
#else
	if (xTaskCreate(izican_task, "IziCan", TASK_IZICAN_STACK_SIZE, NULL, TASK_IZICAN_TASK_PRIORITY, &xIziCan_Task) != pdPASS) {
#endif
		while (1) {
			;
		}
	}
}

/**
 * Debug handling
 */
void izican_debug(uint8_t *data, uint8_t length)
{
	if(data[0] == 't' && length >= 2)
	{
		izi_can_trace_lvl = data[1] - '0';
		IZI_CAN_TRACE_ERROR("Trace level: %d\r\n", izi_can_trace_lvl);
	}
	else if(data[0] == 'i' && length >= 1)
	{
		izi_can_init = false;								// Don't sent any more, will make the driver crash
		//MCAN_Deinit(IZI_CAN_MCAN);
		//vTaskDelay(5);
		izican_driver_reset();
		IZI_CAN_TRACE_ERROR("Re-init IZI can\r\n");
	}
	/*else if(data[0] == 's' && length >= 2)
	{
		if(data[1] == '0')
		{
			GPIO_PinWrite(BOARD_INITPINS_CAN_STB_GPIO, BOARD_INITPINS_CAN_STB_PORT, BOARD_INITPINS_CAN_STB_PIN, 1);
			IZI_CAN_TRACE_ERROR("Standby on\r\n");
		}
		else
		{
			GPIO_PinWrite(BOARD_INITPINS_CAN_STB_GPIO, BOARD_INITPINS_CAN_STB_PORT, BOARD_INITPINS_CAN_STB_PIN, 0);
			IZI_CAN_TRACE_ERROR("Standby off\r\n");
		}
	}*/
#if	IZI_CAN_MASTER > 0
	else if(data[0] == 's' && length >= 2)
	{
		uint16_t i, a;
		status_t s;

		a = data[1] - '0';
		if(a > 0 && a <= 9)
		{
			uint8_t chan_data[512];
			memset(chan_data, 0, sizeof(chan_data));
			for (i = 0; i < ((a - 1) * 64); i++)
				chan_data[i] = i + (a - 1);

			chan_data[0] = numMessage++;
			s = izican_senddmx(0, chan_data, sizeof(chan_data));

			IZI_CAN_TRACE_ERROR("Send channels: %d, stat: %d, data[0]: %d\r\n", i, s, chan_data[0]);
		}
	}
#endif
	else if(data[0] == 'e' && length >= 2)
	{
		uint16_t i, a;
		status_t s;

		a = data[1] - '0';
		if(a <= 9)
		{
			uint8_t tx_data[MAX_LENGTH_MULTI];

			for (i = 0; i < sizeof(tx_data); i++)
				tx_data[i] = i;

			for(i = 0; i < a; i++)
			{
#if	IZI_CAN_MASTER > 0
				s = izican_sendcommand(1, SLAVE_DEVTYPE_GROUP, IZI_CAN_CMD_DISCOVER, IZI_CAN_MSGTYPE_REQ, tx_data, 64, IZI_CAN_SEQ_AUTO);
#else
				s = izican_sendcommand(izi_can_address, SLAVE_DEVTYPE_GROUP, IZI_CAN_CMD_DISCOVER, IZI_CAN_MSGTYPE_RSP, tx_data, 64, IZI_CAN_SEQ_AUTO);
#endif
				tx_data[0] = numMessage++;

				IZI_CAN_TRACE_ERROR("Send command: %d, stat: %d, data[0]: %d\r\n", i, s, tx_data[0]);
			}
		}
	}
	else if(data[0] == 'f' && length >= 2)
	{
		uint16_t i, a;
		int8_t s;

		a = data[1] - '0';
		if(a > 0 && a <= 9)
		{
			uint8_t tx_data[MAX_LENGTH_MULTI];

			for (i = 0; i < sizeof(tx_data); i++)
				tx_data[i] = i;

			for(i = 0; i < a; i++)
			{
#if	IZI_CAN_MASTER > 0
				s = izican_sendcommand(ADDRESS_GROUPCAST, SLAVE_DEVTYPE_GROUP, IZI_CAN_CMD_DISCOVER, IZI_CAN_MSGTYPE_REQ, tx_data, (i * 32), IZI_CAN_SEQ_AUTO);
#else
				s = izican_sendcommand(izi_can_address, SLAVE_DEVTYPE_GROUP, IZI_CAN_CMD_DISCOVER + i, IZI_CAN_MSGTYPE_RSP, tx_data, (i * 32), IZI_CAN_SEQ_AUTO);
#endif
				tx_data[0] = numMessage++;

				IZI_CAN_TRACE_ERROR("Send command: %d, stat: %d, data[0]: %d\r\n", i, s, tx_data[0]);
			}
		}
	}
}

/**
 * Calculate best fitting length
 */
uint8_t izican_getdlc(uint8_t length)
{
	int8_t i;

	if(length <= 8)
		return length;

	for(i = sizeof(fd_len) - 1; i >= 0; i--)
	{
		if(length > fd_len[i])
			return i + 1;
	}
	return 0;
}

#if	IZI_CAN_MASTER > 0
/**
 * Send dmx frames and check for compression when sending 0
 * par len must be multiple of 64!
 */
int8_t izican_senddmx(uint8_t universe, uint8_t *data, uint16_t length)
{
	int i, msg_amount, r, z;
	mcan_tx_buffer_frame_t txFrameStd;
	mcan_buffer_transfer_t txXferStd;

	if(!izi_can_init)
		return IZI_CAN_ERR_NOINIT;

	uint8_t zero[MAX_LENGTH_CHANNEL/MAX_LENGTH_SINGLE];
	memset(zero, 0, sizeof(zero));

	if(length > MAX_LENGTH_CHANNEL || length == 0 || (length % MAX_LENGTH_SINGLE) != 0)
		return IZI_CAN_ERR_LENGTH;

	if(universe >= MAX_CAN_UNIVERSES)
		return IZI_CAN_ERR_DATA;

	msg_amount = (((length - 1) / MAX_LENGTH_SINGLE) + 1);

	for(i = 1; i < msg_amount; i++)					// Check for all 0 single frames, first frame will always be send
	{
		for(r = 0; r < MAX_LENGTH_SINGLE; r++)
		{
			if(data[(i * MAX_LENGTH_SINGLE) + r] > 0)
			{
				zero[i] = 1;						// 1 = has data
				break;
			}
		}
	}

	txFrameStd.xtd  = kMCAN_FrameIDStandard;
	txFrameStd.rtr  = kMCAN_FrameTypeData;
	txFrameStd.fdf = 1;
	txFrameStd.brs = 1;

	izi_can_stdid_u stdid = { .all = 0 };
	stdid.bit.seq_id = izi_can_chan_seqid++;
	stdid.bit.universe = universe;

	for(i = 0; i < msg_amount; i++)
	{
		if(i > 0 && zero[i] == 0)			// Always send first
			continue;						// Should already be reported not to send

		stdid.bit.start_channel = i;
		stdid.bit.sector0 = 0;

		txFrameStd.dlc = izican_getdlc(MAX_LENGTH_SINGLE);
		txFrameStd.size = MAX_LENGTH_SINGLE;
		txFrameStd.data = data + (i * MAX_LENGTH_SINGLE);

		for(z = i + 1; z < msg_amount; z++)
		{
			if(zero[z])
				break;
			stdid.bit.sector0++;			// Block of 64 bytes that do not have to be send, but should be set to 0
		}
		txFrameStd.id   = stdid.all << STDID_OFFSET;

		int idx = -1;
		for(r = 0; r < 3; r++)		// Wait max 2 * 5ms for free buffer
		{
			idx = MCAN_TransferFreeIndex(IZI_CAN_MCAN, FIRST_STD_TX_BUFFER, MAX_STD_TX_BUFFER, msg_amount - i);
			if(idx >= 0)
				break;
			vTaskDelay(5);		// Wait 5 ms to check again for a free buffer
		}
		if(idx < 0)
			return IZI_CAN_ERR_NO_TXBFR;

		txXferStd.bufferIdx = (uint8_t)idx;
		txXferStd.frame     = &txFrameStd;

		status_t s;
		s = MCAN_TransferSendNonBlocking(IZI_CAN_MCAN, &mcanHandle, &txXferStd);
		IZI_CAN_TRACE_VERBOSE("IZI can chan[%d, %d]: %d, id: %08x, data[0]: %d (clr: %d)\r\n", i, idx, s, txFrameStd.id >> STDID_OFFSET, txFrameStd.data[0], stdid.bit.sector0);

		if(s != kStatus_Success)
			return IZI_CAN_ERR_TX_ERR;
	}
	return IZI_CAN_OK;
}
#endif

#if (defined(USE_CANFD) && USE_CANFD)

/**
 * Extend timeout for single time
 */
void izican_extended_timeout(uint32_t to)
{
	if(to >= IZICAN_REQ_TO && (to < (20*IZICAN_REQ_TO)))
		izican_req_timeout = to;
	else
		izican_req_timeout = IZICAN_REQ_TO;
}

/**
 * Send request and try 3 times to get response (max 450ms)
 */
int8_t izican_sendcommand_req(uint8_t address, uint8_t devtype_group, uint8_t cmd, uint8_t *data, uint16_t length, izican_response_data_t *rsp)
{
	uint8_t retry = 0;
	int8_t res;
	for(retry = 0; retry < IZI_CAN_MAX_REQ_RETRY; retry++)
	{
		res = izican_sendcommand(address, devtype_group, cmd, IZI_CAN_MSGTYPE_REQ, data, length, IZI_CAN_SEQ_AUTO);
		if(res >= 0)
		{
			rsp_extid.all = req_extid.all;
			rsp_data = rsp;
			xQueueReset(xIziCan_Semaphore);
			if(xSemaphoreTake(xIziCan_Semaphore, izican_req_timeout) != pdTRUE)
			{
				IZI_CAN_TRACE_INFO("IZI can response too late %d attempt, ticks: %d (a: 0x%x, cmd: 0x%x, gr: 0x%x)\r\n", retry + 1, xTaskGetTickCount(), address, cmd, devtype_group);
				res = IZI_CAN_ERR_NORSP;
			}
			else
				break;				// Received response break retry loop
		}
	}
	izican_req_timeout = IZICAN_REQ_TO;
	rsp_data = NULL;
	return res;
}

/**
 * Send command
 * Use IZI_CAN_SEQ_AUTO for seq_id if new is wanted
 */
int8_t izican_sendcommand(uint8_t address, uint8_t devtype_group, uint8_t cmd, uint8_t msg_type, uint8_t *data, uint16_t length, uint8_t seq_id)
{
	if(!izi_can_init)
		return IZI_CAN_ERR_NOINIT;
	if(length > MAX_LENGTH_MULTI)
		return IZI_CAN_ERR_LENGTH;

	mcan_tx_buffer_frame_t txFrameExt;
	mcan_buffer_transfer_t txXferExt;
	int i, msg_amount, r;

	txFrameExt.xtd  = kMCAN_FrameIDExtend;
	txFrameExt.rtr  = kMCAN_FrameTypeData;
	txFrameExt.fdf = 1;
	txFrameExt.brs = 1;

	izi_can_extid_u extid = { .all = 0 };
#if	IZI_CAN_MASTER > 0
	extid.bit.dir = DIRECTION_TO_SLAVE;
#else
	extid.bit.dir = DIRECTION_FROM_SLAVE;
#endif

	msg_amount = length > 0 ? (((length - 1) / MAX_LENGTH_SINGLE) + 1) : 1;
	if(seq_id == IZI_CAN_SEQ_AUTO)
		extid.bit.seq_id = izi_can_seqid++;
	else
		extid.bit.seq_id = seq_id;
	extid.bit.address = address;
	extid.bit.devtype_group = devtype_group;
	extid.bit.msg_type = msg_type;
	extid.bit.command = cmd;
	extid.bit.total = msg_amount - 1;
	extid.bit.index = 0;

	if(msg_type == IZI_CAN_MSGTYPE_REQ)
		req_extid.all = extid.all;

	for(i = 0; i < msg_amount; i++)
	{
		uint8_t mlen = length > MAX_LENGTH_SINGLE ? MAX_LENGTH_SINGLE : length;
		txFrameExt.dlc = izican_getdlc(mlen);
		txFrameExt.size = mlen;
		txFrameExt.data = data + (i * MAX_LENGTH_SINGLE);
		txFrameExt.id   = extid.all;

		int idx = -1;
		for(r = 0; r < 9; r++)		// Wait max 8 * 5ms for free buffer
		{
			idx = MCAN_TransferFreeIndex(IZI_CAN_MCAN, FIRST_EXT_TX_BUFFER, MAX_EXT_TX_BUFFER, msg_amount - i);
			if(idx >= 0)
				break;
			vTaskDelay(5);		// Wait 5 ms to check again for a free buffer
		}
		if(idx < 0)
			return IZI_CAN_ERR_NO_TXBFR;

		txXferExt.bufferIdx = (uint8_t)idx;
		txXferExt.frame     = &txFrameExt;

		status_t s;
		s = MCAN_TransferSendNonBlocking(IZI_CAN_MCAN, &mcanHandle, &txXferExt);
		IZI_CAN_TRACE_DEBUG("IZI can cmd[%d, %d]: %d, id: %08x, data[0]: %d\r\n", i, idx, s, txFrameExt.id, txFrameExt.data[0]);

		if(s != kStatus_Success)
			return IZI_CAN_ERR_TX_ERR;

		extid.bit.index++;
		length -= MAX_LENGTH_SINGLE;
	}
	return IZI_CAN_OK;
}
#endif
