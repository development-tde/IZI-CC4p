/*
 * includes.h
 *
 * Created: 12-8-2021 21:30:05
 *  Author: Milo
 */ 


#ifndef INCLUDES_H_
#define INCLUDES_H_

#include "atmel_start_pins.h"

#ifdef __cplusplus
extern "C" {
#endif

#include <hal_atomic.h>
#include <hal_delay.h>
#include <hal_gpio.h>
#include <hal_init.h>
#include <hal_io.h>
#include <hal_sleep.h>
#include <peripheral_clk_config.h>
#include "compiler.h"
#include <hal_can_async.h>
#include "string.h"

#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "stack_macros.h"
#include "message_buffer.h"
#include "semphr.h"
#include "utils.h"

typedef enum trace_level_e
{
	TRACE_LEVEL_ERROR	= 0,
	TRACE_LEVEL_WARNING = 1,
	TRACE_LEVEL_INFO = 2,
	TRACE_LEVEL_DEBUG = 3,
	TRACE_LEVEL_VERBOSE = 4,
}trace_level_t;

typedef enum os_report_task_e
{
	TASK_NETWORK	= 0,
	TASK_CANMASTER 	= 1,
	TASK_USBHOST 	= 2,
	TASK_LOCAL_TCP  = 3,
	TASK_DMXIN		= 4,
	TASK_CANDRIVER	= 5,
	TASK_USB_VCOM	= 6,
	TASK_LOGGER		= 7,
	TASK_LOCAL_TCP1 = 8,
	TASK_LOCAL_TCP2 = 9,
	TASK_LOCAL_TCP3 = 10,
	TASK_IZI_TOPIC =  11,
	TASK_OS_TIMER  =  12,
	TASK_OS_IDLE   =  13,
	TASK_DALI	   =  14,
	TASK_HTTP	   =  15,
	TASK_HTTP_SESSION   =  16,
	TASK_SEQUENCE   =  17,
	TASK_SEQUENCE2   =  18,
	TASK_FILESYSTEM   =  19,
	TASK_SEQUENCE3   =  20,
	TASK_SEQUENCE4   =  21,
	TASK_OUTPUT	   =  22,
	// When added, adjust OS_REPORT_ALLTASKS
	// Max 32
}os_report_task_t;


#endif /* INCLUDES_H_ */