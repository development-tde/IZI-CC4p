#include <atmel_start.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	izican_driver_init(2);
	
	FREERTOS_V1000_0_example();
	/* Replace with your application code */
	while (1) {
		// Should not get here
	}
}
